// SPDX-License-Identifier: GPL-2.0
/* Copyright (C) 2018-2019, Intel Corporation. */

#include "ice.h"
#include "ice_lib.h"

//#define IVDM_CONFIG_SPACE_SIZE  0xff
//#define IVDM_CONFIG_SPACE_SIZE  4096
#define IVDM_CONFIG_SPACE_SIZE  256
#define IVDM_BAR0_SIZE  0x200000
#define IVDM_MAX_MMIO_SPACE_SIZE 8192
#define VIDXD_MAX_MSIX_VECS		5

#define STORE_LE16(addr, val)   (*(u16 *)addr = val)
#define STORE_LE32(addr, val)   (*(u32 *)addr = val)

#define IVDM_VFIO_PCI_OFFSET_SHIFT   40

#define IVDM_VFIO_PCI_OFFSET_TO_INDEX(off)   (off >> IVDM_VFIO_PCI_OFFSET_SHIFT)
#define IVDM_VFIO_PCI_INDEX_TO_OFFSET(index) \
				((u64)(index) << IVDM_VFIO_PCI_OFFSET_SHIFT)
#define IVDM_VFIO_PCI_OFFSET_MASK    \
				(((u64)(1) << IVDM_VFIO_PCI_OFFSET_SHIFT) - 1)
struct ice_vdcm_irq_ctx {
	struct eventfd_ctx *trigger;
	char *name;
};

struct ice_vdcm {
	struct pci_dev *pdev;
	struct mdev_device *mdev;
	struct ice_pf *pf;
	u8 *vconfig;
	u8 *bar0;
	u32 id;
	u32 bar_mask[VFIO_PCI_NUM_REGIONS];

	u32 pasid;
	u8 pasid_en;
	struct ice_vsi * vsi;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,11,0)
	struct vfio_group *vfio_group;
#endif
	struct ice_vdcm_irq_ctx ctx[17];
};

static int ice_vdcm_get_irq_count(struct ice_vdcm *ivdm, int type)
{
	//struct vfio_pci_device *vdev = &vidxd->idxd->vdev;

	/*
	 * Even though the number of MSIX vectors supported are not tied to number of
	 * wqs being exported, the current design is to allow 1 vector per WQ for guest.
	 * So here we end up with num of wqs plus 1 that handles the misc interrupts.
	 */
	if (type == VFIO_PCI_MSI_IRQ_INDEX || type == VFIO_PCI_MSIX_IRQ_INDEX) {
		return VIDXD_MAX_MSIX_VECS;
	}

	return 0;
}

static inline void ice_vdcm_reset_vconfig(struct ice_vdcm *ivdm)
{
	memset(ivdm->vconfig, 0, IVDM_CONFIG_SPACE_SIZE);
	ivdm->bar_mask[0] = ~(IVDM_BAR0_SIZE) + 1;
}

static inline void ice_vdcm_reset_vmmio(struct ice_vdcm *ivdm)
{
	memset(ivdm->bar0, 0, IVDM_MAX_MMIO_SPACE_SIZE);
}

/* Helper functions */
static void ice_vdcm_create_config_space(struct ice_vdcm *ivdm)
{
	/* PCI dev ID */
	STORE_LE32((u32 *) &ivdm->vconfig[0x0], 0x18898086);

	/* Control: I/O+, Mem-, BusMaster- */
	STORE_LE16((u16 *) &ivdm->vconfig[0x4], 0x0000);

	/* Status: capabilities list absent */
	STORE_LE16((u16 *) &ivdm->vconfig[0x6], 0x0010);

	/* Rev ID */
	ivdm->vconfig[0x8] =  0x02;

	/* programming interface class */
	ivdm->vconfig[0x9] =  0x00;

	/* Sub class : 00 */
	ivdm->vconfig[0xa] =  0x00;

	/* Base class */
	ivdm->vconfig[0xb] =  0x02;

	/* base address registers */
	/* BAR0: IO space */
	STORE_LE32((u32 *) &ivdm->vconfig[0x10], 0x0000000c);
	ivdm->bar_mask[0] = ~(IVDM_BAR0_SIZE) + 1;

	/* Subsystem ID */
	STORE_LE32((u32 *) &ivdm->vconfig[0x2c], 0x00008086);

	ivdm->vconfig[0x34] =  0x40;   /* Cap Ptr */
	ivdm->vconfig[0x3d] =  0x00;   /* interrupt pin (INTA#) */

	/* Vendor specific data */
	STORE_LE32((u64 *) &ivdm->vconfig[0x40], 0x00040011);
	STORE_LE32((u64 *) &ivdm->vconfig[0x44], 0x00000003);
	STORE_LE32((u64 *) &ivdm->vconfig[0x48], 0x00002003);
	STORE_LE32((u64 *) &ivdm->vconfig[0x4C], 0x00000700);

	ivdm->vconfig[0x60] =  0x50;
	ivdm->vconfig[0x61] =  0x43;
	ivdm->vconfig[0x62] =  0x49;
	ivdm->vconfig[0x63] =  0x20;
	ivdm->vconfig[0x64] =  0x53;
	ivdm->vconfig[0x65] =  0x65;
	ivdm->vconfig[0x66] =  0x72;
	ivdm->vconfig[0x67] =  0x69;
	ivdm->vconfig[0x68] =  0x61;
	ivdm->vconfig[0x69] =  0x6c;
	ivdm->vconfig[0x6a] =  0x2f;
	ivdm->vconfig[0x6b] =  0x55;
	ivdm->vconfig[0x6c] =  0x41;
	ivdm->vconfig[0x6d] =  0x52;
	ivdm->vconfig[0x6e] =  0x54;
}

static void handle_pci_cfg_write(struct ice_vdcm *ivdm, u32 offset,
				 u8 *buf, u32 count)
{
	u32 cfg_addr, bar_index = 0;
	u32 bar_mask;

	switch (offset) {
	case 0x04: /* device control */
		ivdm->vconfig[offset] = buf[0];
		break;
	case 0x06: /* device status */
		/* do nothing */
		break;
	case 0x3c:  /* interrupt line */
		ivdm->vconfig[0x3c] = buf[0];
		break;
	case 0x3d:
		/*
		 * Interrupt Pin is hardwired to INTA.
		 * This field is write protected by hardware
		 */
		break;
	case 0x10:  /* BAR0 */
	case 0x14:  /* BAR1 */
		if (offset == 0x10)
			bar_index = 0;
		else if (offset == 0x14)
			bar_index = 1;

		if (bar_index == 1) {
			STORE_LE32(&ivdm->vconfig[offset], 0);
			break;
		}

		cfg_addr = *(u32 *)buf;
		pr_info("BAR%d addr 0x%x\n", bar_index, cfg_addr);
		if (cfg_addr == 0xffffffff) {
			bar_mask = ivdm->bar_mask[bar_index];
			cfg_addr = (cfg_addr & bar_mask);
		}

		cfg_addr |= (ivdm->vconfig[offset] & 0xful);
		STORE_LE32(&ivdm->vconfig[offset], cfg_addr);
		break;
	case 0x18:  /* BAR2 */
	case 0x20:  /* BAR4 */
		STORE_LE32(&ivdm->vconfig[offset], 0);
		break;
	case 0x42:
		ivdm->vconfig[0x43] &= 0x3F;
		ivdm->vconfig[0x43] |= buf[1] & 0xC0;
		break;
	default:
		pr_info("PCI config write @0x%x of %d bytes not handled\n",
			offset, count);
		break;
	}
}

static void handle_traffic_irq_ctl_write(struct ice_vdcm *ivdm, int index, u32 data)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;

	q_vector = vsi->q_vectors[1 + index];
	wr32(hw, GLINT_DYN_CTL(q_vector->reg_idx), data);
}

static u32 handle_traffic_irq_ctl_read(struct ice_vdcm *ivdm, int index, u32 off)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;

	q_vector = vsi->q_vectors[1 + index];

	return rd32(hw, GLINT_DYN_CTL(q_vector->reg_idx));
}

static void handle_misc_irq_ctl_write(struct ice_vdcm *ivdm, u32 data)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;

	q_vector = vsi->q_vectors[0];
	wr32(hw, GLINT_DYN_CTL(q_vector->reg_idx), data);
}

static u32 handle_misc_irq_ctl_read(struct ice_vdcm *ivdm, u32 off)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;

	q_vector = vsi->q_vectors[0];

	return rd32(hw, GLINT_DYN_CTL(q_vector->reg_idx));
}

static void handle_misc_irq_itr_write(struct ice_vdcm *ivdm, u32 reg_off, u32 data)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	int index = reg_off / 4;

	q_vector = vsi->q_vectors[0];
	wr32(hw, GLINT_ITR(index, q_vector->reg_idx), data);
}

static u32 handle_misc_irq_itr_read(struct ice_vdcm *ivdm, u32 reg_off)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	int index = reg_off / 4;

	q_vector = vsi->q_vectors[0];
	return rd32(hw, GLINT_ITR(index, q_vector->reg_idx));
}

static void handle_traffic_irq_itr_write(struct ice_vdcm *ivdm, u32 reg_off, u32 vector_off, u32 data)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	int index = reg_off / 64;

	q_vector = vsi->q_vectors[1 + vector_off];
	wr32(hw, GLINT_ITR(index, q_vector->reg_idx), data);
}

static u32 handle_traffic_irq_itr_read(struct ice_vdcm *ivdm, u32 reg_off, u32 vector_off)
{
	struct ice_vsi *vsi = ivdm->vsi;
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	int index = reg_off / 64;

	q_vector = vsi->q_vectors[1 + vector_off];
	return rd32(hw, GLINT_ITR(index, q_vector->reg_idx));
}

static void handle_bar_write(unsigned int index, struct ice_vdcm *ivdm,
			     u32 offset, u8 *buf, u32 count)
{
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	struct ice_vsi *vsi;
	u32 data;

	vsi = ivdm->vsi;
	if (!vsi) {
		dev_err(&ivdm->pdev->dev, "%s:%d, Invalid vsi", __func__, __LINE__);
		return;
	}

	data = *(u32 *)buf;

	/* Handle data written by guest */
	switch (offset) {
	case IAVF_VDEV_ATQBAL:
		wr32(hw, VSI_MBX_ATQBAL(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ATQBAH:
		wr32(hw, VSI_MBX_ATQBAH(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ATQLEN:
		wr32(hw, VSI_MBX_ATQLEN(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ATQH:
		wr32(hw, VSI_MBX_ATQH(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ATQT:
		wr32(hw, VSI_MBX_ATQT(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ARQBAL:
		wr32(hw, VSI_MBX_ARQBAL(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ARQBAH:
		wr32(hw, VSI_MBX_ARQBAH(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ARQLEN:
		wr32(hw, VSI_MBX_ARQLEN(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ARQH:
		wr32(hw, VSI_MBX_ARQH(vsi->vsi_num), data);
		break;
	case IAVF_VDEV_ARQT:
		wr32(hw, VSI_MBX_ARQT(vsi->vsi_num), data);
		break;
	case IAVF_VFINT_DYN_CTL01:
		handle_misc_irq_ctl_write(ivdm, data);
		break;
	case IAVF_VFINT_DYN_CTLN1(0):
		handle_traffic_irq_ctl_write(ivdm, 0, data);
		break;
	case IAVF_VFINT_DYN_CTLN1(1):
		handle_traffic_irq_ctl_write(ivdm, 1, data);
		break;
	case IAVF_VFINT_DYN_CTLN1(2):
		handle_traffic_irq_ctl_write(ivdm, 2, data);
		break;
	case IAVF_VFINT_DYN_CTLN1(3):
		handle_traffic_irq_ctl_write(ivdm, 3, data);
		break;
	case IAVF_VFINT_ITR01(0):
	case IAVF_VFINT_ITR01(1):
	case IAVF_VFINT_ITR01(2):
		handle_misc_irq_itr_write(ivdm, offset - IAVF_VFINT_ITR01(0), data);
		break;
	case IAVF_VFINT_ITRN1(0, 0):
	case IAVF_VFINT_ITRN1(1, 0):
	case IAVF_VFINT_ITRN1(2, 0):
		handle_traffic_irq_itr_write(ivdm, offset - IAVF_VFINT_ITRN1(0, 0), 0, data);
		break;
	case IAVF_VDEV_QTX_TAIL(0):
		wr32(hw, QTX_COMM_DBELL_PAGE(vsi->txq_map[0]), data);
		break;
	case IAVF_VDEV_QTX_TAIL(1):
		wr32(hw, QTX_COMM_DBELL_PAGE(vsi->txq_map[1]), data);
		break;
	case IAVF_VDEV_QTX_TAIL(2):
		wr32(hw, QTX_COMM_DBELL_PAGE(vsi->txq_map[2]), data);
		break;
	case IAVF_VDEV_QTX_TAIL(3):
		wr32(hw, QTX_COMM_DBELL_PAGE(vsi->txq_map[3]), data);
		break;
	case IAVF_VDEV_QRX_TAIL(0):
		wr32(hw, QRX_TAIL_PAGE(vsi->rxq_map[0]), data);
		break;
	case IAVF_VDEV_QRX_TAIL(1):
		wr32(hw, QRX_TAIL_PAGE(vsi->rxq_map[1]), data);
		break;
	case IAVF_VDEV_QRX_TAIL(2):
		wr32(hw, QRX_TAIL_PAGE(vsi->rxq_map[2]), data);
		break;
	case IAVF_VDEV_QRX_TAIL(3):
		wr32(hw, QRX_TAIL_PAGE(vsi->rxq_map[3]), data);
		break;
	default:
		break;
	}

	dev_info(&pf->pdev->dev, "%s:%d, addr:0%x val:0x%x",
		__func__, __LINE__, offset, data);

}

static void handle_bar_read(unsigned int index, struct ice_vdcm *ivdm,
			    u32 offset, u8 *buf, u32 count)
{
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	struct ice_vsi *vsi;
	u32 *data_pointer;

	vsi = ivdm->vsi;
	if (!vsi) {
		dev_err(&ivdm->pdev->dev, "%s:%d, Invalid vsi", __func__, __LINE__);
		return;
	}

	data_pointer = (u32 *)buf;

	/* Handle read requests by guest */
	switch (offset) {
	case IAVF_VFGEN_RSTAT:
		*data_pointer = 0x01;
		break;
	case IAVF_VDEV_ATQBAL:
		*data_pointer = rd32(hw, VSI_MBX_ATQBAL(vsi->vsi_num));
		break;
	case IAVF_VDEV_ATQBAH:
		*data_pointer = rd32(hw, VSI_MBX_ATQBAH(vsi->vsi_num));
		break;
	case IAVF_VDEV_ATQLEN:
		*data_pointer = rd32(hw, VSI_MBX_ATQLEN(vsi->vsi_num));
		break;
	case IAVF_VDEV_ATQH:
		*data_pointer = rd32(hw, VSI_MBX_ATQH(vsi->vsi_num));
		break;
	case IAVF_VDEV_ATQT:
		*data_pointer = rd32(hw, VSI_MBX_ATQT(vsi->vsi_num));
		break;
	case IAVF_VDEV_ARQBAL:
		*data_pointer = rd32(hw, VSI_MBX_ARQBAL(vsi->vsi_num));
		break;
	case IAVF_VDEV_ARQBAH:
		*data_pointer = rd32(hw, VSI_MBX_ARQBAH(vsi->vsi_num));
		break;
	case IAVF_VDEV_ARQLEN:
		*data_pointer = rd32(hw, VSI_MBX_ARQLEN(vsi->vsi_num));
		break;
	case IAVF_VDEV_ARQH:
		*data_pointer = rd32(hw, VSI_MBX_ARQH(vsi->vsi_num));
		break;
	case IAVF_VDEV_ARQT:
		*data_pointer = rd32(hw, VSI_MBX_ARQT(vsi->vsi_num));
		break;
	case IAVF_VFINT_DYN_CTL01:
		*data_pointer = handle_misc_irq_ctl_read(ivdm, offset);
		break;
	case IAVF_VFINT_DYN_CTLN1(0):
		*data_pointer = handle_traffic_irq_ctl_read(ivdm, 0, offset);
		break;
	case IAVF_VFINT_ITR01(0):
	case IAVF_VFINT_ITR01(1):
	case IAVF_VFINT_ITR01(2):
		*data_pointer = handle_misc_irq_itr_read(ivdm, offset - IAVF_VFINT_ITR01(0));
		break;
	case IAVF_VFINT_ITRN1(0, 0):
	case IAVF_VFINT_ITRN1(1, 0):
	case IAVF_VFINT_ITRN1(2, 0):
		*data_pointer = handle_traffic_irq_itr_read(ivdm, offset - IAVF_VFINT_ITRN1(0, 0), 0);
		break;
	default:
		break;
	}

	dev_info(&pf->pdev->dev, "%s:%d, addr:0%x val:0x%x",
		__func__, __LINE__, offset, *data_pointer);
}

static ssize_t mdev_access(struct mdev_device *mdev, u8 *buf, size_t count,
			   loff_t pos, bool is_write)
{
	struct ice_vdcm *ivdm;
	unsigned int index;
	loff_t offset;
	int ret = 0;

	if (!mdev || !buf)
		return -EINVAL;

	ivdm = mdev_get_drvdata(mdev);
	if (!ivdm) {
		pr_err("%s ice vdcm not found\n", __func__);
		return -EINVAL;
	}

	index = IVDM_VFIO_PCI_OFFSET_TO_INDEX(pos);
	offset = pos & IVDM_VFIO_PCI_OFFSET_MASK;
	switch (index) {
	case VFIO_PCI_CONFIG_REGION_INDEX:

		if (is_write) {
			handle_pci_cfg_write(ivdm, offset, buf, count);
			pr_err("cfg write addr:0x%x, val:0x%x\n", offset, ((u32 *)buf)[0]);
		} else {
			memcpy(buf, (ivdm->vconfig + offset), count);
			pr_err("cfg read addr:0x%x, val:0x%x\n", offset, ((u32 *)buf)[0]);
		}

		break;

	case VFIO_PCI_BAR0_REGION_INDEX:
		if (is_write) {
			handle_bar_write(index, ivdm, offset, buf, count);
		} else {
			handle_bar_read(index, ivdm, offset, buf, count);
		}
		break;

	case VFIO_PCI_BAR3_REGION_INDEX:
		break;

	case VFIO_PCI_BAR1_REGION_INDEX:
	case VFIO_PCI_BAR2_REGION_INDEX:
	case VFIO_PCI_BAR4_REGION_INDEX:
	case VFIO_PCI_BAR5_REGION_INDEX:
	default:
		ret = -1;
		goto accessfailed;
	}

	ret = count;

accessfailed:
	return ret;
}

static int ice_vdcm_get_mdev_pasid(struct mdev_device *mdev)
{
	struct iommu_domain *domain;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,11,0)
	struct vfio_group *vfio_group;
	struct ice_vdcm * ivdm;
#endif
	struct device *dev = mdev_dev(mdev);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,11,0)
	vfio_group = vfio_group_get_external_user_from_dev(dev);
	if (IS_ERR_OR_NULL(vfio_group))
		return -EFAULT;

	domain = vfio_group_iommu_domain(vfio_group);
	if (IS_ERR_OR_NULL(domain)) {
		vfio_group_put_external_user(vfio_group);
		return -EFAULT;
	}

	ivdm = mdev_get_drvdata(mdev);
	ivdm->vfio_group = vfio_group;
#else
	domain = mdev_get_iommu_domain(dev);
	if (!domain)
		return -EINVAL;
#endif

	return iommu_aux_get_pasid(domain, dev->parent);
}

static int ice_vdcm_mdev_create(struct kobject *kobj, struct mdev_device *mdev)
{
	struct device *dev, *parent;
	struct ice_vdcm *ivdm;
	struct pci_dev *pdev;
	struct ice_pf *pf;
	int ret = 0;

	parent = mdev_parent_dev(mdev);
	dev = mdev_dev(mdev);
	pdev = to_pci_dev(parent);
	pf = pci_get_drvdata(pdev);

//	mutex_lock(&pf->mdev_lock);

	pf->mdev_count++;

	ivdm = kzalloc(sizeof(*ivdm), GFP_KERNEL);
	if (ivdm == NULL) {
		ret = -ENOMEM;
		goto ivdm_alloc_failure;
	}

	ivdm->pf = pf;
	ivdm->pdev = pdev;
	ivdm->mdev = mdev;
	ivdm->id = 0;
	mdev_set_drvdata(mdev, ivdm);

	ivdm->vconfig = kzalloc(IVDM_CONFIG_SPACE_SIZE, GFP_KERNEL);
	if (ivdm->vconfig == NULL) {
		ret = -ENOMEM;
		goto vconfig_alloc_failure;
	}

	ivdm->bar0 = kzalloc(IVDM_MAX_MMIO_SPACE_SIZE, GFP_KERNEL);
	if (ivdm->vconfig == NULL) {
		ret = -ENOMEM;
		goto vconfig_alloc_failure;
	}

	ice_vdcm_reset_vconfig(ivdm);
	ice_vdcm_reset_vmmio(ivdm);
	ice_vdcm_create_config_space(ivdm);

	/* only enable iommu capability when AUX is enabled */
	if (iommu_dev_feature_enabled(parent, IOMMU_DEV_FEAT_AUX)) {
		mdev_set_iommu_device(dev, parent);
		dev_info(dev, "%s:%d, add iommu capability\n",
			 __func__, __LINE__);
	}

//	mutex_unlock(&pf->mdev_lock);
	dev_info(dev, "%s:%d, succeed\n", __func__, __LINE__);
	return 0;

vconfig_alloc_failure:
	kfree(ivdm);
ivdm_alloc_failure:

	return ret;
}

static int ice_vdcm_mdev_remove(struct mdev_device *mdev)
{
	struct ice_vdcm *ivdm = mdev_get_drvdata(mdev);
	struct ice_pf *pf = ivdm->pf;

	pf->mdev_count--;

	kfree(ivdm->bar0);
	kfree(ivdm->vconfig);
	kfree(ivdm);

	return 0;
}

static ssize_t ice_vdcm_mdev_read(struct mdev_device *mdev, char __user *buf,
			 size_t count, loff_t *ppos)
{
	unsigned int done = 0;
	int ret;

	while (count) {
		size_t filled;

		if (count >= 4 && !(*ppos % 4)) {
			u32 val;

			ret =  mdev_access(mdev, (u8 *)&val, sizeof(val),
					   *ppos, false);
			if (ret <= 0)
				goto read_err;

			if (copy_to_user(buf, &val, sizeof(val)))
				goto read_err;

			filled = 4;
		} else if (count >= 2 && !(*ppos % 2)) {
			u16 val;

			ret = mdev_access(mdev, (u8 *)&val, sizeof(val),
					  *ppos, false);
			if (ret <= 0)
				goto read_err;

			if (copy_to_user(buf, &val, sizeof(val)))
				goto read_err;

			filled = 2;
		} else {
			u8 val;

			ret = mdev_access(mdev, (u8 *)&val, sizeof(val),
					  *ppos, false);
			if (ret <= 0)
				goto read_err;

			if (copy_to_user(buf, &val, sizeof(val)))
				goto read_err;

			filled = 1;
		}

		count -= filled;
		done += filled;
		*ppos += filled;
		buf += filled;
	}

	return done;

read_err:
	return -EFAULT;
}

static ssize_t ice_vdcm_mdev_write(struct mdev_device *mdev, const char __user *buf,
		   size_t count, loff_t *ppos)
{
	unsigned int done = 0;
	int ret;

	while (count) {
		size_t filled;

		if (count >= 4 && !(*ppos % 4)) {
			u32 val;

			if (copy_from_user(&val, buf, sizeof(val)))
				goto write_err;

			ret = mdev_access(mdev, (u8 *)&val, sizeof(val),
					  *ppos, true);
			if (ret <= 0)
				goto write_err;

			filled = 4;
		} else if (count >= 2 && !(*ppos % 2)) {
			u16 val;

			if (copy_from_user(&val, buf, sizeof(val)))
				goto write_err;

			ret = mdev_access(mdev, (u8 *)&val, sizeof(val),
					  *ppos, true);
			if (ret <= 0)
				goto write_err;

			filled = 2;
		} else {
			u8 val;

			if (copy_from_user(&val, buf, sizeof(val)))
				goto write_err;

			ret = mdev_access(mdev, (u8 *)&val, sizeof(val),
					  *ppos, true);
			if (ret <= 0)
				goto write_err;

			filled = 1;
		}
		count -= filled;
		done += filled;
		*ppos += filled;
		buf += filled;
	}

	return done;
write_err:
	return -EFAULT;
}

static int ice_vdcm_get_region_info(struct mdev_device *mdev,
			 struct vfio_region_info *region_info,
			 u16 *cap_type_id, void **cap_type)
{
	struct ice_vdcm *ivdm;
	unsigned int size = 0;
	u32 bar_index;

	if (!mdev)
		return -EINVAL;

	ivdm = mdev_get_drvdata(mdev);
	if (!ivdm)
		return -EINVAL;

	bar_index = region_info->index;
	if (bar_index >= VFIO_PCI_NUM_REGIONS)
		return -EINVAL;

	switch (bar_index) {
	case VFIO_PCI_CONFIG_REGION_INDEX:
		size = IVDM_CONFIG_SPACE_SIZE;
		break;
	case VFIO_PCI_BAR0_REGION_INDEX:
	case VFIO_PCI_BAR1_REGION_INDEX:
		size = IVDM_BAR0_SIZE;
		break;
	case VFIO_PCI_BAR3_REGION_INDEX:
		size = IVDM_BAR0_SIZE;
		break;
	default:
		size = 0;
		break;
	}

	region_info->size = size;
	region_info->offset = IVDM_VFIO_PCI_INDEX_TO_OFFSET(bar_index);
	region_info->flags = VFIO_REGION_INFO_FLAG_READ |
		VFIO_REGION_INFO_FLAG_WRITE;
	return 0;
}

static irqreturn_t ice_vdcm_msixhandler(int irq, void *arg)
{
	struct ice_vdcm_irq_ctx *ctx = arg;

	pr_info("%s:%d, %s\n", __func__, __LINE__, ctx->name);
	eventfd_signal(ctx->trigger, 1);
	return IRQ_HANDLED;
}

static int ice_vdcm_msix_trigger_unregister_all(struct ice_vdcm *ivdm)
{
	struct mdev_device *mdev = ivdm->mdev;
	struct device *dev = mdev_dev(mdev);
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct msix_entry *msix;
	struct ice_vsi *vsi;
	int i;

	dev_info(dev, "%s:%d", __func__, __LINE__);

	for (i = 0; i < ARRAY_SIZE(ivdm->ctx); i++) {
		/* remove all the interrupt */
		if (!ivdm->ctx[i].trigger)
			continue;

		vsi = ivdm->vsi;
		q_vector = vsi->q_vectors[i];  // use vsi q 0 vector
		msix = &pf->msix_entries[vsi->base_vector + i];
		devm_free_irq(dev, msix->vector, &ivdm->ctx[i]);

		/* put event fd */
		eventfd_ctx_put(ivdm->ctx[i].trigger);
		ivdm->ctx[i].trigger = NULL;
	}

	return 0;
}

static int
ice_vdcm_msix_set_vector_signal(struct ice_vdcm *ivdm, int vector, int fd)
{
	struct mdev_device *mdev = ivdm->mdev;
	struct device *dev = mdev_dev(mdev);
	struct ice_q_vector *q_vector;
	struct ice_pf *pf = ivdm->pf;
	struct ice_hw *hw = &pf->hw;
	struct eventfd_ctx *trigger;
	struct msix_entry *msix;
	struct ice_vsi *vsi;
	u32 reg;
	int ret;

	vsi = ivdm->vsi;
	msix = &pf->msix_entries[vsi->base_vector + vector];

	if (vector >= vsi->num_q_vectors) {
		dev_err(dev, "invalid vector number %d\n", vector);
		return -EINVAL;
	}

	if (ivdm->ctx[vector].trigger) {
		devm_free_irq(dev, msix->vector, &ivdm->ctx[vector]);

		kfree(ivdm->ctx[vector].name);
		eventfd_ctx_put(ivdm->ctx[vector].trigger);
		ivdm->ctx[vector].trigger = NULL;
	}

	if (fd < 0)
		return 0;

	trigger = eventfd_ctx_fdget(fd);
	if (IS_ERR(trigger)) {
		return PTR_ERR(trigger);
	}

	ivdm->ctx[vector].name = kasprintf(GFP_KERNEL, "vfio-msix[%d](%s)",
					   vector, dev_name(dev));
	if (!ivdm->ctx[vector].name)
		return -ENOMEM;

	ivdm->ctx[vector].trigger = trigger;

	ret = devm_request_irq(dev, msix->vector, ice_vdcm_msixhandler, 0,
			       ivdm->ctx[vector].name, &ivdm->ctx[vector]);
	if (ret) {
		eventfd_ctx_put(trigger);
		return ret;
	}

	q_vector = vsi->q_vectors[vector];  // use vsi q 0 vector
	if (vector == 0) { // mailbox vector
		/* tell mbx irq ctrl register which msix vector will it use */
		reg = ((q_vector->reg_idx << VPINT_MBX_CTL_MSIX_INDX_S) &
			VPINT_MBX_CTL_MSIX_INDX_M
		       ) | VPINT_MBX_CTL_CAUSE_ENA_M;

		wr32(hw, VPINT_MBX_CTL(vsi->vsi_num), reg);

		ice_flush(hw);
	}

	/* tell global interrupt ctrl register to enable interrupt */
	dev_info(dev, "%s:%d, vector index:%d\n", __func__, __LINE__, msix->entry);

	return 0;
}

static int
ice_vdcm_msix_set_block(struct ice_vdcm *ivdm, unsigned start,
			       unsigned count, int32_t *fds)
{
	int i, j, ret = 0;

	for (i = 0, j = start; i < count && !ret; i++, j++) {
		int fd = fds  ? fds[i] : -1;
		ret = ice_vdcm_msix_set_vector_signal(ivdm, j, fd);
	}

	if (ret) {
		for (--j; j >= (int)start; j--)
			ice_vdcm_msix_set_vector_signal(ivdm, j, -1);
	}

	return ret;
}

static int ice_vdcm_set_msix_trigger(struct ice_vdcm *ivdm, unsigned int index,
				     unsigned int start, unsigned int count,
				     uint32_t flags, void *data)
{
	struct mdev_device *mdev = ivdm->mdev;
	struct device *dev = mdev_dev(mdev);
	int ret = -EINVAL;

	if (!count && (flags & VFIO_IRQ_SET_DATA_NONE)) {
		ice_vdcm_msix_trigger_unregister_all(ivdm);
		return 0;
	}

	dev_info(dev, "%s:%d", __func__, __LINE__);
	if (flags & VFIO_IRQ_SET_DATA_EVENTFD) {
		uint32_t *fds = data;
		int ret;

		ret = ice_vdcm_msix_set_block(ivdm, start, count, fds);
		if (ret)
			ice_vdcm_msix_trigger_unregister_all(ivdm);

		return ret;
	}

	return ret;

}

static int ice_vdcm_set_irqs(struct ice_vdcm *ivdm, uint32_t flags,
			     unsigned int index, unsigned int start,
			     unsigned int count, void *data)
{
	struct mdev_device *mdev = ivdm->mdev;
	struct device *dev = mdev_dev(mdev);

	dev_info(dev, "%s:%d", __func__, __LINE__);
	switch (index) {
	case VFIO_PCI_INTX_IRQ_INDEX:
	case VFIO_PCI_MSI_IRQ_INDEX:
		dev_warn(dev, "intx & msi not supported\n");
		break;
	case VFIO_PCI_REQ_IRQ_INDEX:
		return 0;
	case VFIO_PCI_MSIX_IRQ_INDEX:
		switch (flags & VFIO_IRQ_SET_ACTION_TYPE_MASK) {
		case VFIO_IRQ_SET_ACTION_MASK:
		case VFIO_IRQ_SET_ACTION_UNMASK:
			break;
		case VFIO_IRQ_SET_ACTION_TRIGGER:
			return ice_vdcm_set_msix_trigger(ivdm, index, start, count, flags, data);
		}
		break;
	default:
		dev_warn(dev, "not supported irq index\n");
		break;
	}

	return -ENOTTY;
}

static long ice_vdcm_mdev_ioctl(struct mdev_device *mdev, unsigned int cmd,
			unsigned long arg)
{
	struct ice_vdcm *ivdm;
	unsigned long minsz;
	int ret = 0;

	if (!mdev)
		return -EINVAL;

	ivdm = mdev_get_drvdata(mdev);
	if (!ivdm)
		return -ENODEV;

	switch (cmd) {
	case VFIO_DEVICE_GET_INFO:
	{
		struct vfio_device_info info;

		minsz = offsetofend(struct vfio_device_info, num_irqs);

		if (copy_from_user(&info, (void __user *)arg, minsz))
			return -EFAULT;

		if (info.argsz < minsz)
			return -EINVAL;

		info.flags = VFIO_DEVICE_FLAGS_PCI;
		info.num_regions = VFIO_PCI_NUM_REGIONS;
		info.num_irqs = VFIO_PCI_NUM_IRQS;

		if (copy_to_user((void __user *)arg, &info, minsz))
			return -EFAULT;

		return 0;
	}
	case VFIO_DEVICE_GET_REGION_INFO:
	{
		struct vfio_region_info info;
		u16 cap_type_id = 0;
		void *cap_type = NULL;

		minsz = offsetofend(struct vfio_region_info, offset);

		if (copy_from_user(&info, (void __user *)arg, minsz))
			return -EFAULT;

		if (info.argsz < minsz)
			return -EINVAL;

		ret = ice_vdcm_get_region_info(mdev, &info, &cap_type_id,
					   &cap_type);
		if (ret)
			return ret;

		if (copy_to_user((void __user *)arg, &info, minsz))
			return -EFAULT;

		return 0;
	}

	case VFIO_DEVICE_GET_IRQ_INFO:
	{
		struct vfio_irq_info info;

		minsz = offsetofend(struct vfio_irq_info, count);

		if (copy_from_user(&info, (void __user *)arg, minsz))
			return -EFAULT;

		if ((info.argsz < minsz) ||
		    (info.index >= VFIO_PCI_NUM_IRQS))
			return -EINVAL;

		info.flags = VFIO_IRQ_INFO_EVENTFD;

		switch (info.index) {
		case VFIO_PCI_MSI_IRQ_INDEX ... VFIO_PCI_MSIX_IRQ_INDEX:
		case VFIO_PCI_REQ_IRQ_INDEX:
			info.flags |= VFIO_IRQ_INFO_NORESIZE;
			break;
		case VFIO_PCI_ERR_IRQ_INDEX:
			info.flags |= VFIO_IRQ_INFO_NORESIZE;
			break;
		default:
			return -EINVAL;
		} /* switch(info.index) */

		info.count = ice_vdcm_get_irq_count(ivdm, info.index);

		if (copy_to_user((void __user *)arg, &info, minsz))
			return -EFAULT;

		return 0;
	}
	case VFIO_DEVICE_SET_IRQS:
	{
		struct vfio_irq_set hdr;
		u8 *data = NULL, *ptr = NULL;
		size_t data_size = 0;

		minsz = offsetofend(struct vfio_irq_set, count);

		if (copy_from_user(&hdr, (void __user *)arg, minsz))
			return -EFAULT;

		ret = vfio_set_irqs_validate_and_prepare(&hdr,
						VFIO_PCI_NUM_IRQS,
						VFIO_PCI_NUM_IRQS,
						&data_size);
		if (ret)
			return ret;

		if (data_size) {
			ptr = data = memdup_user((void __user *)(arg + minsz),
						 data_size);
			if (IS_ERR(data))
				return PTR_ERR(data);
		}

		ret = ice_vdcm_set_irqs(ivdm, hdr.flags, hdr.index, hdr.start, hdr.count, data);
		kfree(ptr);
		return ret;
	}
	case VFIO_DEVICE_RESET:
		return 0;
	}
	return -ENOTTY;
}

static int ice_vdcm_mdev_open(struct mdev_device *mdev)
{
	struct ice_vdcm *ivdm = mdev_get_drvdata(mdev);
	struct pci_dev *pdev = ivdm->pdev;
	struct device *dev = &pdev->dev;
	struct ice_adi *adi;
	struct ice_pf *pf;

	/* only enable iommu capability when AUX is enabled */
	if (iommu_dev_feature_enabled(dev, IOMMU_DEV_FEAT_AUX)) {
		ivdm->pasid_en = 1;
		ivdm->pasid = ice_vdcm_get_mdev_pasid(mdev);
		dev_info(dev, "%s:%d, get pasid 0x%x\n",
			 __func__, __LINE__, ivdm->pasid);

		ivdm->vsi = ice_adi_vsi_setup(ivdm->pf, ivdm->pasid);
		if (!ivdm->vsi) {
			dev_err(dev, "SIOV: alloc_vsi failed\n");
			return -EINVAL;
		}
		adi = kzalloc(sizeof(*adi), GFP_KERNEL);
		if (adi == NULL) {
			dev_err(dev, "SIOV: alloc_vsi failed\n");
			return -ENOMEM;
		}
		pf = ivdm->vsi->back;
		adi->vsi_num = ivdm->vsi->vsi_num;
		adi->pf = pf;
		list_add_tail(&adi->node, &pf->adi_list);
	} else {
		ivdm->vsi = ice_adi_vsi_setup(ivdm->pf, ivdm->pasid);
		if (!ivdm->vsi) {
			dev_err(dev, "SIOV: alloc_vsi failed\n");
			return -EINVAL;
		}
	}

	pr_info("ivdm:%p, pdev:%p, dev:%p", ivdm, pdev, dev);
	dev_info(dev, "%s:%d\n", __func__, __LINE__);
	return 0;
}

static void ice_vdcm_mdev_close(struct mdev_device *mdev)
{
	struct ice_vdcm *ivdm = mdev_get_drvdata(mdev);
	struct ice_pf *pf = ivdm->vsi->back;
	struct pci_dev *pdev = ivdm->pdev;
	struct device *dev = &pdev->dev;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,11,0)
	if (iommu_dev_feature_enabled(dev, IOMMU_DEV_FEAT_AUX))
		vfio_group_put_external_user(ivdm->vfio_group);
#endif

	ice_free_adi(pf, ivdm->vsi->vsi_num);
	dev_info(dev, "%s:%d\n", __func__, __LINE__);
}

static ssize_t
name_show(struct kobject *kobj, struct device *dev, char *buf)
{
	return sprintf(buf, "%s\n", dev_name(dev));
}

static MDEV_TYPE_ATTR_RO(name);

static ssize_t
available_instances_show(struct kobject *kobj, struct device *dev, char *buf)
{
	return sprintf(buf, "%s\n", "ivdm");
}

static MDEV_TYPE_ATTR_RO(available_instances);


static ssize_t device_api_show(struct kobject *kobj, struct device *dev,
			       char *buf)
{
	return sprintf(buf, "%s\n", VFIO_DEVICE_API_PCI_STRING);
}

static MDEV_TYPE_ATTR_RO(device_api);

static struct attribute *mdev_types_attrs[] = {
	&mdev_type_attr_name.attr,
	&mdev_type_attr_device_api.attr,
	&mdev_type_attr_available_instances.attr,
	NULL,
};

static struct attribute_group mdev_type_group0 = {
	.name  = "ivdm",
	.attrs = mdev_types_attrs,
};

static struct attribute_group *ice_vdcm_mdev_type_groups[] = {
	&mdev_type_group0,
	NULL,
};

static const struct mdev_parent_ops ice_vdcm_mdev_ops = {
	.supported_type_groups  = ice_vdcm_mdev_type_groups,
	.create                 = ice_vdcm_mdev_create,
	.remove			= ice_vdcm_mdev_remove,
	.open                   = ice_vdcm_mdev_open,
	.release                = ice_vdcm_mdev_close,
	.read                   = ice_vdcm_mdev_read,
	.write                  = ice_vdcm_mdev_write,
	.ioctl		        = ice_vdcm_mdev_ioctl,
};

int ice_vdcm_probe(struct pci_dev *pdev)
{
	struct ice_pf *pf = pci_get_drvdata(pdev);
	struct device *dev = &pdev->dev;
	int ret = 0;

	if (pdev->pasid_cap) {
		ret = iommu_dev_enable_feature(dev, IOMMU_DEV_FEAT_AUX);
		if (ret < 0) {
			dev_warn(dev, "Failed to enable aux-domain: %d\n", ret);
			return ret;
		}

		dev_info(dev, "Enable aux-domain successfully\n");
	} else {
		dev_warn(dev, "No aux-domain feature.\n");
	}

	mutex_init(&pf->mdev_lock);
	ret = mdev_register_device(&pdev->dev, &ice_vdcm_mdev_ops);
	if (ret)
		goto mdev_reigister_faliure;

	/* enable PASID mbx */
	if(pf->hw.pf_id == 0) {
		wr32(&pf->hw, GL_MBX_PASID, GL_MBX_PASID_PASID_MODE_M);
	}

	INIT_LIST_HEAD(&pf->adi_list);
	dev_info(&pdev->dev, "%s succeed", __func__);
	return 0;

mdev_reigister_faliure:
	iommu_dev_disable_feature(dev, IOMMU_DEV_FEAT_AUX);
	return ret;
}

void ice_vdcm_remove(struct pci_dev *pdev)
{
	struct device *dev = &pdev->dev;
	int ret;

	mdev_unregister_device(&pdev->dev);
	dev_info(&pdev->dev, "%s succeed", __func__);

	if (iommu_dev_feature_enabled(dev, IOMMU_DEV_FEAT_AUX)) {
		ret = iommu_dev_disable_feature(dev, IOMMU_DEV_FEAT_AUX);
		if (ret < 0)
			dev_warn(dev, "Failed to disable aux-domain: %d\n",
				 ret);
	}

}
