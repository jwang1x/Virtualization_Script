// SPDX-License-Identifier: GPL-2.0
/* Copyright (C) 2018-2019, Intel Corporation. */

#include "ice.h"
#include "ice_base.h"
#include "ice_lib.h"
#include "ice_idc.h"
#include "ice_fltr.h"

/**
 * ice_adi_vsi_setup - Setup a VSI for an ADI(Assignable Device Interface)
 * @pf: board private structure
 *
 * Returns a pointer to the successfully allocated VSI software struct
 * on success, otherwise returns NULL on failure.
 */
struct ice_vsi *ice_adi_vsi_setup(struct ice_pf *pf, u32 pasid_id)
{
	struct device *dev = ice_pf_to_dev(pf);
	enum ice_status status;
	u8 broadcast[ETH_ALEN];
	struct ice_vsi *vsi;

	vsi = ice_vsi_setup(pf, pf->hw.port_info, ICE_VSI_ADI, ICE_INVAL_VFID, pasid_id);
	if (!vsi) {
		dev_err(dev, "failed to setup ADI VSI\n");
		return NULL;
	}

	/* setup broadcast filter for ADI VSI, otherwise broadcast packets
	 * do not gets delivered to ADI VSI in HW
	 */
	eth_broadcast_addr(broadcast);
	status = ice_fltr_add_mac(vsi, broadcast, ICE_FWD_TO_VSI);
	if (status) {
		dev_err(dev, "failed to add broadcast MAC filter for ADI VSI %u, error %s\n",
			vsi->vsi_num, ice_stat_str(status));
		/* if failed to add broadcast filter, no point to continue,
		 * release ADI VSI and return NULL (indicating that fail to
		 * setup ADI VSI)
		 */
		ice_vsi_release(vsi);
		return NULL;
	}

	return vsi;
}

int ice_validate_adi_id(struct ice_pf *pf, u16 vsi_num)
{
	struct ice_adi *adi;

	if(list_empty(&pf->adi_list))
		return -EINVAL;

	/* find the vsi_num in list stored in PF */
	list_for_each_entry(adi, &pf->adi_list, node) {
		if(adi->vsi_num == vsi_num)
			return 0;
	}
	return -EINVAL;
}

int ice_siov_get_ver_msg(struct ice_adi *adi, u8 *msg)
{
	struct virtchnl_version_info info = {
		VIRTCHNL_VERSION_MAJOR, VIRTCHNL_VERSION_MINOR
	};

	adi->vf_ver = *(struct virtchnl_version_info *)msg;
	/* VFs running the 1.0 API expect to get 1.0 back or they will cry. */
	if (VF_IS_V10(&adi->vf_ver))
		info.minor = VIRTCHNL_VERSION_MINOR_NO_VF_CAPS;

	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_VERSION,
				     VIRTCHNL_STATUS_SUCCESS, (u8 *)&info,
				     sizeof(struct virtchnl_version_info));
}

static bool ice_siov_isvalid_q_id(struct ice_adi *adi, u16 vsi_num, u8 qid)
{
	struct ice_vsi *vsi = ice_find_vsi_from_id(adi->pf, vsi_num);

	/* allocated Tx and Rx queues should be always equal for VF VSI */
	return (vsi && (qid < vsi->alloc_txq));
}

static int ice_siov_get_max_frame_size(struct ice_adi *adi)
{
	struct ice_port_info *pi = adi->pf->hw.port_info;
	u16 max_frame_size;

	max_frame_size = pi->phy.link_info.max_frame_size;
	return max_frame_size;
}

int ice_siov_cfg_qs_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_vsi_queue_config_info *qci =
	    (struct virtchnl_vsi_queue_config_info *)msg;
	struct virtchnl_queue_pair_info *qpi;
	struct ice_pf *pf = adi->pf;
	struct ice_vsi *vsi;
	int i, q_idx;

	if (ice_validate_adi_id(pf, qci->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}
	vsi = ice_find_vsi_from_id(pf, qci->vsi_id);
	if(!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (qci->num_queue_pairs > ICE_MAX_TXQ_VMDQ_VSI ||
	    qci->num_queue_pairs > min_t(u16, vsi->alloc_txq, vsi->alloc_rxq)) {
		dev_err(ice_pf_to_dev(pf), "ADI VSI %d trying to configure more than allocated number of queues: %d\n",
			adi->vsi_num, min_t(u16, vsi->alloc_txq, vsi->alloc_rxq));
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}
	for (i = 0; i < qci->num_queue_pairs; i++) {
		qpi = &qci->qpair[i];
		if (qpi->txq.vsi_id != qci->vsi_id ||
		    qpi->rxq.vsi_id != qci->vsi_id ||
		    qpi->rxq.queue_id != qpi->txq.queue_id ||
		    qpi->txq.headwb_enabled ||
		    !ice_vc_isvalid_ring_len(qpi->txq.ring_len) ||
		    !ice_vc_isvalid_ring_len(qpi->rxq.ring_len) ||
		    !ice_siov_isvalid_q_id(adi, qci->vsi_id,
					 qpi->txq.queue_id)) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}
		q_idx = qpi->rxq.queue_id;

		/* make sure selected "q_idx" is in valid range of queues
		 * for selected "vsi" (which could be main VF VSI or
		 * VF ADQ VSI
		 */
		if (q_idx >= vsi->alloc_txq || q_idx >= vsi->alloc_rxq) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}

		/* copy Tx queue info from VF into VSI */
		if (qpi->txq.ring_len > 0) {
			vsi->tx_rings[q_idx]->dma = qpi->txq.dma_ring_addr;
			vsi->tx_rings[q_idx]->count = qpi->txq.ring_len;
			if (ice_vsi_cfg_single_txq(vsi, vsi->tx_rings, q_idx)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}
		}

		/* copy Rx queue info from VF into VSI */
		if (qpi->rxq.ring_len > 0) {
			u16 max_frame_size = ice_siov_get_max_frame_size(adi);
			vsi->rx_rings[q_idx]->dma = qpi->rxq.dma_ring_addr;
			vsi->rx_rings[q_idx]->count = qpi->rxq.ring_len;
			if (qpi->rxq.databuffer_size != 0 &&
			    (qpi->rxq.databuffer_size > ((16 * 1024) - 128) ||
			     qpi->rxq.databuffer_size < 1024)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}
			vsi->rx_buf_len = qpi->rxq.databuffer_size;
			vsi->rx_rings[q_idx]->rx_buf_len = vsi->rx_buf_len;
			if (qpi->rxq.max_pkt_size > max_frame_size ||
			    qpi->rxq.max_pkt_size < 64) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}

			vsi->max_frame = qpi->rxq.max_pkt_size;
			/* add space for the port VLAN since the VF driver is not
			 * expected to account for it in the MTU calculation
			 */
			if (ice_vsi_cfg_single_rxq(vsi, q_idx)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}
		}
	}
error_param:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_CONFIG_VSI_QUEUES,
				     v_ret, NULL, 0);
}

static void
ice_set_pfe_link(struct ice_adi *adi, struct virtchnl_pf_event *pfe,
		 int ice_link_speed, bool link_up)
{
	if (adi->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED) {
		pfe->event_data.link_event_adv.link_status = link_up;
		/* Speed in Mbps */
		pfe->event_data.link_event_adv.link_speed =
			ice_conv_link_speed_to_virtchnl(true, ice_link_speed);
	} else {
		pfe->event_data.link_event.link_status = link_up;
		/* Legacy method for virtchnl link speeds */
		pfe->event_data.link_event.link_speed =
			(enum virtchnl_link_speed)
			ice_conv_link_speed_to_virtchnl(false, ice_link_speed);
	}
}

void ice_siov_notify_adi_link_state(struct ice_adi *adi) {

	struct ice_port_info *pi = adi->pf->hw.port_info;
	struct virtchnl_pf_event pfe = { 0 };
	struct ice_hw *hw = &adi->pf->hw;

	pfe.event = VIRTCHNL_EVENT_LINK_CHANGE;
	pfe.severity = PF_EVENT_SEVERITY_INFO;
	if (pi->phy.link_info.link_info & ICE_AQ_LINK_UP)
		ice_set_pfe_link(adi, &pfe, pi->phy.link_info.link_speed, true);
	else
		ice_set_pfe_link(adi, &pfe, ICE_AQ_LINK_SPEED_UNKNOWN, false);

	ice_aq_send_msg_to_vf(hw, adi->vsi_num, VIRTCHNL_OP_EVENT,
			      VIRTCHNL_STATUS_SUCCESS, (u8 *)&pfe,
			      sizeof(pfe), NULL);
}

int ice_siov_get_vf_res_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_vf_resource *vfres = NULL;
	struct ice_pf *pf = adi->pf;
	struct ice_vsi *vsi;
	int len = 0;
	int ret;

	len = sizeof(struct virtchnl_vf_resource);

	vfres = kzalloc(len, GFP_KERNEL);
	if (!vfres) {
		v_ret = VIRTCHNL_STATUS_ERR_NO_MEMORY;
		len = 0;
		goto err;
	}
	if (VF_IS_V11(&adi->vf_ver))
		adi->driver_caps = *(u32 *)msg;
	else
		adi->driver_caps = VIRTCHNL_VF_OFFLOAD_L2 |
				  VIRTCHNL_VF_OFFLOAD_RSS_REG |
				  VIRTCHNL_VF_OFFLOAD_VLAN;

	vfres->vf_cap_flags = VIRTCHNL_VF_OFFLOAD_L2;
	vsi = ice_find_vsi_from_id(adi->pf, adi->vsi_num);
	if (!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto err;
	}

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_RSS_PF) {
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_RSS_PF;
	} else {
		if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_RSS_AQ)
			vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_RSS_AQ;
		else
			vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_RSS_REG;
	}
	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_RSS_PCTYPE_V2)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_RSS_PCTYPE_V2;

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_ENCAP)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_ENCAP;

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_ENCAP_CSUM)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_ENCAP_CSUM;

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_RX_POLLING)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_RX_POLLING;

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_WB_ON_ITR)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_WB_ON_ITR;

	if (adi->driver_caps & VIRTCHNL_VF_OFFLOAD_REQ_QUEUES)
		vfres->vf_cap_flags |= VIRTCHNL_VF_OFFLOAD_REQ_QUEUES;

	if (adi->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED)
		vfres->vf_cap_flags |= VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

	/* Tx and Rx queue are equal for VF */
	vfres->num_queue_pairs = vsi->num_txq;
	vfres->num_vsis = 1;
	vfres->max_vectors = vsi->num_q_vectors;
	vfres->rss_key_size = ICE_VSIQF_HKEY_ARRAY_SIZE;
	vfres->rss_lut_size = vsi->rss_table_size;
	vfres->max_mtu = ice_siov_get_max_frame_size(adi);

	vfres->vsi_res[0].vsi_id = adi->vsi_num;
	vfres->vsi_res[0].vsi_type = VIRTCHNL_VSI_SRIOV;
	vfres->vsi_res[0].num_queue_pairs = vsi->num_txq;
	ether_addr_copy(vfres->vsi_res[0].default_mac_addr,
			adi->hw_lan_addr.addr);

	/* match guest capabilities */
	adi->driver_caps = vfres->vf_cap_flags;
err:
	/* send the response back to the VF */
	ret = ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_GET_VF_RESOURCES, v_ret,
				    (u8 *)vfres, len);

	kfree(vfres);
	return ret;
}

static int ice_siov_vsi_ena_single_rxq(struct ice_adi *adi, struct ice_vsi *vsi, u16 q_id)
{
	int err;

	if (test_bit(q_id, adi->rxq_ena))
		return 0;

	err = ice_vsi_ctrl_one_rx_ring(vsi, true, q_id, true);
	if (err) {
		dev_err(ice_pf_to_dev(vsi->back), "Failed to enable Rx ring %d on VSI %d\n",
			q_id, vsi->vsi_num);
		return err;
	}

	ice_vf_ena_rxq_interrupt(vsi, q_id);
	set_bit(q_id, adi->rxq_ena);

	return 0;
}

static void ice_siov_vsi_ena_single_txq(struct ice_adi *adi, struct ice_vsi *vsi, u16 q_id)
{
	if (test_bit(q_id, adi->txq_ena))
		return;

	ice_vf_ena_txq_interrupt(vsi, q_id);
	set_bit(q_id, adi->txq_ena);
}

static bool ice_siov_validate_vqs_bitmaps(struct virtchnl_queue_select *vqs)
{
	if ((!vqs->rx_queues && !vqs->tx_queues) ||
	    vqs->rx_queues >= BIT(ICE_MAX_RXQ_VMDQ_VSI) ||
	    vqs->tx_queues >= BIT(ICE_MAX_TXQ_VMDQ_VSI))
		return false;

	return true;
}

int ice_siov_ena_qs_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_queue_select *vqs =
	    (struct virtchnl_queue_select *)msg;
	struct ice_vsi *vsi;
	unsigned long q_map;
	u16 vf_q_id = 0;

	if (ice_validate_adi_id(adi->pf, vqs->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}
	vsi = ice_find_vsi_from_id(adi->pf, vqs->vsi_id);
	if(!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (!ice_siov_validate_vqs_bitmaps(vqs)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	/* Enable RX queues */
	q_map = vqs->rx_queues;
	for_each_set_bit(vf_q_id, &q_map, ICE_MAX_TXQ_VMDQ_VSI) {
		u16 vsi_id, q_id;

		vsi_id = vqs->vsi_id;
		q_id = vf_q_id;
		if (!ice_siov_isvalid_q_id(adi, vsi_id, q_id)) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}

		ice_siov_vsi_ena_single_rxq(adi, vsi, q_id);
	}

	/* Enable TX queues */
	q_map = vqs->tx_queues;
	for_each_set_bit(vf_q_id, &q_map, ICE_MAX_TXQ_VMDQ_VSI) {
		u16 vsi_id, q_id;

		vsi_id = vqs->vsi_id;
		q_id = vf_q_id;
		if (!ice_siov_isvalid_q_id(adi, vsi_id, q_id)) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}

		ice_siov_vsi_ena_single_txq(adi, vsi, q_id);
	}

	/* Set flag to indicate that queues are enabled */
	if (v_ret == VIRTCHNL_STATUS_SUCCESS)
		set_bit(ICE_VF_STATE_QS_ENA, adi->adi_states);
error_param:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_ENABLE_QUEUES, v_ret,
				     NULL, 0);
}

static bool ice_adi_has_no_qs_ena(struct ice_adi *adi)
{
	return (!bitmap_weight(adi->rxq_ena, ICE_MAX_RXQ_VMDQ_VSI) &&
		!bitmap_weight(adi->txq_ena, ICE_MAX_TXQ_VMDQ_VSI));
}

static int ice_siov_vsi_dis_single_txq(struct ice_adi *adi, struct ice_vsi *vsi, u16 q_id)
{
	struct ice_txq_meta txq_meta = { 0 };
	struct ice_ring *ring;
	int err;

	/* Skip queue if not enabled */
	if (!test_bit(q_id, adi->txq_ena))
		return 0;

	ring = vsi->tx_rings[q_id];
	if (!ring)
		return -EINVAL;

	ice_fill_txq_meta(vsi, ring, &txq_meta);

	err = ice_vsi_stop_tx_ring(vsi, ICE_NO_RESET, adi->vsi_num, ring, &txq_meta);
	if (err) {
		dev_err(ice_pf_to_dev(vsi->back), "Failed to stop Tx ring %d on VSI %d\n",
			q_id, vsi->vsi_num);
		return err;
	}

	/* Clear enabled queues flag */
	clear_bit(q_id, adi->txq_ena);

	return 0;
}

static int ice_siov_vsi_dis_single_rxq(struct ice_adi *adi, struct ice_vsi *vsi, u16 q_id)
{
	int err;

	if (!test_bit(q_id, adi->rxq_ena))
		return 0;

	err = ice_vsi_ctrl_one_rx_ring(vsi, false, q_id, true);
	if (err) {
		dev_err(ice_pf_to_dev(vsi->back), "Failed to stop Rx ring %d on VSI %d\n",
			q_id, vsi->vsi_num);
		return err;
	}

	/* Clear enabled queues flag */
	clear_bit(q_id, adi->rxq_ena);

	return 0;
}

int ice_siov_dis_qs_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_queue_select *vqs =
	    (struct virtchnl_queue_select *)msg;
	struct ice_vsi *vsi;
	unsigned long q_map;
	u16 vf_q_id = 0;

	if (ice_validate_adi_id(adi->pf, vqs->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}
	vsi = ice_find_vsi_from_id(adi->pf, vqs->vsi_id);
	if(!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (!ice_siov_validate_vqs_bitmaps(vqs)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (vqs->tx_queues) {
		q_map = vqs->tx_queues;

		for_each_set_bit(vf_q_id, &q_map, ICE_MAX_TXQ_VMDQ_VSI) {
			u16 vsi_id, q_id;

			vsi_id = vqs->vsi_id;
			q_id = vf_q_id;

			if (!ice_siov_isvalid_q_id(adi, vsi_id, q_id)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}

			if(ice_siov_vsi_dis_single_txq(adi, vsi, q_id)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}
		}
	}

	q_map = vqs->rx_queues;
	/* speed up Rx queue disable by batching them if possible */
	if (q_map &&
	    bitmap_equal(&q_map, adi->rxq_ena, ICE_MAX_DFLT_QS_PER_VF)) {
		if (ice_vsi_stop_all_rx_rings(vsi)) {
			dev_err(ice_pf_to_dev(vsi->back), "Failed to stop all Rx rings on VSI %d\n",
				vsi->vsi_num);
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}
		bitmap_zero(adi->rxq_ena, ICE_MAX_DFLT_QS_PER_VF);
	} else if (q_map) {
		for_each_set_bit(vf_q_id, &q_map, ICE_MAX_DFLT_QS_PER_VF) {
			u16 vsi_id = vqs->vsi_id, q_id = vf_q_id;

			if (!ice_siov_isvalid_q_id(adi, vsi_id, q_id)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}

			if (ice_siov_vsi_dis_single_rxq(adi, vsi, q_id)) {
				v_ret = VIRTCHNL_STATUS_ERR_PARAM;
				goto error_param;
			}
		}
	}

	/* Clear enabled queues flag */
	if (v_ret == VIRTCHNL_STATUS_SUCCESS && ice_adi_has_no_qs_ena(adi))
		clear_bit(ICE_VF_STATE_QS_ENA, adi->adi_states);
error_param:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_DISABLE_QUEUES, v_ret,
				     NULL, 0);
}

static int
ice_siov_add_mac_addr(struct ice_adi *adi, struct ice_vsi *vsi,
		      struct virtchnl_ether_addr *vc_ether_addr)
{
	struct device *dev = ice_pf_to_dev(adi->pf);
	u8 *mac_addr = vc_ether_addr->addr;
	enum ice_status status;

	/* device MAC already added */
	if (!ether_addr_equal(mac_addr, adi->dev_lan_addr.addr)) {
		status = ice_fltr_add_mac(vsi, mac_addr, ICE_FWD_TO_VSI);
		if (status == ICE_ERR_ALREADY_EXISTS) {
			dev_err(dev, "MAC %pM already exists for ADI %d\n", mac_addr, adi->vsi_num);
			return -EEXIST;
		} else if (status) {
			dev_err(dev, "Failed to add MAC %pM for ADI %d\n, error %s\n", mac_addr,
				adi->vsi_num, ice_stat_str(status));
			return -EIO;
		}

	//	ice_adi_hw_mac_add(adi, vc_ether_addr);

		adi->num_mac++;
	}
	return 0;
}

static int
ice_siov_del_mac_addr(struct ice_adi *adi, struct ice_vsi *vsi,
		      struct virtchnl_ether_addr *vc_ether_addr)
{
	struct device *dev = ice_pf_to_dev(adi->pf);
	u8 *mac_addr = vc_ether_addr->addr;
	enum ice_status status;

	/* TODO: ADI VF permission check */
	status = ice_fltr_remove_mac(vsi, mac_addr, ICE_FWD_TO_VSI);
	if (status == ICE_ERR_DOES_NOT_EXIST) {
		dev_err(dev, "MAC %pM does not exist for VF %d\n", mac_addr,
			adi->vsi_num);
		return -ENOENT;
	} else if (status) {
		dev_err(dev, "Failed to delete MAC %pM for VF %d, error %s\n",
			mac_addr, adi->vsi_num, ice_stat_str(status));
		return -EIO;
	}
	adi->num_mac--;
	return 0;
}

static int
ice_siov_handle_mac_addr_msg(struct ice_adi *adi, u8 *msg, bool set)
{
	int (*ice_siov_cfg_mac)
		(struct ice_adi *adi, struct ice_vsi *vsi,
		 struct virtchnl_ether_addr *virtchnl_ether_addr);
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_ether_addr_list *al =
	    (struct virtchnl_ether_addr_list *)msg;
	enum virtchnl_ops vc_op;
	struct ice_vsi *vsi;
	int i;

	if (set) {
		vc_op = VIRTCHNL_OP_ADD_ETH_ADDR;
		ice_siov_cfg_mac = ice_siov_add_mac_addr;
	} else {
		vc_op = VIRTCHNL_OP_DEL_ETH_ADDR;
		ice_siov_cfg_mac = ice_siov_del_mac_addr;
	}

	if (ice_validate_adi_id(adi->pf, al->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto handle_mac_exit;
	}

	vsi = ice_find_vsi_from_id(adi->pf, al->vsi_id);
	if(!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto handle_mac_exit;
	}

	for (i = 0; i < al->num_elements; i++) {
		u8 *mac_addr = al->list[i].addr;
		int result;

		if (is_broadcast_ether_addr(mac_addr) ||
		    is_zero_ether_addr(mac_addr))
			continue;

		result = ice_siov_cfg_mac(adi, vsi, &al->list[i]);
		if (result == -EEXIST || result == -ENOENT) {
			continue;
		} else if (result) {
			v_ret = VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR;
			goto handle_mac_exit;
		}
	}

handle_mac_exit:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, vc_op, v_ret, NULL, 0);
}

int ice_siov_add_mac_addr_msg(struct ice_adi *adi, u8 *msg)
{
	return ice_siov_handle_mac_addr_msg(adi, msg, true);
}

int ice_siov_del_mac_addr_msg(struct ice_adi *adi, u8 *msg)
{
	return ice_siov_handle_mac_addr_msg(adi, msg, false);
}

int ice_siov_get_stats_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_queue_select *vqs =
		(struct virtchnl_queue_select *)msg;
	struct ice_eth_stats stats = { 0 };
	struct ice_vsi *vsi;

	if (ice_validate_adi_id(adi->pf, vqs->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	vsi = ice_find_vsi_from_id(adi->pf, vqs->vsi_id);
	if(!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}
	ice_update_eth_stats(vsi);

	stats = vsi->eth_stats;

error_param:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_GET_STATS, v_ret,
				      (u8 *)&stats, sizeof(stats));
}

int ice_siov_config_rss_key(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_rss_key *vrk =
		(struct virtchnl_rss_key *)msg;
	struct ice_vsi *vsi;

	if(ice_validate_adi_id(adi->pf, vrk->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (vrk->key_len != ICE_VSIQF_HKEY_ARRAY_SIZE) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (!test_bit(ICE_FLAG_RSS_ENA, adi->pf->flags)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	vsi = ice_find_vsi_from_id(adi->pf, vrk->vsi_id);
	if (!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (ice_set_rss_key(vsi, vrk->key))
		v_ret = VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR;
error_param:
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_CONFIG_RSS_KEY, v_ret,
				     NULL, 0);
}

int ice_siov_config_rss_lut(struct ice_adi *adi, u8 *msg)
{
	struct virtchnl_rss_lut *vrl = (struct virtchnl_rss_lut *)msg;
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct ice_vsi *vsi;

	if(ice_validate_adi_id(adi->pf, vrl->vsi_id)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	vsi = ice_find_vsi_from_id(adi->pf, vrl->vsi_id);
	if (!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (vrl->lut_entries != vsi->rss_table_size) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (!test_bit(ICE_FLAG_RSS_ENA, adi->pf->flags)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if (ice_set_rss_lut(vsi, vrl->lut, vrl->lut_entries))
		v_ret = VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR;

error_param:
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_CONFIG_RSS_LUT, v_ret,
				     NULL, 0);
}

int ice_siov_get_rss_hena(struct ice_adi *adi)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_rss_hena *vrh = NULL;
	int len = 0, ret;

	if (!test_bit(ICE_FLAG_RSS_ENA, adi->pf->flags)) {
		dev_err(ice_pf_to_dev(adi->pf), "RSS not supported by PF\n");
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto err;
	}

	len = sizeof(struct virtchnl_rss_hena);
	vrh = kzalloc(len, GFP_KERNEL);
	if (!vrh) {
		v_ret = VIRTCHNL_STATUS_ERR_NO_MEMORY;
		len = 0;
		goto err;
	}

	vrh->hena = ICE_DEFAULT_RSS_HENA;
err:
	/* send the response back to the VF */
	ret = ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_GET_RSS_HENA_CAPS, v_ret,
				    (u8 *)vrh, len);
	kfree(vrh);
	return ret;
}

int ice_siov_set_rss_hena(struct ice_adi *adi, u8 *msg)
{
	struct virtchnl_rss_hena *vrh = (struct virtchnl_rss_hena *)msg;
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct ice_pf *pf = adi->pf;
	enum ice_status status;
	struct ice_vsi *vsi;
	struct device *dev;

	dev = ice_pf_to_dev(pf);

	if (!test_bit(ICE_FLAG_RSS_ENA, pf->flags)) {
		dev_err(dev, "RSS not supported by PF\n");
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	if(ice_validate_adi_id(adi->pf, adi->vsi_num)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	vsi = ice_find_vsi_from_id(adi->pf, adi->vsi_num);
	if (!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	/* clear all previously programmed RSS configuration to allow VF drivers
	 * the ability to customize the RSS configuration and/or completely
	 * disable RSS
	 */
	status = ice_rem_vsi_rss_cfg(&pf->hw, vsi->idx);
	if (status && !vrh->hena) {
		/* only report failure to clear the current RSS configuration if
		 * that was clearly the VF's intention (i.e. vrh->hena = 0)
		 */
		v_ret = ice_err_to_virt_err(status);
		goto error_param;
	} else if (status) {
		/* allow the VF to update the RSS configuration even on failure
		 * to clear the current RSS confguration in an attempt to keep
		 * RSS in a working state
		 */
		dev_warn(dev, "Failed to clear the RSS configuration for VF %u\n",
			 adi->vsi_num);
	}

	if (vrh->hena) {
		status = ice_add_avf_rss_cfg(&pf->hw, vsi->idx, vrh->hena);
		v_ret = ice_err_to_virt_err(status);
	}

	/* send the response to the VF */
error_param:
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_SET_RSS_HENA, v_ret,
				      NULL, 0);
}

static int
ice_siov_cfg_interrupt(struct ice_adi *adi, struct ice_vsi *vsi, u16 vector_id,
		  u8 __maybe_unused tc, struct virtchnl_vector_map *map,
		  struct ice_q_vector *q_vector)
{
	unsigned long qmap;
	u16 vsi_q_id_idx;

	q_vector->num_ring_rx = 0;
	q_vector->num_ring_tx = 0;

	qmap = map->rxq_map;
	for_each_set_bit(vsi_q_id_idx, &qmap, ICE_MAX_DFLT_QS_PER_VF) {
		u16 vsi_q_id = vsi_q_id_idx;

		if (!ice_siov_isvalid_q_id(adi, vsi->vsi_num, vsi_q_id))
			return VIRTCHNL_STATUS_ERR_PARAM;

		q_vector->num_ring_rx++;
		q_vector->rx.itr_idx = map->rxitr_idx;
		vsi->rx_rings[vsi_q_id]->q_vector = q_vector;
		ice_cfg_rxq_interrupt(vsi, vsi_q_id, q_vector->reg_idx,
				      q_vector->rx.itr_idx);
	}

	qmap = map->txq_map;
	for_each_set_bit(vsi_q_id_idx, &qmap, ICE_MAX_DFLT_QS_PER_VF) {
		u16 vsi_q_id = vsi_q_id_idx;

		if (!ice_siov_isvalid_q_id(adi, vsi->vsi_num, vsi_q_id))
			return VIRTCHNL_STATUS_ERR_PARAM;

		q_vector->num_ring_tx++;
		q_vector->tx.itr_idx = map->txitr_idx;
		vsi->tx_rings[vsi_q_id]->q_vector = q_vector;
		ice_cfg_txq_interrupt(vsi, vsi_q_id, q_vector->reg_idx,
				      q_vector->tx.itr_idx);
	}

	return VIRTCHNL_STATUS_SUCCESS;
}

int ice_siov_cfg_irq_map_msg(struct ice_adi *adi, u8 *msg)
{
	enum virtchnl_status_code v_ret = VIRTCHNL_STATUS_SUCCESS;
	struct virtchnl_irq_map_info *irqmap_info;
	struct virtchnl_vector_map *map;
	struct ice_pf *pf = adi->pf;
	u16 num_q_vectors_mapped;
	struct ice_vsi *vsi;
	u16 tc = 0;
	int i;

	irqmap_info = (struct virtchnl_irq_map_info *)msg;
	num_q_vectors_mapped = irqmap_info->num_vectors;

	if(ice_validate_adi_id(adi->pf, adi->vsi_num)) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	vsi = ice_find_vsi_from_id(adi->pf, adi->vsi_num);
	if (!vsi) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	/* Check to make sure number of VF vectors mapped is not greater than
	 * number of VF vectors originally allocated, and check that
	 * there is actually at least a single VF queue vector mapped
	 */
	if (vsi->num_q_vectors < num_q_vectors_mapped ||
	    !num_q_vectors_mapped) {
		v_ret = VIRTCHNL_STATUS_ERR_PARAM;
		goto error_param;
	}

	for (i = 0; i < num_q_vectors_mapped; i++) {
		struct ice_q_vector *q_vector;
		u16 vsi_id, vector_id;

		map = &irqmap_info->vecmap[i];

		vector_id = map->vector_id;
		vsi_id = map->vsi_id;
		/* vector_id is always 0-based for each VF, and can never be
		 * larger than or equal to the max allowed interrupts per VF
		 */
		if (!(vector_id < vsi->num_q_vectors) ||
		    (!vector_id && (map->rxq_map || map->txq_map))) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}

		/* No need to map VF miscellaneous or rogue vector */
		if (!vector_id)
			continue;

		q_vector = vsi->q_vectors[vector_id];
		if (!q_vector) {
			v_ret = VIRTCHNL_STATUS_ERR_PARAM;
			goto error_param;
		}

		/* lookout for the invalid queue index */

		v_ret = (enum virtchnl_status_code)
			ice_siov_cfg_interrupt(adi, vsi, vector_id, tc, map,
					  q_vector);
		if (v_ret)
			goto error_param;
	}
error_param:
	/* send the response to the VF */
	return ice_vc_send_msg_to_adi(adi, VIRTCHNL_OP_CONFIG_IRQ_MAP, v_ret,
				      NULL, 0);
}
void ice_free_adi(struct ice_pf *pf, u16 vsi_num)
{
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_adi *adi, *tmp;

	if(list_empty(&pf->adi_list))
		return;

	list_for_each_entry_safe(adi, tmp, &pf->adi_list, node) {
		struct ice_vsi *vsi;

		if(adi->vsi_num == vsi_num){
printk("releasing vsi num %d\n", vsi_num);
			vsi = ice_find_vsi_from_id(pf, adi->vsi_num);
			if(!vsi)
				return;
			dev_info(dev, "releasing VSI %d\n", vsi_num);
			ice_vsi_release(vsi);
			list_del(&adi->node);
			kfree(adi);
		}
	}
}

void ice_free_all_adi(struct ice_pf *pf){
	struct ice_adi *adi, *tmp;

	if(list_empty(&pf->adi_list))
		return;

	list_for_each_entry_safe(adi, tmp, &pf->adi_list, node)
		ice_free_adi(pf, adi->vsi_num);
}

/**
 * ice_alloc_adi - Allocate default resources for a single ADI
 * @iavf_vdcm: pointer to the vdcm struct
 * @parent: the parent device
 * @iavf_adi_conf: pointer to the struct holding the HW info for the ADI
 *
 * This function is called by the vdcm module when requesting for
 * allocation of ADI resources.
 */

