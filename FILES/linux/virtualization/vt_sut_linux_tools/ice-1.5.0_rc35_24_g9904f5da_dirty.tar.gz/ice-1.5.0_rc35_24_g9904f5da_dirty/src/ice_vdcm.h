/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright (C) 2018-2019, Intel Corporation. */

#ifndef _ICE_VDCM_H_
#define _ICE_VDCM_H_

#include "ice.h"

/*
#define IAVF_VDEV_ATQBAH				0x0000
#define IAVF_VDEV_ATQBAL				0x0004
#define IAVF_VDEV_ATQLEN				0x0008
#define IAVF_VDEV_ATQH					0x000C
#define IAVF_VDEV_ATQT					0x0010
#define IAVF_VDEV_ARQBAL				0x0014
#define IAVF_VDEV_ARQBAH				0x0018
#define IAVF_VDEV_ARQLEN				0x001C
#define IAVF_VDEV_ARQH					0x0020
#define IAVF_VDEV_ARQT					0x0024

#define IAVF_VDEV_QRX_TAIL(_Q) (0x00200000 + ((_Q) * 0x1000))
#define IAVF_VDEV_QTX_TAIL(_Q) (0x00100000 + ((_Q) * 0x1000))
*/

#define IAVF_VDEV_ATQBAL				0x7C00
#define IAVF_VDEV_ATQBAH				0x7800
#define IAVF_VDEV_ATQLEN				0x6800
#define IAVF_VDEV_ATQH					0x6400
#define IAVF_VDEV_ATQT					0x8400
#define IAVF_VDEV_ARQBAL				0x6C00
#define IAVF_VDEV_ARQBAH				0x6000
#define IAVF_VDEV_ARQLEN				0x8000
#define IAVF_VDEV_ARQH					0x7400
#define IAVF_VDEV_ARQT					0x7000

#define IAVF_VDEV_QTX_TAIL(_Q) (0x0000 + ((_Q) * 4)) /* _Q=0...255 */
#define IAVF_VDEV_QRX_TAIL(_Q) (0x2000 + ((_Q) * 4)) /* _Q=0...255 */

#define IAVF_VFGEN_RSTAT 0x00008800 /* Reset: VFR */
#define IAVF_VFINT_DYN_CTL01 0x00005C00 /* Reset: VFR */
#define IAVF_VFINT_DYN_CTLN1(_INTVF) (0x00003800 + ((_INTVF) * 4)) /* _i=0...15 */ /* Reset: VFR */
#define IAVF_VFINT_ITR01(_i) (0x00004C00 + ((_i) * 4)) /* _i=0...2 */ /* Reset: VFR */
#define IAVF_VFINT_ITRN1(_i, _INTVF) (0x00002800 + ((_i) * 64 + (_INTVF) * 4)) /* _i=0...2, _INTVF=0...15 */ /* Reset: VFR */

int ice_vdcm_probe(struct pci_dev *pdev);
void ice_vdcm_remove(struct pci_dev *pdev);

#endif /* _ICE_VDCM_H_ */
