var searchData=
[
  ['port_5fcos_248',['port_cos',['../structdlb__dev__cap__t.html#a61605edcfd4c6f125507595c916fd4ee',1,'dlb_dev_cap_t']]],
  ['priority_249',['priority',['../struct____attribute.html#a86f066b5af102e80ff5ca9b896c74b5e',1,'__attribute::priority()'],['../structdlb__adv__send__t.html#aa37d13e1af5582fceba890222936deb6',1,'dlb_adv_send_t::priority()']]]
];
