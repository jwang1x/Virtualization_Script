var searchData=
[
  ['max_5fcontiguous_5fdir_5fcredits_229',['max_contiguous_dir_credits',['../structdlb__resources__t.html#adbe124a6d935ccea748cb9d6eda28a1b',1,'dlb_resources_t']]],
  ['max_5fcontiguous_5fldb_5fcredits_230',['max_contiguous_ldb_credits',['../structdlb__resources__t.html#ad7eceb112ce398470a4c4c9283b1a989',1,'dlb_resources_t']]],
  ['max_5fcontiguous_5fldb_5fevent_5fstate_5fentries_231',['max_contiguous_ldb_event_state_entries',['../structdlb__resources__t.html#aae279b009023b87d2d3233d319cd5284',1,'dlb_resources_t']]]
];
