var searchData=
[
  ['timeout_5fvalue_5fns_262',['timeout_value_ns',['../structdlb__wait__profile__t.html#a2106e72802a310e8a2688ed287b151d4',1,'dlb_wait_profile_t']]],
  ['type_263',['type',['../structdlb__wait__profile__t.html#a8f0d6e3dcaf1e1a263f3e202bb07e2b7',1,'dlb_wait_profile_t']]]
];
