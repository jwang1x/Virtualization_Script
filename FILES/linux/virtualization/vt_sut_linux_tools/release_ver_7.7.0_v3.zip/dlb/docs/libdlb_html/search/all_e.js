var searchData=
[
  ['sched_5fatomic_143',['SCHED_ATOMIC',['../dlb__common_8h.html#a760bc7504c8a9915acdfdaf9b305def0aa9a2a9137d4b2bdc18c80e3cf0e720ae',1,'dlb_common.h']]],
  ['sched_5fdirected_144',['SCHED_DIRECTED',['../dlb__common_8h.html#a760bc7504c8a9915acdfdaf9b305def0a86dc7b5caaaf4aec77f6b8517ee0c187',1,'dlb_common.h']]],
  ['sched_5fordered_145',['SCHED_ORDERED',['../dlb__common_8h.html#a760bc7504c8a9915acdfdaf9b305def0a50ab31879ec40a7dff27610c84d4359a',1,'dlb_common.h']]],
  ['sched_5ftype_146',['sched_type',['../struct____attribute.html#a609cf3831e9a377ed920efecb2762ca2',1,'__attribute::sched_type()'],['../structdlb__adv__send__t.html#a133bc5d0fdd5e8862f411465772d464f',1,'dlb_adv_send_t::sched_type()']]],
  ['sched_5funordered_147',['SCHED_UNORDERED',['../dlb__common_8h.html#a760bc7504c8a9915acdfdaf9b305def0a9d0aecbe75a80092bef4a56f6ac4a1ad',1,'dlb_common.h']]],
  ['send_148',['send',['../uniondlb__event__t.html#ad92ce44d822ec43133d6132ec5902125',1,'dlb_event_t']]],
  ['sleep_5fduration_5fns_149',['sleep_duration_ns',['../structdlb__wait__profile__t.html#a6b706b031f62b1f226ee312ae726790b',1,'dlb_wait_profile_t']]]
];
