var searchData=
[
  ['cmd_3',['cmd',['../structdlb__adv__send__t.html#a7da369bca8823505f4083b58e2b62d42',1,'dlb_adv_send_t']]],
  ['combined_5fcredits_4',['combined_credits',['../structdlb__dev__cap__t.html#ab4cf34bee5dd02404b8bb1e3ecc5988a',1,'dlb_dev_cap_t']]],
  ['cos_5fid_5',['cos_id',['../structdlb__create__port__t.html#aed1aa3459b5149ff31cb9b1464e3f5ab',1,'dlb_create_port_t']]],
  ['cq_5fdepth_6',['cq_depth',['../structdlb__create__port__t.html#af91ed80a32c01f2bcd4ae453170fb6a2',1,'dlb_create_port_t']]],
  ['credit_5fpool_5fid_7',['credit_pool_id',['../structdlb__create__port__t.html#aa2db60f5ad621699d5f28f804edc42c0',1,'dlb_create_port_t']]]
];
