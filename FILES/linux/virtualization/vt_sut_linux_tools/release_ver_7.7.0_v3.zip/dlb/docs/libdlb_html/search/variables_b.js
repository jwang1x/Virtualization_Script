var searchData=
[
  ['recv_253',['recv',['../uniondlb__event__t.html#a93b1e3ec37b5573c3a8e0f57384ca3c1',1,'dlb_event_t']]],
  ['rsvd0_254',['rsvd0',['../struct____attribute.html#a8c4b68e061c09df208b3593991f8bd49',1,'__attribute::rsvd0()'],['../structdlb__adv__send__t.html#af92703a97cd20d9cdd42cf2f1437b6b2',1,'dlb_adv_send_t::rsvd0()']]],
  ['rsvd1_255',['rsvd1',['../struct____attribute.html#a53ebfe8c0c11430fae683db0358118f8',1,'__attribute::rsvd1()'],['../structdlb__adv__send__t.html#ac5b9062fce61efdb8f1e08dff6c3aa69',1,'dlb_adv_send_t::rsvd1()']]],
  ['rsvd2_256',['rsvd2',['../struct____attribute.html#a0efdc0dade83c2e37eb13f7a0cb21302',1,'__attribute::rsvd2()'],['../structdlb__adv__send__t.html#acab01ec9267690dcaac28a3d51a9fdc4',1,'dlb_adv_send_t::rsvd2()']]],
  ['rsvd3_257',['rsvd3',['../struct____attribute.html#a8e485a14e26ec809e26db76e9b3b1efa',1,'__attribute::rsvd3()'],['../structdlb__adv__send__t.html#ab71546bef9739ebfabb08ec75e66fdc7',1,'dlb_adv_send_t::rsvd3()']]],
  ['rsvd4_258',['rsvd4',['../struct____attribute.html#a853fd1d8b47b83314cc797c96d0453dc',1,'__attribute']]]
];
