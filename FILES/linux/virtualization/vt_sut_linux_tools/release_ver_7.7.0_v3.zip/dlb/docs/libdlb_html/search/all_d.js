var searchData=
[
  ['recv_132',['recv',['../uniondlb__event__t.html#a93b1e3ec37b5573c3a8e0f57384ca3c1',1,'dlb_event_t']]],
  ['rel_133',['REL',['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176ab2082544bca640e70f0bb74d17a98082',1,'dlb_common.h']]],
  ['rel_5ft_134',['REL_T',['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176ae39dc15c65ac7372c8d227ba4deeebb7',1,'dlb_common.h']]],
  ['rsvd0_135',['rsvd0',['../struct____attribute.html#a8c4b68e061c09df208b3593991f8bd49',1,'__attribute::rsvd0()'],['../structdlb__adv__send__t.html#af92703a97cd20d9cdd42cf2f1437b6b2',1,'dlb_adv_send_t::rsvd0()']]],
  ['rsvd1_136',['rsvd1',['../struct____attribute.html#a53ebfe8c0c11430fae683db0358118f8',1,'__attribute::rsvd1()'],['../structdlb__adv__send__t.html#ac5b9062fce61efdb8f1e08dff6c3aa69',1,'dlb_adv_send_t::rsvd1()']]],
  ['rsvd2_137',['rsvd2',['../struct____attribute.html#a0efdc0dade83c2e37eb13f7a0cb21302',1,'__attribute::rsvd2()'],['../structdlb__adv__send__t.html#acab01ec9267690dcaac28a3d51a9fdc4',1,'dlb_adv_send_t::rsvd2()']]],
  ['rsvd3_138',['rsvd3',['../struct____attribute.html#a8e485a14e26ec809e26db76e9b3b1efa',1,'__attribute::rsvd3()'],['../structdlb__adv__send__t.html#ab71546bef9739ebfabb08ec75e66fdc7',1,'dlb_adv_send_t::rsvd3()']]],
  ['rsvd4_139',['rsvd4',['../struct____attribute.html#a853fd1d8b47b83314cc797c96d0453dc',1,'__attribute::rsvd4()'],['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176a60622647cdb8ad35b2d673427026f00d',1,'RSVD4():&#160;dlb_common.h']]],
  ['rsvd5_140',['RSVD5',['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176a30374cf516dd521f57c8bf60d880ef9c',1,'dlb_common.h']]],
  ['rsvd6_141',['RSVD6',['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176a51290e53105e1916490bdbd000dd6361',1,'dlb_common.h']]],
  ['rsvd7_142',['RSVD7',['../dlb__common_8h.html#aae1ea668b05f33c9f5e26976b4e38176a44531ca1912d48fcc23f39b39b04804b',1,'dlb_common.h']]]
];
