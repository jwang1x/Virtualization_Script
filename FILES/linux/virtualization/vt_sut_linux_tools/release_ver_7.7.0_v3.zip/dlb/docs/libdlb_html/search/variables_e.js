var searchData=
[
  ['udata16_264',['udata16',['../struct____attribute.html#ac9e5dba637a3f19f24037c97479c4643',1,'__attribute::udata16()'],['../structdlb__adv__send__t.html#ab37b5bdad57272ee5c874aca86e5533f',1,'dlb_adv_send_t::udata16()']]],
  ['udata64_265',['udata64',['../struct____attribute.html#a7a42c02a9e73425c86fd03af4d678dfc',1,'__attribute::udata64()'],['../structdlb__adv__send__t.html#a108951fbd0a081af57f7fcc5d2d5afd1',1,'dlb_adv_send_t::udata64()']]]
];
