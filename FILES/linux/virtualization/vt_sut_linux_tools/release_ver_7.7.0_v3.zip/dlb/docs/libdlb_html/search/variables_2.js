var searchData=
[
  ['data_220',['data',['../structdlb__alert__t.html#a852e659a38bf01304e0769fde011dc1d',1,'dlb_alert_t']]],
  ['dir_5fcredit_5fpool_5fid_221',['dir_credit_pool_id',['../structdlb__create__port__t.html#aa996515a357b700a4be9c120d1a383e5',1,'dlb_create_port_t']]]
];
