var searchData=
[
  ['sched_5ftype_259',['sched_type',['../struct____attribute.html#a609cf3831e9a377ed920efecb2762ca2',1,'__attribute::sched_type()'],['../structdlb__adv__send__t.html#a133bc5d0fdd5e8862f411465772d464f',1,'dlb_adv_send_t::sched_type()']]],
  ['send_260',['send',['../uniondlb__event__t.html#ad92ce44d822ec43133d6132ec5902125',1,'dlb_event_t']]],
  ['sleep_5fduration_5fns_261',['sleep_duration_ns',['../structdlb__wait__profile__t.html#a6b706b031f62b1f226ee312ae726790b',1,'dlb_wait_profile_t']]]
];
