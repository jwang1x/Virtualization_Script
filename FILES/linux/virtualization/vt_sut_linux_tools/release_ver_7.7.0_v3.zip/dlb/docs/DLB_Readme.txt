*******************************************************************************

	    Intel Dynamic Load Balancer 2.0 Driver Release 7.7.0

********************************************************************************
Disclaimer: This code is being provided to potential customers of Intel DLB to
enable the use of Intel DLB well ahead of the kernel.org and DPDK.org
upstreaming process. Please be aware that based on the open source community
feedback, the design of the code module can change considerably, including API
interface definitions. If the open source implementation differs from what is
presented in this release, Intel may reserve the right to update the
implementation to align with the open source version at a later time and stop
supporting this early enablement version.

===================
Table of Contents
===================

* Intel Dynamic Load Balancer
* Intel DLB Software Installation Notes
* Kernel and DPDK Versions
* Build and Installation
* Examples / Test Cases
* Alerts & Notices
* Known Issues

=========================================
Intel Dynamic Load Balancer (Intel DLB)
=========================================

Intel DLB 2.0 is a PCIe device that provides load-balanced, prioritized
scheduling of events across CPU cores enabling efficient core-to-core
communication. It is an accelerator for the event-driven programming model of
DPDK's Event Device Library. This library is used in packet processing pipelines
for multi-core scalability, dynamic load-balancing, and variety of packet
distribution and synchronization schemes.

=======================================
Intel DLB Software Installation Notes
=======================================

The Intel DLB software comes in the following package:

    dlb_linux_src_release_<rel-id>_<rel-date>.txz

The package contains the Intel DLB kernel driver, DPDK Patch for Intel DLB 2.0
PMD (Poll Mode Driver) with other required changes to standard DPDK, and libdlb
client library for non-dpdk applications. The package can be extracted using
the following command:

    $ tar xfJ dlb_linux_src_release_<rel-id>_<rel-date>.txz

============================
Kernel and DPDK Versions
============================

Linux Kernel Version: Tested with Linux Kernel versions 5.13, 5.15, 5.16 and
		      5.17.

DPDK Base Version: v21.11

===========================
Build and Installation
===========================

Refer to document "DLB_Driver_User_Guide.pdf" for detailed instructions on build
and installation.

==========================
Examples / Test Cases
==========================

This Intel DLB release contains libdlb, the client library for building Intel
DLB applications which do not require complete DPDK framework. It also includes
a set of sample tests to demonstrate various features. Accompanying User Guide
has details on the included samples.

==============================
Changes in release 7.7.0
==============================

- HQM-416: Reworked queue drain handling. Added time-based drain logic so that
  unreasonably long hangs are avoided in the case where the queues cannot be
  successfully drained.
- HQM-454, 455, 457: Added DLB scheduling idle and error counters telemetry
  support. Linux kernel driver stats are exposed through perf_events.
- HQM-474: Improved enqueue efficiency by making quanta assignment dependent on
  port hints; producer, consumer, worker.
- HQM-535: Introduced DLB debug utility for libdlb applications.
- HQM-566: Fixed QID inflight exploit by adding sanity check to ensure QID
  inflights is >0 and <= 2048.
- HQM-568: Added RTE_EVENT_DEV_CAP_MULTIPLE_QUEUE_PORT and RUNTIME_PORT_LINK,
  and removed QUEUE_QOS from advertized eventdev capabilities.
- HQM-572: Added eventdev capability check of max enqueue depth <= quanta or
  credit batch size. Enqueue retries are also added.
- HQM-592, 645: Addressed performance variation issues with different
  ports/cores by probing for producer ports for a given CPU and allocating
  the best performing ports to the producers.
- HQM-597: Restored compatibility with SQM for l2fwd-event and l3fwd examples.
- HQM-640: Extended eventfd/epoll support to VM.
- HQM-650: Implemented rate-limiting the total DLB throughput to 200 Mdps
  (million decisions per second) in PF PMD.
- HQM-659: Disabled SIOV support for RHEL 8.5 and Linux kernel 5.16 and later.

=====================
Alerts & Notices
=====================

- The software distributed in this release is not intended for secure use
  and should not be used to transmit or store security sensitive or privacy
  protected data.
- DLB2 application only supports simultaneous use of either Bi-furcated mode
  devices  (bound to dlb2 driver) or PF PMD mode devices (bound to vfio-pci).
  Application should use all devices of the same type when some devices are
  bound to dlb2 driver and some to vfio-pci module. Different application can
  use different types and run at the same time. To avoid picking devices bound
  to vfio-pci while using devices bound to dlb2 driver, use the --no-pci
  option.
- HQM-417: For older kernels (pre 5.15) with some specific application patterns
  and kernel configuration, DLB device binding to vfio-pci driver results in a
  crash. In such cases, "uio_pci_generic" or "igb_uio" module can be used in
  place of "vfio-pci" (with IOMMU disabled or in passthrough mode) or Bifurcated
  mode can be used by linking device to DLB driver. This issue is not observed
  with kernels 5.15 and later.

=====================
Known Issues
=====================
