/* SPDX-License-Identifier: GPL-2.0-only
 * Copyright(c) 2017-2020 Intel Corporation
 */

int dlb2_pci_sriov_configure(struct pci_dev *pdev, int num_vfs);
