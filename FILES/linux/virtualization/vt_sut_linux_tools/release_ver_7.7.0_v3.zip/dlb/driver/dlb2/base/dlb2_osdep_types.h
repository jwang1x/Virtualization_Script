/* SPDX-License-Identifier: GPL-2.0-only
 * Copyright(c) 2017-2020 Intel Corporation
 */

#ifndef __DLB2_OSDEP_TYPES_H
#define __DLB2_OSDEP_TYPES_H

#include <linux/types.h>

#endif /* __DLB2_OSDEP_TYPES_H */
