/* SPDX-License-Identifier: <Insert identifier here!!!>
 * Copyright(c) 2017-2020 Intel Corporation
 */

#ifndef __DLB2_OSDEP_TYPES_H
#define __DLB2_OSDEP_TYPES_H

#endif /* __DLB2_OSDEP_TYPES_H */
