#!/usr/bin/bash

virsh net-destroy default
virsh net-undefine default
virsh net-define default.xml
virsh net-autostart default
virsh net-start default
