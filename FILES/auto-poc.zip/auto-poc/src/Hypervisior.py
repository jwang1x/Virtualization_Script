from io import StringIO
import sys
import paramiko
import traceback
import platform
from time import sleep, time
from shutil import copyfile
from paramiko.ssh_exception import NoValidConnectionsError, AuthenticationException

from Sut import SUT
from log import logger
from const import *

if platform.system().lower() != 'windows':
    import libvirt


class Hypervisor:
    def __init__(self, sut):
        # type: (SUT) -> None
        self.sut = sut
        self.connect_failed_times = 0

    def connect_test(self, ssh_port):
        raise NotImplemented

    def __delete_known_hosts_file(self):
        self.sut.execute_shell_cmd('rm -f /root/.ssh/known_hosts', output=False)
        self.sut.execute_shell_cmd('del C:\\Users\\Administrator\\.ssh\\known_hosts', output=False)

    def download_from_vm(self, vm_name, src_path, dest_path, ssh_port=22):
        logger.info(f"download file from <{vm_name}>:{src_path} to <SUT>:{dest_path}")
        self.__delete_known_hosts_file()
        if (ssh_port == 22) and (not self.is_vm_running(vm_name)):
            sys.exit(f'error: {vm_name} is not running')
        self.__sftp(vm_name, src_path, dest_path, get_from_remote=True, ssh_port=ssh_port)

    def execute_vm_cmd(self, vm_name, cmd, timeout, port=22, output=True):
        logger.info(f'<{vm_name}> execute command {cmd} port: {port}')
        if (port == 22) and (not self.is_vm_running(vm_name)):
            sys.exit(f'error: {vm_name} is not running')

        has_timeout = False
        res = None
        cmd = cmd.replace('@@', '"')
        try:
            res = self.__execute_vm_cmd(vm_name, cmd, timeout, port, output)
        except TimeoutError as e:
            logger.info('ignore timeout issue, as SSH service may get down \
                                                before DTAF function return')
            logger.info('cmd [{}]'.format(cmd))
            err_info = str(traceback.format_exc())
            logger.error(err_info)
            has_timeout = True

        if has_timeout:
            return None
        else:
            return res
    
    def __execute_vm_cmd(self, vm_name, cmd, timeout, port, output):
        self.__delete_known_hosts_file()
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)

        if int(port) != 22:
            try:
                client.connect('localhost', port, 'root', 'password')
                return self.__run_remote_cmd(client, cmd, timeout)
            except Exception as e:
                sys.exit(e.args[0])

        vm_ip = self.get_vm_ip_for_ssh(vm_name)
        vm_os_type = self.get_vm_os_type(vm_name)
        user = VM_USERNAME[vm_os_type]
        password = VM_PASSWORD[vm_os_type]
        try:
            client.connect(vm_ip, port, user, password)
            return self.__run_remote_cmd(client, cmd, timeout, output)
        except Exception as e:
            sys.exit(e.args[0])
        
    def __run_remote_cmd(self, client, cmd, timeout, output=True):
        chan = client.get_transport().open_session()
        chan.settimeout(timeout)
        chan.exec_command(cmd)
        rcode, std_out, std_err = self.__read_data_from_remote(chan)

        logger.unmute()
        if not output:
            return rcode, std_out, std_err

        logger.info(std_out)
        if std_err != "":
            logger.error(std_err)
            sys.exit(1)

        return rcode, std_out, std_err

    def __read_data_from_remote(self, chan):
        std_out = StringIO()
        std_err = StringIO()

        while not chan.exit_status_ready():
            if chan.recv_ready():    
                remote_std_out = chan.recv(1024)
                while remote_std_out:
                    std_out.write(remote_std_out.decode('utf-8'))
                    remote_std_out = chan.recv(1024)
            if chan.recv_stderr_ready():  
                remote_std_err = chan.recv_stderr(1024)
                while remote_std_err:
                    std_err.write(remote_std_err.decode('utf-8'))
                    remote_std_err = chan.recv_stderr(1024)
        else:
            if chan.recv_ready():    
                remote_std_out = chan.recv(1024)
                while remote_std_out:
                    std_out.write(remote_std_out.decode('utf-8'))
                    remote_std_out = chan.recv(1024)
            if chan.recv_stderr_ready():  
                remote_std_err = chan.recv_stderr(1024)
                while remote_std_err:
                    std_err.write(remote_std_err.decode('utf-8'))
                    remote_std_err = chan.recv_stderr(1024)
        rcode = chan.recv_exit_status()
        return rcode, std_out.getvalue(), std_err.getvalue()

    def get_vm_list(self):
        raise NotImplemented

    def get_vm_os_type(self, vm_name):
        if "win" in vm_name:
            return VIRTUAL_MACHINE_OS.WINDOWS
        else:
            return VIRTUAL_MACHINE_OS.LINUX

    def is_vm_exist(self, vm_name):
        return vm_name in self.get_vm_list()

    def is_vm_in_os(self, vm_name):
        if self.connect_failed_times > 0 and self.connect_failed_times % 20 == 0:
            logger.info(f'connect failed too many times, check virtual machine network please')
        if self.connect_failed_times > 200:
            sys.exit('connect failed too many times, check virtual machine network please')

        if not self.is_vm_running(vm_name):
            return False

        vm_ip = self.get_vm_ip_for_ssh(vm_name)
        if vm_ip == '':
            self.connect_failed_times += 1
            return False

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        vm_os_type = self.get_vm_os_type(vm_name)
        try:
            client.connect(vm_ip, 22, VM_USERNAME[vm_os_type], VM_PASSWORD[vm_os_type])
            client.close()
            return True
        except NoValidConnectionsError as e:
            self.connect_failed_times += 1
            return False

    def is_vm_running(self, vm_name):
        raise NotImplemented

    def reboot_vm(self, vm_name, timeout):
        raise NotImplemented

    def shutdown_vm(self, vm_name, timeout):
        raise NotImplemented

    def start_vm(self, vm_name, timeout):
        raise NotImplemented

    def undefine_vm(self, vm_name, timeout):
        raise NotImplemented

    def upload_to_vm(self, vm_name, src_path, dest_path, ssh_port=22):
        logger.info(f'upload file from <SUT>:{src_path} to <{vm_name}>:{dest_path}')
        self.__delete_known_hosts_file()
        if (ssh_port == 22) and (not self.is_vm_running(vm_name)):
            sys.exit(f'error: {vm_name} is not running')
        
        self.__sftp(vm_name, src_path, dest_path, get_from_remote=False, ssh_port=ssh_port)
        
    def __sftp(self, vm_name, src_path, dest_path, get_from_remote, ssh_port=22):
        if int(ssh_port) != 22:
            client = paramiko.Transport(('localhost', int(ssh_port)))
            client.connect(username='root', password='password')
            sftp = paramiko.SFTPClient.from_transport(client)
            if get_from_remote:
                sftp.get(src_path, dest_path)
            else:
                sftp.put(src_path, dest_path)
            client.close()
            return

        vm_ip = self.get_vm_ip_for_ssh(vm_name)
        client = paramiko.Transport((vm_ip, int(ssh_port)))
        vm_os_type = self.get_vm_os_type(vm_name)
        try:
            client.connect(username=VM_USERNAME[vm_os_type], password=VM_PASSWORD[vm_os_type])
        except Exception as e:
            sys.exit(e.args[0])
        sftp = paramiko.SFTPClient.from_transport(client)
        if get_from_remote:
            sftp.get(src_path, dest_path)
        else:
            sftp.put(src_path, dest_path)
        client.close()


class KVM(Hypervisor):
    def attatch_nic_to_vm(self, vm_name, domain_id, bus_id, slot_id, func_id):
        logger.info(f'attach new NIC to {vm_name}')
        self.__create_nic_xml_file(domain_id, bus_id, slot_id, func_id)

        cmd = self.cmd_builder.build_attach_nic_cmd(vm_name, NIC_FILENAME)
        rcode, _, std_err = self.sut.execute_shell_cmd(
            cmd, powershell=self.POWERSHELL)
        if rcode != 0:
            sys.exit(std_err)

    def connect_test(self, ssh_port):
        logger.info(f'try to connect to port {ssh_port}')
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        try:
            client.connect('localhost', int(ssh_port), 'root', 'password', timeout=1)
        except:
            sys.exit('connect failed')
        client.close()

    def create_vm_from_template(self, vm_name, template, ram_mb, disk_dir, vnic_type, timeout):
        logger.info(f'create virtual machine from template')

        disk_path = f'{disk_dir}/{vm_name}.qcow2'

        cmd = 'virt-install '
        cmd += '--import '
        cmd += f'--name {vm_name} '
        cmd += f'--memory {ram_mb} '
        cmd += f'--disk path={disk_path} '
        cmd += f'--network network=default,model={vnic_type} '
        cmd += '--os-variant generic '
        cmd += '--noautoconsole '
        cmd += '--graphics vnc,listen=0.0.0.0 '

        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout)
        if rcode != 0:
            sys.exit(std_err)
        
        while not self.is_vm_cpu_stable(vm_name):
            logger.info('waiting for vm calm down...')
            sleep(5)
        
    def detach_nic_from_vm(self, vm_name, domain_id, bus_id, slot_id, func_id):
        logger.info(f'detach NIC from {vm_name}')
        self.__create_nic_xml_file(domain_id, bus_id, slot_id, func_id)

        cmd = self.cmd_builder.build_detach_nic_cmd(vm_name, NIC_FILENAME)
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd)
        if rcode != 0:
            sys.exit(std_err)  

    def get_vm_list(self):
        logger.info('get the list of virtual machines')
        cmd = 'virsh list --all --name'
        rcode, std_out, std_err = self.sut.execute_shell_cmd(cmd)
        if rcode != 0:
            sys.exit(std_err)
        return std_out.strip().split('\n')

    def get_vm_ip_for_ssh(self, vm_name):
        cmd = f'virsh domifaddr {vm_name} | grep 192'
        _, out, _ = self.sut.execute_shell_cmd(cmd)
        if '192.168.122' in out:
            return out.strip().split()[-1][:-3]

    def is_vm_cpu_stable(self, vm_name):
        VCPU_NUM_INDEX = 3
        CPU_TIME_INDEX = 4
        TEST_TIMES = 10
        conn = libvirt.open('qemu:///system')
        domain = conn.lookupByName(vm_name)

        time_list = []
        cpu_time_list = []
        for i in range(TEST_TIMES):
            time_list.append(time())
            cpu_time_list.append(int(domain.info()[CPU_TIME_INDEX]))
            sleep(1)

        c_nums = int(domain.info()[VCPU_NUM_INDEX])
        usages = []
        for i in range(1, TEST_TIMES):
            t1, t2 = time_list[i - 1], time_list[i]
            c1, c2 = cpu_time_list[i - 1], cpu_time_list[i]
            usage = (c2 - c1) * 100 / ((t2 - t1) * c_nums * 1e9)
            usages.append(usage)

        span = 0
        for i in range(TEST_TIMES-2):
            span = usages[i + 1] - usages[i]
        span = int(span / TEST_TIMES)
        logger.info(f'span value: {span}')
        return span < 3

    def __get_vm_info(self, vm_name):
        cmd = self.cmd_builder.build_get_vm_info(vm_name)
        rcode, std_out, std_err = self.sut.execute_shell_cmd(
            cmd, powershell=self.POWERSHELL)
        if rcode != 0:
            sys.exit(std_err)

        info = {}
        lines = std_out.strip().split('\n')
        for line in lines:
            key, val = line.strip().split(':')
            info[key] = val.strip()
        return info

    def get_vm_nat_ip(self, vm_name):
        cmd = f'virsh domifaddr {vm_name} | grep 192'
        _, out, _ = self.sut.execute_shell_cmd(cmd)
        if '192.168.122' in out:
            return out.strip().split()[-1][:-3]

    def get_vm_list(self):
        logger.info('get the list of virtual machines')
        cmd = 'virsh list --all --name'
        rcode, std_out, std_err = self.sut.execute_shell_cmd(cmd)
        if rcode != 0:
            sys.exit(std_err)
        return std_out.strip().split('\n')

    def is_vm_in_os(self, vm_name):
        logger.info(f'check if {vm_name} have boot into OS')
        if not self.is_vm_running(vm_name):
            return False

        vm_ip = self.get_vm_nat_ip(vm_name)
        if not vm_ip:
            return False
            
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        try:
            vm_os_type = self.get_vm_os_type(vm_name)
            client.connect(vm_ip, 22, VM_USERNAME[vm_os_type], VM_PASSWORD[vm_os_type])
            client.close()
            return True
        except Exception as e:
            return False

    def is_vm_running(self, vm_name):
        cmd = f'virsh list | grep {vm_name}'
        _, std_out, _ = self.sut.execute_shell_cmd(cmd)
        return vm_name in std_out

    def reboot_vm(self, vm_name, timeout):
        logger.info(f'reboot {vm_name}')

        cmd = f'virsh reboot {vm_name}'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout)
        if rcode != 0:
            sys.exit(std_err)

        while not self.is_vm_cpu_stable(vm_name):
            logger.info(f'watting for {vm_name} cpu calm dowm...')
            sleep(3)
        while not self.is_vm_in_os(vm_name):
            logger.info(f'watting for {vm_name} reboot into OS...')
            sleep(3)
        # to avoid the VM still not boot into OS after SSH service started
        sleep(3)

    def shutdown_vm(self, vm_name, timeout):
        logger.info(f'shutdown {vm_name}')

        cmd = f'virsh shutdown {vm_name}'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout)
        if rcode != 0:
            sys.exit(std_err)
        
        remain_time = timeout
        while remain_time > 0 and self.is_vm_running(vm_name):
            logger.info(f'waiting for {vm_name} shut off...')
            self.sut.execute_shell_cmd(cmd)
            time.sleep(3)
            remain_time -= 3
        if remain_time <= 0:
            raise Exception(f'error: cannot shutdown {vm_name} in {timeout}s, try longer timeout please')
        time.sleep(3)
        logger.info(f'shutdown {vm_name} succeed')

    def start_vm(self, vm_name, timeout):
        logger.info(f'start {vm_name}')

        cmd = f'virsh start {vm_name}'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout)
        if rcode != 0:
            sys.exit(std_err)

        while not self.is_vm_cpu_stable(vm_name):
            logger.info(f'watting for {vm_name} cpu calm down...')
            sleep(3)

        while not self.is_vm_in_os(vm_name):
            logger.info(f'watting for {vm_name} boot into OS...')
            sleep(3)

    def undefine_vm(self, vm_name, timeout):
        logger.info(f'undefine {vm_name}')

        cmd = f'virsh undefine {vm_name} --remove-all-storage'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout)
        if rcode != 0:
            raise Exception(std_err)

    def __create_nic_xml_file(self, domain_id, bus_id, slot_id, func_id):
        content = '<hostdev mode="subsystem" type="pci" managed="yes">\n'
        content += '    <driver name="vfio"/>\n'
        content += '    <source>\n'
        content += f'        <address domain="{domain_id}" bus="{bus_id}" \
                                    slot="{slot_id}" function="{func_id}"/>\n'

        content += '    </source>\n'
        content += '</hostdev>\n'
        with open(NIC_FILENAME, 'w') as file:
            file.write(content)

    def __get_vm_info(self, vm_name):
        cmd = self.cmd_builder.build_get_vm_info(vm_name)
        rcode, std_out, std_err = self.sut.execute_shell_cmd(
            cmd, powershell=self.POWERSHELL)
        if rcode != 0:
            sys.exit(std_err)

        info = {}
        lines = std_out.strip().split('\n')
        for line in lines:
            key, val = line.strip().split(':')
            info[key] = val.strip()
        return info


class HyperV(Hypervisor):
    def create_vm_from_template(self, vm_name, template, ram_mb, disk_dir, switch, generation, timeout):
        logger.info(f'create virtual machine from template')

        disk_path = f'{disk_dir}\\{vm_name}.vhdx'

        cmd = 'NEW-VM '
        cmd += f'-Name {vm_name} '
        cmd += f'-VHDPath {disk_path} '
        cmd += f'-MemoryStartupBytes {int(ram_mb/1024)}GB '
        cmd += f'-SwitchName "{switch}" '
        cmd += f'-Generation {generation}; '
        cmd += f'Set-VMFirmware -VMName {vm_name} -EnableSecureBoot Off'

        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout, powershell=True)
        if rcode != 0:
            sys.exit(std_err)

    def get_vm_ip_for_ssh(self, vm_name):
        cmd = f'Get-VM -Name {vm_name} | Get-VMNetworkAdapter | Select IPAddresses | findstr :'
        rcode, std_out, std_err = self.sut.execute_shell_cmd(cmd, powershell=True)
        if rcode != 0:
            raise Exception(std_err)

        if std_out.strip() == '':
            return ''
        ip_lines = std_out.splitlines()
        for line in ip_lines:
            if '10.' in line:
                return line[1:-1].split(',')[0]
        return ''

    def get_vm_list(self):
        logger.info('get virtual machine list')
        return list(self.__get_vm_info_total().keys())

    def is_vm_cpu_stable(self, vm_name):
        return self.__get_vm_info_total()[vm_name][HYPERV_VM_INFO.CPU_USAGE] == 0

    def is_vm_exist(self, vm_name):
        return vm_name in self.__get_vm_info_total()

    def is_vm_running(self, vm_name):
        vm_info_all = self.__get_vm_info_total()
        return vm_info_all[vm_name][HYPERV_VM_INFO.STATE] == VM_STATUS.S0.WINDOWS

    def reboot_vm(self, vm_name, timeout):
        logger.info(f'reboot {vm_name}')

        cmd = f'Restart-VM -Name {vm_name} -Force'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout, powershell=True)
        if rcode != 0:
            sys.exit(std_err)

        while not self.is_vm_in_os(vm_name):
            logger.info(f'waiting for {vm_name} reboot into OS...')
            sleep(5)

    def shutdown_vm(self, vm_name, timeout):
        logger.info(f'shutdown {vm_name}')

        cmd = f'Stop-VM -Name {vm_name} -TurnOff -Force'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout, powershell=True)
        if rcode != 0:
            sys.exit(std_err)
        
        while self.is_vm_running(vm_name):
            logger.info(f'watting for {vm_name} shutdown...')
            sleep(3)

    def start_vm(self, vm_name, timeout):
        logger.info(f'start {vm_name}')

        cmd = f'Start-VM -Name {vm_name}'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout, powershell=True)
        if rcode != 0 or std_err.strip() != "":
            sys.exit(std_err)
        
        while not self.is_vm_cpu_stable(vm_name):
            logger.info(f'waiting for {vm_name} cpu calm down')
            sleep(3)
        
        while not self.is_vm_in_os(vm_name):
            logger.info(f'waiting for {vm_name} boot into os')
            sleep(3)
        
    def __get_vm_info_total(self):
        rcode, std_out, std_err = self.sut.execute_shell_cmd('Get-VM', powershell=True)
        if rcode != 0:
            sys.exit(std_err)
        
        line_list = std_out.strip().split('\n')[2:]
        vm_info = {}
        for line in line_list:
            items = line.split()
            Name, State, CPUUsage, Memory = items[:-4]
            vm_info[Name] = [Name, State, int(CPUUsage), int(Memory)]
        
        return vm_info

    def undefine_vm(self, vm_name, timeout):
        cmd = f'Get-VM -VMName {vm_name} | Select-Object -Property VMId | Get-VHD | findstr vhdx'
        rcode, std_out, std_err = self.sut.execute_shell_cmd(cmd, powershell=True)
        disk_path = std_out.split()[2]

        cmd = f'Remove-VM -Name {vm_name} -Force'
        rcode, _, std_err = self.sut.execute_shell_cmd(cmd, timeout, powershell=True)
        if rcode != 0:
            raise Exception(std_err)

        cmd = f'del {disk_path}'
        self.sut.execute_shell_cmd(cmd, powershell=True)


def get_vmmanger(sut):
    # type: (SUT) -> Hypervisor
    if sut.sutplatform == SUT_PLATFORM.LINUX:
        return KVM(sut)
    elif sut.sutplatform == SUT_PLATFORM.WINDOWS:
        return HyperV(sut)
    else:
        return ESXi(sut)
