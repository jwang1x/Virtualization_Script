from logging import log
import sys


class Logger:
    def __init__(self) -> None:
        self.output = True

    def info(self, message):
        if self.output:
            print(message, file=sys.stdout)
    
    def error(self, message):
        if self.output:
            print(message, file=sys.stderr)
    
    def mute(self):
        self.output = False
    
    def unmute(self):
        self.output = True

logger = Logger()