import sys
import traceback
import subprocess

from log import logger
from const import SUT_PLATFORM

class SUT:
    def __init__(self, os_type):
        if os_type not in [SUT_PLATFORM.WINDOWS, SUT_PLATFORM.LINUX]:
            err_info = f'cannot find SUT OS Type {os_type}'
            logger.error(err_info)
            sys.exit(err_info)
        self.sutplatform = os_type

    def execute_shell_cmd(self, cmd, timeout=30, cwd=None, powershell=False, output=True):
        has_timeout = False
        res = None
        try:
            if self.sutplatform == SUT_PLATFORM.WINDOWS and cwd is not None and cwd.find(' ') > -1:
                workaround_cmd = f'cd {cwd} && {cmd}'
                res = self.__execute_shell_cmd(workaround_cmd, timeout, None, powershell, output)
            else:
                res = self.__execute_shell_cmd(cmd, timeout, cwd, powershell, output)
        except TimeoutError as e:
            logger.info('ignore timeout issue, as SSH service may get down before DTAF function return')
            logger.info('cmd [{}]'.format(cmd))
            err_info = str(traceback.format_exc())
            logger.error(err_info)
            has_timeout = True

        if has_timeout:
            return None
        else:
            return res
    
    def __execute_shell_cmd(self, cmd, timeout, cwd, powershell, output):
        if powershell:
            assert(self.sutplatform == SUT_PLATFORM.WINDOWS)
            cmd = cmd.replace('\"', '\'')
            cmd = 'PowerShell -Command "& {' + cmd + '}"'

        child = subprocess.run(cmd, 
                           shell=True,
                           stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE,
                           check=False,
                           timeout=timeout,
                           cwd=cwd)
        res = child.returncode, child.stdout.decode(), child.stderr.decode()
        if output:
            logger.info(f'SUT execute cmd: {cmd}')
            logger.info(f'SUT execute stdout: {child.stdout.decode().strip()}')
            logger.info(f'SUT execute stderr: {child.stderr.decode().strip()}')

        return res


def get_sut(os_type):
    try:
        sut = SUT(os_type)
    except ValueError as e:
        err_info = str(traceback.format_exc())
        logger.error(err_info)
        logger.info('check the input parameter in get_sut please')
    return sut
