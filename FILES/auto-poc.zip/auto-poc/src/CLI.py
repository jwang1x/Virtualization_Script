import argparse
from const import SUT_PLATFORM

class Parser:
    def __init__(self):
        desc = "Arguments for talking with hypervisior"
        self.parser = argparse.ArgumentParser(description=desc)
        self.add_arguments(Argument.COMMAND, Argument.OS_TYPE)
    
    def get_args(self):
        args = self.parser.parse_args()
        return args
    
    def add_arguments(self, *args):
        for arg in args:
            name_or_flags = arg["name_or_flags"]
            options = arg["options"]
            options["required"] = False
            self.parser.add_argument(*name_or_flags, **options)

    
class Argument:
    def __init__(self):
        pass

    COMMAND = {
        "name_or_flags": ["--command"],
        "options": {
            "action": "store",
            "choices": [
                "connect_test",
                "create_vm_from_template",
                "download_from_vm",
                "execute_vm_cmd",
                "reboot_vm",
                "shutdown_vm",
                "start_vm",
                "undefine_vm",
                "upload_to_vm"
            ],
            "help": "The action going to be taken by hypervisior"
        }
    }

    DEST_PATH = {
        "name_or_flags": ["--dest-path"],
        "options": {"action": "store", "help": "The dest file path"}
    }

    NEW_VM_NAME = {
        "name_or_flags": ["--new-vm-name"],
        "options": {
            "action": "store", 
            "help": "The new name of virtual machine"
        }
    }

    OS_TYPE = {
        "name_or_flags": ["--os-type"],
        "options": {
            "action": "store",
            "choices": [SUT_PLATFORM.LINUX, SUT_PLATFORM.WINDOWS, SUT_PLATFORM.ESXi],
            "help": "The OS type of SUT"
        }
    }

    SOURCE_PATH = {
        "name_or_flags": ["--src-path"],
        "options": {"action": "store", "help": "The source file path"}
    }

    TEMPLATE = {
        "name_or_flags": ["--template"],
        "options": {"action": "store", "help": "The template file path"}
    }

    TIMEOUT = {
        "name_or_flags": ["--timeout"],
        "options": {"action": "store", "help": "The timeout for one API"}
    }

    VM_COMMAND = {
        "name_or_flags": ["--vm-command"],
        "options": {
            "action": "store", 
            "help": "The command will be executed in virtual machine"
        }
    }

    VM_DISK_DIR = {
        "name_or_flags": ["--disk-dir"],
        "options": {"action": "store", "help": "The directory to save disk file"}
    }

    VM_DISK_NAME = {
        "name_or_flags": ["--disk-name"],
        "options": {"action": "store", "help": "The disk name in VM OS"}
    }

    VM_DISK_SIZE = {
        "name_or_flags": ["--disk-size"],
        "options": {
            "action": "store", 
            "help": "The disk size of virtual machine, in GB"
        }
    }

    VM_MEMORY = {
        "name_or_flags": ["--memory"],
        "options": {
            "action": "store", 
            "help": "The memory of virtual machine, in MB"
        }
    }

    VM_NAME = {
        "name_or_flags": ["--vm-name"],
        "options": {"action": "store", "help": "The name of virtual machine"}
    }

    SSH_PORT = {
        "name_or_flags": ["--ssh-port"],
        "options": {"action": "store", "help": "The ssh port of virtual machine"}
    }

    SWITCH = {
        "name_or_flags": ["--switch-name"],
        "options": {"action": "store", "help": "The name of virtual switch"}
    }

    VNIC_TYPE = {
        "name_or_flags": ["--vnic-type"],
        "options": {"action": "store", "help": "The virtual NIC type"}
    }

    GENERATION = {
        "name_or_flags": ["--generation"],
        "options": {"action": "store", "help": "The generation of virtual machine"}
    }


if __name__=="__main__":
    parser = Parser()
    args = parser.get_args()
    print(args.os_type, args.command)
    
    
