class SUT_PLATFORM:
    LINUX = 'LINUX'
    WINDOWS = 'WINDOWS'
    ESXi = 'ESXi'

class VIRTUAL_MACHINE_OS:
    LINUX = 'LINUX'
    WINDOWS = 'WINDOWS'

class VM_STATUS:
    class S0:
        LINUX = 'running'
        WINDOWS = 'Running'
    
    class S5:
        LINUX = 'shut off'
        WINDOWS = 'Off'
    
class KVM_VM_INFO:
    ID = 'Id'
    NAME = 'Name'
    UUID = 'UUID'
    OS_TYPE = 'OS Type'
    STATE = 'State'
    CPU_NUM = 'CPU(s)'
    MAX_MEMORY = 'Max memory'
    USED_MEMORY = 'Used memory'
    IS_PERSISTENT = 'Persistent'
    IS_AUTOSTART = 'Autostart'
    ENABLE_AUTOSTART = 'enable'
    DISABLE_AUTOSTART = 'disable'

class HYPERV_VM_INFO:
    NAME = 0
    STATE = 1
    CPU_USAGE = 2
    MEMORY = 3

NIC_FILENAME = 'temp_nic.xml'

SUT_TOOLS_LINUX_VIRTUALIZATION = '/home/BKCPkg/domains/virtualization'
SUT_TOOLS_LINUX_VIRTUALIZATION_IMGS = f'{SUT_TOOLS_LINUX_VIRTUALIZATION}/imgs'
SUT_TOOLS_LINUX_VIRTUALIZATION_AUTO_PROJ = f'{SUT_TOOLS_LINUX_VIRTUALIZATION}/auto-poc'

SUT_TOOLS_WINDOWS_VIRTUALIZATION = 'C:\\BKCPkg\\domains\\virtualization'
SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS = f'{SUT_TOOLS_WINDOWS_VIRTUALIZATION}\\imgs'
SUT_TOOLS_WINDOWS_VIRTUALIZATION_AUTO_PROJ = f'{SUT_TOOLS_WINDOWS_VIRTUALIZATION}\\auto-poc'

VM_USERNAME = {VIRTUAL_MACHINE_OS.LINUX: 'root', VIRTUAL_MACHINE_OS.WINDOWS: 'administrator'}
VM_PASSWORD = {VIRTUAL_MACHINE_OS.LINUX: 'password', VIRTUAL_MACHINE_OS.WINDOWS: 'intel@123'}