# import subprocess
# from logger import logger

# NO_ERROR = ""

# def execute_sut_cmd(cmd, timeout=10, cwd=None):    
#     logger.debug(f"Executing command `{cmd}`")
#     child = subprocess.Popen(cmd,
#                              shell=True,
#                              stdin=subprocess.PIPE,
#                              stdout=subprocess.PIPE,
#                              stderr=subprocess.PIPE,
#                              cwd=cwd)

#     out, err = child.communicate(timeout=timeout)
#     return out.decode(encoding='utf-8'), err.decode(encoding='utf-8')


# def execute_sut_cmd_sync(cmd, timeout=10, cwd=None):
#     logger.debug(f"Executing sync command `{cmd}`")
#     child = subprocess.run(cmd, 
#                            shell=True,
#                            stdin=subprocess.PIPE,
#                            stdout=subprocess.PIPE,
#                            stderr=subprocess.PIPE,
#                            check=True,
#                            timeout=timeout,
#                            cwd=cwd)
#     out, err = child.stdout.decode(), child.stderr.decode()
#     return out, err


# def raise_exception_if_error(cmd, err_msg):
#     if err_msg.strip() != NO_ERROR:
#         logger.error(f"Execute command `{cmd}` failed\n{err_msg}")
#         raise Exception(err_msg)
#     logger.debug(f"Execute command `{cmd}` succeed")

# if __name__=="__main__":
#     out, err = execute_sut_cmd_sync("sleep 5")
#     print("output:\n{}".format(out))
#     print("error: ", err)