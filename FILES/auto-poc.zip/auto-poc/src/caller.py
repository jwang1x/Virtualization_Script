from argparse import ArgumentDefaultsHelpFormatter
from os import stat
import sys
from log import logger
from CLI import Parser, Argument
from Hypervisior import get_vmmanger
from Sut import get_sut


class Caller:
    def __init__(self):
        self.needed_arguments = {
            'connect_test_LIN': [
                Argument.SSH_PORT
            ],
            'create_vm_from_template_LIN': [
                Argument.NEW_VM_NAME, 
                Argument.TEMPLATE, 
                Argument.VM_MEMORY,
                Argument.VM_DISK_DIR,
                Argument.VNIC_TYPE,
                Argument.TIMEOUT
            ],
            'create_vm_from_template_WIN': [
                Argument.NEW_VM_NAME, 
                Argument.TEMPLATE, 
                Argument.VM_MEMORY,
                Argument.VM_DISK_DIR,
                Argument.SWITCH,
                Argument.GENERATION,
                Argument.TIMEOUT
            ],

            'download_from_vm_LIN': [
                Argument.VM_NAME, Argument.SOURCE_PATH, Argument.DEST_PATH, Argument.SSH_PORT
            ],

            'download_from_vm_WIN': [
                Argument.VM_NAME, Argument.SOURCE_PATH, Argument.DEST_PATH, Argument.SSH_PORT
            ],

            'execute_vm_cmd_LIN': [
                Argument.VM_NAME, Argument.VM_COMMAND, Argument.TIMEOUT, Argument.SSH_PORT
            ],
            'execute_vm_cmd_WIN': [
                Argument.VM_NAME, Argument.VM_COMMAND, Argument.TIMEOUT, Argument.SSH_PORT
            ],

            'reboot_vm_LIN': [Argument.VM_NAME, Argument.TIMEOUT],
            'reboot_vm_WIN': [Argument.VM_NAME, Argument.TIMEOUT],

            'start_vm_LIN': [Argument.VM_NAME, Argument.TIMEOUT],
            'start_vm_WIN': [Argument.VM_NAME, Argument.TIMEOUT],

            'upload_to_vm_LIN': [
                Argument.VM_NAME, Argument.SOURCE_PATH, Argument.DEST_PATH, Argument.SSH_PORT
            ],
            'upload_to_vm_WIN': [
                Argument.VM_NAME, Argument.SOURCE_PATH, Argument.DEST_PATH, Argument.SSH_PORT
            ]
        }

        self.arg_to_name = {
            Argument.VM_NAME['name_or_flags'][0]: 'args.vm_name',
            Argument.NEW_VM_NAME['name_or_flags'][0]: 'args.new_vm_name',
            Argument.TEMPLATE['name_or_flags'][0]: 'args.template', 
            Argument.VM_COMMAND['name_or_flags'][0]: 'args.vm_command',
            Argument.VM_MEMORY['name_or_flags'][0]: 'args.memory',
            Argument.VM_DISK_DIR['name_or_flags'][0]: 'args.disk_dir',
            Argument.TIMEOUT['name_or_flags'][0]: 'args.timeout',
            Argument.SOURCE_PATH['name_or_flags'][0]: 'args.src_path', 
            Argument.DEST_PATH['name_or_flags'][0]: 'args.dest_path',
            Argument.SSH_PORT['name_or_flags'][0]: 'args.ssh_port',
            Argument.SWITCH['name_or_flags'][0]: 'args.switch_name',
            Argument.VNIC_TYPE['name_or_flags'][0]: 'args.vnic_type'
        }
    
    def call_api(self, api_name):
        parser = Parser()
        parser.add_arguments(*self.needed_arguments[api_name])
        args = parser.get_args()

        sut_os_type = args.os_type
        vmm = get_vmmanger(get_sut(sut_os_type))

        if args.command == 'execute_vm_cmd':
            logger.mute()

        statement = self.__get_api_with_args(api_name)
        try:
            exec(statement)
        except Exception as e:
            sys.exit(e.args[0])
    
    def __get_api_with_args(self, api_name):
        statement = f'vmm.{api_name[:-4]}('
        for arg in self.needed_arguments[api_name]:
            arg_name = arg['name_or_flags'][0]
            if arg in [Argument.TIMEOUT, Argument.VM_MEMORY]:
                statement += f'int({self.arg_to_name[arg_name]}),'
            else:
                statement += self.arg_to_name[arg_name] + ','
        statement = statement[:-1] + ')'
        return statement

if __name__ == "__main__":
    caller = Caller()
    for api in caller.needed_arguments:
        os_type = sys.argv[2]
        api_with_os = api[:-4] + "_" + sys.argv[2][:3]
        if api[:-4] in sys.argv:
            logger.info(f"calling api: {api_with_os}")
            caller.call_api(api_with_os)
            break
    else:
        logger.error("error: Cannot match command in parameters")
        sys.exit("error: Cannot match command in parameters")