from auto_path import *
from util import *


name = "rhel1"
file_name = "/root/Documents/test_execute_vm_cmd.txt"
cmd_create_file = f"touch {file_name}"
cmd_count_file = f"ls -al {file_name} | wc -l"
cmd_delete_file = f"rm -f {file_name}"
cmd_wrong = "cmd_wrong"
timeout = 600

class TestExecuteVMCmd(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.WINDOWS)
        self.vmm = get_vmmanger(self.sut)
        # shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        # shutdown_vm_if_running(self.vmm, name)
        pass
    
    # @unittest.skip("Passed Cases")
    def test_execute_vm_cmd(self):
        # build
        # self.vmm.start_vm(name, timeout)
        # operate
        self.vmm.execute_vm_cmd(name, cmd_create_file, timeout)
        # check
        _, out, _ = self.vmm.execute_vm_cmd(name, cmd_count_file, timeout)
        self.assertEqual(out.strip(), "1")
        # restore
        self.vmm.execute_vm_cmd(name, cmd_delete_file, timeout)
        # self.vmm.shutdown_vm(name, timeout)
    
    @unittest.skip("Passed Cases")
    def test_execute_ifconfig(self):
        # build
        self.vmm.start_vm(name, timeout)
        # operate
        rcode, std_out, std_err = self.vmm.execute_vm_cmd(name, 'ifconfig', timeout)
        # check
        self.assertFalse('10.239' in std_out.strip())
        # restore
        self.vmm.execute_vm_cmd(name, cmd_delete_file, timeout)
        self.vmm.shutdown_vm(name, timeout)
    
    @unittest.skip("Passed Cases")
    def test_execute_vm_cmd_with_wrong_cmd(self):
        # build
        self.vmm.start_vm(name, timeout)
        # operate
        _, out, err = self.vmm.execute_vm_cmd(name, cmd_wrong, timeout)
        # check
        self.assertEqual(out.strip(), "")
        print(err)
        # restore
        self.vmm.shutdown_vm(name, timeout)

if __name__ == "__main__":
    unittest.main(verbosity=2)

