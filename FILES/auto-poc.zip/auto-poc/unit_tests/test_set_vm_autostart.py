from auto_path import *
from util import *


name = "rhel1"
timeout = 600

class TestSetAutostart(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        self.__clean_up()
    
    def tearDown(self) -> None:
        self.__clean_up()

    def __clean_up(self):
        if self.vmm.is_vm_autostart(name):
            self.vmm.set_vm_unautostart(name)
        shutdown_vm_if_running(self.vmm, name)

    def test_set_vm_autostart(self):
        # build
        self.vmm.start_vm(name, timeout)
        is_auto_start = self.vmm.is_vm_autostart(name)
        # operate
        self.vmm.set_vm_autostart(name)
        # check
        self.assertEqual(False, is_auto_start)
        self.assertEqual(True, self.vmm.is_vm_autostart(name))
        # restore
        self.vmm.set_vm_unautostart(name)
        self.vmm.shutdown_vm(name, timeout)

if __name__ == "__main__":
    unittest.main(verbosity=2)

