    from auto_path import *
    from util import *


    QEMU_TEST = False
    name = 'rhel1'
    new_name = 'rhel2'
    if PLATFORM == SUT_PLATFORM.LINUX:
        base_cmd = f'python {SUT_TOOLS_LINUX_VIRTUALIZATION_AUTO_PROJ}/src/caller.py --os-type {PLATFORM} '
        template = f'{SUT_TOOLS_LINUX_VIRTUALIZATION_IMGS}/rhel0.qcow2'
        disk_dir = SUT_TOOLS_LINUX_VIRTUALIZATION_IMGS
    else:
        base_cmd = f'python {SUT_TOOLS_WINDOWS_VIRTUALIZATION_AUTO_PROJ}\\src\\caller.py --os-type {PLATFORM} '
        template = f'{SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS}\\template.vhdx'
        disk_dir = SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS
    timeout = 600

    class TestCaller(unittest.TestCase):
        def setUp(self) -> None:
            self.sut = get_sut(PLATFORM)
            if QEMU_TEST:
                return
            if not sys.warnoptions:
                import warnings
                warnings.simplefilter('ignore')
            self.vmm = get_vmmanger(self.sut)
            shutdown_vm_if_running(self.vmm, name)
            if self.vmm.is_vm_exist(new_name):
                self.vmm.undefine_vm(new_name, timeout)
        
        def tearDown(self) -> None:
            if QEMU_TEST:
                return
            shutdown_vm_if_running(self.vmm, name)
            if self.vmm.is_vm_exist(new_name):
                self.vmm.undefine_vm(new_name, timeout)
            pass

        # @unittest.skip("Passed")
        def test_call_create_vm_from_template(self):
            # build
            old_vm_list = self.vmm.get_vm_list()
            # operate
            cmd = base_cmd
            cmd += f'--command create_vm_from_template '
            cmd += f'--new-vm-name {new_name} '
            cmd += f'--template {template} '
            cmd += f'--memory 4096 '
            cmd += f'--disk-dir /home/imgs '
            cmd += f'--switch-name \"New Virtual Switch\" '
            cmd += f'--timeout 600'
            code, _, err = self.sut.execute_shell_cmd(cmd, timeout=timeout)
            # check
            if code != 0:
                raise Exception(err)
            new_vm_list = self.vmm.get_vm_list()
            self.assertNotIn(new_name, old_vm_list)
            self.assertIn(new_name, new_vm_list)
            # restore
            self.vmm.undefine_vm(new_name, timeout)

        @unittest.skip('Passed')
        def test_call_download_from_vm(self):
            # build
            src_file_name = '/root/Documents/test.txt'
            dest_file_name = '/root/Documents/test.txt'
            file_content = 'This is the test information'
            cmd = f'touch {src_file_name} & echo {file_content} > {src_file_name}'
            self.vmm.start_vm(name, timeout)
            self.vmm.execute_vm_cmd(name, cmd, timeout)
            # operate
            cmd = base_cmd
            cmd += f'--command download_from_vm '
            cmd += f'--vm-name {name} '
            cmd += f'--src-path {src_file_name} '
            cmd += f'--dest-path {dest_file_name}'
            code, _, err = self.sut.execute_shell_cmd(cmd, timeout=timeout)
            # check
            if code != 0:
                raise Exception(err)
            _, out, _ = self.sut.execute_shell_cmd(f'cat {dest_file_name}', timeout)
            self.assertEqual(out.strip(), file_content)
            # restore
            self.vmm.execute_vm_cmd(name, f'rm -f {src_file_name}', timeout)
            code, _, err = self.sut.execute_shell_cmd(f'rm -f {dest_file_name}', timeout)
            if code != 0:
                raise Exception(err)
            self.vmm.shutdown_vm(name, timeout)

        @unittest.skip('Passed')
        def test_call_execute_vm_cmd(self):
            # build
            self.vmm.start_vm(name, timeout)
            file_name = '/root/Documents/test_execute_vm_cmd.txt'
            cmd_create_file = f'touch {file_name}'
            cmd_count_file = f'ls -al {file_name} | wc -l'
            cmd_delete_file = f'rm -f {file_name}'
            # operate
            cmd = base_cmd
            cmd += f'--command execute_vm_cmd '
            cmd += f'--vm-name {name} '
            cmd += f'--vm-command "{cmd_create_file}" '
            cmd += f'--timeout {timeout}'
            code, out, err = self.sut.execute_shell_cmd(cmd, timeout=timeout)
            # check
            code, out, _ = self.vmm.execute_vm_cmd(name, cmd_count_file, timeout)
            self.assertEqual(out.strip(), '1')
            # restore
            self.vmm.execute_vm_cmd(name, cmd_delete_file, timeout)
            self.vmm.shutdown_vm(name, timeout)

        @unittest.skip('Passed')
        def test_call_reboot_vm(self):
            # build
            self.vmm.start_vm(name, timeout)
            # operate
            cmd = base_cmd
            cmd += f'--command reboot_vm '
            cmd += f'--vm-name {name} '
            cmd += f'--timeout {timeout}'
            code, _, err = self.sut.execute_shell_cmd(cmd, timeout=timeout)
            # check
            if code != 0:
                raise Exception(err)
            self.assertTrue(self.vmm.is_vm_in_os(name))
            # restore
            self.vmm.shutdown_vm(name, timeout)

        @unittest.skip('Passed')
        def test_call_shutdown_vm(self):
            # build
            self.vmm.start_vm(name, timeout)
            old_state = self.vmm.is_vm_in_os(name)
            # operate
            cmd = base_cmd
            cmd += '--command shutdown_vm '
            cmd += f'--vm-name {name} '
            cmd += f'--timeout {timeout}'
            code, _, err = self.sut.execute_shell_cmd(cmd, 300)
            # check
            if code != 0:
                raise Exception(err)
            self.assertNotEqual(old_state, self.vmm.is_vm_in_os(name))
            # restore

        @unittest.skip('Passed')
        def test_call_start_vm(self):
            # build
            old_state = self.vmm.is_vm_in_os(name)
            # operate
            cmd = base_cmd
            cmd += '--command start_vm '
            cmd += f'--vm-name {name} '
            cmd += f'--timeout {timeout}'
            code, _, err = self.sut.execute_shell_cmd(cmd, 300)
            # check
            if code != 0:
                raise Exception(err)
            self.assertNotEqual(old_state, self.vmm.is_vm_in_os(name))
            # restore
            self.vmm.shutdown_vm(name, timeout)

        @unittest.skip('Passed')
        def test_call_undefine_vm(self):
            # build
            self.vmm.create_vm_from_template(new_name, template, 4096, disk_dir, timeout)
            old_vm_list = self.vmm.get_vm_list()
            # operate
            cmd = base_cmd
            cmd += '--command undefine_vm '
            cmd += f'--vm-name {new_name} '
            cmd += f'--timeout 300'
            code, _, err = self.sut.execute_shell_cmd(cmd, 300)
            # check
            if code != 0:
                raise Exception(err)
            new_vm_list = self.vmm.get_vm_list()
            self.assertIn(new_name, old_vm_list)
            self.assertNotIn(new_name, new_vm_list)
            # restore

        @unittest.skip('Passed')
        def test_call_upload_to_vm(self):
            # build
            src_file_name = '/root/Documents/test.txt'
            dest_file_name = '/root/Documents/test.txt'
            file_content = 'This is the test information'
            self.vmm.start_vm(name, timeout)
            code, _, err = self.sut.execute_shell_cmd(f'touch {src_file_name} && echo {file_content} > {src_file_name}', timeout)
            # operate
            if code != 0:
                raise Exception(err)
            cmd = base_cmd
            cmd += '--command upload_to_vm '
            cmd += f'--vm-name {name} '
            cmd += f'--src-path {src_file_name} '
            cmd += f'--dest-path {dest_file_name} '
            cmd += f'--ssh-port 22 '
            code, _, err = self.sut.execute_shell_cmd(cmd, 300)
            # check
            if code != 0:
                raise Exception(err)
            code, out, _ = self.vmm.execute_vm_cmd(name, f'ls -al {dest_file_name} | wc -l', timeout)
            self.assertEqual(out.strip(), '1')
            # restore
            self.vmm.execute_vm_cmd(name, f'rm -rf {dest_file_name}', timeout)
            code, _, err = self.sut.execute_shell_cmd(f'rm -rf {src_file_name}', timeout)
            if code != 0:
                raise Exception(err)
            self.vmm.shutdown_vm(name, timeout)
            
        
        @unittest.skip('Passed')
        def test_call_connect_test(self):
            # build
            # operate
            cmd = base_cmd
            cmd += '--command connect_test '
            cmd += f'--ssh-port 2223'
            code, out, err = self.sut.execute_shell_cmd(cmd, 300)
            # check
            print(err)
            self.assertEqual(code, 0)
            # restore

        @unittest.skip('Passed')
        def test_execute_cmd_in_qemu_vm(self):
            # build
            name = 'vm'
            file_name = '/root/Documents/test_execute_vm_cmd.txt'
            cmd_create_file = f'touch {file_name}'
            cmd_count_file = f'ls -al {file_name} | wc -l'
            # operate
            cmd = base_cmd
            cmd += f'--command execute_vm_cmd '
            cmd += f'--vm-name {name} '
            cmd += f'--vm-command "{cmd_create_file}" '
            cmd += f'--timeout {timeout} '
            cmd += f'--ssh-port 2222'
            code, out, err = self.sut.execute_shell_cmd(cmd, timeout=timeout)
            # check
            print(code, out, err)


    if __name__ == '__main__':
        unittest.main(verbosity=2)

