class parent:
    def say(self):
        self.laugh()
        print('who are you')

    def laugh(self):
        raise NotImplemented


class son(parent):
    def laugh(self):
        print('hhhhhhh')


s = son()
s.say()