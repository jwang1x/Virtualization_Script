from unittest import result
from pip import main
from auto_path import *


def split_results(line_list):
    results = []
    item = []
    for line in line_list:
        if line != "":
            item.append(line)
        else:
            results.append('\n'.join(item))
            item = []
    results.append('\n'.join(item))
    return results


def find_item_with_twice_search(cmd1, keyword, cmd2):
    _, out, _ = sut.execute_shell_cmd(cmd1, powershell=True)
    line_list = out.strip().splitlines()
    results = split_results(line_list)
    target_i = -1
    for i in range(len(results)):
        if keyword in results[i]:
            target_i = i
            break
    if target_i == -1:
        raise Exception(f"error: cannot find {keyword} with command {cmd1} which output is\n{out}")
    
    _, out, _ = sut.execute_shell_cmd(cmd2, powershell=True)
    line_list = out.strip().splitlines()
    result = split_results(line_list)
    target_item = result[target_i]
    target_item_value = target_item.split(" : ")[1].strip()
    return target_item_value


if __name__=="__main__":
    sut = get_sut(PLATFORM)

    vm = "rhel1"
    interface_desc = "X710-T2L"

    first_cmd = f"Get-VMSwitch | fl -Property Name, NetAdapterInterfaceDescription"
    second_cmd = f"Get-VMSwitch | fl -Property Name"
    switch_name = find_item_with_twice_search(first_cmd, interface_desc, second_cmd)
    print(switch_name)

    first_cmd = f"Get-VM -Name {vm} | Get-VMNetworkAdapter | fl -Property SwitchName, IPAddresses"
    second_cmd = f"Get-VM -Name {vm} | Get-VMNetworkAdapter | fl -Property IPAddresses"
    ip_mac_pair = find_item_with_twice_search(first_cmd, switch_name, second_cmd)
    
    ip = ip_mac_pair[1:-1].split(",")[0]
    print(ip)
