from auto_path import *
from util import *


name = "rhel1"
timeout = 600


class TestShutdownVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    @unittest.skip("Passed Cases")
    def test_shutdown_vm_with_vm_shutoff_should_failed(self):
        # build
        is_in_os = self.vmm.is_vm_in_os(name)
        # operate
        shutdown_vm_if_running(self.vmm, name)
        # check
        self.assertEqual(is_in_os, self.vmm.is_vm_in_os(name))
        # restore
    
    def test_shutdown_vm(self):
        # build
        self.vmm.start_vm(name, 600)
        is_in_os = self.vmm.is_vm_in_os(name)
        # operate
        self.vmm.shutdown_vm(name, 600)
        # check
        self.assertNotEqual(is_in_os, self.vmm.is_vm_in_os(name))
        # restore


if __name__ == "__main__":
    unittest.main(verbosity=2)

