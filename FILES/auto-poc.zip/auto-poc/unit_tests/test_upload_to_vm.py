from auto_path import *
from util import *


name = "rhel1"
src_file_name = "/root/Documents/test.txt"
dest_file_name = "/root/Documents/test.txt"
file_content = "This is the test information"
timeout = 600


class TestUploadToVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    def test_upload_to_vm(self):
        # build
        self.vmm.start_vm(name, 600)
        self.sut.execute_shell_cmd(f"touch {src_file_name} && echo {file_content} > {dest_file_name}")
        # operate
        self.vmm.upload_to_vm(name, src_file_name, dest_file_name)
        # check
        _, out, _ = self.vmm.execute_vm_cmd(name, f"ls -al {dest_file_name} | wc -l", timeout)
        self.assertEqual(out.strip(), "1")
        # restore
        self.vmm.execute_vm_cmd(name, f"rm -rf {dest_file_name}", timeout)
        self.sut.execute_shell_cmd(f"rm -rf {src_file_name}")
        self.vmm.shutdown_vm


if __name__ == "__main__":
    unittest.main(verbosity=2)

