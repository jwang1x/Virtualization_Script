from auto_path import *
from util import *


name = "rhel1"
src_file_name = "/root/Documents/test.txt"
dest_file_name = "/root/Documents/test.txt"
file_content = "This is the test information"
timeout = 600

class TestDownloadFromVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    def test_download_from_vm(self):
        # build
        cmd = f"touch {src_file_name} & echo {file_content} > {src_file_name}"
        self.vmm.start_vm(name, 600)
        self.vmm.execute_vm_cmd(name, cmd, timeout)
        # operate
        self.vmm.download_from_vm(name, src_file_name, dest_file_name, 22)
        # check
        _, out, _ = self.sut.execute_shell_cmd(f"cat {dest_file_name}")
        self.assertEqual(out.strip(), file_content)
        # restore
        self.vmm.execute_vm_cmd(name, f"rm -f {src_file_name}", timeout)
        self.sut.execute_shell_cmd(f"rm -f {dest_file_name}")
        self.vmm.shutdown_vm(name, 600)
    
    @unittest.skip('Passed Cases')
    def test_download_from_vm_with_src_file_unexist(self):
        # build
        self.vmm.start_vm(name, 600)
        # operate
        download_from_vm_ignore_error(self.vmm, name, src_file_name, dest_file_name, 22)
        # check
        _, out, _ = self.sut.execute_shell_cmd(f"ls -al {dest_file_name} | wc -l")
        self.assertNotEqual(out.strip(), file_content)
        # restore
        self.vmm.shutdown_vm(name, 600)


if __name__ == "__main__":
    unittest.main(verbosity=2)

