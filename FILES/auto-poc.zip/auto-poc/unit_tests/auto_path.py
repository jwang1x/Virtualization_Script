import os
from platform import system
import sys
import unittest

cur_dir = os.path.dirname(__file__)
work_dir = os.path.dirname(cur_dir)
src_dir = os.path.join(work_dir, "src")

sys.path.append(work_dir)
sys.path.append(src_dir)

from src.Hypervisior import *
from src.Sut import get_sut
from src.const import *

error_log_file = os.path.join(work_dir, "log/log.txt")

if system().lower() == 'windows':
    PLATFORM = SUT_PLATFORM.WINDOWS
else:
    PLATFORM = SUT_PLATFORM.LINUX