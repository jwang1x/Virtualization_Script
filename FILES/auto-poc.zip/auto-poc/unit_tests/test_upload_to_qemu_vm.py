from auto_path import *
from util import *


name = 'vm'
ssh_port = 2222
base_cmd = f'python {SUT_TOOLS_LINUX_VIRTUALIZATION_AUTO_PROJ}/src/caller.py --os-type LINUX '

class TestCaller(unittest.TestCase):
    def setUp(self) -> None:
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)

    def test_execute_cmd_in_qemu_vm(self):
        # build
        name = 'vm'
        file_name = '/root/test_execute_vm_cmd.txt'
        cmd_create_file = f'touch {file_name}'
        self.sut.execute_shell_cmd(cmd_create_file)
        # operate
        self.vmm.upload_to_vm(name, file_name, file_name, ssh_port)        
        # check
        out = self.vmm.execute_vm_cmd(name, f'ls -l {file_name} | wc -l', 100, ssh_port)[1]
        self.assertEqual(out.strip(), '1')

if __name__ == '__main__':
    unittest.main(verbosity=2)

