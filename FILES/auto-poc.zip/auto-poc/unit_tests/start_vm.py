from auto_path import *


if __name__ == "__main__":
    sut = get_sut(PLATFORM)
    vmm = get_vmmanger(sut)
    vmm.start_vm(name, 600)



python start_vm.py --vm-name rhel1

