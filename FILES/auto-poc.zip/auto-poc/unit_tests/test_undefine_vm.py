from typing import Union
from auto_path import *
from util import *


name = "rhel1"
clone_name = "RHEL-CLONE"
timeout = 600

class TestUndefineVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    def test_undefine_vm(self):
        # build
        self.vmm.clone_vm(name, clone_name, "/home/imgs", 600)
        old_vm_list = self.vmm.get_vm_list()
        # operate
        self.vmm.undefine_vm(clone_name, timeout)
        # check
        new_vm_list = self.vmm.get_vm_list()
        self.assertIn(clone_name, old_vm_list)
        self.assertNotIn(clone_name, new_vm_list)
        # restore
    
    @unittest.skip("Passed Cases")
    def test_udefine_vm_with_vm_unexist_should_fail(self):
        # build
        old_vm_list = self.vmm.get_vm_list()
        # operate
        undefine_vm_ignore_error(self.vmm, name)
        # check
        new_vm_list = self.vmm.get_vm_list()
        self.assertEqual(len(old_vm_list), len(new_vm_list))
        # restore


if __name__ == "__main__":
    unittest.main(verbosity=2)

