from auto_path import *
from src.Hypervisior import Hypervisor


def start_vm_if_not_running(vmm, name):
    if not vmm.is_vm_in_os(name):
        vmm.start_vm(name, 600)

def shutdown_vm_if_running(vmm, name):
    if vmm.is_vm_in_os(name):
        vmm.shutdown_vm(name, 600)

def clone_vm_ignore_error(vmm, src, dest):
    try:
        vmm.clone_vm(src, dest)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def undefine_vm_ignore_error(vmm, name):
    try:
        vmm.undefine_vm(name)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def reboot_vm_ignore_error(vmm, name, timeout):
    try:
        vmm.reboot_vm(name, timeout)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def download_from_vm_ignore_error(vmm, name, src, dest):
    try:
        vmm.download_from_vm(name, src, dest)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def upload_to_vm_ignore_error(vmm, name, src, dest):
    try:
        vmm.upload_to_vm(name, src, dest)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def execute_vm_cmd_ignore_error(vmm, name, cmd):
    try:
        vmm.execute_vm_cmd(name, cmd)
    except Exception as e:
        with open(error_log_file, "w") as file:
            print(e.args, file=file)

def create_empty_file(vmm, filename):
    vmm.sut.execcute_shell_cmd("touch {}".format(filename))

def delete_empty_file(vmm, filename):
    vmm.sut.execcute_shell_cmd("rm -f {}".format(filename))
