from auto_path import *
from util import *


new_name = 'rhel2'
if PLATFORM == SUT_PLATFORM.LINUX:
    template = f'{SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS}/rhel1.qcow2'
    disk_dir = SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS
else:
    template = f'{SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS}\\rhel1.vhdx'
    disk_dir = SUT_TOOLS_WINDOWS_VIRTUALIZATION_IMGS
    
timeout = 600

class TestCreateVMFromTemplate(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter('ignore')
        self.sut = get_sut(PLATFORM)
        self.vmm = get_vmmanger(self.sut)
        if self.vmm.is_vm_exist(new_name):
           self.vmm.undefine_vm(new_name, timeout)

    def test_create_vm_from_template(self):
        # build
        old_vm_list = self.vmm.get_vm_list()
        # operate
        self.vmm.create_vm_from_template(new_name, template, 4096, disk_dir, "New Virtual Switch", timeout)
        # check
        new_vm_list = self.vmm.get_vm_list()
        self.assertNotIn(new_name, old_vm_list)
        self.assertIn(new_name, new_vm_list)
        self.vmm.start_vm(new_name, timeout)
        self.vmm.shutdown_vm(new_name, timeout)
        # restore
        self.vmm.undefine_vm(new_name, timeout)

if __name__ == '__main__':
    unittest.main(verbosity=2)


