import paramiko

cmd = 'poweroff'
vm_name = 'cent0'

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
client.connect('localhost', 2222, 'root', 'password')

_, stdout, stderr = client.exec_command(cmd, timeout=60)
res = stdout.channel.recv_exit_status, stdout.read().decode(), stderr.read().decode()

print(f'<{vm_name}> execute cmd: {cmd}')
print(f'<{vm_name}> execute stdout: {res[1]}')
print(f'<{vm_name}> execute stderr: {res[2]}')