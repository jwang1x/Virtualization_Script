from auto_path import *
from util import *


name = 'vm'
ssh_port = 2222
base_cmd = f'python {SUT_TOOLS_LINUX_VIRTUALIZATION_AUTO_PROJ}/src/caller.py --os-type LINUX '

class TestCaller(unittest.TestCase):
    def setUp(self) -> None:
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)

    def test_execute_cmd_in_qemu_vm(self):
        # build
        name = 'vm'
        file_name = '/root/test_execute_vm_cmd.txt'
        cmd_create_file = f'touch {file_name}'
        # operate
        # cmd = base_cmd
        # cmd += f'--command execute_vm_cmd '
        # cmd += f'--vm-name {name} '
        # cmd += f'--vm-command "{cmd_create_file}" '
        # cmd += f'--timeout 600 '
        # cmd += f'--ssh-port 2222'
        # code, out, err = self.sut.execute_shell_cmd(cmd, timeout=600)
        code, out, err = self.vmm.execute_vm_cmd(name, cmd_create_file, 600, port=ssh_port)
        # check
        print(code, out, err)


if __name__ == '__main__':
    unittest.main(verbosity=2)

