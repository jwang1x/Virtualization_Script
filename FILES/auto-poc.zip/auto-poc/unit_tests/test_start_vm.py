from auto_path import *
from util import *


# name = "rhel1"
name = "win1"
timeout = 600

class TestStartVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(PLATFORM)
        self.vmm = get_vmmanger(self.sut)

    def test_start_vm_with_vm_shutoff_should_success(self):
        # build
        is_in_os = self.vmm.is_vm_in_os(name)
        # operate
        self.vmm.start_vm(name, 600)
        # check
        self.assertNotEqual(is_in_os, self.vmm.is_vm_in_os(name))
        # restore
        self.vmm.shutdown_vm(name, 600)


if __name__ == "__main__":
    unittest.main(verbosity=2)

