from auto_path import *
from util import *


name = "rhel1"
timeout = 600

class TestRebootVM(unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    def test_reboot_vm_with_vm(self):
        # build
        self.vmm.start_vm(name, timeout)
        # operate
        self.vmm.reboot_vm(name, timeout)
        # check
        self.assertTrue(self.vmm.is_vm_in_os(name))
        # restore
        self.vmm.shutdown_vm(name, timeout)
    
    @unittest.skip("Passed Cases")
    def test_reboot_vm_with_vm_shutoff_should_failed(self):
        # build
        # operate
        reboot_vm_ignore_error(name, timeout)
        # check
        self.assertFalse(self.vmm.is_vm_in_os(name))
        # restore

if __name__ == "__main__":
    unittest.main(verbosity=2)

