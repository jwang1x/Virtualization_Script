from auto_path import *
from util import *


name = "rhel1"
timeout = 600

class (unittest.TestCase):
    def setUp(self) -> None:
        if not sys.warnoptions:
            import warnings
            warnings.simplefilter("ignore")
        self.sut = get_sut(SUT_PLATFORM.LINUX)
        self.vmm = get_vmmanger(self.sut)
        shutdown_vm_if_running(self.vmm, name)
    
    def tearDown(self) -> None:
        shutdown_vm_if_running(self.vmm, name)

    def test(self):
        # build
        # operate
        # check
        # restore
        pass

if __name__ == "__main__":
    unittest.main(verbosity=2)

