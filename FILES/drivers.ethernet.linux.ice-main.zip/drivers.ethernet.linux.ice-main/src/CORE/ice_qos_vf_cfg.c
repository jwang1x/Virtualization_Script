#include "ice.h"
#include "ice_qos_vf_cfg.h"
#include "ice_qos_static_cfg.h"
#include "ice_virtchnl_pf.h"
#include "ice_common.h"
#include "ice_lib.h"

/**
 * ice_get_port_by_vf_id - Get port num from QoS configuration by vf_id
 * @vf_id: VF id
 */
u16 ice_get_port_by_vf_id(s16 vf_id)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	int cfg_id;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++)
		if (vf_id == ice_vfs_qos_config[cfg_id].vf_id)
			return ice_vfs_qos_config[cfg_id].port_num;

	return 0;
}

/**
 * ice_get_tcmap_by_vf_id - Get TC bitmap from QoS configuration by vf_id
 * @vf_id: VF id
 */
u16 ice_get_tcmap_by_vf_id(s16 vf_id)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	u16 tcmap = BIT(0);
	int cfg_id;
	int i;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++) {
		if (vf_id == ice_vfs_qos_config[cfg_id].vf_id) {
			for (i = 0; i < ICE_MAX_STATIC_TRAFFIC_CLASS; i++)
				if (ice_vfs_qos_config[cfg_id].num_qs[i] > 0)
					tcmap |= BIT(i);

			break;
		}
	}

	return tcmap;
}

/**
 * ice_get_vf_qnum - Get sum number of queues for specified VF id
 * @vf_id: VF id
 */
u16 ice_get_vf_qnum(s16 vf_id)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	u16 sum_qnum = 0;
	int cfg_id;
	int i;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++) {
		struct ice_qos_vf *qos_cfg = &ice_vfs_qos_config[cfg_id];

		if (vf_id == qos_cfg->vf_id) {
			for (i = 0; i < ICE_MAX_STATIC_TRAFFIC_CLASS; i++)
				sum_qnum += qos_cfg->num_qs[i];
			break;
		}
	}
	return sum_qnum;
}

/**
 * ice_get_vf_qnum_per_tc - Get number of queues for specified TC and VF id
 * @vf_id: VF id
 * @tc: TC num to get queues
 */
u16 ice_get_vf_qnum_per_tc(s16 vf_id, u8 tc)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	int cfg_id;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++)
		if (vf_id == ice_vfs_qos_config[cfg_id].vf_id)
			return ice_vfs_qos_config[cfg_id].num_qs[tc];

	return 0;
}

/**
 * ice_get_numtc_by_vf_id - Get number of enabled TCs per VF id
 * @vf_id: VF id
 */
u8 ice_get_numtc_by_vf_id(s16 vf_id)
{
	unsigned long tcmap = BIT(0);
	u8 numtc = 0;
	int i = 0;

	tcmap = ice_get_tcmap_by_vf_id(vf_id);
	ice_for_each_set_bit(i, &tcmap, ICE_MAX_STATIC_TRAFFIC_CLASS)
		numtc++;

	return numtc;
}

/**
 * ice_validate_qnum_sum - Check if sum of queues not exceed limit
 * @pf: pointer to ice_pf structure
 */
static bool ice_validate_qnums(struct ice_pf *pf)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	int cfg_id;
	bool ret = true;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++) {
		u16 qnum_sum = 0;
		u8 i;

		for (i = 0; i < ICE_MAX_STATIC_TRAFFIC_CLASS; i++) {
			u16 numqs = ice_vfs_qos_config[cfg_id].num_qs[i];

			if (!numqs)
				break;

			if (!ice_is_pow2(numqs)) {
				dev_err(ice_pf_to_dev(pf),
					"Specified number of queues must be pow2 %d\n",
					numqs);
				return false;
			}

			qnum_sum += numqs;
		}

		ret &= (qnum_sum == 0) || (qnum_sum <= ICE_MAX_QS_PER_VF);
		if (!ret)
			dev_err(ice_pf_to_dev(pf),
				"Specified amount of queues exceeds limit %d\n",
				ICE_MAX_QS_PER_VF);
	}

	return ret;
}

/**
 * ice_is_unique_vf_ids - Check if all vf_ids are unique
 */
static bool ice_is_unique_vf_ids(void)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	bool ret = true;
	int cfg_id;
	int i;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++) {
		u8 vf_id = ice_vfs_qos_config[cfg_id].vf_id;

		for (i = cfg_id + 1; i < num_cfgs; i++)
			ret &= (vf_id != ice_vfs_qos_config[i].vf_id);
	}
	return ret;
}

/**
 * ice_qos_set_vfs_ring_tc - Set TC number of each TX ring in VF VSI
 * @vsi: pointer to ice_vsi structure
 */
void ice_qos_set_vf_ring_tc(struct ice_vsi *vsi)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	int cfg_id, tc, i;
	u16 q_index = 0;

	if (!vsi || vsi->type != ICE_VSI_VF)
		return;

	if (WARN_ON(!vsi->vf))
		return;

	for (cfg_id = 0; cfg_id < num_cfgs; cfg_id++) {
		struct ice_qos_vf cfg = ice_vfs_qos_config[cfg_id];

		if (vsi->vf->vf_id != cfg.vf_id)
			continue;

		for (tc = 0; tc < ICE_MAX_STATIC_TRAFFIC_CLASS; tc++)
			for (i = 0; i < cfg.num_qs[tc]; i++)
				vsi->tx_rings[q_index++]->tc = tc;

		break;
	}
}

/**
 * ice_qos_load_vf_config - Load static configuration
 * @pf: pointer to ice_pf structure
 */
void ice_qos_load_vf_config(struct ice_pf *pf)
{
	int num_cfgs = ARRAY_SIZE(ice_vfs_qos_config);
	int ret;

	if (num_cfgs == 0 || !ice_is_unique_vf_ids() || !ice_validate_qnums(pf))
		return;

	ret = ice_sriov_configure(pf->pdev, num_cfgs);
	if (ret < 0)
		dev_err(ice_pf_to_dev(pf),
			"Failed to enable VFs error: %d\n", ret);
}
