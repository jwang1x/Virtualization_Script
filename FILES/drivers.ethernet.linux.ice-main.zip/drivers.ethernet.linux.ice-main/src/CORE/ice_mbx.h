#ifndef _ICE_MBX_H_
#define _ICE_MBX_H_


int
ice_mbx_send_msg_to_ies(struct ice_pf *pf, u16 msg_opcode, u16 seq_num,
			u8 data, void *buf, u16 buf_size,
			struct ice_sq_cd *cd);
int
ice_process_msg_from_ies(void *data);
#if !defined(NO_PTP_SUPPORT) && defined(BMSM_MODE)
enum peerchnl_status_code
ice_process_phy_state_change(struct ice_pf *pf, void *buf);
int
ice_send_phy_state_change_to_ies(struct ice_pf *pf, u32 lports_map, bool state);
#endif /* !NO_PTP_SUPPORT && BMSM_MODE */
#ifdef OLD_IDC_SUPPORT
void
ice_update_ies_link_info(struct ice_port_info *pi,
			 struct ice_aqc_get_link_status_data *link_data,
			 bool *lse);
#endif /* OLD_IDC_SUPPORT */

#endif /* !_ICE_MBX_H_ */
