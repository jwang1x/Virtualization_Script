#ifndef _ICE_QOS_VF_CFG_H_
#define _ICE_QOS_VF_CFG_H_

u16 ice_get_port_by_vf_id(s16 vf_id);
void ice_qos_load_vf_config(struct ice_pf *pf);
u16 ice_get_tcmap_by_vf_id(s16 vf_id);
u8 ice_get_numtc_by_vf_id(s16 vf_id);
u16 ice_get_vf_qnum_per_tc(s16 vf_id, u8 tc);
u16 ice_get_vf_qnum(s16 vf_id);
void ice_qos_set_vf_ring_tc(struct ice_vsi *vsi);

#endif /* _ICE_QOS_VF_CFG_H_ */
