#include <linux/fs.h>
#include <linux/debugfs.h>
#include <linux/random.h>
#ifdef REMOVE_COMPAT
#include <linux/nospec.h>
#endif
#include "ice.h"
#include "ice_lib.h"
#include "ice_fltr.h"

#ifdef SWITCH_MODE
#include "ice_lib.h"
#endif /* SWITCH_MODE */

static struct dentry *ice_debugfs_root;

#ifdef DEBUGFS_INTERNAL
#ifdef INTERNAL_ONLY
#define ICE_BLK_DEBUGFS_MAX 512
#define ICE_BLK_DEBUGFS_BLK_SIZE 4096
struct ice_dbg_swt_data {
	struct dentry *node;
	struct debugfs_blob_wrapper blob;
};

#define ICE_PKG_DEBUGFS_BLK_SIZE 4096
#define ICE_DBG_PKG_COUNT_NAME "count"
#define ICE_DBG_PKG_ERROR_NAME "error"
#define ICE_DBG_PKG_BLOCK_NAME "buffer.bin"

/* The ice_dbg_pkg_data structure contains the file pointers and data used to
 * upload the current pipeline filter data tables. The algorithm for the
 * package upload is: repeatedly call the Upload Section Command (AQ 0x0C41)
 * with successive 4k buffers. The AQ command responds with the requested 4k
 * buffer.
 *
 * There are 2 dentry pointers:
 *     pkg_dir - directory to contain the other files.
 *     pkg_file - a debugfs file with special read and write functions
 *
 * The "dump package <dir>" command creates a directory and 3 files. The dentry
 * pkg_dir is a pointer to the directory named "<dir>", that will contain the
 * other files. The memory buffer *buff contains the 4k buffer request for data
 * and *output contains the uploaded data from FW. The file pointer pkg_file is
 * a special debugfs file - data written is stored in *buff and data is read
 * from *output. Each time a complete 4k (4096) buffer is written to *buff the
 * AQ command is called, the buffer is stored in *output, the count cnt is
 * incremented, and the error return from the AQ call is stored in err.
 */
struct ice_dbg_pkg_data {
	struct dentry *pkg_dir;
	struct dentry *pkg_file;
	u8 *buff;
	u8 *output;
	u32 cnt;
	u32 err;
};

static void ice_blk_debugfs_clean(struct ice_pf *pf)
{
	struct device *dev;

	if (!pf->dbg_swt_dir)
		return;

	dev = ice_pf_to_dev(pf);
	if (pf->dbg_swt_data) {
		int i;

		/* clean pointer array */
		for (i = 0; i < ICE_BLK_DEBUGFS_MAX; i++) {
			if (!pf->dbg_swt_data[i])
				continue;
			debugfs_remove(pf->dbg_swt_data[i]->node);
			pf->dbg_swt_data[i]->node = NULL;
			if (pf->dbg_swt_data[i]->blob.data) {
				devm_kfree(dev,
					   pf->dbg_swt_data[i]->blob.data);
				pf->dbg_swt_data[i]->blob.data = NULL;
				pf->dbg_swt_data[i]->blob.size = 0;
			}
			devm_kfree(dev, pf->dbg_swt_data[i]);
			pf->dbg_swt_data[i] = NULL;
		}
		devm_kfree(dev, pf->dbg_swt_data);
		pf->dbg_swt_data = NULL;
	}
	debugfs_remove(pf->dbg_swt_dir);
	pf->dbg_swt_dir = NULL;
}

static void ice_blk_debugfs_create(struct ice_pf *pf, struct device *dev,
				   char *dir_name)
{
	u32 table_idx, table_cnt;
	u16 table_id;
	int i;

	if (!pf->dbg_swt_dir)
		pf->dbg_swt_dir = debugfs_create_dir(dir_name,
						     pf->ice_debugfs_pf);
	if (!pf->dbg_swt_dir) {
		dev_err(dev, "creating block directory failed\n");
		return;
	}

	if (!pf->dbg_swt_data) {
		struct ice_dbg_swt_data **blk_ptrs;

		/* allocate pointer array */
		blk_ptrs = devm_kcalloc(dev, ICE_BLK_DEBUGFS_MAX,
					sizeof(*blk_ptrs), GFP_KERNEL);
		if (!blk_ptrs)
			goto blk_debugfs_cleanup;

		pf->dbg_swt_data = blk_ptrs;
	} else {
		/* clean pointer array */
		for (i = 0; i < ICE_BLK_DEBUGFS_MAX; i++) {
			if (!pf->dbg_swt_data[i] || !pf->dbg_swt_data[i]->node)
				continue;
			debugfs_remove(pf->dbg_swt_data[i]->node);
			pf->dbg_swt_data[i]->node = NULL;
			if (pf->dbg_swt_data[i]->blob.data)
				devm_kfree(dev,
					   pf->dbg_swt_data[i]->blob.data);
			pf->dbg_swt_data[i]->blob.data = NULL;
			pf->dbg_swt_data[i]->blob.size = 0;
		}
	}

	table_id = 0;
	table_idx = 0;
	table_cnt = 0;

	for (i = 0; i < ICE_BLK_DEBUGFS_MAX; i++) {
		struct ice_dbg_swt_data *seg;
		char f_name[30];
		u16 buf_len;
		int res;
		u8 *blk;

		/* make name */
		snprintf(f_name, 29, "block_%04d_%04d.bin", table_id,
			 table_cnt);

		/* get data */
		blk = devm_kcalloc(dev, 1,
				   ICE_BLK_DEBUGFS_BLK_SIZE, GFP_KERNEL);
		if (!blk)
			goto blk_debugfs_cleanup;

		res = ice_aq_get_internal_data(&pf->hw,
					       ICE_AQC_DBG_DUMP_CLUSTER_ID_SW,
					       table_id, table_idx, blk,
					       ICE_BLK_DEBUGFS_BLK_SIZE,
					       &buf_len, &table_id, &table_idx,
					       NULL);

		if (res) {
			devm_kfree(dev, blk);
			goto blk_debugfs_cleanup;
		}

		/* alloc and make blob */
		seg = devm_kcalloc(dev, 1, sizeof(struct ice_dbg_swt_data),
				   GFP_KERNEL);
		if (!seg) {
			devm_kfree(dev, blk);
			goto blk_debugfs_cleanup;
		}
		pf->dbg_swt_data[i] = seg;
		seg->blob.data = blk;
		seg->blob.size = (unsigned long)buf_len;

		/* write blob */
		seg->node = debugfs_create_blob(f_name, 0400,
						pf->dbg_swt_dir,
						&seg->blob);
		if (seg->node)
			i_size_write(seg->node->d_inode, buf_len);

		/* prep for next block */
		table_cnt++;
		if (table_idx == 0xffffffff) {
			table_idx = 0;
			table_cnt = 0;
		}

		/* quit loop if last */
		if (table_id == 0xff)
			break;
	}
	return;

blk_debugfs_cleanup:
	dev_err(dev, "no memory allocating blocks\n");
	ice_blk_debugfs_clean(pf);
}

static void ice_pkg_debugfs_clean(struct ice_pf *pf)
{
	struct ice_dbg_pkg_data *pkg_data;
	struct device *dev;

	if (!pf->dbg_pkg_data)
		return;

	dev = ice_pf_to_dev(pf);
	pkg_data = pf->dbg_pkg_data;
	debugfs_remove_recursive(pkg_data->pkg_dir);
	if (pkg_data->buff)
		devm_kfree(dev, pkg_data->buff);
	if (pkg_data->output)
		devm_kfree(dev, pkg_data->output);
	devm_kfree(dev, pf->dbg_pkg_data);
	pf->dbg_pkg_data = NULL;
}

static ssize_t ice_pkg_debugfs_read_op(struct file *filp, char __user *buff,
				       size_t count, loff_t *pos)
{
	struct ice_pf *pf;

	pf = (struct ice_pf *)filp->private_data;
	return simple_read_from_buffer(buff, count, pos, pf->dbg_pkg_data->buff,
				       ICE_PKG_DEBUGFS_BLK_SIZE);
}

static ssize_t ice_pkg_debugfs_write_op(struct file *filp,
					const char __user *buffer,
					size_t count, loff_t *pos)
{
	ssize_t bytes_written;
	struct ice_pf *pf;

	pf = (struct ice_pf *)filp->private_data;
	bytes_written = simple_write_to_buffer(pf->dbg_pkg_data->buff,
					       ICE_PKG_DEBUGFS_BLK_SIZE, pos,
					       buffer, count);
	if (*pos == ICE_BLK_DEBUGFS_BLK_SIZE) {
		/* assumes we write all bytes before making AQ call */
		struct ice_dbg_pkg_data *pkg_data;
		int status;
		u8 *buff;

		pkg_data = pf->dbg_pkg_data;
		buff = pkg_data->buff;

		status = ice_aq_upload_section(&pf->hw,
					       (struct ice_buf_hdr *)buff,
					       ICE_PKG_DEBUGFS_BLK_SIZE, NULL);
		if (!status)
			memcpy(pkg_data->output, pkg_data->buff,
			       ICE_PKG_DEBUGFS_BLK_SIZE);
		else
			memset(pkg_data->output, 0, ICE_PKG_DEBUGFS_BLK_SIZE);

		pkg_data->err = status;
		pkg_data->cnt++;
	}
	return bytes_written;
}

static const struct file_operations ice_pkg_debugfs_fops = {
	.llseek = default_llseek,
	.open = simple_open,
	.read = ice_pkg_debugfs_read_op,
	.write = ice_pkg_debugfs_write_op,
};

static void ice_pkg_debugfs_init(struct ice_pf *pf, struct device *dev,
				 char *dir_name)
{
	struct ice_dbg_pkg_data *pkg_data;

	if (!pf->dbg_pkg_data) {
		pf->dbg_pkg_data = devm_kcalloc(dev, 1,
						sizeof(*pkg_data),
						GFP_KERNEL);
		if (!pf->dbg_pkg_data)
			return;
	}
	pkg_data = pf->dbg_pkg_data;
	if (!pkg_data->buff) {
		pkg_data->buff = devm_kcalloc(dev, 1,
					      ICE_PKG_DEBUGFS_BLK_SIZE,
					      GFP_KERNEL);
		if (!pkg_data->buff)
			goto pkg_debugfs_cleanup;
	}
	if (!pkg_data->output) {
		pkg_data->output = devm_kcalloc(dev, 1,
						ICE_PKG_DEBUGFS_BLK_SIZE,
						GFP_KERNEL);
		if (!pkg_data->output)
			goto pkg_debugfs_cleanup;
	}
	pkg_data->cnt = 0;
	pkg_data->err = 0;
	if (!pkg_data->pkg_dir) {
		pkg_data->pkg_dir = debugfs_create_dir(dir_name,
						       pf->ice_debugfs_pf);
		if (!pkg_data->pkg_dir)
			goto pkg_debugfs_cleanup;
	}
	debugfs_create_u32(ICE_DBG_PKG_COUNT_NAME, 0400, pkg_data->pkg_dir,
			   &pkg_data->cnt);
	debugfs_create_u32(ICE_DBG_PKG_ERROR_NAME, 0400, pkg_data->pkg_dir,
			   &pkg_data->err);
	pkg_data->pkg_file = debugfs_create_file(ICE_DBG_PKG_BLOCK_NAME,
						 0400, pkg_data->pkg_dir, pf,
						 &ice_pkg_debugfs_fops);
	return;

pkg_debugfs_cleanup:
	ice_pkg_debugfs_clean(pf);
}
#endif /* INTERNAL_ONLY */

/**************************************************************
 * command
 * The command entry in debugfs is for giving the ice commands
 * to be executed - these may be for changing the internal switch
 * setup, adding or removing filters, or other things. Many of
 * these will be useful for some forms of unit testing.
 **************************************************************/

/* helper functions */
static bool ice_addr_in_range(struct ice_pf *pf, u32 address, int bar)
{
	u32 ioremap_len;

	if (bar == ICE_BAR0)
		ioremap_len = pf->ioremap_len;
	else if (bar == ICE_BAR3)
		ioremap_len = pf->bar3_ioremap_len;
	else
		return false;

	if (address <= (ioremap_len - sizeof(u32)))
		return true;

	dev_err(ice_pf_to_dev(pf), "reg address 0x%08x too large, max=0x%08lx\n",
		address, (ioremap_len - sizeof(u32)));

	return false;
}

static bool ice_addr_aligned(struct ice_pf *pf, u32 address)
{
	if (IS_ALIGNED(address, sizeof(u32)))
		return true;

	dev_err(ice_pf_to_dev(pf), "register must be 32-bit aligned\n");

	return false;
}

#ifdef SWITCH_MODE
static int ice_add_mac_port(struct ice_pf *pf, u8 *mac_addr, u8 port)
{
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_vsi *vsi = NULL;
	int status = 0;
	int v;

	/* get the destination VSI using port info */
	ice_for_each_vsi(pf, v) {
		if (pf->vsi[v]->port_info->lport == port &&
		    pf->vsi[v]->type == ICE_VSI_PF) {
			vsi = pf->vsi[v];
			break;
		}
	}
	/* get the destination VSI */
	if (!vsi)
		return -EINVAL;

	/* program MAC filters for entries in tmp_add_list */
	status = ice_fltr_add_mac(vsi, mac_addr, ICE_FWD_TO_VSI);
	if (status)
		dev_err(dev, "failed to add MAC(%pM) filter for port %u\n",
			mac_addr, port);

	return status;
}
#endif /* SWITCH_MODE */
#endif /* DEBGUFS_INTERNAL */

static void ice_dump_pf(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);

	dev_info(dev, "pf struct:\n");
	dev_info(dev, "\tmax_pf_txqs = %d\n", pf->max_pf_txqs);
	dev_info(dev, "\tmax_pf_rxqs = %d\n", pf->max_pf_rxqs);
	dev_info(dev, "\tnum_alloc_vsi = %d\n", pf->num_alloc_vsi);
	dev_info(dev, "\tnum_lan_tx = %d\n", pf->num_lan_tx);
	dev_info(dev, "\tnum_lan_rx = %d\n", pf->num_lan_rx);
	dev_info(dev, "\tnum_avail_tx = %d\n", ice_get_avail_txq_count(pf));
	dev_info(dev, "\tnum_avail_rx = %d\n", ice_get_avail_rxq_count(pf));
	dev_info(dev, "\tnum_lan_msix = %d\n", pf->num_lan_msix);
#ifdef RDMA_SUPPORT
	dev_info(dev, "\tnum_rdma_msix = %d\n", pf->num_rdma_msix);
	dev_info(dev, "\trdma_base_vector = %d\n", pf->rdma_base_vector);
#endif /* RDMA_SUPPORT */
#ifdef OFFLOAD_MACVLAN_SUPPORT
#ifdef HAVE_NDO_DFWD_OPS
	dev_info(dev, "\tnum_macvlan = %d\n", pf->num_macvlan);
	dev_info(dev, "\tmax_num_macvlan = %d\n", pf->max_num_macvlan);
#endif /* HAVE_NDO_DFWD_OPS */
#endif /* OFFLOAD_MACVLAN_SUPPORT */
	dev_info(dev, "\tirq_tracker->num_entries = %d\n",
		 pf->irq_tracker->num_entries);
	dev_info(dev, "\tirq_tracker->end = %d\n", pf->irq_tracker->end);
	dev_info(dev, "\tirq_tracker valid count = %d\n",
		 ice_get_valid_res_count(pf->irq_tracker));
	dev_info(dev, "\tnum_avail_sw_msix = %d\n", pf->num_avail_sw_msix);
	dev_info(dev, "\tsriov_base_vector = %d\n", pf->sriov_base_vector);
	dev_info(dev, "\tnum_alloc_vfs = %d\n", ice_get_num_vfs(pf));
	dev_info(dev, "\tnum_qps_per_vf = %d\n", pf->vfs.num_qps_per);
	dev_info(dev, "\tnum_msix_per_vf = %d\n", pf->vfs.num_msix_per);
}

static void ice_dump_pf_vsi_list(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);
	u16 i;

	ice_for_each_vsi(pf, i) {
		struct ice_vsi *vsi = pf->vsi[i];

		if (!vsi)
			continue;

		dev_info(dev, "vsi[%d]:\n", i);
		dev_info(dev, "\tvsi = %p\n", vsi);
		dev_info(dev, "\tvsi_num = %d\n", vsi->vsi_num);
		dev_info(dev, "\ttype = %s\n", ice_vsi_type_str(vsi->type));
		if (vsi->type == ICE_VSI_VF)
			dev_info(dev, "\tvf_id = %d\n", vsi->vf->vf_id);
		dev_info(dev, "\tback = %p\n", vsi->back);
		dev_info(dev, "\tnetdev = %p\n", vsi->netdev);
		dev_info(dev, "\tmax_frame = %d\n", vsi->max_frame);
		dev_info(dev, "\trx_buf_len = %d\n", vsi->rx_buf_len);
		dev_info(dev, "\tnum_txq = %d\n", vsi->num_txq);
		dev_info(dev, "\tnum_rxq = %d\n", vsi->num_rxq);
		dev_info(dev, "\treq_txq = %d\n", vsi->req_txq);
		dev_info(dev, "\treq_rxq = %d\n", vsi->req_rxq);
		dev_info(dev, "\talloc_txq = %d\n", vsi->alloc_txq);
		dev_info(dev, "\talloc_rxq = %d\n", vsi->alloc_rxq);
		dev_info(dev, "\tnum_rx_desc = %d\n", vsi->num_rx_desc);
		dev_info(dev, "\tnum_tx_desc = %d\n", vsi->num_tx_desc);
		dev_info(dev, "\tnum_vlan = %d\n", vsi->num_vlan);
	}
}

#ifdef FDIR_SUPPORT
/**
 * ice_dump_pf_fdir - output Flow Director stats to dmesg log
 * @pf: pointer to PF to get Flow Director HW stats for.
 */
static void ice_dump_pf_fdir(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_hw *hw = &pf->hw;
	u16 pf_guar_pool = 0;
	u32 dev_fltr_size;
	u32 dev_fltr_cnt;
	u32 pf_fltr_cnt;
#ifdef INTERNAL_ONLY
	u32 pfqf_fd_ena;
#endif /* INTERNAL_ONLY */
	u16 i;

#ifdef INTERNAL_ONLY
	pfqf_fd_ena = rd32(hw, PFQF_FD_ENA);
#endif /* INTERNAL_ONLY */
	pf_fltr_cnt = rd32(hw, PFQF_FD_CNT);
	dev_fltr_cnt = rd32(hw, GLQF_FD_CNT);
	dev_fltr_size = rd32(hw, GLQF_FD_SIZE);

#ifdef INTERNAL_ONLY
#ifndef EXTERNAL_RELEASE
	/* An old NVM had a problem accessing the PFQF_FD_ENA register
	 * after reset. Check if the value read from the register is
	 * valid.
	 *
	 * Test to verify expected values. Should be checked after reset.
	 * Production NVMs should never have this problem.
	 * HSD 1808764919
	 */
#endif /* EXTERNAL_RELEASE */
	if (pfqf_fd_ena && pfqf_fd_ena != PFQF_FD_ENA_FD_ENA_M)
		dev_err(dev, "Error: Unexpected value Flow Director enable word = 0x%08x\n",
			pfqf_fd_ena);
	else
		dev_info(dev, "Flow Director enable word has expected value.\n");

#endif /* INTERNAL_ONLY */
	ice_for_each_vsi(pf, i) {
		struct ice_vsi *vsi = pf->vsi[i];

		if (!vsi)
			continue;

		pf_guar_pool += vsi->num_gfltr;
	}

	dev_info(dev, "Flow Director filter usage:\n");
	dev_info(dev, "\tPF guaranteed used = %d\n",
#ifdef E830_SUPPORT
		 (pf_fltr_cnt & PFQF_FD_CNT_FD_GCNT_M_BY_MAC(hw)) >>
#else
		 (pf_fltr_cnt & PFQF_FD_CNT_FD_GCNT_M) >>
#endif /* E830_SUPPORT */
		 PFQF_FD_CNT_FD_GCNT_S);
	dev_info(dev, "\tPF best_effort used = %d\n",
#ifdef E830_SUPPORT
		 (pf_fltr_cnt & PFQF_FD_CNT_FD_BCNT_M_BY_MAC(hw)) >>
#else
		 (pf_fltr_cnt & PFQF_FD_CNT_FD_BCNT_M) >>
#endif /* E830_SUPPORT */
		 PFQF_FD_CNT_FD_BCNT_S);
	dev_info(dev, "\tdevice guaranteed used = %d\n",
#ifdef E830_SUPPORT
		 (dev_fltr_cnt & GLQF_FD_CNT_FD_GCNT_M_BY_MAC(hw)) >>
#else
		 (dev_fltr_cnt & GLQF_FD_CNT_FD_GCNT_M) >>
#endif /* E830_SUPPORT */
		 GLQF_FD_CNT_FD_GCNT_S);
	dev_info(dev, "\tdevice best_effort used = %d\n",
#ifdef E830_SUPPORT
		 (dev_fltr_cnt & GLQF_FD_CNT_FD_BCNT_M_BY_MAC(hw)) >>
#else
		 (dev_fltr_cnt & GLQF_FD_CNT_FD_BCNT_M) >>
#endif /* E830_SUPPORT */
		 GLQF_FD_CNT_FD_BCNT_S);
	dev_info(dev, "\tPF guaranteed pool = %d\n", pf_guar_pool);
	dev_info(dev, "\tdevice guaranteed pool = %d\n",
#ifdef E830_SUPPORT
		 (dev_fltr_size & GLQF_FD_SIZE_FD_GSIZE_M_BY_MAC(hw)) >>
#else
		 (dev_fltr_size & GLQF_FD_SIZE_FD_GSIZE_M) >>
#endif /* E830_SUPPORT */
		 GLQF_FD_SIZE_FD_GSIZE_S);
	dev_info(dev, "\tdevice best_effort pool = %d\n",
		 hw->func_caps.fd_fltr_best_effort);
}
#endif /* FDIR_SUPPORT */

#ifdef SYNCE_SUPPORT
/**
 * ice_dump_rclk_status - print the PHY recovered clock status
 * @pf: pointer to PF
 *
 * Print the PHY's recovered clock pin status.
 */
static void ice_dump_rclk_status(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);
	u8 phy, phy_pin, pin;
	int phy_pins;

	if (ice_is_e810(&pf->hw))
		phy_pins = ICE_C827_RCLK_PINS_NUM;
	else
		/* E822-based devices have only one RCLK pin */
		phy_pins = E822_CGU_RCLK_PHY_PINS_NUM;

	for (phy_pin = 0; phy_pin < phy_pins; phy_pin++) {
		const char *pin_name, *pin_state;
		u8 port_num, flags;
		u32 freq;

		port_num = ICE_AQC_SET_PHY_REC_CLK_OUT_CURR_PORT;
		if (ice_aq_get_phy_rec_clk_out(&pf->hw, phy_pin, &port_num,
					       &flags, &freq))
			return;

#ifndef EXTERNAL_RELEASE
		/* It is ice_is_e810() not ice_is_e810t() function because we do
		 * have LOM HW where we do have E810T-like IO board but subdev
		 * id is 0x0 instead of 0xE/0xF as in WPC/LGB despite the fact
		 * CGU is there.
		 */
#endif /* !EXTERNAL_RELEASE */
		if (ice_is_e810(&pf->hw)) {
			int status = ice_get_pf_c827_idx(&pf->hw, &phy);

			if (status) {
				dev_err(dev,
					"Could not find PF C827 PHY, status=%d\n",
					status);
				return;
			}

			pin = E810T_CGU_INPUT_C827(phy, phy_pin);
			pin_name = ice_zl_pin_idx_to_name_e810t(pin);
		} else {
			/* e822-based devices for now have only one phy
			 * available (from Rimmon) and only one DPLL RCLK input
			 * pin
			 */
			pin_name = E822_CGU_RCLK_PIN_NAME;
		}
		pin_state =
			flags & ICE_AQC_SET_PHY_REC_CLK_OUT_OUT_EN ?
			"Enabled" : "Disabled";

		dev_info(dev, "State for pin %s: %s\n", pin_name, pin_state);
	}
}

#endif /* SYNCE_SUPPORT */
/**
 * ice_vsi_dump_ctxt - print the passed in VSI context structure
 * @dev: Device used for dev_info prints
 * @ctxt: VSI context structure to print
 */
static void ice_vsi_dump_ctxt(struct device *dev, struct ice_vsi_ctx *ctxt)
{
	struct ice_aqc_vsi_props *info;

	if (!ctxt)
		return;

	info = &ctxt->info;
	dev_info(dev, "Get VSI Parameters:\n");
	dev_info(dev, "\tVSI Number: %d Valid sections: 0x%04x\n",
		 ctxt->vsi_num, le16_to_cpu(info->valid_sections));

	dev_info(dev, "========================\n");
	dev_info(dev, "| Category - Switching |");
	dev_info(dev, "========================\n");
	dev_info(dev, "\tSwitch ID: %u\n", info->sw_id);
	dev_info(dev, "\tAllow Loopback: %s\n", (info->sw_flags &
		 ICE_AQ_VSI_SW_FLAG_ALLOW_LB) ? "enabled" : "disabled");
	dev_info(dev, "\tAllow Local Loopback: %s\n", (info->sw_flags &
		 ICE_AQ_VSI_SW_FLAG_LOCAL_LB) ? "enabled" : "disabled");
	dev_info(dev, "\tApply source VSI pruning: %s\n", (info->sw_flags &
		 ICE_AQ_VSI_SW_FLAG_SRC_PRUNE) ? "enabled" : "disabled");
	dev_info(dev, "\tEgress (Rx VLAN) pruning: %s\n",
		 (info->sw_flags2 & ICE_AQ_VSI_SW_FLAG_RX_PRUNE_EN_M) ?
		 "enabled" : "disabled");
	dev_info(dev, "\tLAN enable: %s\n", (info->sw_flags2 &
		 ICE_AQ_VSI_SW_FLAG_LAN_ENA) ? "enabled" : "disabled");
	dev_info(dev, "\tVEB statistic block ID: %u\n", info->veb_stat_id &
		 ICE_AQ_VSI_SW_VEB_STAT_ID_M);
	dev_info(dev, "\tVEB statistic block ID valid: %d\n",
		 (info->veb_stat_id & ICE_AQ_VSI_SW_VEB_STAT_ID_VALID) ? 1 : 0);

	dev_info(dev, "=======================\n");
	dev_info(dev, "| Category - Security |\n");
	dev_info(dev, "=======================\n");
	dev_info(dev, "\tAllow destination override: %s\n", (info->sec_flags &
		 ICE_AQ_VSI_SEC_FLAG_ALLOW_DEST_OVRD) ? "enabled" : "disabled");
	dev_info(dev, "\tEnable MAC anti-spoof: %s\n", (info->sec_flags &
		 ICE_AQ_VSI_SEC_FLAG_ENA_MAC_ANTI_SPOOF) ? "enabled" : "disabled");
	dev_info(dev, "\tIngress (Tx VLAN) pruning enables: %s\n",
		 (info->sec_flags & ICE_AQ_VSI_SEC_TX_PRUNE_ENA_M) ?
		 "enabled" : "disabled");

	dev_info(dev, "=================================\n");
	dev_info(dev, "| Category: Inner VLAN Handling |\n");
	dev_info(dev, "=================================\n");
	dev_info(dev, "\tPort Based Inner VLAN Insertion: PVLAN ID: %d PRIO: %d\n",
		 le16_to_cpu(info->port_based_inner_vlan) & VLAN_VID_MASK,
		 (le16_to_cpu(info->port_based_inner_vlan) & VLAN_PRIO_MASK) >>
		 VLAN_PRIO_SHIFT);
	dev_info(dev, "\tInner VLAN TX Mode: 0x%02x\n",
		 (info->inner_vlan_flags & ICE_AQ_VSI_INNER_VLAN_TX_MODE_M) >>
		 ICE_AQ_VSI_INNER_VLAN_TX_MODE_S);
	dev_info(dev, "\tInsert PVID: %s\n", (info->inner_vlan_flags &
		 ICE_AQ_VSI_INNER_VLAN_INSERT_PVID) ? "enabled" : "disabled");
	dev_info(dev, "\tInner VLAN and UP expose mode (RX): 0x%02x\n",
		 (info->inner_vlan_flags & ICE_AQ_VSI_INNER_VLAN_EMODE_M) >>
		 ICE_AQ_VSI_INNER_VLAN_EMODE_S);
	dev_info(dev, "\tBlock Inner VLAN from TX Descriptor: %s\n",
		 (info->inner_vlan_flags & ICE_AQ_VSI_INNER_VLAN_BLOCK_TX_DESC) ?
		 "enabled" : "disabled");

	dev_info(dev, "=================================\n");
	dev_info(dev, "| Category: Outer VLAN Handling |\n");
	dev_info(dev, "=================================\n");
	dev_info(dev, "\tPort Based Outer VLAN Insertion: PVID: %d PRIO: %d\n",
		 le16_to_cpu(info->port_based_outer_vlan) & VLAN_VID_MASK,
		 (le16_to_cpu(info->port_based_outer_vlan) & VLAN_PRIO_MASK) >>
		 VLAN_PRIO_SHIFT);
	dev_info(dev, "\tOuter VLAN and UP expose mode (RX): 0x%02x\n",
		 (info->outer_vlan_flags & ICE_AQ_VSI_OUTER_VLAN_EMODE_M) >>
		 ICE_AQ_VSI_OUTER_VLAN_EMODE_S);
	dev_info(dev, "\tOuter Tag type (Tx and Rx): 0x%02x\n",
		 (info->outer_vlan_flags & ICE_AQ_VSI_OUTER_TAG_TYPE_M) >>
		 ICE_AQ_VSI_OUTER_TAG_TYPE_S);
	dev_info(dev, "\tPort Based Outer VLAN Insert Enable: %s\n",
		 (info->outer_vlan_flags &
		 ICE_AQ_VSI_OUTER_VLAN_PORT_BASED_INSERT) ?
		 "enabled" : "disabled");
	dev_info(dev, "\tOuter VLAN TX Mode: 0x%02x\n",
		 (info->outer_vlan_flags & ICE_AQ_VSI_OUTER_VLAN_TX_MODE_M) >>
		 ICE_AQ_VSI_OUTER_VLAN_TX_MODE_S);
	dev_info(dev, "\tBlock Outer VLAN from TX Descriptor: %s\n",
		 (info->outer_vlan_flags & ICE_AQ_VSI_OUTER_VLAN_BLOCK_TX_DESC) ?
		 "enabled" : "disabled");
}

#ifndef SWITCH_MODE
#ifdef SYNCE_SUPPORT
#define ICE_E810T_NEVER_USE_PIN 0xff
#define ZL_VER_MAJOR_SHIFT	24
#define ZL_VER_MAJOR_MASK	MAKEMASK(0xff, ZL_VER_MAJOR_SHIFT)
#define ZL_VER_MINOR_SHIFT	16
#define ZL_VER_MINOR_MASK	MAKEMASK(0xff, ZL_VER_MINOR_SHIFT)
#define ZL_VER_REV_SHIFT	8
#define ZL_VER_REV_MASK		MAKEMASK(0xff, ZL_VER_REV_SHIFT)
#define ZL_VER_BF_SHIFT		0
#define ZL_VER_BF_MASK		MAKEMASK(0xff, ZL_VER_BF_SHIFT)

/**
 * ice_get_dpll_status - get the detailed state of the clock generator
 * @pf: pointer to PF
 * @buff: buffer for the state to be printed
 * @buff_size: size of the buffer
 *
 * This function reads current status of the ZL CGU and prints it to the buffer
 * buff_size will be updated to reflect the number of bytes written to the
 * buffer
 *
 * Return: 0 on success, error code otherwise
 */
static int
ice_get_dpll_status(struct ice_pf *pf, char *buff, size_t *buff_size)
{
	u8 pin, synce_prio, ptp_prio, ver_major, ver_minor, rev, bugfix;
	struct ice_aqc_get_cgu_abilities abilities = {0};
	struct ice_aqc_get_cgu_input_config cfg = {0};
	struct device *dev = ice_pf_to_dev(pf);
	u32 cgu_id, cgu_cfg_ver, cgu_fw_ver;
	size_t bytes_left = *buff_size;
	struct ice_hw *hw = &pf->hw;
	char pin_name[MAX_PIN_NAME];
	int cnt = 0;
	int status;

	if (!ice_is_cgu_present(hw)) {
		dev_err(dev, "CGU not present\n");
		return -ENODEV;
	}

	memset(&abilities, 0, sizeof(struct ice_aqc_get_cgu_abilities));
	status = ice_aq_get_cgu_abilities(hw, &abilities);
	if (status) {
		dev_err(dev,
			"Failed to read CGU caps, status: %d, Error: 0x%02X\n",
			status, hw->adminq.sq_last_status);
#ifdef INTERNAL_ONLY
		/* TODO: Remove this hardcoded values as soon as
		 * FW will not be crashing on returning abilities
		 */
#endif /* INTERNAL_ONLY */
		abilities.num_inputs = 7;
		abilities.pps_dpll_idx = 1;
		abilities.synce_dpll_idx = 0;
	}

	status = ice_aq_get_cgu_info(hw, &cgu_id, &cgu_cfg_ver, &cgu_fw_ver);
	if (status)
		return status;

	if (abilities.cgu_part_num ==
	    ICE_ACQ_GET_LINK_TOPO_NODE_NR_ZL30632_80032) {
		cnt = snprintf(buff, bytes_left, "Found ZL80032 CGU\n");

		/* Read DPLL config version from AQ */
		ver_major = (cgu_cfg_ver & ZL_VER_MAJOR_MASK)
			     >> ZL_VER_MAJOR_SHIFT;
		ver_minor = (cgu_cfg_ver & ZL_VER_MINOR_MASK)
			     >> ZL_VER_MINOR_SHIFT;
		rev = (cgu_cfg_ver & ZL_VER_REV_MASK) >> ZL_VER_REV_SHIFT;
		bugfix = (cgu_cfg_ver & ZL_VER_BF_MASK) >> ZL_VER_BF_SHIFT;

		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"DPLL Config ver: %d.%d.%d.%d\n", ver_major,
				ver_minor, rev, bugfix);
	} else if (abilities.cgu_part_num ==
		   ICE_ACQ_GET_LINK_TOPO_NODE_NR_SI5383_5384) {
		cnt = snprintf(buff, bytes_left, "Found SI5383/5384 CGU\n");
	}

	cnt += snprintf(&buff[cnt], bytes_left - cnt, "\nCGU Input status:\n");
	cnt += snprintf(&buff[cnt], bytes_left - cnt,
			"                   |            |      priority     |            |\n"
			"      input (idx)  |    state   | EEC (%d) | PPS (%d) | ESync fail |\n",
			abilities.synce_dpll_idx, abilities.pps_dpll_idx);
	cnt += snprintf(&buff[cnt], bytes_left - cnt,
			"  ----------------------------------------------------------------\n");

	for (pin = 0; pin < abilities.num_inputs; pin++) {
		u8 esync_fail = 0;
		u8 esync_en = 0;
		char *pin_state;
		u8 data;

		status = ice_aq_get_input_pin_cfg(hw, &cfg, pin);
		if (status)
			data = ICE_CGU_IN_PIN_FAIL_FLAGS;
		else
			data = (cfg.status & ICE_CGU_IN_PIN_FAIL_FLAGS);

		/* get either e810t pin names or generic ones */
		ice_dpll_pin_idx_to_name(pf, pin, pin_name);

		/* get pin priorities */
		if (ice_aq_get_cgu_ref_prio(hw, abilities.synce_dpll_idx, pin,
					    &synce_prio))
			synce_prio = ICE_E810T_NEVER_USE_PIN;
		if (ice_aq_get_cgu_ref_prio(hw, abilities.pps_dpll_idx, pin,
					    &ptp_prio))
			ptp_prio = ICE_E810T_NEVER_USE_PIN;

		/* if all flags are set, the pin is invalid */
		if (data == ICE_CGU_IN_PIN_FAIL_FLAGS) {
			pin_state = ICE_DPLL_PIN_STATE_INVALID;
		/* if some flags are set, the pin is validating */
		} else if (data) {
			pin_state = ICE_DPLL_PIN_STATE_VALIDATING;
		/* if all flags are cleared, the pin is valid */
		} else {
			pin_state = ICE_DPLL_PIN_STATE_VALID;
			esync_en = !!(cfg.flags2 &
				      ICE_AQC_GET_CGU_IN_CFG_FLG2_ESYNC_EN);
			esync_fail = !!(cfg.status &
				      ICE_AQC_GET_CGU_IN_CFG_STATUS_ESYNC_FAIL);
		}

		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"  %12s (%d) | %10s |     %3d |     %3d |    %4s    |\n",
				pin_name, pin, pin_state, synce_prio, ptp_prio,
				esync_en ? esync_fail ?
				"true" : "false" : "N/A");
	}

	if (!test_bit(ICE_FLAG_DPLL_MONITOR, pf->flags)) {
		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"\nDPLL Monitoring disabled\n");
	} else {
		/* SYNCE DPLL status */
		ice_dpll_pin_idx_to_name(pf, pf->synce_ref_pin, pin_name);
		cnt += snprintf(&buff[cnt], bytes_left - cnt, "\nEEC DPLL:\n");
		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"\tCurrent reference:\t%s\n", pin_name);

		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"\tStatus:\t\t\t%s\n",
				ice_cgu_state_to_name(pf->synce_dpll_state));

		ice_dpll_pin_idx_to_name(pf, pf->ptp_ref_pin, pin_name);
		cnt += snprintf(&buff[cnt], bytes_left - cnt, "\nPPS DPLL:\n");
		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"\tCurrent reference:\t%s\n", pin_name);
		cnt += snprintf(&buff[cnt], bytes_left - cnt,
				"\tStatus:\t\t\t%s\n",
				ice_cgu_state_to_name(pf->ptp_dpll_state));

		if (pf->ptp_dpll_state != ICE_CGU_STATE_INVALID)
			cnt += snprintf(&buff[cnt], bytes_left - cnt,
					"\tPhase offset [ns]:\t\t\t%lld\n",
					pf->ptp_dpll_phase_offset);
	}

	*buff_size = cnt;
	return 0;
}

/**
 * ice_debugfs_cgu_read - debugfs interface for reading DPLL status
 * @filp: the opened file
 * @user_buf: where to find the user's data
 * @count: the length of the user's data
 * @ppos: file position offset
 *
 * Return: number of bytes read
 */
static ssize_t ice_debugfs_cgu_read(struct file *filp, char __user *user_buf,
				    size_t count, loff_t *ppos)
{
	struct ice_pf *pf = filp->private_data;
	size_t buffer_size = PAGE_SIZE;
	char *kbuff;
	int err;

	if (*ppos != 0)
		return 0;

	kbuff = (char *)get_zeroed_page(GFP_KERNEL);
	if (!kbuff)
		return -ENOMEM;

	err = ice_get_dpll_status(pf, kbuff, &buffer_size);

	if (err) {
		err = -EIO;
		goto err;
	}

	err = simple_read_from_buffer(user_buf, count, ppos, kbuff,
				      buffer_size);

err:
	free_page((unsigned long)kbuff);
	return err;
}

static const struct file_operations ice_debugfs_cgu_fops = {
	.owner = THIS_MODULE,
	.llseek = default_llseek,
	.open  = simple_open,
	.read  = ice_debugfs_cgu_read,
};
#endif /* SYNCE_SUPPORT */
#endif /* !SWITCH_MODE */

#ifdef FWLOG_SUPPORT_V2
static const char *module_id_to_name(u16 module_id)
{
	switch (module_id) {
	case ICE_AQC_FW_LOG_ID_GENERAL:
		return "General";
	case ICE_AQC_FW_LOG_ID_CTRL:
		return "Control (Resets + Autoload)";
	case ICE_AQC_FW_LOG_ID_LINK:
		return "Link Management";
	case ICE_AQC_FW_LOG_ID_LINK_TOPO:
		return "Link Topology Detection";
	case ICE_AQC_FW_LOG_ID_DNL:
		return "DNL";
	case ICE_AQC_FW_LOG_ID_I2C:
		return "I2C";
	case ICE_AQC_FW_LOG_ID_SDP:
		return "SDP";
	case ICE_AQC_FW_LOG_ID_MDIO:
		return "MDIO";
	case ICE_AQC_FW_LOG_ID_ADMINQ:
		return "Admin Queue";
	case ICE_AQC_FW_LOG_ID_HDMA:
		return "HDMA";
	case ICE_AQC_FW_LOG_ID_LLDP:
		return "LLDP";
	case ICE_AQC_FW_LOG_ID_DCBX:
		return "DCBX";
	case ICE_AQC_FW_LOG_ID_DCB:
		return "DCB";
	case ICE_AQC_FW_LOG_ID_XLR:
		return "XLR";
	case ICE_AQC_FW_LOG_ID_NVM:
		return "NVM";
	case ICE_AQC_FW_LOG_ID_AUTH:
		return "Authentication";
	case ICE_AQC_FW_LOG_ID_VPD:
		return "VPD";
	case ICE_AQC_FW_LOG_ID_IOSF:
		return "IOSF";
	case ICE_AQC_FW_LOG_ID_PARSER:
		return "Parser";
	case ICE_AQC_FW_LOG_ID_SW:
		return "Switch";
	case ICE_AQC_FW_LOG_ID_SCHEDULER:
		return "Scheduler";
	case ICE_AQC_FW_LOG_ID_TXQ:
		return "Tx Queue Management";
#ifndef NO_ACL_SUPPORT
	case ICE_AQC_FW_LOG_ID_ACL:
		return "ACL";
#endif /* NO_ACL_SUPPORT */
	case ICE_AQC_FW_LOG_ID_POST:
		return "Post";
	case ICE_AQC_FW_LOG_ID_WATCHDOG:
		return "Watchdog";
	case ICE_AQC_FW_LOG_ID_TASK_DISPATCH:
		return "Task Dispatcher";
	case ICE_AQC_FW_LOG_ID_MNG:
		return "Manageability";
	case ICE_AQC_FW_LOG_ID_SYNCE:
		return "Synce";
	case ICE_AQC_FW_LOG_ID_HEALTH:
		return "Health";
	case ICE_AQC_FW_LOG_ID_TSDRV:
		return "Time Sync";
	case ICE_AQC_FW_LOG_ID_PFREG:
		return "PF Registration";
	case ICE_AQC_FW_LOG_ID_MDLVER:
		return "Module Version";
	default:
		return "Unsupported";
	}
}

static const char *log_level_to_name(u8 log_level)
{
	switch (log_level) {
	case ICE_FWLOG_LEVEL_NONE:
		return "None";
	case ICE_FWLOG_LEVEL_ERROR:
		return "Error";
	case ICE_FWLOG_LEVEL_WARNING:
		return "Warning";
	case ICE_FWLOG_LEVEL_NORMAL:
		return "Normal";
	case ICE_FWLOG_LEVEL_VERBOSE:
		return "Verbose";
	default:
		return "Unsupported";
	}
}

/**
 * ice_fwlog_dump_cfg - Dump current FW logging configuration
 * @hw: pointer to the HW structure
 */
static void ice_fwlog_dump_cfg(struct ice_hw *hw)
{
	struct device *dev = ice_pf_to_dev((struct ice_pf *)(hw->back));
	struct ice_fwlog_cfg *cfg;
	int status;
	u16 i;

	cfg = (struct ice_fwlog_cfg *)kzalloc(sizeof(*cfg), GFP_KERNEL);
	if (!cfg)
		return;

	status = ice_fwlog_get(hw, cfg);
	if (status) {
		kfree(cfg);
		return;
	}

	dev_info(dev, "FWLOG Configuration:\n");
	dev_info(dev, "Options: 0x%04x\n", cfg->options);
	dev_info(dev, "\tarq_ena: %s\n",
		 (cfg->options &
		  ICE_FWLOG_OPTION_ARQ_ENA) ? "true" : "false");
	dev_info(dev, "\tuart_ena: %s\n",
		 (cfg->options &
		  ICE_FWLOG_OPTION_UART_ENA) ? "true" : "false");
	dev_info(dev, "\tPF registered: %s\n",
		 (cfg->options &
		  ICE_FWLOG_OPTION_IS_REGISTERED) ? "true" : "false");

	dev_info(dev, "Module Entries:\n");
	for (i = 0; i < ICE_AQC_FW_LOG_ID_MAX; i++) {
		struct ice_fwlog_module_entry *entry =
			&cfg->module_entries[i];

		dev_info(dev, "\tModule ID %d (%s) Log Level %d (%s)\n",
			 entry->module_id, module_id_to_name(entry->module_id),
			 entry->log_level, log_level_to_name(entry->log_level));
	}

	kfree(cfg);
}
#endif /* FWLOG_SUPPORT_V2 */

/**
 * ice_debugfs_command_write - write into command datum
 * @filp: the opened file
 * @buf: where to find the user's data
 * @count: the length of the user's data
 * @ppos: file position offset
 */
static ssize_t
ice_debugfs_command_write(struct file *filp, const char __user *buf,
			  size_t count, loff_t *ppos)
{
	struct ice_pf *pf = filp->private_data;
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_hw *hw = &pf->hw;
	char *cmd_buf, *cmd_buf_tmp;
#ifdef DEBUGFS_INTERNAL
	u32 address, value;
#endif /* DEBUGFS_INTERNAL */
	ssize_t ret;
	char **argv;
	int argc;

	/* don't allow partial writes and writes when reset is in progress*/
	if (*ppos != 0 || ice_is_reset_in_progress(pf->state))
		return 0;

	cmd_buf = memdup_user(buf, count + 1);
	if (IS_ERR(cmd_buf))
		return PTR_ERR(cmd_buf);
	cmd_buf[count] = '\0';

#ifndef EXTERNAL_RELEASE
	/* FIXME: is this really necessary? In what usage model will there be a
	 * new-line character embedded in a command echoed to the debugfs file?
	 */
#endif
	cmd_buf_tmp = strchr(cmd_buf, '\n');
	if (cmd_buf_tmp) {
		*cmd_buf_tmp = '\0';
		count = (size_t)cmd_buf_tmp - (size_t)cmd_buf + 1;
	}

	argv = argv_split(GFP_KERNEL, cmd_buf, &argc);
	if (!argv) {
		ret = -ENOMEM;
		goto err_copy_from_user;
	}

#ifdef DEBUGFS_INTERNAL
	if (argc == 2 && !strncmp(argv[0], "read", 4)) {
		ret = kstrtou32(argv[1], 0, &address);
		if (ret)
			goto command_help;

		/* check the address */
		if (!ice_addr_in_range(pf, address, ICE_BAR0) ||
		    !ice_addr_aligned(pf, address)) {
			ret = -EFAULT;
			dev_err(dev, "invalid address for read\n");
			goto command_write_done;
		}

		value = rd32(hw, address);
		dev_info(dev, "read: 0x%08x = 0x%08x\n", address, value);
#ifdef HEALTH_STATUS_SUPPORT
	} else if (argc == 2 && !strncmp(argv[0], "health_event", 12)) {
		struct ice_aqc_health_status_elem hse;
		struct ice_rq_event_info event;
		u16 status_code;

		ret = kstrtou16(argv[1], 0, &status_code);
		if (ret)
			goto command_help;

		hse.health_status_code = status_code;
		event.msg_buf = (u8 *)&hse;
		event.buf_len = sizeof(hse);
		event.desc.params.get_health_status.health_status_count = 1;
		ice_process_health_status_event(pf, &event);
#endif /* HEALTH_STATUS_SUPPORT */
#ifndef NO_PTP_SUPPORT
#ifdef SWITCH_MODE
	} else if (argc == 1 && !strncmp(argv[0], "ptp_src_phy_time", 17)) {
#ifndef OLD_IDC_SUPPORT
		struct iidc_ptp_timer_info *ts;
		struct iidc_src_timer *m;
		struct iidc_port_timer *p;
#else /* OLD_IDC_SUPPORT */
		struct ice_ptp_timer_info *ts;
		struct ice_src_timer *m;
		struct ice_port_timer *p;
#endif /* OLD_IDC_SUPPORT */
		u32 port = 0;

		ts = devm_kzalloc(dev, sizeof(*ts), GFP_KERNEL);
		if (!ts) {
			ret = -ENOMEM;
			goto command_write_done;
		}

#ifndef OLD_IDC_SUPPORT
		m = &ts->s_timer;
#else /* OLD_IDC_SUPPORT */
		m = &ts->m_timer;
#endif /* OLD_IDC_SUPPORT */
		p = ts->p_timer;

		ice_ptp_get_src_phy_time(pf, ts);
		dev_info(dev, "ptp_src_phy_time: source: hi = 0x%08x lo = 0x%08x, zo = 0x%08x, inc_hi = 0x%08x, inc_lo = 0x%018x\n",
			 m->time_hi, m->time_lo, m->time_zo,
			 m->inc_hi, m->inc_lo);

		for (port = 0; port < ICE_NUM_EXTERNAL_PORTS; port++) {
			if (!(hw->ena_lports & BIT(port)))
				continue;

#ifndef EXTERNAL_RELEASE
	/* Although we know that Phy_tx_inc may just represent the stale value
	 * that was used to program the PHY INCVAL but that's required for us
	 * to know what the user/driver has programmed. Until someone
	 * overwrites the SHADOW INCVAL registers in PHY, the read back stale
	 * values still represents the last configured INCVAL.
	 */
#endif /* !EXTERNAL_RELEASE */
			dev_info(dev, "ptp_src_phy_time: port %02d: tx_time = 0x%llx, rx_time = 0x%llx, sh_inc = 0x%llx\n",
				 port, p[port].tx_time, p[port].rx_time,
				 p[port].sh_inc);
		}
		devm_kfree(dev, ts);
#endif /* SWITCH_MODE */
#endif /* !NO_PTP_SUPPORT */
	} else if ((argc == 3) && !strncmp(argv[0], "write", 5)) {
		ret = kstrtou32(argv[1], 0, &address);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[2], 0, &value);
		if (ret)
			goto command_help;

		/* check the address */
		if (!ice_addr_in_range(pf, address, ICE_BAR0) ||
		    !ice_addr_aligned(pf, address)) {
			ret = -EFAULT;
			dev_err(dev, "invalid address for write\n");
			goto command_write_done;
		}

		wr32(hw, address, value);
		dev_info(dev, "write: 0x%08x = 0x%08x\n", address, value);
	} else if ((argc == 3) && !strncmp(argv[0], "bar3", 4) &&
		   !strncmp(argv[1], "read", 4)) {
		ret = kstrtou32(argv[2], 0, &address);
		if (ret)
			goto command_help;

		/* check the address */
		if (!ice_addr_in_range(pf, address, ICE_BAR3) ||
		    !ice_addr_aligned(pf, address)) {
			ret = -EFAULT;
			dev_err(dev, "invalid BAR3 address for read\n");
			goto command_write_done;
		}

		value = readl(pf->bar3_hw_addr + address);
		dev_info(dev, "read: 0x%08x = 0x%08x\n", address, value);
#ifndef NO_SBQ_SUPPORT
	} else if ((argc == 3) && !strncmp(argv[0], "read", 4)) {
		struct ice_sbq_msg_input sbq_msg;
		u8 sbq_dst;

		if (!strncmp(argv[1], "rmn0", 4))
			sbq_dst = rmn_0;
		else if (!strncmp(argv[1], "rmn1", 4))
			sbq_dst = rmn_1;
		else if (!strncmp(argv[1], "rmn2", 4))
			sbq_dst = rmn_2;
		else if (!strncmp(argv[1], "cgu", 3))
			sbq_dst = cgu;
		else
			goto command_help;

		ret = kstrtou32(argv[2], 0, &address);
		if (ret)
			goto command_help;

		sbq_msg.dest_dev = sbq_dst;
		sbq_msg.opcode = ice_sbq_msg_rd;
		sbq_msg.msg_addr_low = address & 0xFFFF;
		sbq_msg.msg_addr_high = (address & 0xFFFF0000) >> 16;

		ret = ice_sbq_rw_reg(hw, &sbq_msg);

		if (ret) {
			ret = -EFAULT;
			dev_err(dev, "sideband queue read reg failed\n");
			goto command_write_done;
		}

		value = sbq_msg.data;

		dev_info(dev, "read: 0x%08x = 0x%08x\n", address, value);
	} else if ((argc == 4) && !strncmp(argv[0], "write", 5)) {
		struct ice_sbq_msg_input sbq_msg;
		u8 sbq_dst;

		if (!strncmp(argv[1], "rmn0", 4))
			sbq_dst = rmn_0;
		else if (!strncmp(argv[1], "rmn1", 4))
			sbq_dst = rmn_1;
		else if (!strncmp(argv[1], "rmn2", 4))
			sbq_dst = rmn_2;
		else if (!strncmp(argv[1], "cgu", 3))
			sbq_dst = cgu;
		else
			goto command_help;

		ret = kstrtou32(argv[2], 0, &address);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[3], 0, &value);
		if (ret)
			goto command_help;

		/* write */
		sbq_msg.dest_dev = sbq_dst;
		sbq_msg.opcode = ice_sbq_msg_wr;
		sbq_msg.msg_addr_low = address & 0xFFFF;
		sbq_msg.msg_addr_high = (address & 0xFFFF0000) >> 16;
		sbq_msg.data = value;

		ret = ice_sbq_rw_reg(hw, &sbq_msg);

		if (ret) {
			ret = -EFAULT;
			dev_err(dev, "sideband queue write reg failed\n");
			goto command_write_done;
		}

		/* read back */
		sbq_msg.dest_dev = sbq_dst;
		sbq_msg.opcode = ice_sbq_msg_rd;
		sbq_msg.msg_addr_low = address & 0xFFFF;
		sbq_msg.msg_addr_high = (address & 0xFFFF0000) >> 16;
		sbq_msg.data = 0x0;

		ret = ice_sbq_rw_reg(hw, &sbq_msg);

		if (ret) {
			ret = -EFAULT;
			dev_err(dev, "sideband queue readback reg failed\n");
			goto command_write_done;
		}

		value = sbq_msg.data;

		dev_info(dev, "write: 0x%08x = 0x%08x\n", address, value);
#endif /* !NO_SBQ_SUPPORT */
	} else if ((argc == 1) && !strncmp(argv[0], "pfr", 3)) {
#ifndef SWITCH_MODE
		dev_info(dev, "debugfs: forcing PFR\n");
		ice_schedule_reset(pf, ICE_RESET_PFR);
#else
#ifndef EXTERNAL_RELEASE
/* PFR is not supported in switch mode. */
#endif
		ret = -EINVAL;
		dev_info(dev, "debugfs: PFR is not supported\n");
		goto command_write_done;
#endif
	} else if ((argc == 1) && !strncmp(argv[0], "empr", 4)) {
		dev_info(dev, "debugfs: forcing EMPR\n");
		ice_schedule_reset(pf, ICE_RESET_EMPR);
#ifndef SWITCH_MODE
	} else if ((argc == 1) && !strncmp(argv[0], "corer", 5)) {
		dev_info(dev, "debugfs: forcing CoreR\n");
		ice_schedule_reset(pf, ICE_RESET_CORER);
#endif /* !SWITCH_MODE */
	} else if ((argc == 1) && !strncmp(argv[0], "globr", 5)) {
		dev_info(dev, "debugfs: forcing GlobR\n");
		ice_schedule_reset(pf, ICE_RESET_GLOBR);
#ifdef SWITCH_MODE
	} else if ((argc == 1) && !strncmp(argv[0], "corer_switch_full", 17)) {
		dev_info(dev, "debugfs: forcing CoreR switch full\n");
#ifdef BMSM_MODE
#ifndef OLD_IDC_SUPPORT
		ice_cdev_info_sw_clean_cfg(pf);
#else /* OLD_IDC_SUPPORT */
		ice_peer_sw_clean_cfg(pf);
#endif /* OLD_IDC_SUPPORT */
#endif /* BMSM_MODE */
		ret = ice_schedule_reset(pf, ICE_RESET_CORER);
		if (!ret)
			wr32(&pf->hw, GLGEN_ASSERT_HLP,
			     GLGEN_ASSERT_HLP_CORE_ON_RST_M |
			     GLGEN_ASSERT_HLP_FULL_ON_RST_M);
	} else if ((argc == 1) && !strncmp(argv[0], "corer_switch", 12)) {
		dev_info(dev, "debugfs: forcing CoreR switch\n");
#ifdef BMSM_MODE
#ifndef OLD_IDC_SUPPORT
		ice_cdev_info_sw_clean_cfg(pf);
#else /* OLD_IDC_SUPPORT */
		ice_peer_sw_clean_cfg(pf);
#endif /* OLD_IDC_SUPPORT */
#endif /* BMSM_MODE */
		ret = ice_schedule_reset(pf, ICE_RESET_CORER);
		if (!ret)
			wr32(&pf->hw, GLGEN_ASSERT_HLP, GLGEN_ASSERT_HLP_CORE_ON_RST_M);
	} else if ((argc == 1) && (!strncmp(argv[0], "corer", 5)) &&
				   (strlen(argv[0]) == 5)) {
		dev_info(dev, "debugfs: forcing CoreR\n");
		ice_schedule_reset(pf, ICE_RESET_CORER);
	} else if ((argc == 3) && !strncmp(argv[0], "add_mac", 7)) {
		u8 mac_addr[ETH_ALEN];
		u8 port;

		if (!argv[1] || !argv[2])
			goto command_help;

		ret = kstrtou8(argv[2], 0, &port);
		if (ret)
			goto command_help;

		ret = sscanf(argv[1], "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
			     &mac_addr[0], &mac_addr[1], &mac_addr[2],
			     &mac_addr[3], &mac_addr[4], &mac_addr[5]);

		dev_dbg(dev, "sscanf ret %zu, MAC address: %pM, port no: %u\n",
			ret, mac_addr, port);

		if (ret != sizeof(mac_addr))
			goto command_write_done;

		ret = ice_add_mac_port(pf, mac_addr, port);
		if (ret) {
			dev_err(dev, "failed to add MAC(%pM) filter for port %u\n",
				mac_addr, port);
			goto command_write_done;
		} else {
			dev_info(dev, "added MAC(%pM) filter for port %u\n", mac_addr, port);
		}
#endif /* SWITCH_MODE */
#ifdef FWLOG_SUPPORT_V2
	} else if (argc == 4 && !strncmp(argv[1], "fwlog_cfg", 9)) {
		unsigned long events;
		u8 log_level;

		if (strncmp(argv[0], "update", 6)) {
			ret = -EINVAL;
			goto command_write_done;
		}

		ret = kstrtou8(argv[2], 0, &log_level);
		if (ret)
			goto command_write_done;

		ret = kstrtoul(argv[3], 0, &events);
		if (ret)
			goto command_write_done;

		ret = ice_pf_fwlog_update_modules(pf, log_level, events);
		if (ret)
			goto command_write_done;
	} else if (argc == 2 && !strncmp(argv[0], "register", 8) &&
		   !strncmp(argv[1], "fwlog", 5)) {
		ret = ice_fwlog_register(hw);
		if (ret)
			goto command_write_done;
	} else if (argc == 2 && !strncmp(argv[0], "unregister", 10) &&
		   !strncmp(argv[1], "fwlog", 5)) {
		ret = ice_fwlog_unregister(hw);
		if (ret)
			goto command_write_done;
#endif /* FWLOG_SUPPORT_V2 */
	} else if ((argc > 1) && !strncmp(argv[1], "vsi", 3)) {
		struct ice_vsi_ctx *vsi_ctx;

		vsi_ctx = devm_kzalloc(dev, sizeof(*vsi_ctx), GFP_KERNEL);
		if (!vsi_ctx) {
			ret = -ENOMEM;
			goto command_write_done;
		}

		if (argc == 5 && !strncmp(argv[0], "add", 3) &&
		    !strncmp(argv[2], "pool", 4) &&
		    !strncmp(argv[3], "buf", 3)) {
			u64 vsi_handle;

			get_random_bytes(&vsi_handle, sizeof(vsi_handle));
			vsi_ctx->alloc_from_pool = true;
			memcpy(&vsi_ctx->info, argv[4],
			       min(sizeof(vsi_ctx->info), strlen(argv[4])));

			ret = ice_add_vsi(hw, vsi_handle, vsi_ctx, NULL);
			if (!ret)
				dev_err(dev, "vsi created. vsi_handle = 0x%llx, vsi_num = %d\n",
					vsi_handle, vsi_ctx->vsi_num);
		} else if (argc == 5 && !strncmp(argv[0], "add", 3) &&
			   !strncmp(argv[3], "buf", 3)) {
			u64 vsi_handle;

			get_random_bytes(&vsi_handle, sizeof(vsi_handle));
			ret = kstrtou16(argv[2], 0, &vsi_ctx->vsi_num);
			if (ret)
				goto vsi_error;

			memcpy(&vsi_ctx->info, argv[4],
			       min(sizeof(vsi_ctx->info), strlen(argv[4])));

			ret = ice_add_vsi(hw, vsi_handle, vsi_ctx, NULL);

			if (!ret)
				dev_err(dev, "vsi created. vsi_handle = 0x%llx, vsi_num = %d\n",
					vsi_handle, vsi_ctx->vsi_num);
		} else if (argc == 5 && !strncmp(argv[0], "update", 6) &&
			   !strncmp(argv[3], "buf", 3)) {
			u16 vsi_idx;
			int v;

			ret = kstrtou16(argv[2], 0, &vsi_ctx->vsi_num);
			if (ret)
				goto vsi_error;

			vsi_idx = pf->num_alloc_vsi;
			ice_for_each_vsi(pf, v)
				if (pf->vsi[v] &&
				    pf->vsi[v]->vsi_num == vsi_ctx->vsi_num) {
					vsi_idx = v;
					break;
				}

			memcpy(&vsi_ctx->info, argv[4],
			       min(sizeof(vsi_ctx->info), strlen(argv[4])));

			ret = ice_update_vsi(hw, vsi_idx, vsi_ctx, NULL);
			if (!ret)
				dev_err(dev, "VSI updated. vsi_handle = %d, vsi_num = %d\n",
					vsi_idx, vsi_ctx->vsi_num);
		} else if (argc == 3 && !strncmp(argv[0], "get", 3)) {
#else
	if (argc > 1 && !strncmp(argv[1], "vsi", 3)) {
		if (argc == 3 && !strncmp(argv[0], "get", 3)) {
			struct ice_vsi_ctx *vsi_ctx;

			vsi_ctx = devm_kzalloc(dev, sizeof(*vsi_ctx),
					       GFP_KERNEL);
			if (!vsi_ctx) {
				ret = -ENOMEM;
				goto command_write_done;
			}
#endif /* DEBUGFS_INTERNAL */
			ret = kstrtou16(argv[2], 0, &vsi_ctx->vsi_num);
			if (ret) {
				devm_kfree(dev, vsi_ctx);
				goto command_help;
			}
			ret = ice_aq_get_vsi_params(hw, vsi_ctx, NULL);
			if (ret) {
				devm_kfree(dev, vsi_ctx);
				goto command_help;
			}

			ice_vsi_dump_ctxt(dev, vsi_ctx);
#ifndef DEBUGFS_INTERNAL
			devm_kfree(dev, vsi_ctx);
		} else {
			goto command_help;
#else
		} else if (argc == 3 &&
			   !strncmp(argv[0], "schedule_napi", 13)) {
			u16 vsinum, vsi_idx = pf->num_alloc_vsi;
			int i, num_q_vectors;
			struct ice_vsi *vsi;

			ret = kstrtou16(argv[2], 0, &vsinum);
			if (ret)
				goto vsi_error;

			ice_for_each_vsi(pf, i)
				if (pf->vsi[i] &&
				    pf->vsi[i]->vsi_num == vsinum) {
					vsi_idx = i;
					break;
				}

			vsi = pf->vsi[vsi_idx];

			if (vsi) {
				num_q_vectors = vsi->num_q_vectors;
				for (i = 0; i < num_q_vectors; i++)
					napi_schedule(&vsi->q_vectors[i]->napi);
			} else {
				dev_err(dev, "VSI with vsi_num %d doesn't exists\n",
					vsinum);
			}
		} else if ((argc == 3 || argc == 4) &&
			   !strncmp(argv[0], "free", 4)) {
			bool keep = false;
			u64 vsi_handle;

			ret = kstrtou64(argv[2], 0, &vsi_handle);
			if (ret)
				goto vsi_error;

			if (argc == 4)
				keep = !strncmp(argv[3], "keep", 4);

			ret = ice_free_vsi(hw, vsi_handle, vsi_ctx, keep, NULL);
		} else {
			goto vsi_error;
		}

		if (ret) {
			ret = -EINVAL;
			devm_kfree(dev, vsi_ctx);
			dev_err(dev, "Command failed\n");
			goto command_write_done;
		} else {
			ret = (ssize_t)count;
			dev_info(dev, "Command succeeded\n");
#ifndef EXTERNAL_RELEASE
			/* FIXME - vsi_ctx should be maintained within
			 * ice_pf struct. Freeing as temporary work around
			 * till VSI array in ice_pf is defined.
			 */
#endif
			devm_kfree(dev, vsi_ctx);
#ifndef EXTERNAL_RELEASE
			/* FIXME - the below goto bypasses the "nothing
			 * went wrong" flow
			 */
#endif

			goto command_write_done;
		}

vsi_error:
		devm_kfree(dev, vsi_ctx);
		goto command_help;
	} else if ((argc >= 2) && !strncmp(argv[0], "add", 3) &&
		   !strncmp(argv[1], "switch", 6)) {
		bool ena_stats = false, shared = false;
		u16 counter_id, sw_id;

		if (argc >= 3) {
			ena_stats = !strncmp(argv[2], "ena_stats", 9);
			if (argc > 3)
				shared = !strncmp(argv[3], "shared", 6);
			else
				shared = !strncmp(argv[2], "shared", 6);
		}

		ret = ice_alloc_sw(hw, ena_stats, shared, &sw_id, &counter_id);

		if (ret) {
#ifndef EXTERNAL_RELEASE
			/* FIXME - returning -EINVAL masks actual error
			 * returned by the function. Handle this by returning
			 * POSIX error codes from the function underneath?
			 */
#endif
			ret = -EINVAL;
			goto command_write_done;
		} else {
			dev_info(dev, "sw_id = %d, cntr_id = %d\n", sw_id,
				 counter_id);
		}

#ifndef EXTERNAL_RELEASE
		/* FIXME: save sw_id and counter_id somewhere in ice_pf? */
#endif

	} else if (argc == 6 && !strncmp(argv[0], "free", 4) &&
		   !strncmp(argv[1], "switch", 6) &&
		   !strncmp(argv[2], "swid", 4) &&
		   !strncmp(argv[4], "ctrid", 5)) {
		u16 counter_id, sw_id;

		ret = kstrtou16(argv[3], 0, &sw_id);
		if (ret)
			goto command_help;

		ret = kstrtou16(argv[5], 0, &counter_id);
		if (ret)
			goto command_help;

		ret = ice_free_sw(hw, sw_id, counter_id);
		if (ret) {
#ifndef EXTERNAL_RELEASE
			/* FIXME - returning -EINVAL masks actual error
			 * returned by the function. Handle this by returning
			 * POSIX error codes from the function underneath?
			 */
#endif
			ret = -EINVAL;
			goto command_write_done;
#endif /* DEBUGFS_INTERNAL */
		}
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "switch", 6)) {
		ret = ice_dump_sw_cfg(hw);
		if (ret) {
			ret = -EINVAL;
			dev_err(dev, "dump switch failed\n");
			goto command_write_done;
		}
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "capabilities", 11)) {
		ice_dump_caps(hw);
#ifdef FWLOG_SUPPORT_V2
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "fwlog_cfg", 9)) {
		ice_fwlog_dump_cfg(&pf->hw);
#endif /* FWLOG_SUPPORT_V2 */
#ifndef NO_PTP_SUPPORT
	} else if (argc == 4 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "ptp", 3) &&
		   !strncmp(argv[2], "func", 4) &&
		   !strncmp(argv[3], "capabilities", 11)) {
		ice_dump_ptp_func_caps(hw);
	} else if (argc == 4 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "ptp", 3) &&
		   !strncmp(argv[2], "dev", 3) &&
		   !strncmp(argv[3], "capabilities", 11)) {
		ice_dump_ptp_dev_caps(hw);
#endif /* !NO_PTP_SUPPORT */
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "ports", 5)) {
#ifdef SWITCH_MODE
		int i;

#ifndef EXTERNAL_RELEASE
/* TODO: Following code should be refactored to use ice_for_each_set_bit
 * once supported.
 */
#endif /* !EXTERNAL_RELEASE */
		for (i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++)
			if (hw->ena_lports & BIT(i)) {
				dev_info(dev, "port_info[%d]:\n", i);
				ice_dump_port_info(&hw->port_info[i]);
			}
#else /* !SWITCH_MODE */
		dev_info(dev, "port_info:\n");
		ice_dump_port_info(hw->port_info);
#endif /* SWITCH_MODE */
#if defined(ARFS_SUPPORT) && defined(FDIR_SUPPORT)
#ifdef ICE_ADD_PROBES
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "arfs_stats", 10)) {
		struct ice_vsi *vsi = ice_get_main_vsi(pf);

		if (!vsi) {
			dev_err(dev, "Failed to find PF VSI\n");
		} else if (vsi->netdev->features & NETIF_F_NTUPLE) {
			struct ice_arfs_active_fltr_cntrs *fltr_cntrs;

			fltr_cntrs = vsi->arfs_fltr_cntrs;

			/* active counters can be updated by multiple CPUs */
			smp_mb__before_atomic();
			dev_info(dev, "arfs_active_tcpv4_filters: %d\n",
				 atomic_read(&fltr_cntrs->active_tcpv4_cnt));
			dev_info(dev, "arfs_active_tcpv6_filters: %d\n",
				 atomic_read(&fltr_cntrs->active_tcpv6_cnt));
			dev_info(dev, "arfs_active_udpv4_filters: %d\n",
				 atomic_read(&fltr_cntrs->active_udpv4_cnt));
			dev_info(dev, "arfs_active_udpv6_filters: %d\n",
				 atomic_read(&fltr_cntrs->active_udpv6_cnt));
		}
#endif /* ICE_ADD_PROBES */
#endif /* ARFS_SUPPORT && FDIR_SUPPORT */
#ifdef DEBUGFS_INTERNAL
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "descriptors", 11)) {
		struct ice_vsi *vsi = ice_get_main_vsi(pf);

		if (!vsi)
			dev_err(dev, "Failed to find PF VSI\n");
		else
			ice_vsi_dump_ring_descs(vsi);
	} else if (argc == 3 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "descriptors", 11) &&
		   !strncmp(argv[2], "tx", 2)) {
		struct ice_vsi *vsi = ice_get_main_vsi(pf);

		if (!vsi)
			dev_err(dev, "Failed to find PF VSI\n");
		else
			ice_vsi_dump_tx_ring_descs(vsi);
	} else if (argc == 3 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "descriptors", 11) &&
		   !strncmp(argv[2], "rx", 2)) {
		struct ice_vsi *vsi = ice_get_main_vsi(pf);

		if (!vsi)
			dev_err(dev, "Failed to find PF VSI\n");
		else
			ice_vsi_dump_rx_ring_descs(vsi);
#ifdef INTERNAL_ONLY
	} else if (argc == 4 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "block", 5)) {
		if (!strncmp(argv[2], "switch", 6)) {
			ice_blk_debugfs_create(pf, dev, argv[3]);
		}
	} else if (argc == 3 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "block", 5) &&
		   !strncmp(argv[2], "clean", 5)) {
		ice_blk_debugfs_clean(pf);
	} else if (argc == 3 && !strncmp(argv[0], "dump", 4) &&
		   !strncmp(argv[1], "package", 7)) {
		if (!strncmp(argv[2], "clean", 5)) {
			ice_pkg_debugfs_clean(pf);
		} else {
			ice_pkg_debugfs_init(pf, dev, argv[2]);
		}
#endif /* INTERNAL_ONLY */
#endif /* DEBUGFS_INTERNAL */
	} else if (argc == 2 && !strncmp(argv[0], "dump", 4)) {
		if (!strncmp(argv[1], "mmcast", 6)) {
			ice_dump_sw_rules(hw, ICE_SW_LKUP_MAC);
		} else if (!strncmp(argv[1], "vlan", 4)) {
			ice_dump_sw_rules(hw, ICE_SW_LKUP_VLAN);
		} else if (!strncmp(argv[1], "eth", 3)) {
			ice_dump_sw_rules(hw, ICE_SW_LKUP_ETHERTYPE);
		} else if (!strncmp(argv[1], "pf_vsi", 6)) {
			ice_dump_pf_vsi_list(pf);
		} else if (!strncmp(argv[1], "pf_port_num", 11)) {
			dev_info(dev, "pf_id = %d, port_num = %d\n",
				 hw->pf_id, hw->port_info->lport);
		} else if (!strncmp(argv[1], "pf", 2)) {
			ice_dump_pf(pf);
		} else if (!strncmp(argv[1], "vfs", 3)) {
			ice_dump_all_vfs(pf);
#ifdef FDIR_SUPPORT
		} else if (!strncmp(argv[1], "fdir_stats", 10)) {
			ice_dump_pf_fdir(pf);
#endif /* FDIR_SUPPORT */
#ifdef ACL_DEBUG
		} else if (!strncmp(argv[1], "acl", 3)) {
			ice_acl_dump_info(hw);
#endif
		} else if (!strncmp(argv[1], "reset_stats", 11)) {
			dev_info(dev, "core reset count: %d\n",
				 pf->corer_count);
			dev_info(dev, "global reset count: %d\n",
				 pf->globr_count);
#ifndef SWITCH_MODE
			dev_info(dev, "emp reset count: %d\n", pf->empr_count);
			dev_info(dev, "pf reset count: %d\n", pf->pfr_count);
#endif /* !SWITCH_MODE */
#ifdef SYNCE_SUPPORT
		} else if ((!strncmp(argv[1], "rclk_status", 11))) {
#ifdef FEATURE_BITS_SUPPORT
			if (ice_is_feature_supported(pf, ICE_F_PHY_RCLK))
#else /* FEATURE_BITS_SUPPORT */
			if (ice_is_e810t(&pf->hw))
#endif /* FEATURE_BITS_SUPPORT */
				ice_dump_rclk_status(pf);
#endif /* SYNCE_SUPPORT */
		}
#ifdef SV_SUPPORT
	} else if (argc == 2 && !strncmp(argv[0], "dump_pkt_buf", 12)) {
		u64 addr_arg;
		u32 *addr;
		int i;

		ret = kstrtou64(argv[1], 0, &addr_arg);
		if (ret)
			goto command_help;

		addr = phys_to_virt(addr_arg);
		if (!virt_addr_valid(addr)) {
			/* Do not leak kernel addresses */
			dev_info(dev, "translated virt addr (%p) is invalid\n",
				 addr);
			ret = -EINVAL;
			goto command_write_done;
		}

		/* Do not leak kernel addresses */
		/* For now, printing only 64 bytes */
		for (i = 0; i < 16; i++) {
			dev_info(dev, "addr: %p, val : 0x%08x\n", addr, *addr);
			addr++;
		}
#endif /* SV_SUPPORT */
#ifdef DEBUGFS_INTERNAL
#ifdef INTERNAL_ONLY
	} else if (argc == 5 && !strncmp(argv[0], "dump", 4) &&
			!strncmp(argv[1], "fwdata", 6)) {
		u16 fwdata_len = 4096, fwdata_rlen = 0;
		u32 index, next_index = 0, offset = 0;
		u16 table_id, next_table = 0;
		u8 *fwdata, *pb, cluster_id;
		u16 pb_size, len, i = 0;

		ret = kstrtou8(argv[2], 0, &cluster_id);
		if (ret)
			goto command_help;

		ret = kstrtou16(argv[3], 0, &table_id);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[4], 0, &index);
		if (ret)
			goto command_help;

		fwdata = devm_kzalloc(dev, fwdata_len, GFP_KERNEL);
		if (!fwdata) {
			ret = -ENOMEM;
			goto command_write_done;
		}

		ret = ice_aq_get_internal_data(hw, cluster_id, table_id, index,
					       fwdata, fwdata_len, &fwdata_rlen,
					       &next_table, &next_index, NULL);
		if (ret) {
			ret = -EINVAL;
			dev_info(dev, "command failed\n");
			goto fwdata_err;
		}

		dev_info(dev, "next_table = 0x%x, next_index = 0x%x\n",
			 next_table, next_index);

#ifndef EXTERNAL_RELEASE
/* User specifies cluster_id, table_id and index. The above AQ command passes a
 * data buffer which is populated and returned by the FW. This buffer is
 * already formatted correctly by the firmware and the driver just has to apply
 * a prefix string and print the buffer one byte at a time with each byte
 * printed in 2 char hexadecimal format.
 *	For the scheduler cluster, the prefix is "<table_id,level>:"
 *	Example: for table_id 7, level 3, if five entries (say 10, 12, 32, 1, 0)
 *	were returned, the print should be "7,3:0a0c200100
 *
 *	For all other clusters, the prefix is "<table_id>:"
 *	Example: for table_id 7, if four entries (say 1, 2, 4, 10) were
 *	returned, the print should be "7:0102040a"
 *
 * dev_info is used here because the print format requested cannot be achieved
 * using any existing kernel hex print functions.
 */
#endif

#define ICE_CLUSTER_PREFIX_FMT	"255,255:"
#define ICE_TABLE_PREFIX_FMT	"65535:"

		/* print buffer size (pb_size) is maximum prefix length +
		 * return length from FW * 2 (2-character hex representation of
		 * each byte from FW) + 1 for the terminating null byte (\0).
		 */
		pb_size = max(strlen(ICE_CLUSTER_PREFIX_FMT),
			      strlen(ICE_TABLE_PREFIX_FMT)) +
			(fwdata_rlen * 2) + 1;
		pb = devm_kzalloc(dev, pb_size, GFP_KERNEL);

		if (!pb) {
			ret = -ENOMEM;
			goto fwdata_err;
		}

		if (cluster_id == ICE_AQC_DBG_DUMP_CLUSTER_ID_TXSCHED) {
			u8 *tmp = (u8 *)&table_id;

			len = snprintf(pb, strlen(ICE_CLUSTER_PREFIX_FMT) + 1,
				       "%d,%d:", tmp[1], tmp[0]);
		} else {
			len = snprintf(pb, strlen(ICE_TABLE_PREFIX_FMT) + 1,
				       "%d:", table_id);
		}

		do {
			u16 _pb_size = pb_size - 3;
			offset += len;
			if (offset <= _pb_size) {
				offset = array_index_nospec(offset, _pb_size);
				len = snprintf(&pb[offset], 3, "%02x",
					       fwdata[i]);
			}
		} while (++i < fwdata_rlen);

		dev_info(dev, "%s\n", pb);
		devm_kfree(dev, pb);
fwdata_err:
		devm_kfree(dev, fwdata);
		goto command_write_done;
#endif /* INTERNAL_ONLY */
#endif /* DEBUGFS_INTERNAL */

#if !defined(NO_DCB_SUPPORT) && !defined(SWITCH_MODE)
#ifdef CONFIG_DCB
	} else if (argc == 3 && !strncmp(argv[0], "lldp", 4) &&
				!strncmp(argv[1], "get", 3)) {
		u8 mibtype;
		u16 llen, rlen;
		u8 *buff;

		if (!strncmp(argv[2], "local", 5))
			mibtype = ICE_AQ_LLDP_MIB_LOCAL;
		else if (!strncmp(argv[2], "remote", 6))
			mibtype = ICE_AQ_LLDP_MIB_REMOTE;
		else
			goto command_help;

		buff = devm_kzalloc(dev, ICE_LLDPDU_SIZE, GFP_KERNEL);
		if (!buff) {
			ret = -ENOMEM;
			goto command_write_done;
		}

		ret = ice_aq_get_lldp_mib(hw,
					  ICE_AQ_LLDP_BRID_TYPE_NEAREST_BRID,
					  mibtype, (void *)buff,
					  ICE_LLDPDU_SIZE,
					  &llen, &rlen, NULL);

		if (!ret) {
			if (mibtype == ICE_AQ_LLDP_MIB_LOCAL) {
				dev_info(dev, "LLDP MIB (local)\n");
				print_hex_dump(KERN_INFO, "LLDP MIB (local): ",
					       DUMP_PREFIX_OFFSET, 16, 1,
					       buff, llen, true);
			} else if (mibtype == ICE_AQ_LLDP_MIB_REMOTE) {
				dev_info(dev, "LLDP MIB (remote)\n");
				print_hex_dump(KERN_INFO, "LLDP MIB (remote): ",
					       DUMP_PREFIX_OFFSET, 16, 1,
					       buff, rlen, true);
			}
		} else {
			dev_err(dev, "GET LLDP MIB failed. Status: %ld\n", ret);
		}
		devm_kfree(dev, buff);
#endif /* CONFIG_DCB */
#endif /* !NO_DCB_SUPPORT && !SWITCH_MODE */
#ifdef DEBUGFS_INTERNAL
	} else if ((argc > 2) && !strncmp(argv[0], "send", 4) &&
		   !strncmp(argv[1], "aq_cmd", 6)) {
		u32 cookie_high, cookie_low;
		u32 param2 = 0, param3 = 0;
		struct ice_aq_desc *desc;
		u16 data_buf_len = 0;
		u8 *data_buf = NULL;
		u32 param0, param1;
		u16 datalen;
		u16 retval;
		u16 opcode;
		u16 flags;

		if (!hw->adminq.sq.count) {
			/* send queue not initialized */
			ret = -EAGAIN;
			dev_err(dev, "send queue not initialized\n");
			goto command_write_done;
		}

		if (argc <= 10)
			goto command_help;

		ret = kstrtou16(argv[2], 0, &flags);
		if (ret)
			goto command_help;

		ret = kstrtou16(argv[3], 0, &opcode);
		if (ret)
			goto command_help;

		ret = kstrtou16(argv[4], 0, &datalen);
		if (ret)
			goto command_help;

		ret = kstrtou16(argv[5], 0, &retval);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[6], 0, &cookie_high);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[7], 0, &cookie_low);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[8], 0, &param0);
		if (ret)
			goto command_help;

		ret = kstrtou32(argv[9], 0, &param1);
		if (ret)
			goto command_help;

		if (!strncmp(argv[10], "buf", 3)) {
			int i;

			flags |= ICE_AQ_FLAG_BUF;
			data_buf_len = argc - 11;
			if (data_buf_len > 0)
				flags |= ICE_AQ_FLAG_RD;
			data_buf = devm_kzalloc(dev, max(data_buf_len, datalen),
						GFP_KERNEL);

			if (!data_buf) {
				dev_err(dev, "error allocating buffer\n");
				ret = -ENOMEM;
				goto command_write_done;
			}

			for (i = 0; i < data_buf_len; i++) {
				ret = kstrtou8(argv[i + 11], 0, data_buf + i);
				if (ret) {
					dev_err(dev, "error populating buffer\n");
					devm_kfree(dev, data_buf);
					ret = -EINVAL;
					goto command_write_done;
				}
			}
		} else {
			ret = kstrtou32(argv[10], 0, &param2);
			if (ret)
				goto command_help;

			ret = kstrtou32(argv[11], 0, &param3);
			if (ret)
				goto command_help;
		}

		desc = devm_kzalloc(dev, sizeof(*desc), GFP_KERNEL);
		if (!desc) {
			if (data_buf)
				devm_kfree(dev, data_buf);
			dev_err(dev, "error allocating buffer\n");
			ret = -ENOMEM;
			goto command_write_done;
		}

		desc->flags = cpu_to_le16(flags);
		desc->opcode = cpu_to_le16(opcode);
		desc->datalen = cpu_to_le16(datalen);
		desc->retval = cpu_to_le16(retval);
		desc->cookie_high = cpu_to_le32(cookie_high);
		desc->cookie_low = cpu_to_le32(cookie_low);
		desc->params.generic.param0 = cpu_to_le32(param0);
		desc->params.generic.param1 = cpu_to_le32(param1);
		if (!data_buf) {
			desc->params.generic.addr_high = cpu_to_le32(param2);
			desc->params.generic.addr_low = cpu_to_le32(param3);
		}

		dev_info(dev, "AQ send    0x%04x 0x%04x 0x%04x 0x%04x 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x\n",
			 desc->flags, desc->opcode, desc->datalen, desc->retval,
			 desc->cookie_high, desc->cookie_low,
			 desc->params.generic.param0,
			 desc->params.generic.param1,
			 desc->params.generic.addr_high,
			 desc->params.generic.addr_low);

		if (min(data_buf_len, datalen) &&
		    (le16_to_cpu(desc->flags) & ICE_AQ_FLAG_RD))
			print_hex_dump(KERN_INFO, "AQ send buffer: ",
				       DUMP_PREFIX_OFFSET, 16, 1, data_buf,
				       (size_t)min(data_buf_len, datalen),
				       true);

		ret = ice_sq_send_cmd(hw, &hw->adminq, desc, data_buf,
				      max(data_buf_len, datalen), NULL);
		dev_info(dev, "AQ desc WB 0x%04x 0x%04x 0x%04x 0x%04x 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x\n",
			 desc->flags, desc->opcode, desc->datalen, desc->retval,
			 desc->cookie_high, desc->cookie_low,
			 desc->params.generic.param0,
			 desc->params.generic.param1,
			 desc->params.generic.addr_high,
			 desc->params.generic.addr_low);

		if (data_buf) {
			if (desc->datalen) {
				print_hex_dump(KERN_INFO, "AQ buffer WB: ",
					       DUMP_PREFIX_OFFSET, 16, 1,
					       data_buf,
					       (size_t)
					       le16_to_cpu(desc->datalen),
					       true);
			}
			devm_kfree(dev, data_buf);
		}

		devm_kfree(dev, desc);
		if (!ret) {
			dev_info(dev, "AQ command sent Status : Success\n");
		} else {
			ret = -EINVAL;
			ice_dev_err_errno(dev, ret,
					  "AQ command send failed Opcode 0x%04X Return 0x%02X",
					  desc->opcode, desc->retval);
			devm_kfree(dev, desc);
			goto command_write_done;
		}

#endif /* DEBUGFS_INTERNAL */
	} else if ((argc > 1) && !strncmp(argv[1], "scheduling", 10)) {
		if (argc == 4 && !strncmp(argv[0], "get", 3) &&
		    !strncmp(argv[2], "tree", 4) &&
		    !strncmp(argv[3], "topology", 8)) {
#ifndef SWITCH_MODE
			ice_dump_port_topo(hw->port_info);
#else /* SWITCH_MODE */
			u8 i;

#ifndef EXTERNAL_RELEASE
/* TODO: Following code should be refactored to use ice_for_each_set_bit
 * once supported.
 */
#endif /* !EXTERNAL_RELEASE */
			/* info for all ports */
			for (i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++)
				if (hw->ena_lports & BIT(i))
					ice_dump_port_topo(&hw->port_info[i]);
		} else if (argc == 6 && !strncmp(argv[0], "get", 3) &&
			 !strncmp(argv[2], "tree", 4) &&
			 !strncmp(argv[3], "topology", 8) &&
			 !strncmp(argv[4], "portnum", 7)) {
			u8 port_num;

			ret = kstrtou8(argv[5], 0, &port_num);
			if (ret)
				goto command_help;
			if (port_num >= ICE_MAX_PORT_PER_PCI_DEV)
				goto command_help;
			if (hw->ena_lports & BIT(port_num)) {
				port_num = array_index_nospec(port_num, ICE_MAX_PORT_PER_PCI_DEV);
				ice_dump_port_topo(&hw->port_info[port_num]);
			} else {
				dev_info(dev, "Port %d is not enabled\n", port_num);
			}
#endif /* !SWITCH_MODE */
		}
#ifdef CGU_SUPPORT
	} else if (argc == 4 && !strncmp(argv[0], "set_ts_pll", 10)) {
		u8 time_ref_freq;
		u8 time_ref_sel;
		u8 src_tmr_mode;

		ret = kstrtou8(argv[1], 0, &time_ref_freq);
		if (ret)
			goto command_help;
		ret = kstrtou8(argv[2], 0, &time_ref_sel);
		if (ret)
			goto command_help;
		ret = kstrtou8(argv[3], 0, &src_tmr_mode);
		if (ret)
			goto command_help;

		ice_cfg_cgu_pll_e822(hw, time_ref_freq, time_ref_sel);
		ice_ptp_update_incval(pf, time_ref_freq, src_tmr_mode);
#endif /* CGU_SUPPORT */
	} else {
command_help:
		dev_info(dev, "unknown or invalid command '%s'\n", cmd_buf);
		dev_info(dev, "available commands\n");
#ifdef DEBUGFS_INTERNAL
		dev_info(dev, "\t read <reg>\n");
		dev_info(dev, "\t write <reg> <value>\n");
#ifdef HEALTH_STATUS_SUPPORT
		dev_info(dev, "\t health_event <status_code>\n");
#endif /* HEALTH_STATUS_SUPPORT */
#ifndef NO_PTP_SUPPORT
#ifdef SWITCH_MODE
		dev_info(dev, "\t ptp_src_phy_time\n");
#endif /* SWITCH_MODE */
#endif /* !NO_PTP_SUPPORT */
#ifdef CGU_SUPPORT
		dev_info(dev, "\t set_ts_pll <time_ref_freq> <time_ref_sel> <src_tmr_mode>\n");
#endif /* CGU_SUPPORT */
#ifndef NO_SBQ_SUPPORT
		dev_info(dev, "\t bar3 read <reg>\n");
		dev_info(dev, "\t read <cgu,rmn0,rmn1,rmn2> <reg>\n");
		dev_info(dev, "\t write <cgu,rmn0,rmn1,rmn2> <reg> <value>\n");
#endif /* !NO_SBQ_SUPPORT */
		dev_info(dev, "\t corer\n");
		dev_info(dev, "\t globr\n");
		dev_info(dev, "\t empr\n");
#ifndef SWITCH_MODE
		dev_info(dev, "\t pfr\n");
#else /* SWITCH_MODE */
		dev_info(dev, "\t corer_switch_full\n");
		dev_info(dev, "\t corer_switch\n");
		dev_info(dev, "\t add_mac <mac_address> <port_number>\n");
#endif /* !SWITCH_MODE */
		dev_info(dev, "\t add vsi pool buffer <command_buffer>\n");
		dev_info(dev, "\t add vsi <vsinum> buffer <command_buffer>>\n");
		dev_info(dev, "\t update vsi <vsinum> buffer <command_buffer>\n");
		dev_info(dev, "\t schedule_napi vsi <vsinum>\n");
		dev_info(dev, "\t free vsi <vsi_handle> [keep]\n");
		dev_info(dev, "\t add switch [ena_stats] [shared]\n");
#ifdef INTERNAL_ONLY
		dev_info(dev, "\t dump block switch <dir>\n");
		dev_info(dev, "\t dump block clean\n");
		dev_info(dev, "\t dump package clean\n");
		dev_info(dev, "\t dump package <dir>\n");
#endif /* INTERNAL_ONLY */
#endif /* DEBUGFS_INTERNAL */
		dev_info(dev, "\t get vsi <vsinum>\n");
#ifdef DEBUGFS_INTERNAL
		dev_info(dev, "\t dump descriptors\n");
		dev_info(dev, "\t dump descriptors tx\n");
		dev_info(dev, "\t dump descriptors rx\n");
#endif /* DEBUGFS_INTERNAL */
		dev_info(dev, "\t dump switch\n");
		dev_info(dev, "\t dump ports\n");
		dev_info(dev, "\t dump capabilities\n");
#ifdef FWLOG_SUPPORT_V2
		dev_info(dev, "\t dump fwlog_cfg\n");
#ifdef DEBUGFS_INTERNAL
		dev_info(dev, "\t update fwlog_cfg <fwlog_level> <fwlog_events>");
		dev_info(dev, "\t register fwlog\n");
		dev_info(dev, "\t unregister fwlog\n");
#endif /* DEBUGFS_INTERNAL */
#endif /* FWLOG_SUPPORT_V2 */
#ifndef NO_PTP_SUPPORT
		dev_info(dev, "\t dump ptp func capabilities\n");
		dev_info(dev, "\t dump ptp dev capabilities\n");
#endif /* !NO_PTP_SUPPORT */
		dev_info(dev, "\t dump mmcast\n");
		dev_info(dev, "\t dump vlan\n");
		dev_info(dev, "\t dump eth\n");
		dev_info(dev, "\t dump pf_vsi\n");
		dev_info(dev, "\t dump pf\n");
		dev_info(dev, "\t dump pf_port_num\n");
		dev_info(dev, "\t dump vfs\n");
		dev_info(dev, "\t dump reset_stats\n");
#ifdef FDIR_SUPPORT
		dev_info(dev, "\t dump fdir_stats\n");
#endif /* FDIR_SUPPORT */
#ifdef ACL_DEBUG
		dev_info(dev, "\t dump acl\n");
#endif /* ACL_DEBUG */
#ifdef DEBUGFS_INTERNAL
#ifdef SV_SUPPORT
		dev_info(dev, "\t dump_pkt_buffer <address>\n");
#endif
		dev_info(dev, "\t dump fwdata <cluster_id> <table_id> <index>\n");
		dev_info(dev, "\t free switch swid <value> ctrid <value>\n");
#endif /* DEBUGFS_INTERNAL */
		dev_info(dev, "\t get scheduling tree topology\n");
		dev_info(dev, "\t get scheduling tree topology portnum <port>\n");
#if !defined(NO_DCB_SUPPORT) && !defined(SWITCH_MODE)
#ifdef CONFIG_DCB
		dev_info(dev, "\t lldp get local\n");
		dev_info(dev, "\t lldp get remote\n");
#endif /* CONFIG_DCB */
#endif /* !NO_DCB_SUPPORT && !SWITCH_MODE */
#ifdef DEBUGFS_INTERNAL
		dev_info(dev, "\t send aq_cmd <flags> <opcode> <datalen> <retval> <cookie_h> <cookie_l> <param0> <param1> <param2|\"buffer\"> <param3|command_buffer...>\n");
#if defined(PEER_SUPPORT) && defined(SWITCH_MODE)
		dev_info(dev, "\t send mbxq_cmd <driver_id> <msg_opcode> <seq_num> [data <data>] [buffer <command_buffer>]\n");
#endif /* PEER_SUPPORT && SWITCH_MODE */
#endif /* DEBUGFS_INTERNAL */
#ifdef ARFS_SUPPORT
#ifdef ICE_ADD_PROBES
		dev_info(dev, "\t dump arfs_stats\n");
#endif /* ICE_ADD_PROBES */
#endif /* ICE_ARFS_SUPPORT */
#ifdef SYNCE_SUPPORT
#ifdef FEATURE_BITS_SUPPORT
		if (ice_is_feature_supported(pf, ICE_F_PHY_RCLK))
#else /* FEATURE_BITS_SUPPORT */
		if (ice_is_e810t(&pf->hw))
#endif /* FEATURE_BITS_SUPPORT */
			dev_info(dev, "\t dump rclk_status\n");
#endif /* SYNCE_SUPPORT */
		ret = -EINVAL;
		goto command_write_done;
	}

	/* if we get here, nothing went wrong; return bytes copied */
	ret = (ssize_t)count;

command_write_done:
	argv_free(argv);
err_copy_from_user:
	kfree(cmd_buf);
	return ret;
}

static const struct file_operations ice_debugfs_command_fops = {
	.owner = THIS_MODULE,
	.open  = simple_open,
	.write = ice_debugfs_command_write,
};

/**
 * ice_debugfs_pf_init - setup the debugfs directory
 * @pf: the ice that is starting up
 */
void ice_debugfs_pf_init(struct ice_pf *pf)
{
	const char *name = pci_name(pf->pdev);
	struct dentry *pfile;

	pf->ice_debugfs_pf = debugfs_create_dir(name, ice_debugfs_root);
	if (IS_ERR(pf->ice_debugfs_pf))
		return;

	pfile = debugfs_create_file("command", 0600, pf->ice_debugfs_pf, pf,
				    &ice_debugfs_command_fops);
	if (!pfile)
		goto create_failed;

#ifndef SWITCH_MODE
#ifdef SYNCE_SUPPORT
	/* Expose external CGU debugfs interface if CGU available*/
	if (ice_is_feature_supported(pf, ICE_F_CGU)) {
		if (!debugfs_create_file("cgu", 0400, pf->ice_debugfs_pf, pf,
					 &ice_debugfs_cgu_fops))
			goto create_failed;
	}
#endif /* SYNCE_SUPPORT */
#endif /* SWITCH_MODE */

#ifdef DEBUGFS_INTERNAL
	/* We will use this to validate register addresses before read/write */
	pf->ioremap_len = min_t(int, pci_resource_len(pf->pdev, ICE_BAR0),
				ICE_MAX_CSR_SPACE);

	pf->bar3_ioremap_len = min_t(int, pci_resource_len(pf->pdev, ICE_BAR3),
				     ICE_MAX_CSR_SPACE);

#ifdef INTERNAL_ONLY
	/* initialize Filter Block dump */
	pf->dbg_swt_dir = NULL;
	pf->dbg_swt_data = NULL;
#endif /* INTERNAL_ONLY */
#endif /* DEBUGFS_INTERNAL */
	return;

create_failed:
	dev_err(ice_pf_to_dev(pf), "debugfs dir/file for %s failed\n", name);
	debugfs_remove_recursive(pf->ice_debugfs_pf);
}

/**
 * ice_debugfs_pf_exit - clear out the ices debugfs entries
 * @pf: the ice that is stopping
 */
void ice_debugfs_pf_exit(struct ice_pf *pf)
{
#ifdef DEBUGFS_INTERNAL
#ifdef INTERNAL_ONLY
	/* clean up block dump */
	if (pf->dbg_swt_dir)
		ice_blk_debugfs_clean(pf);
	if (pf->dbg_pkg_data)
		ice_pkg_debugfs_clean(pf);
#endif /* INTERNAL_ONLY */
#endif /* DEBUGFS_INTERNAL */
	debugfs_remove_recursive(pf->ice_debugfs_pf);
	pf->ice_debugfs_pf = NULL;
}

/**
 * ice_debugfs_init - create root directory for debugfs entries
 */
void ice_debugfs_init(void)
{
	ice_debugfs_root = debugfs_create_dir(KBUILD_MODNAME, NULL);
	if (IS_ERR(ice_debugfs_root))
		pr_info("init of debugfs failed\n");
}

/**
 * ice_debugfs_exit - remove debugfs entries
 */
void ice_debugfs_exit(void)
{
	debugfs_remove_recursive(ice_debugfs_root);
	ice_debugfs_root = NULL;
}
