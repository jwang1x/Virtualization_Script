/* Inter-Driver Communication */
#include "ice.h"
#include "ice_lib.h"
#include "ice_fltr.h"
#ifdef VIRTCHNL_IPSEC
#include "ice_ipsec.h"
#endif /* VIRTCHNL_IPSEC */
#ifndef NO_DCB_SUPPORT
#include "ice_dcb_lib.h"
#endif /* !NO_DCB_SUPPORT */
#include "ice_common.h"
#include "ice_vf_veb.h"
#include "ice_external_bridge.h"

DEFINE_IDA(ice_peer_index_ida);
#ifndef EXTERNAL_RELEASE
/* FIXME: this define will be included in the PTP code. Just placing it here
 * to not have an undefined value. Remove when define added elsewhere.
 */
#endif /* !EXTERNAL_RELEASE */
DECLARE_WAIT_QUEUE_HEAD(peer_wait);

#ifndef EXTERNAL_RELEASE
/* Dedicated resources in SWITCH mode, Max length in bytes : 0x3FFFF
 * Dedicated resource (in CSR space) for HLP (Switch), starts at 0x2000000
 * Dedicated resource (in CSR space) for AE (DSC), starts at 0x2040000
 * Dedicated resource (in CSR space) for CRYPTO (IPSec), starts at 0x2080000
 */
#endif /* EXTERNAL_RELEASE */

#define ICE_PEER_PCI_RES_LEN (BIT_ULL(18) - 1)
#define ICE_PEER_SW_RES_START 0x02D00000
#define ICE_PEER_INLINE_CRYPTO_RES_START (ICE_PEER_SW_RES_START | BIT_ULL(19))

static struct mfd_cell ice_mfd_cells[] = ASSIGN_PEER_INFO;

#ifndef EXTERNAL_RELEASE
/* If this function needs to be used elsewhere, move it to ice_lib.c and add
 * a prototype in ice_lib.h
 */
#endif
/**
 * ice_is_vsi_state_nominal
 * @vsi: pointer to the VSI struct
 *
 * returns true if VSI state is nominal, false otherwise
 */
static bool ice_is_vsi_state_nominal(struct ice_vsi *vsi)
{
	if (!vsi)
		return false;

	if (test_bit(ICE_VSI_DOWN, vsi->state) ||
	    test_bit(ICE_VSI_NEEDS_RESTART, vsi->state))
		return false;

	return true;
}

#ifdef ADK_SUPPORT
/**
 * ice_vsi_from_port_info - return the PF VSI's ID from port_info
 * @pf: pointer to the PF that contains VSIs
 * @port_info: pointer to the port_info struct
 */
static int
ice_vsi_from_port_info(struct ice_pf *pf, struct ice_port_info *port_info)
{
	int i;

	ice_for_each_vsi(pf, i)
		if (pf->vsi[i]->port_info == port_info &&
		    pf->vsi[i]->type == ICE_VSI_PF)
			return i;

	/* No VSI found */
	return -EINVAL;
}

/**
 * ice_peer_adk_setup - setup resources for ADK peer
 * @peer_obj: pointer to the ADK peer_obj
 */
static void ice_peer_adk_setup(struct ice_peer_obj *peer_obj)
{
	struct ice_peer_port_info *peer_p;
	struct ice_port_info *p;
	struct ice_pf *pf;
	int i;

	/* If this is not an ADK peer - do not complete setup */
	if (peer_obj->peer_obj_id != ICE_PEER_ADK_ID)
		return;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (!pf)
		return;

	p = pf->hw.port_info;
	peer_p = peer_obj->peer_port_info;

#ifndef EXTERNAL_RELEASE
/* TODO: Following code should be refactored to use ice_for_each_set_bit
 * once supported.
 */
#endif /* !EXTERNAL_RELEASE */
	for (i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++) {
		int vsi_num;

		if (!(pf->hw.ena_lports & BIT(i)))
			continue;
		vsi_num = ice_vsi_from_port_info(pf, &p[i]);

		if (vsi_num < 0)
			continue;
		peer_p[i].lwr_netdev = pf->vsi[vsi_num]->netdev;
		peer_p[i].vsi_num = vsi_num;
		peer_p[i].is_internal = p[i].is_internal_port;
		peer_p[i].lport = p[i].lport;
		/* bank_id is a value from 0-4.
		 * Bank 0 and 1 are on PHY 0
		 * Bank 2 and 3 are on PHY 1
		 * Bank 4 is on PHY 2.
		 */
		peer_p[i].bank_id = p[i].lport / ICE_PORTS_PER_QUAD;
#ifndef ICE_TDD
		ether_addr_copy(peer_p[i].mac_addr, p[i].mac.lan_addr);
#endif /* !ICE_TDD */
		pf->vsi[vsi_num]->adk_peer = peer_obj;
		bitmap_zero(peer_p[i].ena, ICE_PEER_PORT_NBITS);
	}
}

/**
 * ice_clear_port_info - helper to clear data structure
 * @po: peer_obj to clear port info from
 */
static void ice_clear_port_info(struct ice_peer_obj *po)
{
	/* There is an expectation in 'stack mode' that after
	 * reset/init VSI is in down state and it is a user
	 * application resposibility to bring VSI back up.
	 * Here, we clear only state of the peer port info to
	 * be consistent with the state of peer object. All
	 * clean up is done at VSI close call.
	 */
	if (!ice_is_nd_vis() && po->peer_obj_id == ICE_PEER_ADK_ID) {
		int i;

		for (i = 0; i < ICE_MAX_NUM_LPORTS; i++)
			bitmap_zero(po->peer_port_info[i].ena,
				    ICE_PEER_PORT_NBITS);
	}
}
#endif /* ADK_SUPPORT */

/**
 * ice_peer_state_change - manage state machine for peer
 * @peer_obj: pointer to peer's configuration
 * @new_state: the state requested to transition into
 * @locked: boolean to determine if call made with mutex held
 *
 * This function handles all state transitions for peer objects.
 *
 * The state machine is as follows:
 *
 *     +<-----------------------+<-----------------------------+
 *				|<-------+<----------+	       +
 *				\/	 +	     +	       +
 *    INIT  --------------> PROBED --> OPENING	  CLOSED --> REMOVED
 *					 +           +
 *				       OPENED --> CLOSING
 *					 +	     +
 *				       PREP_RST	     +
 *					 +	     +
 *				      PREPPED	     +
 *					 +---------->+
 *
 * NOTE: there is an error condition that can take a peer from OPENING
 * to REMOVED.
 */
static void
ice_peer_state_change(struct ice_peer_obj_int *peer_obj, long new_state,
		      bool locked)
{
	struct device *dev;

	dev = bus_find_device_by_name(&platform_bus_type, NULL,
				      peer_obj->plat_name);

	if (!locked)
		mutex_lock(&peer_obj->peer_obj_state_mutex);

	switch (new_state) {
	case ICE_PEER_OBJ_STATE_INIT:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_REMOVED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_INIT, peer_obj->state);
			dev_dbg(dev, "state transition from _REMOVED to _INIT\n");
		} else {
			set_bit(ICE_PEER_OBJ_STATE_INIT, peer_obj->state);
#ifndef ICE_TDD
			if (dev)
				dev_dbg(dev, "state set to _INIT\n");
#endif /* !ICE_TDD */
		}
		break;
	case ICE_PEER_OBJ_STATE_PROBED:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_INIT,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_PROBED, peer_obj->state);
			dev_dbg(dev, "state transition from _INIT to _PROBED\n");
		} else if (test_and_clear_bit(ICE_PEER_OBJ_STATE_REMOVED,
					      peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_PROBED, peer_obj->state);
			dev_dbg(dev, "state transition from _REMOVED to _PROBED\n");
		} else if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENING,
					      peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_PROBED, peer_obj->state);
			dev_dbg(dev, "state transition from _OPENING to _PROBED\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_OPENING:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_PROBED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_OPENING, peer_obj->state);
			dev_dbg(dev, "state transition from _PROBED to _OPENING\n");
		} else if (test_and_clear_bit(ICE_PEER_OBJ_STATE_CLOSED,
					      peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_OPENING, peer_obj->state);
			dev_dbg(dev, "state transition from _CLOSED to _OPENING\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_OPENED:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENING,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj->state);
			dev_dbg(dev, "state transition from _OPENING to _OPENED\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_PREP_RST:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_PREP_RST, peer_obj->state);
			dev_dbg(dev, "state transition from _OPENED to _PREP_RST\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_PREPPED:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_PREP_RST,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_PREPPED, peer_obj->state);
			dev_dbg(dev, "state transition _PREP_RST to _PREPPED\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_CLOSING:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_CLOSING, peer_obj->state);
			dev_dbg(dev, "state transition from _OPENED to _CLOSING\n");
		}
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_PREPPED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_CLOSING, peer_obj->state);
			dev_dbg(dev, "state transition _PREPPED to _CLOSING\n");
		}
		/* NOTE - up to peer to handle this situation correctly */
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_PREP_RST,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_CLOSING, peer_obj->state);
			dev_warn(dev,
				 "WARN: Peer state _PREP_RST to _CLOSING\n");
		}
		break;
	case ICE_PEER_OBJ_STATE_CLOSED:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_CLOSING,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_CLOSED, peer_obj->state);
			dev_dbg(dev, "state transition from _CLOSING to _CLOSED\n");
#ifdef ADK_SUPPORT
			ice_clear_port_info(&peer_obj->peer_obj);
#endif /* ADK_SUPPORT */
		}
		break;
	case ICE_PEER_OBJ_STATE_REMOVED:
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENED,
				       peer_obj->state) ||
		    test_and_clear_bit(ICE_PEER_OBJ_STATE_CLOSED,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_REMOVED, peer_obj->state);
			dev_dbg(dev, "state from _OPENED/_CLOSED to _REMOVED\n");
			/* Clear registration for events when peer removed */
			bitmap_zero(peer_obj->events, ICE_PEER_OBJ_STATE_NBITS);
		}
		if (test_and_clear_bit(ICE_PEER_OBJ_STATE_OPENING,
				       peer_obj->state)) {
			set_bit(ICE_PEER_OBJ_STATE_REMOVED, peer_obj->state);
			dev_warn(dev, "Peer failed to open, set to _REMOVED");
		}
		break;
	default:
		break;
	}

	if (!locked)
		mutex_unlock(&peer_obj->peer_obj_state_mutex);

	put_device(dev);
}

/**
 * ice_peer_close - close a peer object
 * @peer_obj_int: peer object to close
 * @data: pointer to opaque data
 *
 * This function will also set the state bit for the peer to CLOSED. This
 * function is meant to be called from a ice_for_each_peer().
 */
int ice_peer_close(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	enum ice_close_reason reason = *(enum ice_close_reason *)(data);
	struct ice_peer_obj *peer_obj;
	struct ice_pf *pf;
	int i;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	/* return 0 so ice_for_each_peer will continue closing other peers */
	if (!ice_validate_peer_obj(peer_obj))
		return 0;
	pf = pci_get_drvdata(peer_obj->pdev);

	if (test_bit(ICE_DOWN, pf->state) ||
	    test_bit(ICE_SUSPENDED, pf->state) ||
	    test_bit(ICE_NEEDS_RESTART, pf->state))
		return 0;

	mutex_lock(&peer_obj_int->peer_obj_state_mutex);

	/* no peer driver, already closed, closing or opening nothing to do */
	if (test_bit(ICE_PEER_OBJ_STATE_CLOSED, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_CLOSING, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_OPENING, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_PROBED, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_REMOVED, peer_obj_int->state))
		goto peer_close_out;

	/* Set the peer state to CLOSING */
	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSING, true);

	for (i = 0; i < ICE_EVENT_NBITS; i++)
		bitmap_zero(peer_obj_int->current_events[i].type,
			    ICE_EVENT_NBITS);

	if (peer_obj->peer_ops && peer_obj->peer_ops->close)
		peer_obj->peer_ops->close(peer_obj, reason);

	/* Set the peer state to CLOSED */
	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSED, true);

peer_close_out:
	mutex_unlock(&peer_obj_int->peer_obj_state_mutex);

	return 0;
}

/**
 * ice_close_peer_for_reset - queue work to close peer for reset
 * @peer_obj_int: pointer peer object internal struct
 * @data: pointer to opaque data used for reset type
 */
int ice_close_peer_for_reset(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	struct ice_peer_obj *peer_obj;
	enum ice_reset_req reset;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!ice_validate_peer_obj(peer_obj) ||
	    (!test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state) &&
	     !test_bit(ICE_PEER_OBJ_STATE_PREPPED, peer_obj_int->state)))
		return 0;

	reset = *(enum ice_reset_req *)data;

	switch (reset) {
	case ICE_RESET_EMPR:
		peer_obj_int->rst_type = ICE_REASON_EMPR_REQ;
		break;
	case ICE_RESET_GLOBR:
		peer_obj_int->rst_type = ICE_REASON_GLOBR_REQ;
		break;
	case ICE_RESET_CORER:
		peer_obj_int->rst_type = ICE_REASON_CORER_REQ;
		break;
	default:
		/* reset type is invalid */
		return 1;
	}
#ifndef ICE_TDD
	queue_work(peer_obj_int->ice_peer_wq, &peer_obj_int->peer_close_task);
#endif /* !ICE_TDD */
	return 0;
}

/**
 * ice_check_peer_drv_for_events - check peer_drv for events to report
 * @peer_obj: peer object to report to
 */
static void ice_check_peer_drv_for_events(struct ice_peer_obj *peer_obj)
{
	const struct ice_peer_ops *p_ops = peer_obj->peer_ops;
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_drv_int *peer_drv_int;
	int i;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	if (!peer_obj_int)
		return;
	peer_drv_int = peer_obj_int->peer_drv_int;

	for_each_set_bit(i, peer_obj_int->events, ICE_EVENT_NBITS) {
		struct ice_event *curr = &peer_drv_int->current_events[i];

		if (!bitmap_empty(curr->type, ICE_EVENT_NBITS) &&
		    p_ops->event_handler)
			p_ops->event_handler(peer_obj, curr);
	}
}

/**
 * ice_check_peer_for_events - check peer_objs for events new peer reg'd for
 * @src_peer_int: peer to check for events
 * @data: ptr to opaque data, to be used for the peer struct that opened
 *
 * This function is to be called when a peer object is opened.
 *
 * Since a new peer opening would have missed any events that would
 * have happened before its opening, we need to walk the peers and see
 * if any of them have events that the new peer cares about
 *
 * This function is meant to be called by a ice_for_each_peer.
 */
static int
ice_check_peer_for_events(struct ice_peer_obj_int *src_peer_int, void *data)
{
	struct ice_peer_obj *new_peer = (struct ice_peer_obj *)data;
	const struct ice_peer_ops *p_ops = new_peer->peer_ops;
	struct ice_peer_obj_int *new_peer_int;
	struct ice_peer_obj *src_peer;
	unsigned long i;

	src_peer = ice_get_peer_obj(src_peer_int);
	if (!ice_validate_peer_obj(new_peer) ||
	    !ice_validate_peer_obj(src_peer))
		return 0;

	new_peer_int = peer_to_ice_obj_int(new_peer);

	for_each_set_bit(i, new_peer_int->events, ICE_EVENT_NBITS) {
		struct ice_event *curr = &src_peer_int->current_events[i];

		if (!bitmap_empty(curr->type, ICE_EVENT_NBITS) &&
		    new_peer->peer_obj_id != src_peer->peer_obj_id &&
		    p_ops->event_handler)
			p_ops->event_handler(new_peer, curr);
	}

	return 0;
}

/**
 * ice_for_each_peer - iterate across and call function for each peer obj
 * @pf: pointer to private board struct
 * @data: data to pass to function on each call
 * @fn: pointer to function to call for each peer
 */
int
ice_for_each_peer(struct ice_pf *pf, void *data,
		  int (*fn)(struct ice_peer_obj_int *, void *))
{
	unsigned int i;

	if (!pf->cdev_infos)
		return 0;

	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		struct ice_peer_obj_int *peer_obj_int;

		peer_obj_int = pf->cdev_infos[i];
		if (peer_obj_int) {
			int ret = fn(peer_obj_int, data);

			if (ret)
				return ret;
		}
	}

	return 0;
}

/**
 * ice_finish_init_peer_obj - complete peer object initialization
 * @peer_obj_int: ptr to peer object internal struct
 * @data: ptr to opaque data
 *
 * This function completes remaining initialization of peer objects
 */
int
ice_finish_init_peer_obj(struct ice_peer_obj_int *peer_obj_int,
			 void __always_unused *data)
{
	struct ice_peer_obj *peer_obj;
	struct ice_peer_drv *peer_drv;
	struct device *dev;
	struct ice_pf *pf;
	int ret = 0;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	/* peer_obj will not always be populated at the time of this check */
	if (!ice_validate_peer_obj(peer_obj))
		return ret;

	peer_drv = peer_obj->peer_drv;
	pf = pci_get_drvdata(peer_obj->pdev);
	dev = ice_pf_to_dev(pf);
	/* There will be several assessments of the peer_obj's state in this
	 * chunk of logic.  We need to hold the peer_obj_int's state mutex
	 * for the entire part so that the flow progresses without another
	 * context changing things mid-flow
	 */
	mutex_lock(&peer_obj_int->peer_obj_state_mutex);

	if (!peer_obj->peer_ops) {
		dev_err(dev, "peer_ops not defined in peer obj\n");
		goto init_unlock;
	}

	if (!peer_obj->peer_ops->open) {
		dev_err(dev, "peer_ops:open not defined in peer obj\n");
		goto init_unlock;
	}

	if (!peer_obj->peer_ops->close) {
		dev_err(dev, "peer_ops:close not defined in peer obj\n");
		goto init_unlock;
	}

	/* Peer driver expected to set driver_id during registration */
	if (!peer_drv->driver_id) {
		dev_err(dev, "Peer driver did not set driver_id\n");
		goto init_unlock;
	}

	if ((test_bit(ICE_PEER_OBJ_STATE_CLOSED, peer_obj_int->state) ||
	     test_bit(ICE_PEER_OBJ_STATE_PROBED, peer_obj_int->state)) &&
	    ice_pf_state_is_nominal(pf)) {
		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_OPENING,
				      true);
		ret = peer_obj->peer_ops->open(peer_obj);
		if (ret == -EAGAIN) {
			dev_err(dev, "Peer %d failed to open\n",
				peer_obj->peer_obj_id);
			ice_peer_state_change(peer_obj_int,
					      ICE_PEER_OBJ_STATE_PROBED, true);
			goto init_unlock;
		} else if (ret) {
			ice_peer_state_change(peer_obj_int,
					      ICE_PEER_OBJ_STATE_REMOVED, true);
			peer_obj->peer_ops = NULL;
			module_put(THIS_MODULE);
			goto init_unlock;
		}

		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_OPENED,
				      true);
		ret = ice_for_each_peer(pf, peer_obj,
					ice_check_peer_for_events);
		ice_check_peer_drv_for_events(peer_obj);
	}

	if (test_bit(ICE_PEER_OBJ_STATE_PREPPED, peer_obj_int->state)) {
		enum ice_close_reason reason = ICE_REASON_CORER_REQ;
		int i;

		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSING,
				      true);
		for (i = 0; i < ICE_EVENT_NBITS; i++)
			bitmap_zero(peer_obj_int->current_events[i].type,
				    ICE_EVENT_NBITS);

		peer_obj->peer_ops->close(peer_obj, reason);

		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSED,
				      true);
	}

init_unlock:
	mutex_unlock(&peer_obj_int->peer_obj_state_mutex);

	return ret;
}

/**
 * ice_unreg_peer_obj - unregister specified peer object
 * @peer_obj_int: ptr to peer object internal
 * @data: ptr to opaque data
 *
 * This function invokes object unregistration, removes ID associated with
 * the specified object.
 */
int ice_unreg_peer_obj(struct ice_peer_obj_int *peer_obj_int,
		       void __always_unused *data)
{
	struct ice_peer_drv_int *peer_drv_int;
	struct ice_peer_obj *peer_obj;
	struct pci_dev *pdev;
	struct device *dev;
	struct ice_pf *pf;

	if (!peer_obj_int)
		return 0;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	pdev = peer_obj->pdev;
	if (!pdev)
		return 0;

	pf = pci_get_drvdata(pdev);
	if (!pf)
		return 0;
	dev = ice_pf_to_dev(pf);

	mfd_remove_devices(&pdev->dev);

	peer_drv_int = peer_obj_int->peer_drv_int;

	if (peer_obj_int->ice_peer_wq) {
		if (peer_obj_int->peer_prep_task.func)
			cancel_work_sync(&peer_obj_int->peer_prep_task);

		if (peer_obj_int->peer_close_task.func)
			cancel_work_sync(&peer_obj_int->peer_close_task);
#ifndef ICE_TDD
		destroy_workqueue(peer_obj_int->ice_peer_wq);
#endif /* !ICE_TDD */
	}

	devm_kfree(dev, peer_drv_int);

	devm_kfree(dev, peer_obj_int);

	return 0;
}

/**
 * ice_unroll_peer - destroy peers and peer_wq in case of error
 * @peer_obj_int: ptr to peer object internal struct
 * @data: ptr to opaque data
 *
 * This function releases resources in the event of a failure in creating
 * peer objects or their individual work_queues. Meant to be called from
 * a ice_for_each_peer invocation
 */
int ice_unroll_peer(struct ice_peer_obj_int *peer_obj_int,
		    void __always_unused *data)
{
	struct ice_peer_obj *peer_obj;
	struct ice_pf *pf;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!peer_obj || !peer_obj->pdev)
		return 0;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (!pf)
		return 0;

#ifndef ICE_TDD
	if (peer_obj_int->ice_peer_wq)
		destroy_workqueue(peer_obj_int->ice_peer_wq);
#endif /* !ICE_TDD */

	if (peer_obj_int->peer_drv_int)
		devm_kfree(ice_pf_to_dev(pf), peer_obj_int->peer_drv_int);

	devm_kfree(ice_pf_to_dev(pf), peer_obj_int);

	return 0;
}

#ifdef CONFIG_PM
/**
 * ice_peer_refresh_msix - load new values into ice_peer_obj structs
 * @pf: pointer to private board struct
 */
void ice_peer_refresh_msix(struct ice_pf *pf)
{
	struct ice_peer_obj *peer;
	unsigned int i;

	if (!pf->cdev_infos)
		return;

	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		if (!pf->cdev_infos[i])
			continue;

		peer = ice_get_peer_obj(pf->cdev_infos[i]);
		if (!peer)
			continue;

		switch (peer->peer_obj_id) {
		case ICE_PEER_IPSEC_ID:
			peer->msix_count = pf->num_crypto_msix;
			peer->msix_entries =
				&pf->msix_entries[pf->crypto_base_vector];
			break;
		case ICE_PEER_SW_ID:
			peer->msix_count = pf->num_swt_msix;
			peer->msix_entries =
				&pf->msix_entries[pf->swt_base_vector];
			break;
		default:
			break;
		}
	}
}

#endif /* CONFIG_PM */

/**
 * ice_peer_reg_for_notif - register a peer to receive specific notifications
 * @peer_obj: peer that is registering for event notifications
 * @events: mask of event types peer is registering for
 */
static void
ice_peer_reg_for_notif(struct ice_peer_obj *peer_obj, struct ice_event *events)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(peer_obj) || !events)
		return;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	pf = pci_get_drvdata(peer_obj->pdev);

	bitmap_or(peer_obj_int->events, peer_obj_int->events, events->type,
		  ICE_EVENT_NBITS);

	/* Check to see if any events happened previous to peer registering */
	ice_for_each_peer(pf, peer_obj, ice_check_peer_for_events);
	ice_check_peer_drv_for_events(peer_obj);
}

/**
 * ice_peer_unreg_for_notif - unreg a peer from receiving certain notifications
 * @peer_obj: peer that is unregistering from event notifications
 * @events: mask of event types peer is unregistering for
 */
static void
ice_peer_unreg_for_notif(struct ice_peer_obj *peer_obj,
			 struct ice_event *events)
{
	struct ice_peer_obj_int *peer_obj_int;

	if (!ice_validate_peer_obj(peer_obj) || !events)
		return;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);

	bitmap_andnot(peer_obj_int->events, peer_obj_int->events, events->type,
		      ICE_EVENT_NBITS);
}

/**
 * ice_peer_check_for_reg - check to see if any peers are reg'd for event
 * @peer_obj_int: ptr to peer object internal struct
 * @data: ptr to opaque data, to be used for ice_event to report
 *
 * This function is to be called by ice_for_each_peer to handle an
 * event reported by a peer or the ice driver.
 */
int ice_peer_check_for_reg(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	struct ice_event *event = (struct ice_event *)data;
	DECLARE_BITMAP(comp_events, ICE_EVENT_NBITS);
	struct ice_peer_obj *peer_obj;
	bool check = true;

	peer_obj = ice_get_peer_obj(peer_obj_int);

	if (!ice_validate_peer_obj(peer_obj) || !data)
	/* If invalid obj, in this case return 0 instead of error
	 * because caller ignores this return value
	 */
		return 0;

	if (event->reporter)
		check = event->reporter->peer_obj_id != peer_obj->peer_obj_id;

	if (bitmap_and(comp_events, event->type, peer_obj_int->events,
		       ICE_EVENT_NBITS) &&
	    (test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state) ||
	     test_bit(ICE_PEER_OBJ_STATE_PREP_RST, peer_obj_int->state) ||
	     test_bit(ICE_PEER_OBJ_STATE_PREPPED, peer_obj_int->state)) &&
	    check &&
	    peer_obj->peer_ops->event_handler)
		peer_obj->peer_ops->event_handler(peer_obj, event);

	return 0;
}

/**
 * ice_peer_report_state_change - accept report of a peer state change
 * @peer_obj: peer that is sending notification about state change
 * @event: ice_event holding info on what the state change is
 *
 * We also need to parse the list of peers to see if anyone is registered
 * for notifications about this state change event, and if so, notify them.
 */
static void
ice_peer_report_state_change(struct ice_peer_obj *peer_obj,
			     struct ice_event *event)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_drv_int *peer_drv_int;
	unsigned int e_type;
	int drv_event = 0;
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(peer_obj) || !event)
		return;

	pf = pci_get_drvdata(peer_obj->pdev);
	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	peer_drv_int = peer_obj_int->peer_drv_int;

	e_type = find_first_bit(event->type, ICE_EVENT_NBITS);
	if (!e_type)
		return;

	switch (e_type) {
	/* Check for peer_drv events */
	case ICE_EVENT_MBX_CHANGE:
		drv_event = 1;
		if (event->info.mbx_rdy)
			set_bit(ICE_PEER_DRV_STATE_MBX_RDY,
				peer_drv_int->state);
		else
			clear_bit(ICE_PEER_DRV_STATE_MBX_RDY,
				  peer_drv_int->state);
		break;

	/* Check for peer_obj events */
	case ICE_EVENT_API_CHANGE:
		if (event->info.api_rdy) {
			set_bit(ICE_PEER_OBJ_STATE_API_RDY,
				peer_obj_int->state);
		} else {
			pf->block_mtu_change = false;
			clear_bit(ICE_PEER_OBJ_STATE_API_RDY,
				  peer_obj_int->state);
		}
		break;

#ifndef EXTERNAL_RELEASE
	/* FIXME:
	 * case ICE_EVENT_LINK_CHANGE:
	 * case ICE_EVENT_MTU_CHANGE:
	 * case ICE_EVENT_TC_CHANGE:
	 */
#endif
	default:
		return;
	}

	/* store the event and state to notify any new peers opening */
	if (drv_event)
		memcpy(&peer_drv_int->current_events[e_type], event,
		       sizeof(*event));
	else
		memcpy(&peer_obj_int->current_events[e_type], event,
		       sizeof(*event));

	ice_for_each_peer(pf, event, ice_peer_check_for_reg);

	/* sync Pre-VEB function should be called after ice_peer_check_for_reg
	 * to avoid crash due to uninitialized peer
	 */
	if (test_bit(ICE_PEER_OBJ_STATE_API_RDY, peer_obj_int->state))
		ice_vf_sync_pre_veb_peer(pf);
}

/**
 * ice_peer_unregister - request to unregister peer
 * @peer_obj: peer object
 *
 * This function triggers close/remove on peer_obj allowing peer
 * to unregister.
 */
static int ice_peer_unregister(struct ice_peer_obj *peer_obj)
{
	enum ice_close_reason reason = ICE_REASON_PEER_DRV_UNREG;
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_pf *pf;
	int ret;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (ice_is_reset_in_progress(pf->state))
		return -EBUSY;
#ifdef ICE_TDD
	return 0;
#endif /* ICE_TDD */

	peer_obj_int = peer_to_ice_obj_int(peer_obj);

	ret = ice_peer_close(peer_obj_int, &reason);
	if (ret)
		return ret;

	switch (peer_obj->peer_obj_id) {
#ifdef ADK_SUPPORT
	case ICE_PEER_ADK_ID:
	{
		struct ice_port_info *p = pf->hw.port_info;
		int vsi_num;
		u8 i;

		for (i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++) {
			if (!(pf->hw.ena_lports & BIT(i)))
				continue;

			vsi_num = ice_vsi_from_port_info(pf, &p[i]);

			if (vsi_num < 0)
				continue;

			pf->vsi[vsi_num]->adk_peer = NULL;
		}
		break;
	}
#endif /* ADK_SUPPORT */
	default:
		break;
	}

	peer_obj->peer_ops = NULL;

	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_REMOVED, false);
	module_put(THIS_MODULE);

	return 0;
}

/**
 * ice_peer_register - Called by peer to open communication with LAN
 * @peer_obj: ptr to peer object
 *
 * registering peer is expected to populate the ice_peerdrv->name field
 * before calling this function.
 */
static int ice_peer_register(struct ice_peer_obj *peer_obj)
{
	struct ice_peer_drv_int *peer_drv_int;
	struct ice_peer_obj_int *peer_obj_int;
	u64 support = ICE_IDC_FEATURES;
	struct ice_peer_drv *peer_drv;
	struct ice_pf *pf;

	if (!peer_obj) {
		pr_err("Failed to reg peer_obj: peer_obj ptr NULL\n");
		return -EINVAL;
	}

	if (!peer_obj->pdev) {
		pr_err("Failed to reg peer_obj: peer_obj pdev NULL\n");
		return -EINVAL;
	}

	if (!peer_obj->peer_ops || !peer_obj->ops) {
		pr_err("Failed to reg peer_obj: peer_obj peer_ops/ops NULL\n");
		return -EINVAL;
	}

	peer_drv = peer_obj->peer_drv;
	if (!peer_drv) {
		pr_err("Failed to reg peer_obj: peer drv NULL\n");
		return -EINVAL;
	}

	pf = pci_get_drvdata(peer_obj->pdev);

	if (ice_is_safe_mode(pf) &&
	    peer_drv->driver_id != ICE_PEER_SWITCH_DRIVER) {
		pr_err("Failed to register: in safe mode only IES driver is supported\n");
		return -EOPNOTSUPP;
	}

	if (peer_drv->ver.major != ICE_PEER_MAJOR_VER ||
	    peer_drv->ver.minor != ICE_PEER_MINOR_VER) {
		pr_err("failed to register due to version mismatch:\n");
		pr_err("expected major ver %d, caller specified major ver %d\n",
		       ICE_PEER_MAJOR_VER, peer_drv->ver.major);
		pr_err("expected minor ver %d, caller specified minor ver %d\n",
		       ICE_PEER_MINOR_VER, peer_drv->ver.minor);
		return -EINVAL;
	}

#ifdef ADK_SUPPORT
	/* In ND_VIS=1 mode, the ADK peer is not allowed to load */
	if (ice_is_nd_vis() && peer_obj->peer_obj_id == ICE_PEER_ADK_ID)
		return -EINVAL;

#endif /* ADK_SUPPORT */
	if (peer_drv->ver.support != support) {
		pr_err("failed to register due to support mismatch:\n");
		pr_err("expected feature map %08llx, caller provided %08llx\n",
		       support, peer_drv->ver.support);
		return -EINVAL;
	}

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	peer_drv_int = peer_obj_int->peer_drv_int;
	if (!peer_drv_int) {
		pr_err("Failed to match peer_drv_int to peer_obj\n");
		return -EINVAL;
	}

	peer_drv_int->peer_drv = peer_drv;

	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_PROBED, false);

	if (!try_module_get(THIS_MODULE)) {
		pr_err("Failed to increment module use count\n");
		return -EINVAL;
	}

	return 0;
}

/**
 * ice_peer_sw_clean_cfg - clean NIC configuration created by switch peer obj
 * @pf: ptr to struct ice_pf
 *
 * switch peer objeect can create configuration on NIC that goes away during
 * peer reset. This function rolls back such configuration changes to reach
 * back consistent state between NIC and switch
 */
void ice_peer_sw_clean_cfg(struct ice_pf *pf)
{
	ice_bridge_clean(pf);
	ice_hw_lag_clean(pf);
}

/**
 * ice_peer_request_reset - accept request from peer to perform a reset
 * @peer_obj: peer object that is requesting a reset
 * @reset_type: type of reset the peer is requesting
 */
static int
ice_peer_request_reset(struct ice_peer_obj *peer_obj,
		       enum ice_peer_reset_type reset_type)
{
	enum ice_reset_req reset;
	struct ice_pf *pf;
	int err;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	pf = pci_get_drvdata(peer_obj->pdev);

	switch (reset_type) {
	case ICE_PEER_CORER:
		reset = ICE_RESET_CORER;
		break;
	case ICE_PEER_CORER_SW_CORE:
		reset = ICE_RESET_CORER;
		break;
	case ICE_PEER_CORER_SW_FULL:
		reset = ICE_RESET_CORER;
		break;
	case ICE_PEER_GLOBR:
		reset = ICE_RESET_GLOBR;
		break;
#ifdef INTERNAL_ONLY
	case ICE_PEER_EMPR:
		reset = ICE_RESET_EMPR;
		break;
#endif /* INTERNAL_ONLY */
	default:
		dev_err(ice_pf_to_dev(pf), "incorrect reset request from peer\n");
		return -EINVAL;
	}

#ifndef EXTERNAL_RELEASE
	/* When IES requests CPK reset or when other peer requests both CPK
	 * and HLP reset we need to reflect HLP reset behaviour that affects
	 * CPK side configuration.
	 */
#endif /* !EXTERNAL_RELEASE */
	if (reset_type == ICE_PEER_CORER_SW_CORE ||
	    reset_type == ICE_PEER_CORER_SW_FULL ||
#ifdef INTERNAL_ONLY
	    reset_type == ICE_PEER_EMPR ||
#endif /* INTERNAL_ONLY */
	    reset_type == ICE_PEER_GLOBR)
		ice_peer_sw_clean_cfg(pf);
	err = ice_schedule_reset(pf, reset);
	if (err)
		return err;

	if (reset_type == ICE_PEER_CORER_SW_CORE)
		wr32(&pf->hw, GLGEN_ASSERT_HLP, GLGEN_ASSERT_HLP_CORE_ON_RST_M);

	if (reset_type == ICE_PEER_CORER_SW_FULL ||
	    reset_type == ICE_PEER_GLOBR)
		wr32(&pf->hw, GLGEN_ASSERT_HLP, GLGEN_ASSERT_HLP_CORE_ON_RST_M |
		     GLGEN_ASSERT_HLP_FULL_ON_RST_M);

	return 0;
}

/**
 * ice_peer_is_vsi_ready - query if VSI in nominal state
 * @peer_obj: pointer to ice_peer_obj struct
 * @portnum: number of the port to check VSI state
 */
static int ice_peer_is_vsi_ready(struct ice_peer_obj *peer_obj, u8 portnum)
{
#ifndef ICE_TDD
	struct ice_port_info *pi;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
#else
	struct ice_vsi *vsi = NULL;
#endif /* ICE_TDD */

	/* If the peer_obj or associated values are not valid, then return
	 * 0 as there is no ready port associated with the values passed in
	 * as parameters.
	 */

	if (!peer_obj || !peer_obj->pdev || !pci_get_drvdata(peer_obj->pdev) ||
	    !peer_to_ice_obj_int(peer_obj))
		return 0;

#ifndef ICE_TDD
	pf = pci_get_drvdata(peer_obj->pdev);
	pi = &pf->hw.port_info[portnum];
	vsi = ice_find_vsi_from_pi(pf, pi);
#endif /* !ICE_TDD */

	return ice_is_vsi_state_nominal(vsi);
}

/**
 * ice_peer_vc_send - send a virt channel message from a peer
 * @peer_obj: pointer to a peer object
 * @vf_id: the absolute VF ID of recipient of message
 * @msg: pointer to message contents
 * @len: len of message
 */
static int
ice_peer_vc_send(struct ice_peer_obj *peer_obj, u32 vf_id, u8 *msg, u16 len)
{
	struct ice_pf *pf;
	int status;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;
	if (!msg || !len)
		return -ENOMEM;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (len > ICE_AQ_MAX_BUF_LEN)
		return -EINVAL;

	if (ice_is_reset_in_progress(pf->state))
		return -EBUSY;

	switch (peer_obj->peer_drv->driver_id) {
#ifdef VIRTCHNL_IPSEC
	case ICE_PEER_INLINECRYPTO_DRIVER:
		if (vf_id != VIRTCHNL_IPSEC_BROADCAST_VFID &&
		    !ice_is_valid_vf_id(pf, vf_id))
			return -ENODEV;

		status = ice_ipsec_send_vc_msg(pf, msg, len, vf_id);
		break;
#endif /* VIRTCHNL_IPSEC */
	default:
		dev_err(ice_pf_to_dev(pf),
			"Peer driver (%u) not supported!",
			(u32)peer_obj->peer_drv->driver_id);
		return -ENODEV;
	}

	if (status)
		dev_err(ice_pf_to_dev(pf), "Unable to send msg to VF, error %d\n",
			status);
	return status;
}

/**
 * ice_reserve_peer_qvector - Reserve vector resources for peer drivers
 * @pf: board private structure to initialize
 */
static int ice_reserve_peer_qvector(struct ice_pf *pf)
{
	int index;

#ifndef EXTERNAL_RELEASE
	/* TODO: work with peer driver teams and figure out what they need and
	 * provide necessary base vector information. IDC header file might
	 * get changed.
	 */
#endif
	/* reserve vectors in irq_tracker for peer drivers */
	index = ice_get_res(pf, pf->irq_tracker, ICE_MAX_SWT_VEC,
			    ICE_RES_SWT_VEC_ID);
	if (index < 0)
		return index;
	pf->swt_base_vector = (u16)index;
	pf->num_avail_sw_msix -= ICE_MAX_SWT_VEC;
	index = ice_get_res(pf, pf->irq_tracker, ICE_MAX_CRYPTO_VEC,
			    ICE_RES_CRYPTO_VEC_ID);
	if (index < 0)
		return index;
	pf->crypto_base_vector = (u16)index;
	pf->num_avail_sw_msix -= ICE_MAX_CRYPTO_VEC;
	return 0;
}

/**
 * ice_peer_close_task - call peer's close asynchronously
 * @work: pointer to work_struct contained by the peer_obj_int struct
 *
 * This method (asynchronous) of calling a peer's close function is
 * meant to be used in the reset path.
 */
static void ice_peer_close_task(struct work_struct *work)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_obj *peer_obj;

	peer_obj_int = container_of(work, struct ice_peer_obj_int,
				    peer_close_task);

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!peer_obj || !peer_obj->peer_ops)
		return;

	/* If this peer_obj is going to close, we do not want any state changes
	 * to happen until after we successfully finish or abort the close.
	 * Grab the peer_obj_state_mutex to protect this flow
	 */
	mutex_lock(&peer_obj_int->peer_obj_state_mutex);

	/* Only allow a close to go to the peer if they are in a state
	 * to accept it. The last state of PREP_RST is a special case
	 * that will not normally happen, but it is up to the peer
	 * to handle it correctly.
	 */
	if (test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_PREPPED, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_PREP_RST, peer_obj_int->state)) {
		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSING,
				      true);

		if (peer_obj->peer_ops->close)
			peer_obj->peer_ops->close(peer_obj,
						  peer_obj_int->rst_type);

		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_CLOSED,
				      true);
	}

	mutex_unlock(&peer_obj_int->peer_obj_state_mutex);
}

/**
 * ice_mbx_send_msg_to_peer_drv
 * @pf: ptr to struct ice_pf
 * @peer_drv: pointer to the peer driver structure
 * @msg_opcode: message command opcode
 * @seq_num: message sequence number
 * @data: direct command data (0 for indirect commands)
 * @buf: buffer to use for indirect commands (NULL for direct commands)
 * @buf_size: size of buffer for indirect commands (0 for direct commands)
 * @details: pointer to command details structure or NULL
 *
 * Send (direct or indirect) Message to Peer driver (0x0804).
 */
#ifndef DEBUGFS_SUPPORT
static int
#else
int
#endif /* !DEBUGFS_SUPPORT */
ice_mbx_send_msg_to_peer_drv(struct ice_pf *pf, struct ice_peer_drv *peer_drv,
			     u16 msg_opcode, u16 seq_num, u8 data, void *buf,
			     u16 buf_size, struct ice_sq_cd *details)
{
	struct ice_peer_drv_int *peer_drv_int = NULL;
	struct peerchnl_mbx_desc desc;
	struct ice_hw *hw = &pf->hw;
	struct device *dev;
	unsigned int i;
	int status;

	if (!pf || !peer_drv || !pf->cdev_infos)
		return -EINVAL;

	dev = ice_pf_to_dev(pf);
	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		struct ice_peer_obj_int *dev_int;

		dev_int = pf->cdev_infos[i];
		if (dev_int && dev_int->peer_drv_int->peer_drv == peer_drv) {
			peer_drv_int = dev_int->peer_drv_int;
			break;
		}
	}
	if (!peer_drv_int)
		return -EINVAL;

	if (!test_bit(ICE_PEER_DRV_STATE_MBX_RDY, peer_drv_int->state)) {
		dev_dbg(dev, "peer_id=%d not ready to receive mailbox messages\n",
			peer_drv->driver_id);
		return 0;
	}

	ice_fill_dflt_direct_cmd_desc((struct ice_aq_desc *)&desc,
				      ice_mbx_opc_send_to_peer_drv);

	if (buf)
		desc.flags |= cpu_to_le16(ICE_AQ_FLAG_RD);

	desc.cookie_high.msg_opcode = cpu_to_le16(msg_opcode);
	desc.cookie_high.seq_num = cpu_to_le16(seq_num);

	switch (msg_opcode) {
	case PEERCHNL_OP_FW_CMD_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_FW_CMD_RESP_VER;
		break;
	case PEERCHNL_OP_FW_EVENT:
		desc.cookie_low.ver = PEERCHNL_OP_FW_EVENT_VER;
		break;
	case PEERCHNL_OP_EVENT:
		desc.cookie_low.ver = PEERCHNL_OP_EVENT_VER;
		break;
	case PEERCHNL_OP_ACK:
		desc.cookie_low.ver = PEERCHNL_OP_ACK_VER;
		break;
	case PEERCHNL_OP_WOL_WAKEUP_REASON_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_WOL_WAKEUP_REASON_RESP_VER;
		break;
	case PEERCHNL_OP_ADD_PRE_VEB_ENTRY:
		desc.cookie_low.ver = PEERCHNL_OP_ADD_PRE_VEB_ENTRY_VER;
		break;
	case PEERCHNL_OP_DEL_PRE_VEB_ENTRY:
		desc.cookie_low.ver = PEERCHNL_OP_DEL_PRE_VEB_ENTRY_VER;
		break;
	case PEERCHNL_OP_SET_MAX_FRM_SIZE_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_SET_MAX_FRM_SIZE_VER;
		break;
	default:
		dev_err(dev, "Unknown/unsupported message opcode (%d) to peer_id=%d\n",
			msg_opcode, peer_drv->driver_id);
		return -EOPNOTSUPP;
	}

	desc.cookie_low.data = data;

	desc.param0.cmd_peer_id = cpu_to_le32(peer_drv->driver_id);

	status = ice_sq_send_cmd(hw, &hw->mailboxq, (struct ice_aq_desc *)&desc,
				 buf, buf_size, details);
	if (status)
		dev_err(dev, "Error sending mailbox command peer_id=%d msg_opcode=0x%x seq_num=%d data=%d buf_size=%d status=%d\n",
			peer_drv->driver_id, msg_opcode, seq_num, data,
			buf_size, status);

	return 0;
}

/**
 * ice_check_for_peer - check for at lest one peer_obj
 * @peer_obj_int: pointer to peer obj internal struct
 * @data: opaque pointer - not used
 */
int
ice_check_for_peer(struct ice_peer_obj_int *peer_obj_int,
		   void __always_unused *data)
{
	struct ice_peer_obj *peer_obj;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!ice_validate_peer_obj(peer_obj))
		return 0;

	if (!peer_obj->peer_ops)
		return 0;

	return 1;
}

/**
 * ice_prep_peer_for_reset - queue work to prep peer for reset
 * @peer_obj_int: pointer to peer_obj internal struct
 * @data: opaque pointer used for reset type
 *
 * Meant to be called from a ice_for_each_peer call
 */
int ice_prep_peer_for_reset(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	struct ice_peer_obj *peer_obj;
	enum ice_reset_req reset;
	struct ice_pf *pf;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!ice_validate_peer_obj(peer_obj))
		return 0;

	reset = *(enum ice_reset_req *)data;
	pf = pci_get_drvdata(peer_obj->pdev);

	peer_obj_int->swto = pf->swto;

	switch (reset) {
	case ICE_RESET_EMPR:
		peer_obj_int->rst_type = ICE_REASON_EMPR_REQ;
		break;
	case ICE_RESET_GLOBR:
		peer_obj_int->rst_type = ICE_REASON_GLOBR_REQ;
		break;
	case ICE_RESET_CORER:
		peer_obj_int->rst_type = ICE_REASON_CORER_REQ;
		break;
	default:
		return 1;
	}
#ifndef ICE_TDD
	queue_work(peer_obj_int->ice_peer_wq, &peer_obj_int->peer_prep_task);
#endif /* !ICE_TDD */
	return 0;
}

/**
 * ice_for_each_peer_drv - iterate across and call function for each peer drv
 * @pf: pointer to private board struct
 * @data: data to pass to function on each call
 * @fn: pointer to function to call for each peer
 *
 * This function to be used similarly to ice_for_each_peer_drv
 */
int ice_for_each_peer_drv(struct ice_pf *pf, void *data,
			  int (*fn)(struct ice_peer_drv *, void *))
{
	unsigned int i;

	if (!pf->cdev_infos)
		return 1;

	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		struct ice_peer_obj_int *peer_obj_int;
		struct ice_peer_obj *peer_obj;

		peer_obj_int = pf->cdev_infos[i];
		peer_obj = ice_get_peer_obj(peer_obj_int);
		if (peer_obj_int &&
		    ice_validate_peer_obj(peer_obj)) {
			struct ice_peer_drv *peer_drv;

			peer_drv = peer_obj->peer_drv;
			if (peer_drv) {
				int status = fn(peer_drv, data);

				if (status)
					return status;
			}
		}
	}
	return 0;
}

/**
 * ice_is_peer_in_rdy_state - check if peer_obj is in API_RDY state
 * @peer_obj_int: Peer object structure
 */
static bool ice_is_peer_in_rdy_state(struct ice_peer_obj_int *peer_obj_int)
{
	return (ice_validate_peer_obj(ice_get_peer_obj(peer_obj_int)) &&
		test_bit(ICE_PEER_OBJ_STATE_API_RDY, peer_obj_int->state));
}

/**
 * find_peer_obj_by_drv_id - find peer_obj instance by its driver ID
 * @pf: pointer to private board struct
 * @drv_id: peer driver ID
 */
static
struct ice_peer_obj_int *find_peer_obj_by_drv_id(struct ice_pf *pf, int drv_id)
{
	struct ice_peer_obj_int *peer_obj_int = NULL;
	unsigned int i;

	if (!pf->cdev_infos)
		return NULL;

	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		struct ice_peer_obj *peer_obj;

		peer_obj_int = pf->cdev_infos[i];
		peer_obj = ice_get_peer_obj(peer_obj_int);
		if (peer_obj &&
		    peer_obj->peer_drv &&
		    peer_obj->peer_drv->driver_id == drv_id &&
		    ice_validate_peer_obj(peer_obj))
			break;
		peer_obj_int = NULL;
	}
	return peer_obj_int;
}

/**
 * ice_peer_vf_reset - send msg to peer_obj informing about vf reset
 * @peer_obj_int: pointer to internal peer_obj structure
 * @data: pointer to opaque data
 *
 * This function is meant to be called from ice_for_each_peer()
 */
int ice_peer_vf_reset(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	struct ice_peer_obj *peer_obj;
	u32 vf_id;

	if (!data)
		return -EINVAL;

	vf_id = *(u32 *)(data);
	peer_obj = ice_get_peer_obj(peer_obj_int);

	/* return 0 so ice_for_each_peer will continue */
	if (!ice_validate_peer_obj(peer_obj))
		return 0;

	if (peer_obj->peer_ops && peer_obj->peer_ops->vf_reset)
		peer_obj->peer_ops->vf_reset(peer_obj, vf_id);

	return 0;
}

/**
 * ice_send_vf_reset_to_peers - inform peer_objs about VF getting reset
 * @pf: pointer to pf struct
 * @vf_id: VF's id in PF space
 */
void ice_send_vf_reset_to_peers(struct ice_pf *pf, u16 vf_id)
{
	u32 peer_vf_id = (u32)vf_id;

	ice_for_each_peer(pf, &peer_vf_id, ice_peer_vf_reset);
}

/**
 * ice_send_add_pre_veb_to_peer_drv - send request to add Pre-VEB rule
 * @vf: VF associated to Pre-VEB rule
 * @vlan_id: VLAN id for rules triggered by adding new VLAN
 * @mac_addr: unicast/broadcast MAC address
 */
int
ice_send_add_pre_veb_to_peer_drv(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_drv *peer_drv;
#ifndef ICE_TDD
	struct peerchnl_add_pre_veb_entry pre_veb_entry = {
		.fn = vf->vf_id,
		.vlan_valid = 1,
		.vlan_id = vlan_id
	};
	ether_addr_copy(pre_veb_entry.addr, mac_addr);
#else
	struct peerchnl_add_pre_veb_entry pre_veb_entry = { };
#endif

	peer_obj_int = find_peer_obj_by_drv_id(vf->pf, ICE_PEER_SWITCH_DRIVER);
	if (!peer_obj_int ||
	    !ice_is_peer_in_rdy_state(peer_obj_int) ||
	    !ice_get_peer_obj(peer_obj_int)->peer_drv)
		return -EBUSY;

	peer_drv = ice_get_peer_obj(peer_obj_int)->peer_drv;
	return ice_mbx_send_msg_to_peer_drv(vf->pf, peer_drv,
					    PEERCHNL_OP_ADD_PRE_VEB_ENTRY,
					    ++peer_drv->msg_seq_num, 0,
					    &pre_veb_entry,
					    sizeof(pre_veb_entry),
					    NULL);
}

/**
 * ice_send_del_pre_veb_to_peer_drv - send request to remove Pre-VEB rule
 * @pf: PF associated with the link event
 * @rule_id: Pre-VEB rule id will be deleted
 */
int
ice_send_del_pre_veb_to_peer_drv(struct ice_pf *pf, int rule_id)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_drv *peer_drv;
#ifndef ICE_TDD
	struct peerchnl_del_pre_veb_entry pre_veb_entry = {
		.rule_id = rule_id
	};
#else
	struct peerchnl_del_pre_veb_entry pre_veb_entry = { };
#endif

	peer_obj_int = find_peer_obj_by_drv_id(pf, ICE_PEER_SWITCH_DRIVER);
	if (!peer_obj_int ||
	    !ice_is_peer_in_rdy_state(peer_obj_int) ||
	    !ice_get_peer_obj(peer_obj_int)->peer_drv) {
		dev_info(ice_pf_to_dev(pf), "Not found switch peer_obj, msg is not sent\n");
		return -EBUSY;
	}

	peer_drv = ice_get_peer_obj(peer_obj_int)->peer_drv;
	return ice_mbx_send_msg_to_peer_drv(pf, peer_drv,
					    PEERCHNL_OP_DEL_PRE_VEB_ENTRY,
					    ++peer_drv->msg_seq_num, 0,
					    &pre_veb_entry,
					    sizeof(pre_veb_entry),
					    NULL);
}

#ifdef ADK_SUPPORT
/**
 * ice_peer_req_free_irq - req/free IRQs for a lower netdevs VSI
 * @vsi: VSI to req/fre IRQs for
 * @ena: boolean whether to req or free
 */
static int ice_peer_req_free_irq(struct ice_vsi *vsi, bool ena)
{
	char int_name[ICE_INT_NAME_STR_LEN];

	snprintf(int_name, sizeof(int_name) - 1, "ice_sw-port%d",
		 vsi->port_info->lport);
	if (ena) {
		int ret;

		/* Get vectors from OS for VSI */
		ret = ice_vsi_req_irq_msix(vsi, int_name);
		if (ret)
			return ret;

		/* Enable interrupts in the HW */
		ice_vsi_ena_irq(vsi);
	} else {
		/* Mask off int cause and turn off ints */
		ice_vsi_dis_irq(vsi);

		/* Free OS association with IRQs */
		ice_vsi_free_irq(vsi);
	}

	return 0;
}

/**
 * ice_peer_cfg_irq - enable/disable IRQ for a VSI based on peer context
 * @pp: peer_port_info context
 * @vsi: VSI to enable/disable
 * @ena: boolean whether to enable or disable IRQ
 */
static int
ice_peer_cfg_irq(struct ice_peer_port_info *pp, struct ice_vsi *vsi, bool ena)
{
	if (ena) {
		/* only enable IRQ if both Tx and Rx enabled */
		if (!test_bit(ICE_PEER_TX, pp->ena) ||
		    !test_bit(ICE_PEER_RX, pp->ena))
			return 0;

		if (!test_and_set_bit(ICE_PEER_IRQ, pp->ena)) {
			int ret;

			clear_bit(ICE_VSI_DOWN, vsi->state);

			ret = ice_peer_req_free_irq(vsi, ena);
			if (ret)
				return ret;

			ice_vsi_cfg_msix(vsi);
			ice_napi_enable_all(vsi);
		}
	} else {
		/* disable irq if either Tx or Rx disabled */
		if (test_bit(ICE_PEER_TX, pp->ena) &&
		    test_bit(ICE_PEER_RX, pp->ena))
			return 0;

		if (test_and_clear_bit(ICE_PEER_IRQ, pp->ena)) {
			ice_peer_req_free_irq(vsi, ena);
			ice_napi_disable_all(vsi);
			set_bit(ICE_VSI_DOWN, vsi->state);
		}
	}

	return 0;
}

/**
 * ice_peer_ena_tx - enable Tx on a given port
 * @vsi: VSI struct for port to enable Tx
 * @pp: peer_port_info struct for port
 */
static int ice_peer_ena_tx(struct ice_vsi *vsi, struct ice_peer_port_info *pp)
{
	int err = 0;

	if (test_and_set_bit(ICE_PEER_TX, pp->ena))
		return err;

	err = ice_vsi_setup_tx_rings(vsi);
	if (err)
		goto err_tx_setup;

	err = ice_vsi_cfg_lan_txqs(vsi);
	if (err)
		goto err_tx_setup;

	err = ice_peer_cfg_irq(pp, vsi, true);
	if (err)
		goto err_tx_setup;

	return err;

err_tx_setup:
	ice_vsi_free_tx_rings(vsi);
	return err;
}

/**
 * ice_peer_ena_rx - enable Rx on a given port
 * @vsi: VSI struct for port to enable Rx
 * @pp: peer_port_info struct for port
 */
static int ice_peer_ena_rx(struct ice_vsi *vsi, struct ice_peer_port_info *pp)
{
	int err = 0;

	if (test_and_set_bit(ICE_PEER_RX, pp->ena))
		return err;

	err = ice_vsi_setup_rx_rings(vsi);
	if (err)
		goto err_rx_setup;

	err = ice_vsi_cfg_rxqs(vsi);
	if (err)
		goto err_rx_setup;

	err = ice_peer_cfg_irq(pp, vsi, true);
	if (err)
		goto err_rx_setup;

	err = ice_vsi_start_all_rx_rings(vsi);
	if (err)
		goto err_rx_setup;

	return err;

err_rx_setup:
	ice_vsi_free_rx_rings(vsi);
	return err;
}

/**
 * ice_peer_dis_tx - disable Tx on a given port
 * @vsi: VSI struct for the port to disable Tx
 * @pp: peer_port_info struct for port
 */
static int ice_peer_dis_tx(struct ice_vsi *vsi, struct ice_peer_port_info *pp)
{
	int err = 0, i;

	if (!test_and_clear_bit(ICE_PEER_TX, pp->ena))
		return err;

	err = ice_vsi_stop_lan_tx_rings(vsi, ICE_NO_RESET, 0);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back), "Failed to disable Tx rings\n");

	err = ice_peer_cfg_irq(pp, vsi, false);

#ifdef TXPP_SUPPORT
	ice_for_each_txq(vsi, i) {
		if (vsi->tx_rings[i]->flags & ICE_TX_FLAGS_TXTIME)
			ice_clean_tx_ring(vsi->tx_rings[i],
					  vsi->tstamp_rings[i]);
		else
			ice_clean_tx_ring(vsi->tx_rings[i], NULL);
	}
#else
	ice_for_each_txq(vsi, i)
		ice_clean_tx_ring(vsi->tx_rings[i]);
#endif /* TXPP_SUPPORT */

	ice_vsi_free_tx_rings(vsi);

	return err;
}

/**
 * ice_peer_dis_rx - disable Rx on a given port
 * @vsi: VSI struct for the port to disable Rx
 * @pp: peer_port_info struct for port
 */
static int ice_peer_dis_rx(struct ice_vsi *vsi, struct ice_peer_port_info *pp)
{
	int err = 0, i;

	if (!test_and_clear_bit(ICE_PEER_RX, pp->ena))
		return err;

	err = ice_vsi_stop_all_rx_rings(vsi);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back), "Failed to disable Rx rings\n");

	err = ice_peer_cfg_irq(pp, vsi, false);

	ice_for_each_rxq(vsi, i)
		ice_clean_rx_ring(vsi->rx_rings[i]);

	ice_vsi_free_rx_rings(vsi);

	return err;
}

/**
 * ice_adk_vsi_q_cfg - peer_ops callback for ADK peer to enable/disable queues
 * @peer_obj: pointer to ADK's ice_peer_obj struct
 * @lwr_netdev: pointer to CPK's lower net_device
 * @peer_q_type: Tx, Rx, or Tx+Rx
 * @enable: is this call to enable or disable queues
 *
 * Returns 0 on success and negative on any error
 */
static int
ice_adk_vsi_q_cfg(struct ice_peer_obj *peer_obj, struct net_device *lwr_netdev,
		  u8 peer_q_type, bool enable)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_port_info *pp;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int ret = 0;

	if (!lwr_netdev)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);

	if (ice_is_reset_in_progress(vsi->back->state) ||
	    !test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state))
		return -EBUSY;

	pp = &peer_obj->peer_port_info[vsi->port_info->lport];

	if (enable) {
		if (!test_bit(ICE_VSI_DOWN, vsi->state))
			return 0;

		switch (peer_q_type) {
		case ICE_PEER_TX:
			return ice_peer_ena_tx(vsi, pp);
		case ICE_PEER_RX:
			return ice_peer_ena_rx(vsi, pp);
		case ICE_PEER_TXRX:
			ret = ice_peer_ena_tx(vsi, pp);
			if (ret)
				return ret;
			return ice_peer_ena_rx(vsi, pp);
		default:
			return -EINVAL;
		}
	} else {
		if (test_bit(ICE_VSI_DOWN, vsi->state))
			return 0;

		switch (peer_q_type) {
		case ICE_PEER_TX:
			return ice_peer_dis_tx(vsi, pp);
		case ICE_PEER_RX:
			return ice_peer_dis_rx(vsi, pp);
		case ICE_PEER_TXRX:
			ret = ice_peer_dis_tx(vsi, pp);
			if (ret)
				return ret;
			return ice_peer_dis_rx(vsi, pp);
		default:
			return -EINVAL;
		}
	}
}

/**
 * ice_adk_strt_xmit_internal - transmit a SKB received from ADK object
 * @peer_obj: pointer to ADK's ice_peer_obj struct
 * @skb: sk_buff to transmit
 * @txmd: Tx metadata about sk_buff
 * @netdev: lower net_device
 *
 * The ADK driver populates the SKB's dev field with a pointer
 * to the upper (ADK specific) netdev. The additional netdev
 * passed in (lower netdev) contains the ICE specific tx_ring and VSI.
 *
 * Returns 0 on success and negative value on error.
 */
static int
ice_adk_strt_xmit_internal(struct ice_peer_obj *peer_obj, struct sk_buff *skb,
			   struct ice_nd_tx_md __maybe_unused *txmd,
			   struct net_device *netdev)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_netdev_priv *np;
	struct ice_ring *tx_ring;
	struct ice_vsi *vsi;
	u8 lport;

	if (!netdev)
		return -EINVAL;

	np = netdev_priv(netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	lport = vsi->port_info->lport;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (!test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state))
		return -ENODEV;

	if (test_bit(ICE_VSI_DOWN, vsi->state))
		return -ENODEV;

	if (!test_bit(ICE_PEER_TX, vsi->adk_peer->peer_port_info[lport].ena))
		return -EIO;

#ifndef NO_PTP_SUPPORT
	if (txmd->ts_index >= INDEX_PER_QUAD)
		return -EINVAL;
#endif
	tx_ring = vsi->tx_rings[skb->queue_mapping];
#ifndef NO_PTP_SUPPORT
	tx_ring->ptp_ts_ena = txmd->ts_ena;
	tx_ring->ptp_ts_idx = txmd->ts_index;
#endif /* !NO_PTP_SUPPORT */
#if defined(SWITCH_MODE) && defined(ADK_SUPPORT) && defined(IPSEC_OVRLD_SUPPORT)
	tx_ring->ipsec_offload = txmd->ipsec_offload;
	tx_ring->ipsec_flex_param_2 = txmd->flex_param_2;
#endif /* SWITCH_MODE && ADK_SUPPORT && IPSEC_OVRLD_SUPPORT */
	return ice_start_xmit(skb, netdev);
}

/**
 * ice_adk_get_port_id - provide port ID
 * @netdev: netdev to evaluate
 */
static int ice_adk_get_port_id(struct net_device *netdev)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	if (!netdev)
		return -EINVAL;

	np = netdev_priv(netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (vsi->type != ICE_VSI_PF)
		return -EINVAL;

	if (!vsi->port_info)
		return -EINVAL;

	return vsi->port_info->lport;
}

/**
 * ice_adk_add_mac_port - add a MAC filter for a port
 * @peer_obj: pointer to ADK's ice_peer_obj struct
 * @lwr_netdev: pointer to lower net_device
 * @mac_addr: MAC address to add a filter for
 *
 * Returns 0 on success and negative on any error
 */
static int
ice_adk_add_mac_port(struct ice_peer_obj *peer_obj,
		     struct net_device *lwr_netdev, u8 *mac_addr)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	struct device *dev;
	struct ice_pf *pf;
	int status;

	if (!lwr_netdev || !mac_addr)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	pf = pci_get_drvdata(peer_obj->pdev);
	dev = ice_pf_to_dev(pf);

	peer_obj_int = peer_to_ice_obj_int(peer_obj);

	if (ice_is_reset_in_progress(vsi->back->state) ||
	    !test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state))
		return -EBUSY;

	/* Add a unicast MAC filter so the VSI can get its packets */
	status = ice_fltr_add_mac(vsi, mac_addr, ICE_FWD_TO_VSI);
	if (status)
		dev_err(dev, "failed to add MAC(%pM) filter for vsi_num %u\n",
			mac_addr, vsi->vsi_num);

	return status;
}

#endif /* ADK_SUPPORT */
#ifndef NO_SBQ_SUPPORT
/**
 * ice_peer_sbq_rw_reg - Send message to PHY
 * @obj: The peer_obj
 * @msg: message read or write
 *
 * Send the message received from peer driver to the destination object.
 * Could be PHY or CGU
 */
static int ice_peer_sbq_rw_reg(struct ice_peer_obj *obj, void *msg)
{
	struct ice_hw *hw;
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);
	hw = &pf->hw;

	return ice_sbq_rw_reg(hw, (struct ice_sbq_msg_input *)msg);
}

#endif /* !NO_SBQ_SUPPORT */
#ifndef NO_PTP_SUPPORT
/**
 * ice_peer_update_incval - Update INCVAL according to new freq and mode
 * @obj: The peer object
 * @time_ref_freq: TIME_REF frequency to use
 * @src_tmr_mode: Source timer mode (nanoseconds or locked)
 *
 * Update INCVAL to match the specified TIME_REF frequency and mode.
 */
static int
ice_peer_update_incval(struct ice_peer_obj *obj,
		       enum ice_time_ref_freq time_ref_freq,
		       enum ice_src_tmr_mode src_tmr_mode)
{
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);

	return ice_ptp_update_incval(pf, time_ref_freq, src_tmr_mode);
}

/**
 * ice_peer_get_incval - Get current configured INCVAL parameters
 * @obj: The peer object
 * @time_ref_freq: TIME_REF frequency
 * @src_tmr_mode: Source timer mode (nanoseconds or locked)
 *
 * Update INCVAL to match the specified TIME_REF frequency and mode.
 */
static int
ice_peer_get_incval(struct ice_peer_obj *obj,
		    enum ice_time_ref_freq *time_ref_freq,
		    enum ice_src_tmr_mode *src_tmr_mode)
{
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);

	return ice_ptp_get_incval(pf, time_ref_freq, src_tmr_mode);
}

/**
 * ice_peer_match_and_adj - Perform PTP match and adjust operation
 * @obj: The peer object
 * @at_time: The time at which to perform the adjustment
 * @offset: The adjustment to apply
 *
 * Adjust the source timer by the specified offset at the specified time.
 */
static int
ice_peer_match_and_adj(struct ice_peer_obj *obj,
		       struct ptp_clock_time *at_time,
		       struct ptp_clock_time *offset)
{
	struct ice_pf *pf;
	u64 at_time_ns;
	s64 offset_ns;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;
	if (!at_time || !offset)
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);

	at_time_ns = ((u64)at_time->sec * NSEC_PER_SEC) + at_time->nsec;
	offset_ns = ((s64)offset->sec * NSEC_PER_SEC) + offset->nsec;

	return ice_ptp_match_and_adj(pf, at_time_ns, offset_ns);
}

/**
 * ice_peer_cfg_1588_clk_out_to_cgu - Configure 1588 freq out pin to CGU
 * @obj: The peer object
 * @ena: True to enable; false to disable
 * @period_ns: Period in nanoseconds
 *
 * Configure the 1588_freq_out signal to the CGU.
 */
static int
ice_peer_cfg_1588_clk_out_to_cgu(struct ice_peer_obj *obj, bool ena,
				 u64 period_ns)
{
	struct ice_perout_channel config;
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);

#define CLK_OUT_1588_CHANNEL 2
#define CLK_OUT_1588_GPIO_PIN 6 /* CLK_SYNCE */

	/* wait a bit before starting the output */
	config.start_time = ice_ptp_read_src_clk_reg(pf, NULL) + START_OFFS_NS;
	config.gpio_pin = CLK_OUT_1588_GPIO_PIN;
	config.period = period_ns;
	config.ena = ena;

	return ice_ptp_cfg_clkout(pf, CLK_OUT_1588_CHANNEL, &config, true);
}

/**
 * ice_peer_get_src_phy_tmr_val - Perform synchronized read of source/PHY
 *                                 timers
 * @obj: The peer object
 * @ts: pointer to ice_ptp_timer_info structure (out param)
 *
 * Perform a synchronized read of the source and PHY timers.  Used for debug
 * purposes.
 */
static int
ice_peer_get_src_phy_tmr_val(struct ice_peer_obj *obj,
			     struct ice_ptp_timer_info *ts)
{
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(obj))
		return -EINVAL;
	if (!ts)
		return -EINVAL;

	pf = pci_get_drvdata(obj->pdev);

	return ice_ptp_get_src_phy_time(pf, ts);
}

#endif /* !NO_PTP_SUPPORT */
/**
 * ice_peer_check_ack - check peer for _PREPPED state
 * @peer_obj_int: pointer to peers internal struct
 * @data: opaque data pointer
 *
 * This function is meant to be called form a ice_for_each_peer call
 */
static int
ice_peer_check_ack(struct ice_peer_obj_int *peer_obj_int,
		   void __always_unused *data)
{
	struct ice_peer_obj *peer_obj;

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!ice_validate_peer_obj(peer_obj))
		return 0;

	/* If even one peer is in _PREP_RST state stop checking (return 1) */
	if (test_bit(ICE_PEER_OBJ_STATE_PREP_RST, peer_obj_int->state))
		return 1;

	return 0;
}

/**
 * ice_peer_ack_reset_prep - receive an ACK from peer for prep_reset
 * @peer_obj: pointer to struct for peer providing ACK
 */
static void ice_peer_ack_reset_prep(struct ice_peer_obj *peer_obj)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_pf *pf;

	if (!ice_validate_peer_obj(peer_obj))
		return;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	pf = pci_get_drvdata(peer_obj->pdev);

	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_PREPPED, false);
	if (!(ice_for_each_peer(pf, NULL, ice_peer_check_ack))) {
		pf->swto_ack = true;
		wake_up(&peer_wait);
	}
}

/**
 * ice_sched_tree_size - calculate required buffer for the sched tree struct
 * @pf: PF which we are building tree for
 *
 * returns buffer size in bytes needed to accommodate tree
 */
static unsigned int ice_sched_tree_size(struct ice_pf *pf)
{
	unsigned int size = 0;
	int i;

	size = sizeof(struct ice_sched_tree);
	size += sizeof(struct ice_sched_tree_port) * pf->hw.num_total_ports;

	for (i = 0; i < pf->hw.num_total_ports; i++) {
		size += sizeof(struct ice_sched_tree_branch) *
			ICE_TXSCHED_MAX_BRANCHES;

		size += sizeof(struct ice_sched_tree_elem) *
			ICE_AQC_TOPO_MAX_LEVEL_NUM * ICE_TXSCHED_MAX_BRANCHES;
	}
	return size;
}

/**
 * ice_sched_tree_alloc_from_buf - set up tree xfer structures inside buffer
 * @pf: PF which we are building tree for
 * @buf: buffer in which to store tree parameters, usually allocated by the
 *        AE driver. Note: buff must be large enough to hold the tree; it
 *        should be sized according to ice_sched_tree_size().
 * @tree_out: pointer to where the struct ice_sched_tree was created within the
 *            buffer (currently, the start of the buffer).
 */
static void
ice_sched_tree_alloc_from_buf(struct ice_pf *pf, void *buf,
			      struct ice_sched_tree **tree_out)
{
#ifndef EXTERNAL_RELEASE
/* FIXME - For NIC mode, num_ports is always 1, so this function should be
 * rewritten to use num_ports only in case of switch mode.
 */
#endif
	struct ice_sched_tree *tree;
	u32 offset = 0;
	int i, j;

	tree = (struct ice_sched_tree *)buf;
	offset += sizeof(*tree);

	tree->num_ports = pf->hw.num_total_ports;
#ifndef EXTERNAL_RELEASE
	/* TODO: Dead code, should be removed in future */
#endif

	tree->ports = (struct ice_sched_tree_port *)((u8 *)buf + offset);
	offset += sizeof(struct ice_sched_tree_port) * tree->num_ports;

	for (i = 0; i < tree->num_ports; i++) {
		tree->ports[i].branches =
			(struct ice_sched_tree_branch *)((u8 *)buf + offset);
		offset += sizeof(struct ice_sched_tree_branch) *
			  ICE_TXSCHED_MAX_BRANCHES;
		tree->ports[i].num_branches = 0;

		for (j = 0; j < ICE_TXSCHED_MAX_BRANCHES; j++) {
			tree->ports[i].branches[j].elems =
			    (struct ice_sched_tree_elem *)((u8 *)buf + offset);
			offset += (sizeof(struct ice_sched_tree_elem) *
				  ICE_AQC_TOPO_MAX_LEVEL_NUM);
			tree->ports[i].branches[j].num_elems = 0;
		}
	}

	*tree_out = tree;
}

/**
 * ice_build_node_branch - traverse a sched branch and tally elements
 * @node: pointer to ice_sched_node to traverse and tally
 * @branch: pointer to the branch we are tallying into
 *
 * This function is intended to be called with the sched_lock held for
 * the sched tree which contains node
 */
static void
ice_build_node_branch(struct ice_sched_node *node,
		      struct ice_sched_tree_branch *branch)
{
	int i;

	/* tally this element */
	memcpy(&branch->elems[branch->num_elems], &node->info,
	       ICE_AE_ELEMENT_SIZE);
	branch->num_elems++;

	for (i = 0; i < node->num_children; i++)
		ice_build_node_branch(node->children[i], branch);
}

/**
 * ice_build_node_port - traverse a root node's branches to build sched tree
 * @node: pointer to ice_sched_node to use for root of tree
 * @port: pointer to ice_sched_tree_port to be filled
 *
 * This function is intended to be called with the sched_lock held for
 * the sched tree which has node as its root
 */
static void
ice_build_node_port(struct ice_sched_node *node,
		    struct ice_sched_tree_port *port)
{
	int i;

	port->num_branches = node->num_children;
	memcpy(&port->root.raw, &node->info, ICE_AE_ELEMENT_SIZE);

	for (i = 0; i < port->num_branches; i++) {
		port->branches[i].num_elems = 0;
		ice_build_node_branch(node->children[i], &port->branches[i]);
	}
}

/**
 * ice_peer_report_txsched_config - fill buffer with TXSched tree topology
 * @peer_obj: peer we are sending txsched report to
 * @buf: pointer to supplied memory to fill with topology elements
 * @buf_size: size of buffer in bytes
 *
 * Returns 0 on success, and -ENOMEM if the trees won't fit in buff or
 * cannot allocate memory to locally build the tree and -EINVAL if
 * peer_obj is invalid or retrieved logical port index is invalid
 */
static int
ice_peer_report_txsched_config(struct ice_peer_obj *peer_obj, void *buf,
			       u32 buf_size)
{
	struct ice_sched_tree *tree;
	unsigned int tree_size = 0;
	struct device *dev;
	struct ice_pf *pf;
	u8 i;

	if (!ice_validate_peer_obj(peer_obj))
		return -EINVAL;

	if (!buf)
		return -ENOMEM;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (!ice_pf_state_is_nominal(pf))
		return -EBUSY;
	dev = ice_pf_to_dev(pf);

	tree_size = ice_sched_tree_size(pf);

	dev_dbg(dev, "Tree size: %u\n", tree_size);

	if (buf_size < tree_size) {
		dev_err(dev, "xfer buff too small to fit tree\n");
		return -ENOMEM;
	}

	ice_sched_tree_alloc_from_buf(pf, buf, &tree);

#ifdef SV_SUPPORT
	dev_info(dev, "TXSched ports: %d\n", tree->num_ports);
#endif /* SV_support */

	/* Loop through logical ports */
	for (i = 0; i < tree->num_ports; i++) {
		s8 pi_idx = ice_get_port_info_idx(&pf->hw, i);

		if (pi_idx < 0) {
			dev_err(dev, "txsched config: invalid port number %d\n",
				i);
			return -EINVAL;
		}
#ifdef SV_SUPPORT
		dev_info(dev, "Building Port: %d\n", pi_idx);
#endif /* SV_support */
		/* Reading the root node and subsequent children must
		 * be controlled with the sched_lock for the port.
		 * Locking here so that all subsequent calls to nodes
		 * in this tree are also locked in the recursive calls
		 * from within ice_build_node_* functions
		 */
		ice_acquire_lock(&pf->hw.port_info[pi_idx].sched_lock);
		/* get the txsched tree for  port i */
		ice_build_node_port(pf->hw.port_info[pi_idx].root,
				    &tree->ports[i]);
		ice_release_lock(&pf->hw.port_info[pi_idx].sched_lock);
	}
	memcpy(buf, tree, tree_size);

#ifdef SV_SUPPORT
	dev_info(dev, "TXSCHED CONFIG:\n");
	dev_info(dev, "Num Ports: %d\n", tree->num_ports);
	for (i = 0; i < tree->num_ports; i++) {
		struct ice_aqc_txsched_elem_data elem;
		int j;

		dev_info(dev, "PORT %d:\n", i);
		memcpy(&elem, &tree->ports[i].root, ICE_AE_ELEMENT_SIZE);
		dev_info(dev, "Root: %d\n", elem.node_teid);
		dev_info(dev, "Num Branches %d:\n",
			 tree->ports[i].num_branches);
		for (j = 0; j < tree->ports[i].num_branches; j++) {
			int k = 0;

			dev_info(dev, "\tBranch: %d\n", j);
			dev_info(dev, "\tNode_id\tParent_id\n");
			for (; k < tree->ports[i].branches[j].num_elems; k++) {
				memcpy(&elem,
				       &tree->ports[i].branches[j].elems[k],
				       ICE_AE_ELEMENT_SIZE);
				dev_info(dev, "%d\t%d\t%d\n", k, elem.node_teid,
					 elem.parent_teid);
			}
		}
	}

#endif /* SV_SUPPORT */
	return 0;
}

/**
 * ice_peer_prep_task - call peer's prep for reset asynchronously
 * @work: pointer to work_struct contained by the peer_obj_int struct
 */
static void ice_peer_prep_task(struct work_struct *work)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_peer_obj *peer_obj;

	peer_obj_int = container_of(work, struct ice_peer_obj_int,
				    peer_prep_task);
	if (!peer_obj_int)
		return;

	mutex_lock(&peer_obj_int->peer_obj_state_mutex);

	peer_obj = ice_get_peer_obj(peer_obj_int);
	if (!peer_obj || !peer_obj->peer_ops ||
	    !test_bit(ICE_PEER_OBJ_STATE_OPENED, peer_obj_int->state)) {
		mutex_unlock(&peer_obj_int->peer_obj_state_mutex);
		return;
	}

	ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_PREP_RST, true);

	if (peer_obj->peer_ops->prep_for_reset) {
		mutex_unlock(&peer_obj_int->peer_obj_state_mutex);
		peer_obj->peer_ops->prep_for_reset(peer_obj,
						   peer_obj_int->rst_type,
						   peer_obj_int->swto);
	} else {
		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_PREPPED,
				      true);
		mutex_unlock(&peer_obj_int->peer_obj_state_mutex);
	}
}

/**
 * ice_send_event_to_peer_drv - send event msg to peer driver
 * @peer_drv: pointer to struct ice_peer_drv
 * @data: pointer to opaque data
 *
 * Helper function to send an event message to a peer driver.
 */
static int ice_send_event_to_peer_drv(struct ice_peer_drv *peer_drv, void *data)
{
	struct ice_peer_event_info *ev = (struct ice_peer_event_info *)data;

	if (!peer_drv)
		return -EINVAL;

	return ice_mbx_send_msg_to_peer_drv(ev->pf, peer_drv, (u16)ev->op,
					    ++peer_drv->msg_seq_num, 0,
					    ev->event_msg, ev->event_len, NULL);
}

/**
 * ice_send_fw_event_to_all_peer_drv - send FW AdminQ event msg to peer drivers
 * @pf: ptr to struct ice_pf
 * @event: FW Admin ARQ event
 */
void
ice_send_fw_event_to_all_peer_drv(struct ice_pf *pf,
				  struct ice_rq_event_info *event)
{
	struct peerchnl_fw_data *fw_event_msg;
	struct ice_peer_event_info ev;
	u16 datalen, size;

	datalen = le16_to_cpu(event->desc.datalen);
	WARN_ON(datalen != event->msg_len);
	size = (u16)sizeof(fw_event_msg->desc) + datalen;

	fw_event_msg = (struct peerchnl_fw_data *)kzalloc(size, GFP_KERNEL);
	if (!fw_event_msg)
		return;
	fw_event_msg->desc = event->desc;
	memcpy(fw_event_msg->buf, event->msg_buf, datalen);

	ev.pf = pf;
	ev.op = PEERCHNL_OP_FW_EVENT;
	ev.event_msg = fw_event_msg;
	ev.event_len = size;

	ice_for_each_peer_drv(pf, &ev, ice_send_event_to_peer_drv);
	kfree(fw_event_msg);
}

/**
 * ice_send_gen_event_to_all_peer_drv - send generic event msg to peer drivers
 * @pf: ptr to struct ice_pf
 * @event: base generic event structure
 *
 * No direct response is expected from the peers, though it may generate other
 * messages in response to this one. All Events must be ACKed by the receiver.
 */
void ice_send_gen_event_to_all_peer_drv(struct ice_pf *pf,
					struct peerchnl_event *event)
{
#ifndef ICE_TDD
	struct ice_peer_event_info ei = {
		.pf = pf,
		.event_msg = event,
		.event_len = sizeof(*event),
		.op = PEERCHNL_OP_EVENT,
	};
#else
	struct ice_peer_event_info ei = { };
#endif

	ice_for_each_peer_drv(pf, &ei, ice_send_event_to_peer_drv);
}

/**
 * ice_process_msg_from_peer_drv - handle peer driver message event via ARQ
 * @peer_drv: ptr to struct ice_peer_drv
 * @data: ptr to opaque data
 *
 * Return code 1 is intended to break the loop going over all of the peers and
 * should not be processed as an error.
 */
int ice_process_msg_from_peer_drv(struct ice_peer_drv *peer_drv, void *data)
{
	u16 seq_num, msg_opcode, buf_size, sender_id;
	struct peerchnl_port_state_change *psc;
	enum peerchnl_status_code msg_data;
	struct ice_rq_event_info event_lm;
	struct ice_rq_event_info *event;
	struct peerchnl_mbx_desc *desc;
	struct device *dev;
	struct ice_pf *pf;
	void *fw_cmd_buf;
	int status;
	void *buf;

	if (!peer_drv || !data)
		return -EINVAL;
	msg_data = PEERCHNL_STATUS_ERR_VER_MISMATCH;
	pf = ((struct ice_recv_ies_msg_info *)data)->pf;
	if (!pf)
		return -EINVAL;
	dev = ice_pf_to_dev(pf);
	event = ((struct ice_recv_ies_msg_info *)data)->event;
	if (!event)
		return -EINVAL;

	desc = (struct peerchnl_mbx_desc *)&event->desc;
	sender_id = le16_to_cpu(desc->mbx_data.event_sender_id);
	if (peer_drv->driver_id != sender_id)
		return 0;
	seq_num = le16_to_cpu(desc->cookie_high.seq_num);
	msg_opcode = le16_to_cpu(desc->cookie_high.msg_opcode);
	buf = (void *)event->msg_buf;
	buf_size = le16_to_cpu(desc->datalen);
	if (buf_size && !buf)
		return -EINVAL;

	switch (msg_opcode) {
	case PEERCHNL_OP_FW_CMD_REQ:
	{
		struct peerchnl_fw_data *fw_cmd;
		struct ice_aq_desc *fw_desc;

		if (desc->cookie_low.ver != PEERCHNL_OP_FW_CMD_REQ_VER)
			goto ack;

		fw_cmd = (struct peerchnl_fw_data *)buf;
		fw_desc = &fw_cmd->desc;

		if (le16_to_cpu(fw_cmd->desc.flags) & ICE_AQ_FLAG_BUF)
			fw_cmd_buf = fw_cmd->buf;
		else
			fw_cmd_buf = NULL;

		switch (le16_to_cpu(fw_desc->opcode)) {
		case ice_aqc_opc_set_wol_parameters:
		{
			struct ice_aqc_set_wol_parameters *wol_params;
			u32 pmask;
			u16 timer;
			u32 val;

			wol_params = &fw_desc->params.set_wol_parameters;
			pmask = le32_to_cpu(wol_params->monitored_ports_bits);
			timer = le16_to_cpu(wol_params->timer_value);
			val = rd32(&pf->hw, PFPM_WUFC);

			if (timer && pmask && pf->wol_ena)
				wr32(&pf->hw, PFPM_WUFC, val | PFPM_WUFC_MNG_M);
			else
				wr32(&pf->hw, PFPM_WUFC,
				     val & ~PFPM_WUFC_MNG_M);
			break;
		}
		default:
			break;
		}

		status = ice_aq_send_cmd(&pf->hw, fw_desc, fw_cmd_buf,
					 le16_to_cpu(fw_desc->datalen), NULL);
		if (status) {
			dev_err(dev, "Error sending FW Admin command on behalf of peer ID %d status=%d\n",
				sender_id, status);

			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
		} else {
			msg_data = PEERCHNL_STATUS_SUCCESS;
		}
		/* Send FW AdminQ completion/writeback as a response to peer */
		msg_opcode = PEERCHNL_OP_FW_CMD_RESP;
		goto send_resp;
	}
	case PEERCHNL_OP_EVENT:
	{
		struct peerchnl_event *peerchnl_event;

		if (desc->cookie_low.ver != PEERCHNL_OP_EVENT_VER)
			goto ack;

		peerchnl_event = (struct peerchnl_event *)buf;
		/* No need to notify error for unhandled INFO events */
		if (peerchnl_event->severity == PEERCHNL_EVENT_SEVERITY_INFO)
			msg_data = PEERCHNL_STATUS_SUCCESS;
		else
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
		switch (peerchnl_event->event) {
#ifndef ICE_TDD
		case PEERCHNL_EVENT_BRIDGE_ADD_PORT:
		case PEERCHNL_EVENT_BRIDGE_DEL_PORT:
			status = ice_handle_ies_bridge_event(pf,
							     peerchnl_event);
			if (status)
				msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			else
				msg_data = PEERCHNL_STATUS_SUCCESS;
			break;
		case PEERCHNL_EVENT_LAG_ADD_PORT:
		case PEERCHNL_EVENT_LAG_DEL_PORT:
			status =  ice_handle_ies_hw_lag_event(pf,
							      peerchnl_event);
			if (status)
				msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			else
				msg_data = PEERCHNL_STATUS_SUCCESS;
			break;
#endif /* !ICE_TDD */
		default:
			dev_warn(dev, "Unknown event %d",
				 peerchnl_event->event);
			break;
		}
		goto ack;
	}
	case PEERCHNL_OP_ACK:
		if (desc->cookie_low.ver != PEERCHNL_OP_ACK_VER)
			goto ack;

		if (desc->cookie_low.data)
			dev_info(dev, "Negative acknowledgment peer_id=%d opcode=0x%x seq_num=%d data=%d\n",
				 sender_id, msg_opcode, seq_num,
				 desc->cookie_low.data);
		break;
	case PEERCHNL_OP_PORT_STATE_CHANGE:
		if (desc->cookie_low.ver != PEERCHNL_OP_PORT_STATE_CHANGE_VER)
			goto ack;

		/* build an event info struct */
		psc = (struct peerchnl_port_state_change *)buf;

		event_lm.desc = psc->desc;
		event_lm.buf_len = sizeof(struct ice_aqc_get_link_status_data);
		event_lm.msg_len = event_lm.buf_len;
		event_lm.msg_buf = (u8 *)&psc->data;
#ifndef ICE_TDD
		status = ice_handle_ies_link_event(pf, &event_lm);
		if (status) {
			dev_err(&pf->pdev->dev, "Error processing port state change command from peer ID %d status=%d\n",
				sender_id, status);
		}
		/* No need to send ACK */
#else
		status = 0;
#endif /* !ICE_TDD */
		return status;
	case PEERCHNL_OP_WOL_WAKEUP_REASON_REQ:
	{
		struct peerchnl_wol_wakeup_reason_resp *response;
		enum peerchnl_wol_wakeup_reason *reason;
		DECLARE_BITMAP(val, 32);

		response = (struct peerchnl_wol_wakeup_reason_resp *)buf;
		*val = pf->wakeup_reason;
		reason = &response->wakeup_reason;

		if (test_bit(PFPM_WUS_LNKC_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_LINK_STATUS_CHANGE;
		else if (test_bit(PFPM_WUS_MAG_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_MAGIC_PACKET;
		else if (test_bit(PFPM_WUS_MNG_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_MANAGEABILITY;
		else if (test_bit(PFPM_WUS_FW_RST_WK_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_EMP_RESET;
		else
			*reason = PEERCHNL_WOL_WAKEUP_REASON_POWER_ON;

		msg_data = PEERCHNL_STATUS_SUCCESS;
		msg_opcode = PEERCHNL_OP_WOL_WAKEUP_REASON_RESP;
		buf_size = sizeof(struct peerchnl_wol_wakeup_reason_resp);
		goto send_resp;
	}
	case PEERCHNL_OP_SET_MAX_FRM_SIZE:
	{
		struct net_device *netdev = NULL;
		struct peerchnl_mtu_change *pmc;
		int new_mtu, i, mstatus = 0;
		u8 lport, iport;

		msg_opcode = PEERCHNL_OP_SET_MAX_FRM_SIZE_RESP;
		pmc = (struct peerchnl_mtu_change *)buf;
		new_mtu = pmc->new_mtu;
		lport = pmc->lport;
		iport = pf->hw.port_info[ICE_INTERNAL_PORT_TO_SWITCH].lport;

		/* Frame size set by the IES include L2 header + FCS + VLAN
		 * So we have to subtract packet header pad to compute
		 * the actual MTU size.
		 */
		new_mtu -= ICE_ETH_PKT_HDR_PAD;

		/* Internal port MTU is always set as max */
		if (lport == iport)
			return 1;

		if (!pf->block_mtu_change)
			dev_info(dev, "From now on, MTU settings are managed by IES API\n");

		ice_for_each_vsi(pf, i) {
			struct ice_vsi *vsi = pf->vsi[i];

			if (vsi && vsi->port_info->lport == lport) {
				netdev = vsi->netdev;
				break;
			}
		}

		if (netdev) {
			rtnl_lock();
			pf->block_mtu_change = false;
			mstatus = dev_set_mtu(netdev, new_mtu);
			pf->block_mtu_change = true;
			rtnl_unlock();
		} else {
			pf->block_mtu_change = true;
			dev_err(dev,
				"There is no netdevice for port: %d\n", lport);
			mstatus = -ENODEV;
		}

		if (mstatus) {
			dev_err(dev,
				"MTU update on port %d was not successful\n",
				lport);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto send_resp;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto send_resp;
	}
#ifndef NO_PTP_SUPPORT
	case PEERCHNL_OP_RX_CODE_ERR:
	{
		int err;

		buf_size = 0;
		buf = NULL;

		err = ice_ptp_check_rx_fifo(pf, desc->cookie_low.data);
		if (err) {
			dev_err(dev,
				"Port %d Rx FIFO reset was not successful\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
	case PEERCHNL_OP_TIMESTAMP_ENABLE:
	{
		int err;

		buf_size = 0;
		buf = NULL;

		err = ptp_ts_enable(pf, desc->cookie_low.data, true);
		if (err) {
			dev_err(dev, "Port %d timestamp enabling was not successful\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
	case PEERCHNL_OP_TIMESTAMP_DISABLE:
	{
		int err;

		buf_size = 0;
		buf = NULL;

		err = ptp_ts_enable(pf, desc->cookie_low.data, false);
		if (err) {
			dev_err(dev, "Port %d timestamp disabling was not successful\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
#endif /* !NO_PTP_SUPPORT */
	case PEERCHNL_OP_ADD_PRE_VEB_ENTRY_RESP:
	{
		struct peerchnl_add_pre_veb_entry_resp *pv_resp;
		struct ice_vf *vf;
		bool sent_state;
		int err;

		sent_state = (desc->cookie_low.data == PEERCHNL_STATUS_SUCCESS);
		if (!sent_state) {
			dev_info(dev, "Pre-VEB rule was not added on peer side\n");
			return -EAGAIN;
		}

		pv_resp = (struct peerchnl_add_pre_veb_entry_resp *)buf;
		vf = ice_get_vf_by_id(pf, pv_resp->fn);
		if (!vf) {
			dev_dbg(dev, "Failed to locate VF ID %u\n",
				pv_resp->fn);
			return -EINVAL;
		}

		err = ice_vf_update_pre_veb_status(vf,
						   pv_resp->vlan_id,
						   pv_resp->mac_addr,
						   pv_resp->rule_id,
						   sent_state);
		ice_put_vf(vf);
		return err;
	}
	case PEERCHNL_OP_DEL_PRE_VEB_ENTRY_RESP:
	{
		struct peerchnl_del_pre_veb_entry *del_pv_resp;
		bool sent_state;

		sent_state = (desc->cookie_low.data == PEERCHNL_STATUS_SUCCESS);
		if (!sent_state)
			dev_info(dev, "Pre-VEB rule was not removed on peer side\n");

		del_pv_resp = (struct peerchnl_del_pre_veb_entry *)buf;
		ice_vf_del_pre_veb(pf, del_pv_resp->rule_id);
		return 0;
	}
	default:
		dev_err(dev, "Received unrecognized message command 0x%x from peer_id=%d\n",
			msg_opcode, sender_id);
		msg_data = PEERCHNL_STATUS_ERR_OPCODE_UNKNOWN;
		goto ack;
	}
	return 1;
ack:
	msg_opcode = PEERCHNL_OP_ACK;
send_resp:
	ice_mbx_send_msg_to_peer_drv(pf, peer_drv, msg_opcode, seq_num,
				     (u8)msg_data, buf, buf_size, NULL);

	return 1;
}

/**
 * ice_send_link_event_to_peer_objs - send link event to peer_objects
 * @pf: PF associated with the link event
 * @vsi: VSI associated with this link event
 * @pi: port_info for the port that received the link event
 * @link_up: true if physical link is up and false if it is down
 *
 * Returns 0 on success and negative on failure
 */
static int
ice_send_link_event_to_peer_objs(struct ice_pf *pf, struct ice_vsi *vsi,
				 struct ice_port_info *pi, bool link_up)
{
	struct ice_event *l_event;

	if (!pf || !pi || !vsi)
		return -EINVAL;

	l_event = (struct ice_event *)kzalloc(sizeof(*l_event), GFP_KERNEL);
	if (!l_event)
		return -ENOMEM;

	/* Setup LSC event */
	set_bit(ICE_EVENT_LINK_CHANGE, l_event->type);

	l_event->reporter = NULL;
	l_event->info.link_info.new_link_state = link_up;
	l_event->info.link_info.lport = pi->lport;
	l_event->info.link_info.lwr_nd = vsi->netdev;
	l_event->info.link_info.vsi_num = vsi->vsi_num;

	/* send event to registered peers */
	ice_for_each_peer(pf, l_event, ice_peer_check_for_reg);

	kfree(l_event);

	return 0;
}

/**
 * ice_send_link_event_to_peer_drvs - send link event to peer drivers
 * @pf: PF associated with the link event
 * @link_up: true if physical link is up and false if it is down
 */
static int ice_send_link_event_to_peer_drvs(struct ice_pf *pf, bool link_up)
{
	struct peerchnl_event event;

	if (!pf)
		return -EINVAL;

	event.event = PEERCHNL_EVENT_ADMIN_LINK_CHANGE;
	event.severity = PEERCHNL_EVENT_SEVERITY_ATTENTION;
	if (link_up)
		event.event_data = PEERCHNL_EVENT_DATA_LINK_UP;
	else
		event.event_data = PEERCHNL_EVENT_DATA_LINK_DOWN;

	ice_send_gen_event_to_all_peer_drv(pf, &event);

	return 0;
}

/**
 * ice_send_link_event_to_peers - send link event to peer objects and drivers
 * @vsi: VSI associated with the link event
 * @pi: port_info for the port that received the link event
 * @link_up: true if physical link is up and false if it is down
 *
 * Returns 0 on succes and negative on failure
 */
int
ice_send_link_event_to_peers(struct ice_vsi *vsi, struct ice_port_info *pi,
			     bool link_up)
{
	struct ice_pf *pf;
	int result;

	if (!vsi)
		return -EINVAL;

	pf = vsi->back;
	if (!pf)
		return -EINVAL;

	result = ice_send_link_event_to_peer_drvs(pf, link_up);
	if (!result)
		return ice_send_link_event_to_peer_objs(pf, vsi, pi, link_up);

	return result;
}

#ifndef ICE_TDD
/* Initialize the ice_ops struct, which is used in 'ice_init_peer_devices' */
static const struct ice_ops ops = {
	.is_vsi_ready			= ice_peer_is_vsi_ready,
	.reg_for_notification		= ice_peer_reg_for_notif,
	.unreg_for_notification		= ice_peer_unreg_for_notif,
	.notify_state_change		= ice_peer_report_state_change,
	.request_reset			= ice_peer_request_reset,
	.peer_register			= ice_peer_register,
	.peer_unregister		= ice_peer_unregister,
	.ack_reset_prep			= ice_peer_ack_reset_prep,
	.query_sched_tree		= ice_peer_report_txsched_config,
#ifdef ADK_SUPPORT
	.vsi_q_cfg			= ice_adk_vsi_q_cfg,
	.strt_xmit_internal		= ice_adk_strt_xmit_internal,
	.get_stats64			= ice_get_stats64,
	.get_port_id			= ice_adk_get_port_id,
	.add_mac_port			= ice_adk_add_mac_port,
#ifndef NO_PTP_SUPPORT
	.ptp_get_tx_hwtstamp_ready	= ice_ptp_adk_tx_hwtstamp_ready,
	.ptp_get_tx_hwtstamp_ver	= ice_ptp_adk_tx_hwtstamp_ver,
	.ptp_get_tx_hwtstamp		= ice_ptp_adk_tx_hwtstamp,
	.ptp_ts_ena_intr		= ice_ptp_ts_ena_intr,
	.ptp_convert_ts			= ice_ptp_convert_ts,
#endif /* !NO_PTP_SUPPORT */
#endif /* ADK_SUPPORT */
#ifndef NO_SBQ_SUPPORT
	.sbq_rw_reg			= ice_peer_sbq_rw_reg,
#endif /* !NO_SBQ_SUPPORT */
#ifndef NO_PTP_SUPPORT
	.update_incval			= ice_peer_update_incval,
	.get_incval			= ice_peer_get_incval,
	.match_and_adj			= ice_peer_match_and_adj,
	.cfg_1588_clk_out_to_cgu	= ice_peer_cfg_1588_clk_out_to_cgu,
	.get_src_phy_tmr_val		= ice_peer_get_src_phy_tmr_val,
#endif /* !NO_PTP_SUPPORT */
	.vc_send			= ice_peer_vc_send,

#ifndef EXTERNAL_RELEASE
	/* FIXME: Initialize remaining functions later */
#endif
};
#endif /* ICE_TDD */

/**
 * ice_init_peer_devices - initializes peer objects and aux devices
 * @pf: ptr to ice_pf
 *
 * This function initializes peer objects and auxiliary device, then
 * associates them with specified pci_dev as their parent.
 */
int ice_init_peer_devices(struct ice_pf *pf)
{
	struct pci_dev *pdev = pf->pdev;
	struct device *dev = &pdev->dev;
	unsigned int i;
	int status;

	/* Reserve vector resources */
	status = ice_reserve_peer_qvector(pf);
	if (status < 0) {
		dev_err(dev, "failed to reserve vectors for peer drivers\n");
		return status;
	}
	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		struct ice_peer_obj_platform_data *platform_data;
		struct ice_peer_obj_int *peer_obj_int;
		struct ice_peer_drv_int *peer_drv_int;
		struct msix_entry *entry = NULL;
		struct ice_peer_obj *peer_obj;
		int j;

		peer_obj_int = (struct ice_peer_obj_int *)
			devm_kzalloc(dev, sizeof(*peer_obj_int), GFP_KERNEL);
		if (!peer_obj_int)
			return -ENOMEM;
		pf->cdev_infos[i] = peer_obj_int;

		peer_drv_int = (struct ice_peer_drv_int *)
			devm_kzalloc(dev, sizeof(*peer_drv_int), GFP_KERNEL);
		if (!peer_drv_int)
			return -ENOMEM;

		peer_obj_int->peer_drv_int = peer_drv_int;

		/* Initialize driver values */
		for (j = 0; j < ICE_EVENT_NBITS; j++)
			bitmap_zero(peer_drv_int->current_events[j].type,
				    ICE_EVENT_NBITS);

#ifndef ICE_TDD
		mutex_init(&peer_obj_int->peer_obj_state_mutex);

#endif /* !ICE_TDD */
		peer_obj = ice_get_peer_obj(peer_obj_int);
		peer_obj_int->plat_data.peer_obj = peer_obj;
		platform_data = &peer_obj_int->plat_data;
		peer_obj->peer_ops = NULL;
		peer_obj->hw_addr = (u8 __iomem *)pf->hw.hw_addr;
		peer_obj->ver.major = ICE_PEER_MAJOR_VER;
		peer_obj->ver.minor = ICE_PEER_MINOR_VER;
		peer_obj->ver.support = ICE_IDC_FEATURES;
		peer_obj->peer_obj_id = ice_mfd_cells[i].id;

		ice_mfd_cells[i].platform_data = platform_data;
		ice_mfd_cells[i].pdata_size = sizeof(*platform_data);

#ifndef ICE_TDD
		peer_obj_int->ice_peer_wq =
			alloc_ordered_workqueue("ice_peer_wq_%d", WQ_UNBOUND,
						i);
		if (!peer_obj_int->ice_peer_wq)
			return -ENOMEM;
		INIT_WORK(&peer_obj_int->peer_prep_task, ice_peer_prep_task);
		INIT_WORK(&peer_obj_int->peer_close_task, ice_peer_close_task);
#endif /* !ICE_TDD */

		peer_obj->pdev = pdev;
#ifndef ICE_TDD
		/* Initialize ice_ops */
		peer_obj->ops = &ops;
#endif

		/* make sure peer specific resources such as msix_count and
		 * msix_entries are initialized
		 */
		switch (ice_mfd_cells[i].id) {
		case ICE_PEER_IPSEC_ID:
			peer_obj->res_start = ICE_PEER_INLINE_CRYPTO_RES_START;
			peer_obj->res_len = ICE_PEER_PCI_RES_LEN;
			peer_obj->msix_count = pf->num_crypto_msix;
			entry = &pf->msix_entries[pf->crypto_base_vector];
			pf->ipsec_peer = peer_obj;
			break;
		case ICE_PEER_SW_ID:
			peer_obj->res_start = ICE_PEER_SW_RES_START;
			peer_obj->res_len = ICE_PEER_PCI_RES_LEN;
			peer_obj->msix_count = pf->num_swt_msix;
			entry = &pf->msix_entries[pf->swt_base_vector];
			break;
#ifdef ADK_SUPPORT
		case ICE_PEER_ADK_ID:
			/* Need to cache this peer for later access in
			 * the hot path
			 */
			ice_peer_adk_setup(peer_obj);
			break;
#endif /* ADK_SUPPORT */
		default:
			break;
		}

		peer_obj->msix_entries = entry;
		ice_peer_state_change(peer_obj_int, ICE_PEER_OBJ_STATE_INIT,
				      false);
	}

	status = ida_simple_get(&ice_peer_index_ida, 0, 0, GFP_KERNEL);
	if (status < 0) {
		dev_err(&pdev->dev, "failed to get unique index for device\n");
		return status;
	}

	pf->aux_idx = status;

	status = mfd_add_devices(dev, pf->aux_idx, ice_mfd_cells,
				 ARRAY_SIZE(ice_mfd_cells), NULL, 0, NULL);
	if (status) {
		dev_err(dev, "Failure adding MFD devs for peers: %d\n", status);
		return status;
	}

	for (i = 0; i < ARRAY_SIZE(ice_mfd_cells); i++) {
		snprintf(pf->cdev_infos[i]->plat_name, ICE_MAX_PEER_NAME,
			 "%s.%d", ice_mfd_cells[i].name,
			 pf->aux_idx + ice_mfd_cells[i].id);
		dev = bus_find_device_by_name(&platform_bus_type, NULL,
					      pf->cdev_infos[i]->plat_name);
		if (dev) {
			dev_dbg(dev, "Peer Created: %s %d\n",
				pf->cdev_infos[i]->plat_name, pf->aux_idx);
			put_device(dev);
		}
	}

	return status;
}
