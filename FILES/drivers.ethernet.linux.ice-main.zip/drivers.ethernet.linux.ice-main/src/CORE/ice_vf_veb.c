#include "ice.h"
#include "ice_vf_veb.h"
#include "ice_mbx.h"

#define NO_VLAN_ID USHRT_MAX
/**
 * ice_find_pre_veb - Search for Pre-VEB by MAC address and VLAN id
 * @vf: pointer to the VF structure
 * @vlan_id: VLAN id together with MAC form unique rule tuple
 * @mac_addr: MAC address to search for
 *
 * In case of no-VLAN rule peer driver returns VLAN id = USHRT_MAX, then
 * rule identified by MAC address only
 */
static struct vf_pre_veb_rule *
ice_find_pre_veb(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	struct vf_pre_veb_rule *cur_rule, *tmp, *ret = NULL;

	if (!vf || !mac_addr)
		return ret;

	spin_lock(&vf->pre_veb_rules_list.list_lock);
	list_for_each_entry_safe(cur_rule, tmp, &vf->pre_veb_rules_list.head,
				 head) {
		if (!memcmp(cur_rule->mac_addr, mac_addr, ETH_ALEN) &&
		    (vlan_id == cur_rule->vlan_id || vlan_id == NO_VLAN_ID)) {
			ret = cur_rule;
			break;
		}
	}
	spin_unlock(&vf->pre_veb_rules_list.list_lock);
	return ret;
}

/* ice_send_add_veb_to_aux - send a new VEB to auxiliary drivers
 * @vf: ice_vf that is reveiving the new VEB
 * @vlan_id: vlan_id for VEB
 * @mac_addr: MAC address for VEB
 */
static int
ice_send_add_veb_to_aux(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	struct peerchnl_add_pre_veb_entry veb = {
		.vlan_id = vlan_id,
		.vlan_valid = 1,
		.fn = (u8)vf->vf_id
	};

	ether_addr_copy(veb.addr, mac_addr);

	return ice_mbx_send_msg_to_ies(vf->pf, PEERCHNL_OP_ADD_PRE_VEB_ENTRY,
				       ++vf->pf->msg_seq_num, 0, &veb,
				       sizeof(veb), NULL);
}

/* ice_send_del_veb_to_aux - tell aux driver to del veb entry
 * @pf: pointer to PF struct
 * @rule_id: id of VEB rule to delete
 */
static int ice_send_del_veb_to_aux(struct ice_pf *pf, int rule_id)
{
	struct peerchnl_del_pre_veb_entry veb = {
		.rule_id = (u32)rule_id
	};

	return ice_mbx_send_msg_to_ies(pf, PEERCHNL_OP_DEL_PRE_VEB_ENTRY,
				       ++pf->msg_seq_num, 0, &veb, sizeof(veb),
				       NULL);
}

/**
 * ice_vf_sync_pre_veb_peer - Synchronize Pre-VEB with peer
 * @pf: pointer to the VF structure
 */
void ice_vf_sync_pre_veb_peer(struct ice_pf *pf)
{
	struct vf_pre_veb_rule *cur_rule, *tmp;
	struct ice_vf *vf;
	unsigned int bkt;

	if (!pf)
		return;

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf) {
		list_for_each_entry_safe(cur_rule, tmp,
					 &vf->pre_veb_rules_list.head, head) {
			if (cur_rule->sent_state)
				continue;
			ice_send_add_veb_to_aux(vf, cur_rule->vlan_id,
						cur_rule->mac_addr);
		}
	}
	mutex_unlock(&pf->vfs.table_lock);
}

/**
 * ice_vf_update_pre_veb_status - Update PRE_VEB rule
 * @vf: pointer to the PF structure
 * @vlan_id: id of VLAN to find rule
 * @mac_addr: MAC address assigned with rule
 * @rule_id: id of rule
 * @sent_state: bool flag indicates whether rule is synced with switch peer
 */
int
ice_vf_update_pre_veb_status(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr, int rule_id,
			     bool sent_state)
{
	struct vf_pre_veb_rule *rule;

	rule = ice_find_pre_veb(vf, vlan_id, mac_addr);
	if (!rule) {
		dev_err(ice_pf_to_dev(vf->pf), "Pre-veb rule id:%d, not found", rule_id);
		return -ENOENT;
	}
	rule->rule_id = rule_id;
	rule->sent_state = sent_state;
	return 0;
}

/**
 * ice_vf_add_pre_veb - Add new PRE_VEB rule to VF structure
 * @vf: pointer to the PF structure
 * @vlan_id: id of VLAN related to rule
 * @mac_addr: MAC address to be assigned with rule
 */
static int
ice_vf_add_pre_veb(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	struct vf_pre_veb_rule *new_rule;

	if (ice_find_pre_veb(vf, vlan_id, mac_addr))
		return -EEXIST;

	new_rule = (vf_pre_veb_rule *)
		    kzalloc(sizeof(*new_rule), GFP_KERNEL);
	if (!new_rule)
		return -ENOMEM;

	INIT_LIST_HEAD(&new_rule->head);
	ether_addr_copy(new_rule->mac_addr, mac_addr);
	new_rule->vlan_id = vlan_id;
	new_rule->rule_id = ICE_UNKNOWN_PRE_VEB_ID;
	new_rule->sent_state = false;
	list_add_tail(&new_rule->head, &vf->pre_veb_rules_list.head);

	return 0;
}

/**
 * ice_vf_send_add_pre_veb_peer - Send request to add new Pre-VEB rule
 * @vf: pointer to the VF structure
 * @vlan_id: id of VLAN related to rule
 * @mac_addr: MAC address to be assigned with rule
 */
void ice_vf_send_add_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	int err;

	if (!vf || !mac_addr)
		return;

	err = ice_vf_add_pre_veb(vf, vlan_id, mac_addr);
	if (err) {
		if (err == -EEXIST)
			dev_dbg(ice_pf_to_dev(vf->pf), "Attempt to add existing Pre-VEB rule");
		return;
	}
	err = ice_send_add_veb_to_aux(vf, vlan_id, mac_addr);
	if (err)
		dev_err(ice_pf_to_dev(vf->pf),
			"Failed to send Pre-VEB rule ADD msg to peer");
}

/**
 * ice_vf_del_pre_veb - Remove PRE_VEB rule from VF with rule_id
 * @pf: pointer to the PF structure
 * @rule_id: id of rule
 */
void ice_vf_del_pre_veb(struct ice_pf *pf, int rule_id)
{
	struct vf_pre_veb_rule *cur_rule, *tmp;
	struct ice_vf *vf;
	unsigned int bkt;

	if (!pf)
		return;

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf) {
		spin_lock(&vf->pre_veb_rules_list.list_lock);
		list_for_each_entry_safe(cur_rule, tmp,
					 &vf->pre_veb_rules_list.head, head) {
			if (cur_rule->rule_id == rule_id) {
				list_del(&cur_rule->head);
				kfree(cur_rule);
				break;
			}
		}
		spin_unlock(&vf->pre_veb_rules_list.list_lock);
	}
	mutex_unlock(&pf->vfs.table_lock);
}

/**
 * ice_vf_free_pre_veb - Free all PRE_VEB rule from VF
 * @vf: pointer to the VF structure
 *
 * Free all Pre-VEB rules assigned to VF
 */
void ice_vf_free_pre_veb(struct ice_vf *vf)
{
	struct vf_pre_veb_rule *cur_rule, *tmp;

	list_for_each_entry_safe(cur_rule, tmp, &vf->pre_veb_rules_list.head, head) {
		list_del(&cur_rule->head);
		kfree(cur_rule);
	}
}

/**
 * ice_vf_send_del_pre_veb_peer - Send msg to peer with delete Pre-VEB opcode
 * @vf: pointer to the VF structure
 * @vlan_id: VLAN id of rule to be deleted
 * @mac_addr: MAC address of rule to be deleted
 *
 * Send msg to peer to delete Pre-VEB rule. In case when rule is synced with
 * peer, it will be deleted after receiving PEERCHNL_OP_DEL_PRE_VEB_ENTRY_RESP
 * In case when rule is not synced (!sent_state) or peer is not accesible rule
 * is deleted without confirmation from peer.
 */
void ice_vf_send_del_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	struct vf_pre_veb_rule *cur_rule;

	if (!vf || !mac_addr)
		return;

	cur_rule = ice_find_pre_veb(vf, vlan_id, mac_addr);
	if (cur_rule) {
		int err = 0;

		if (cur_rule->sent_state) {
			err = ice_send_del_veb_to_aux(vf->pf,
						      cur_rule->rule_id);
		}
		if (!cur_rule->sent_state || err) {
			list_del(&cur_rule->head);
			kfree(cur_rule);
		}
	}
}
