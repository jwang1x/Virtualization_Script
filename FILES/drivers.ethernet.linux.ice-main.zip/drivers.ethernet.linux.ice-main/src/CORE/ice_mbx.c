#include "ice.h"
#include "ice_mbx.h"
#ifdef BMSM_MODE
#include "ice_external_bridge.h"
#endif /* BMSM_MODE */
#include "ice_lib.h"
#ifndef NO_PTP_SUPPORT
#include "ice_ptp.h"
#endif /* !NO_PTP_SUPPORT */
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
#include "ice_ipsec.h"
#endif /* SWITCH_MODE && !BMSM_MODE */

#if !defined(NO_PTP_SUPPORT) && defined(BMSM_MODE)
DECLARE_WAIT_QUEUE_HEAD(phy_state_ack_wait);
#endif /* !NO_PTP_SUPPORT && BMSM_MODE */
#define ICE_PEER_SWITCH_DRIVER 2

#ifndef BMSM_MODE
/**
 * ice_wait_for_fp_close - sleep until fast path is closed or timeout
 * @work: ptr to struct work_struct
 */
static void ice_wait_for_fp_close(struct work_struct *work)
{
	struct ice_pf *pf = container_of(work, struct ice_pf, fp_task);

	wait_event_interruptible_timeout(fp_wait, !pf->fp_open, pf->fpto);
	pf->fp_open = false;
}

#endif /* !BMSM_MODE */
/**
 * ice_update_ies_link_info - Updates internal port info struct
 * @pi: port_info for the port that the link event is associated with
 * @link_data: the link data for the port
 * @lse: indicates whether or not there is a link state or speed change
 */
#ifndef OLD_IDC_SUPPORT
static void
#else /* OLD_IDC_SUPPORT */
void
#endif /* OLD_IDC_SUPPORT */
ice_update_ies_link_info(struct ice_port_info *pi,
			 struct ice_aqc_get_link_status_data *link_data,
			 bool *lse)
{
	bool tx_pause, rx_pause, new_state, old_state, old_speed;
	struct ice_link_status *li;

	li = &pi->phy.link_info;

	old_state = !!(li->link_info & ICE_AQ_LINK_UP);
	old_speed = li->link_speed;

	/* update current link status information */
	li->link_speed = le16_to_cpu(link_data->link_speed);
	li->phy_type_low = le64_to_cpu(link_data->phy_type_low);
	li->phy_type_high = le64_to_cpu(link_data->phy_type_high);
#ifndef ICE_TDD
	pi->phy.media_type = ice_get_media_type(pi);
#endif /* !ICE_TDD */
	li->link_info = link_data->link_info;
	li->an_info = link_data->an_info;
	li->ext_info = link_data->ext_info;
	li->max_frame_size = le16_to_cpu(link_data->max_frame_size);
	li->fec_info = link_data->cfg & ICE_AQ_FEC_MASK;
	li->topo_media_conflict = link_data->topo_media_conflict;
	li->pacing = link_data->cfg & (ICE_AQ_CFG_PACING_M |
				       ICE_AQ_CFG_PACING_TYPE_M);

	new_state = !!(li->link_info & ICE_AQ_LINK_UP);

	/* update fc info */
	tx_pause = !!(link_data->an_info & ICE_AQ_LINK_PAUSE_TX);
	rx_pause = !!(link_data->an_info & ICE_AQ_LINK_PAUSE_RX);
	if (tx_pause && rx_pause)
		pi->fc.current_mode = ICE_FC_FULL;
	else if (tx_pause)
		pi->fc.current_mode = ICE_FC_TX_PAUSE;
	else if (rx_pause)
		pi->fc.current_mode = ICE_FC_RX_PAUSE;
	else
		pi->fc.current_mode = ICE_FC_NONE;

	li->lse_ena = true;

	if (new_state != old_state || old_speed != li->link_speed)
		*lse = true;
	else
		*lse = false;
}

#if !defined(NO_PTP_SUPPORT) && defined(BMSM_MODE)
/**
 * ice_process_phy_state_change - Updates internal port info struct
 * @pf: board private structure
 * @buf: AQ message buffer
 */
enum peerchnl_status_code
ice_process_phy_state_change(struct ice_pf *pf, void *buf)
{
	struct peerchnl_phy_state *phy_state = (struct peerchnl_phy_state *)buf;
	const unsigned long *lports_map =
		(const unsigned long *)&phy_state->lports_map;
	int status = 0;
	u8 lport;

	for_each_set_bit(lport, lports_map, ICE_NUM_EXTERNAL_PORTS) {
		struct ice_ptp_port *ptp_port = &pf->ptp.ports[lport];

		if (!(pf->hw.ena_lports & BIT(lport)))
			continue;

		if (phy_state->state)
			status = ice_ptp_port_phy_restart(ptp_port);
		else
			status = ice_ptp_port_phy_stop(ptp_port);

		if (status) {
			dev_err(ice_pf_to_dev(pf), "Port %d PHY state change was not successful\n",
				lport);
			return PEERCHNL_STATUS_ERR_CMD_FAIL;
		}
	}

	return PEERCHNL_STATUS_SUCCESS;
}

#endif /* !NO_PTP_SUPPORT && BMSM_MODE */
/**
 * ice_mbx_send_msg_to_ies - send a MBX msg to IES user-space app
 * @pf: ptr to struct ice_pf
 * @msg_opcode: message command opcode
 * @seq_num: message sequence number
 * @data: direct command data (0 for indirect commands)
 * @buf: buffer to use for indirect commands (NULL for direct commands)
 * @buf_size: size of buffer for indirect commands (0 for direct commands)
 * @details: pointer to command details structure or NULL
 *
 * Send (direct or indirect) Message to IES (0x0804).
 */
int
ice_mbx_send_msg_to_ies(struct ice_pf *pf, u16 msg_opcode, u16 seq_num, u8 data,
			void *buf, u16 buf_size, struct ice_sq_cd *details)
{
	struct peerchnl_mbx_desc desc;
	struct ice_hw *hw = &pf->hw;
	struct device *dev;
	int status;

	if (!pf)
		return -EINVAL;

	dev = ice_pf_to_dev(pf);
	ice_fill_dflt_direct_cmd_desc((struct ice_aq_desc *)&desc,
				      ice_mbx_opc_send_to_peer_drv);
	if (buf)
		desc.flags |= cpu_to_le16(ICE_AQ_FLAG_RD);
	desc.cookie_high.msg_opcode = cpu_to_le16(msg_opcode);
	desc.cookie_high.seq_num = cpu_to_le16(seq_num);

	switch (msg_opcode) {
	case PEERCHNL_OP_FW_CMD_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_FW_CMD_RESP_VER;
		break;
	case PEERCHNL_OP_FW_EVENT:
		desc.cookie_low.ver = PEERCHNL_OP_FW_EVENT_VER;
		break;
	case PEERCHNL_OP_EVENT:
		desc.cookie_low.ver = PEERCHNL_OP_EVENT_VER;
		break;
	case PEERCHNL_OP_ACK:
		desc.cookie_low.ver = PEERCHNL_OP_ACK_VER;
		break;
	case PEERCHNL_OP_WOL_WAKEUP_REASON_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_WOL_WAKEUP_REASON_RESP_VER;
		break;
	case PEERCHNL_OP_ADD_PRE_VEB_ENTRY:
		desc.cookie_low.ver = PEERCHNL_OP_ADD_PRE_VEB_ENTRY_VER;
		break;
	case PEERCHNL_OP_DEL_PRE_VEB_ENTRY:
		desc.cookie_low.ver = PEERCHNL_OP_DEL_PRE_VEB_ENTRY_VER;
		break;
	case PEERCHNL_OP_SET_MAX_FRM_SIZE_RESP:
		desc.cookie_low.ver = PEERCHNL_OP_SET_MAX_FRM_SIZE_VER;
		break;
	case PEERCHNL_OP_PHY_STATE_CHANGE:
		desc.cookie_low.ver = PEERCHNL_OP_PHY_STATE_CHANGE_VER;
		break;
	default:
		dev_err(dev, "Unknown message opcode (%d) to IES", msg_opcode);
		return -EOPNOTSUPP;
	}

	desc.cookie_low.data = data;
	desc.param0.cmd_peer_id = cpu_to_le32(ICE_PEER_SWITCH_DRIVER);
	status = ice_sq_send_cmd(hw, &hw->mailboxq, (struct ice_aq_desc *)&desc,
				 buf, buf_size, details);
	if (status)
#ifndef EXTERNAL_RELEASE
		/* This message is temporarily lowered to DEBUG level, since
		 * it's expected to pop up during driver load, before IES
		 * is present. It should be reverted once the driver is changed
		 * to not attempt communicating with IES in such case.
		 */
#endif /* EXTERNAL_RELEASE */
		dev_dbg(dev, "Sending mailbox cmd failed msg_opcode=0x%x seq_num=%d data=%d buf_size=%d status=%d\n",
			msg_opcode, seq_num, data, buf_size, status);
	return status;
}

#if !defined(NO_PTP_SUPPORT) && defined(BMSM_MODE)
/**
 * ice_send_phy_state_change_to_ies - send PHY state change msg to IES API
 * @pf: ptr to struct ice_pf
 * @lports_map: bitmap of logical ports on which the PHY soft reset happened
 * @state: true to indicate the phy is prepared for start, false otherwise
 */
int
ice_send_phy_state_change_to_ies(struct ice_pf *pf, u32 lports_map, bool state)
{
	struct peerchnl_phy_state ps_data = {
		.lports_map = lports_map,
		.state = (u8)state,
	};
	int err;

	if (!pf->ptp.phy_state_ack)
		wait_event_interruptible_timeout(phy_state_ack_wait,
						 pf->ptp.phy_state_ack, 5 * HZ);

	err = ice_mbx_send_msg_to_ies(pf, (u16)PEERCHNL_OP_PHY_STATE_CHANGE,
				      ++pf->msg_seq_num, 0, &ps_data,
				      sizeof(ps_data), NULL);
	if (!err)
		pf->ptp.phy_state_ack = false;

	return err;
}

#endif /* !NO_PTP_SUPPORT && BMSM_MODE */
/**
 * ice_handle_ies_link_event - handle link events from IES API
 * @pf: PF that the link event is associated with
 * @event: event structure containing link status info
 */
#ifndef OLD_IDC_SUPPORT
static int
#else /* OLD_IDC_SUPPORT */
int
#endif /* OLD_IDC_SUPPORT */
ice_handle_ies_link_event(struct ice_pf *pf, struct ice_rq_event_info *event)
{
	struct ice_aqc_get_link_status_data *link_data;
	struct ice_aqc_get_link_status *link_status;
	struct ice_port_info *port_info;
#ifndef OLD_IDC_SUPPORT
	struct iidc_event *ie;
#endif /* OLD_IDC_SUPPORT */
	struct ice_vsi *vsi;
	bool link_up, lse;
#ifdef BMSM_MODE
	int result;
#endif /* BMSM_MODE */

	link_data = (struct ice_aqc_get_link_status_data *)event->msg_buf;
	link_status = &event->desc.params.get_link_status;
	/* Make sure logical port number is valid */
	port_info = ice_find_port_info(&pf->hw, link_status->lport_num);
	if (!port_info)
		return -EINVAL;

	if (port_info->is_internal_port)
		return 0;

	/* Enter IES API LM Mode */
	if (port_info->hw->lm_mode != ICE_LM_MODE_IES_API) {
		port_info->hw->lm_mode = ICE_LM_MODE_IES_API;
		dev_info(ice_pf_to_dev(pf), "Changing LM Mode to IES API\n");
	}

	ice_update_ies_link_info(port_info, link_data, &lse);

	/* No link state event */
	if (!lse)
		return 0;

	link_up = !!(port_info->phy.link_info.link_info & ICE_AQ_LINK_UP);

	vsi = ice_find_vsi_from_pi(pf, port_info);
	if (!vsi || !vsi->port_info)
		return -EINVAL;

#ifndef NO_PTP_SUPPORT
#ifndef BMSM_MODE
	ice_ptp_link_change(pf, port_info->lport, link_up);
#else
	ice_ptp_link_change(pf, port_info->lport, link_up, true);
#endif
#endif /* NO_PTP_SUPPORT */

	ice_vsi_link_event(vsi, link_up);
	ice_print_link_msg(vsi, link_up);
#ifdef BMSM_MODE
	result = ice_recalc_each_link_speed_kbps(pf);
	if (result)
		ice_dev_dbg_errno(ice_pf_to_dev(pf), result,
				  "Failed to set link speed, port %d",
				  port_info->lport);

#endif /* BMSM_MODE */
	if (ice_has_vfs(pf))
		ice_vc_notify_link_state(pf);

#ifndef OLD_IDC_SUPPORT
	ie = kzalloc(sizeof(*ie), GFP_KERNEL);
	if (!ie)
		return -ENOMEM;

	set_bit(IIDC_EVENT_LINK_CHNG, ie->type);
	ie->info.link_up = link_up;
#ifndef BMSM_MODE
	ie->info.lport = link_status->lport_num;
#endif /* !BMSM_MODE */
	ice_send_event_to_auxs(pf, ie);
	kfree(ie);
	return 0;
#else /* OLD_IDC_SUPPORT */
	return ice_send_link_event_to_peers(vsi, port_info, link_up);
#endif /* OLD_IDC_SUPPORT */
}

/* ice_process_msg_from_ies - handle MBX message from ies_api user-space app
 * @data: opaque pointer to passed data
 */
int ice_process_msg_from_ies(void *data)
{
	u16 seq_num, msg_opcode, buf_size, sender_id;
	struct peerchnl_port_state_change *psc;
	enum peerchnl_status_code msg_data;
	struct ice_rq_event_info event_lm;
	struct ice_rq_event_info *event;
	struct peerchnl_mbx_desc *desc;
#ifndef BMSM_MODE
	bool wait_for_fp_close = false;
#endif /* !BMSM_MODE */
#if defined(BMSM_MODE) && !defined(NO_PTP_SUPPORT)
	u16 inc_msg_opcode;
#endif /* BMSM_MODE && !NO_PTP_SUPPORT */
	struct device *dev;
	struct ice_pf *pf;
	void *fw_cmd_buf;
	int status;
	void *buf;

	if (!data)
		return -EINVAL;

	msg_data = PEERCHNL_STATUS_ERR_VER_MISMATCH;
	pf = ((struct ice_recv_ies_msg_info *)data)->pf;
	if (!pf)
		return -EINVAL;

	dev = ice_pf_to_dev(pf);
	event = ((struct ice_recv_ies_msg_info *)data)->event;
	if (!event)
		return -EINVAL;

	desc = (struct peerchnl_mbx_desc *)&event->desc;
	sender_id = le16_to_cpu(desc->mbx_data.event_sender_id);
	seq_num = le16_to_cpu(desc->cookie_high.seq_num);
	msg_opcode = le16_to_cpu(desc->cookie_high.msg_opcode);
#if defined(BMSM_MODE) && !defined(NO_PTP_SUPPORT)
	inc_msg_opcode = msg_opcode;
#endif /* BMSM_MODE && !NO_PTP_SUPPORT */
	buf = (void *)event->msg_buf;
	buf_size = le16_to_cpu(desc->datalen);
	if (buf_size && !buf)
		return -EINVAL;

	switch (msg_opcode) {
	case PEERCHNL_OP_FW_CMD_REQ:
	{
		struct peerchnl_fw_data *fw_cmd;
		struct ice_aq_desc *fw_desc;

		if (desc->cookie_low.ver != PEERCHNL_OP_FW_CMD_REQ_VER)
			goto ack;

		fw_cmd = (struct peerchnl_fw_data *)buf;
		fw_desc = &fw_cmd->desc;
		if (le16_to_cpu(fw_cmd->desc.flags) & ICE_AQ_FLAG_BUF)
			fw_cmd_buf = fw_cmd->buf;
		else
			fw_cmd_buf = NULL;

		switch (le16_to_cpu(fw_desc->opcode)) {
#ifndef BMSM_MODE
		case ice_aqc_opc_io_close_fastpath:
			pf->fp_open = false;
			wake_up(&fp_wait);
			break;
		case ice_aqc_opc_io_open_fastpath:
		{
			u32 timeout;

			if (pf->fp_open) {
				pf->fp_open = false;
				wake_up(&fp_wait);
			}

			/* Maximum value of timeout is 100 seconds */
			timeout = fw_desc->params.io_open_fastpath.timeout * HZ;
			if (timeout > 100 * HZ)
				timeout = 100 * HZ;
			pf->fpto = timeout;
			pf->fp_open = true;
			wait_for_fp_close = true;
			break;
		}
		case ice_aqc_opc_read_io_widget:
		case ice_aqc_opc_write_io_widget:
			if (pf->fp_open) {
				msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
				msg_opcode = PEERCHNL_OP_FW_CMD_RESP;
				goto send_resp;
			}
			break;
#endif /* !BMSM_MODE */
		case ice_aqc_opc_set_wol_parameters:
		{
			struct ice_aqc_set_wol_parameters *wol_params;
			u32 pmask;
			u16 timer;
			u32 val;

			wol_params = &fw_desc->params.set_wol_parameters;
			pmask = le32_to_cpu(wol_params->monitored_ports_bits);
			timer = le16_to_cpu(wol_params->timer_value);
			val = rd32(&pf->hw, PFPM_WUFC);

			if (timer && pmask && pf->wol_ena)
				wr32(&pf->hw, PFPM_WUFC, val | PFPM_WUFC_MNG_M);
			else
				wr32(&pf->hw, PFPM_WUFC,
				     val & ~PFPM_WUFC_MNG_M);
			break;
		}
		default:
			break;
		}

		status = ice_aq_send_cmd(&pf->hw, fw_desc, fw_cmd_buf,
					 le16_to_cpu(fw_desc->datalen), NULL);
		if (status) {
			dev_err(dev, "Error sending FW Admin cmd for %d %d\n",
				sender_id, status);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
#ifndef BMSM_MODE
			if (wait_for_fp_close) {
				pf->fp_open = false;
				wait_for_fp_close = false;
			}
#endif /* !BMSM_MODE */
		} else {
			msg_data = PEERCHNL_STATUS_SUCCESS;
		}

		/* Send FW AdminQ completion/writeback as a response to peer */
		msg_opcode = PEERCHNL_OP_FW_CMD_RESP;
		goto send_resp;
	}
	case PEERCHNL_OP_EVENT:
	{
		struct peerchnl_event *peerchnl_event;

		if (desc->cookie_low.ver != PEERCHNL_OP_EVENT_VER)
			goto ack;

		peerchnl_event = (struct peerchnl_event *)buf;
		/* No need to notify error for unhandled INFO events */
		if (peerchnl_event->severity == PEERCHNL_EVENT_SEVERITY_INFO)
			msg_data = PEERCHNL_STATUS_SUCCESS;
		else
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;

		switch (peerchnl_event->event) {
#ifdef BMSM_MODE
		case PEERCHNL_EVENT_BRIDGE_ADD_PORT:
		case PEERCHNL_EVENT_BRIDGE_DEL_PORT:
			status = ice_handle_ies_bridge_event(pf,
							     peerchnl_event);
			if (status)
				msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			else
				msg_data = PEERCHNL_STATUS_SUCCESS;
			break;
#ifndef NO_HW_LAG_SUPPORT
		case PEERCHNL_EVENT_LAG_ADD_PORT:
		case PEERCHNL_EVENT_LAG_DEL_PORT:
			status =  ice_handle_ies_hw_lag_event(pf,
							      peerchnl_event);
			if (status)
				msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			else
				msg_data = PEERCHNL_STATUS_SUCCESS;
			break;
#endif /* !NO_HW_LAG_SUPPORT */
#endif /* BMSM_MODE */
		default:
			 dev_warn(dev, "Unknown event %d",
				  peerchnl_event->event);
			break;
		}
		goto ack;
	}
	case PEERCHNL_OP_ACK:
		if (desc->cookie_low.ver != PEERCHNL_OP_ACK_VER)
			goto ack;

		if (desc->cookie_low.data)
			dev_info(dev, "Negative acknowledgment peer_id=%d opcode=0x%x seq_num=%d data=%d\n",
				 sender_id, msg_opcode, seq_num,
				 desc->cookie_low.data);
		break;
	case PEERCHNL_OP_PORT_STATE_CHANGE:
		if (desc->cookie_low.ver != PEERCHNL_OP_PORT_STATE_CHANGE_VER)
			goto ack;

		/* build an event info struct */
		psc = (struct peerchnl_port_state_change *)buf;

		event_lm.desc = psc->desc;
		event_lm.buf_len = sizeof(struct ice_aqc_get_link_status_data);
		event_lm.msg_len = event_lm.buf_len;
		event_lm.msg_buf = (u8 *)&psc->data;
#ifndef ICE_TDD
		status = ice_handle_ies_link_event(pf, &event_lm);
#else
		status = 0;
#endif /* !ICE_TDD */
		if (status)
			dev_err(&pf->pdev->dev,
				"Error processing port state change %d %d\n",
				sender_id, status);
		return status;
	case PEERCHNL_OP_WOL_WAKEUP_REASON_REQ:
	{
		struct peerchnl_wol_wakeup_reason_resp *response;
		enum peerchnl_wol_wakeup_reason *reason;
		DECLARE_BITMAP(val, 32);

		response = (struct peerchnl_wol_wakeup_reason_resp *)buf;
		*val = pf->wakeup_reason;
		reason = &response->wakeup_reason;

		if (test_bit(PFPM_WUS_LNKC_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_LINK_STATUS_CHANGE;
		else if (test_bit(PFPM_WUS_MAG_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_MAGIC_PACKET;
		else if (test_bit(PFPM_WUS_MNG_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_MANAGEABILITY;
		else if (test_bit(PFPM_WUS_FW_RST_WK_S, val))
			*reason = PEERCHNL_WOL_WAKEUP_REASON_EMP_RESET;
		else
			*reason = PEERCHNL_WOL_WAKEUP_REASON_POWER_ON;

		msg_data = PEERCHNL_STATUS_SUCCESS;
		msg_opcode = PEERCHNL_OP_WOL_WAKEUP_REASON_RESP;
		buf_size = sizeof(struct peerchnl_wol_wakeup_reason_resp);
		goto send_resp;
	}
	case PEERCHNL_OP_SET_MAX_FRM_SIZE:
	{
		struct net_device *netdev = NULL;
		struct peerchnl_mtu_change *pmc;
		int new_mtu, i, mstatus = 0;
		u8 lport, iport;

		msg_opcode = PEERCHNL_OP_SET_MAX_FRM_SIZE_RESP;
		pmc = (struct peerchnl_mtu_change *)buf;
		new_mtu = pmc->new_mtu;
		lport = pmc->lport;
		iport = pf->hw.port_info[ICE_INTERNAL_PORT_TO_SWITCH].lport;

		/* Frame size set by the IES include L2 header + FCS + VLAN
		 * So we have to subtract packet header pad to compute
		 * the actual MTU size.
		 */
		new_mtu -= ICE_ETH_PKT_HDR_PAD;

		if (!pf->block_mtu_change) {
			dev_info(dev, "MTU settings are managed by IES API\n");
			pf->block_mtu_change = true;
		}

		/* Internal port MTU is always set as max */
		if (lport == iport)
			return 1;

		ice_for_each_vsi(pf, i) {
			struct ice_vsi *vsi = pf->vsi[i];

			if (vsi && vsi->port_info->lport == lport) {
				netdev = vsi->netdev;
				break;
			}
		}

		if (netdev) {
			rtnl_lock();
			pf->block_mtu_change = false;
			mstatus = dev_set_mtu(netdev, new_mtu);
			pf->block_mtu_change = true;
			rtnl_unlock();
		} else {
			pf->block_mtu_change = true;
			dev_err(dev,
				"There is no netdevice for port: %d\n", lport);
			mstatus = -ENODEV;
		}

		if (mstatus) {
			dev_err(dev,
				"MTU update on port %d was not successful\n",
				lport);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto send_resp;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto send_resp;
	}
#ifndef NO_PTP_SUPPORT
	case PEERCHNL_OP_RX_CODE_ERR:
	{
		int err;

		buf_size = 0;
		buf = NULL;

#ifdef ETH56G_SUPPORT
		err = ice_ptp_phy_restart(pf, desc->cookie_low.data);
#else
		err = ice_ptp_check_rx_fifo(pf, desc->cookie_low.data);
#endif
		if (err) {
			dev_err(dev,
				"Port %d Rx FIFO reset was not successful\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
	case PEERCHNL_OP_TIMESTAMP_ENABLE:
	{
		int err;

		buf_size = 0;
		buf = NULL;

		err = ptp_ts_enable(pf, desc->cookie_low.data, true);
		if (err) {
			dev_err(dev,
				"Port %d timestamp enabling failed\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
	case PEERCHNL_OP_TIMESTAMP_DISABLE:
	{
		int err;

		buf_size = 0;
		buf = NULL;

		err = ptp_ts_enable(pf, desc->cookie_low.data, false);
		if (err) {
			dev_err(dev,
				"Port %d timestamp disabling failed\n",
				desc->cookie_low.data);
			msg_data = PEERCHNL_STATUS_ERR_CMD_FAIL;
			goto ack;
		}

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
	}
#endif /* !NO_PTP_SUPPORT */
#ifdef SWITCH_MODE
	case PEERCHNL_OP_ADD_PRE_VEB_ENTRY_RESP:
	{
		struct peerchnl_add_pre_veb_entry_resp *pv_resp;
		struct ice_vf *vf;
		bool sent_state;
		int err;

		sent_state = (desc->cookie_low.data == PEERCHNL_STATUS_SUCCESS);
		if (!sent_state) {
			dev_info(dev,
				 "Pre-VEB rule was not added on IES side\n");
			return -EAGAIN;
		}

		pv_resp = (struct peerchnl_add_pre_veb_entry_resp *)buf;
		vf = ice_get_vf_by_id(pf, pv_resp->fn);
		if (!vf)
			return -EINVAL;

		err = ice_vf_update_pre_veb_status(vf, pv_resp->vlan_id,
						   pv_resp->mac_addr,
						   pv_resp->rule_id,
						   sent_state);
		ice_put_vf(vf);
		return err;
	}
	case PEERCHNL_OP_DEL_PRE_VEB_ENTRY_RESP:
	{
		struct peerchnl_del_pre_veb_entry *del_pv_resp;
		bool sent_state;

		sent_state = (desc->cookie_low.data == PEERCHNL_STATUS_SUCCESS);
		if (!sent_state)
			dev_info(dev,
				 "Pre-VEB rule was not removed on IES side\n");
		del_pv_resp = (struct peerchnl_del_pre_veb_entry *)buf;
		ice_vf_del_pre_veb(pf, del_pv_resp->rule_id);
		return 0;
	}
#endif /* SWITCH_MODE*/
#ifdef BMSM_MODE
#ifndef NO_PTP_SUPPORT
	case PEERCHNL_OP_PHY_STATE_CHANGE_RESP:
		msg_data = ice_process_phy_state_change(pf, buf);
		goto ack;
#endif /* !NO_PTP_SUPPORT */
#endif /* BMSM_MODE */
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
	case PEERCHNL_OP_IPSEC_ENABLE:
	case PEERCHNL_OP_IPSEC_DISABLE:
		buf_size = 0;
		buf = NULL;

		ice_ipsec_ena_dis(pf, msg_opcode == PEERCHNL_OP_IPSEC_ENABLE);

		msg_data = PEERCHNL_STATUS_SUCCESS;
		goto ack;
#endif /* SWITCH_MODE && !BMSM_MODE */
	default:
		dev_err(dev,
			"Receive unrecognized msg cmd 0x%x from %d\n",
			msg_opcode, sender_id);
		msg_data = PEERCHNL_STATUS_ERR_OPCODE_UNKNOWN;
		goto ack;
	}
	return 1;
ack:
	msg_opcode = PEERCHNL_OP_ACK;
send_resp:
	ice_mbx_send_msg_to_ies(pf, msg_opcode, seq_num, (u8)msg_data, buf,
				buf_size, NULL);
#ifndef BMSM_MODE
	if (wait_for_fp_close) {
		INIT_WORK(&pf->fp_task, ice_wait_for_fp_close);
		queue_work(pf->fp_wq, &pf->fp_task);
	}
#else
#ifndef NO_PTP_SUPPORT
	if (!pf->ptp.phy_state_ack &&
	    inc_msg_opcode == PEERCHNL_OP_PHY_STATE_CHANGE_RESP) {
		pf->ptp.phy_state_ack = true;
		wake_up(&phy_state_ack_wait);
	}
#endif /* !NO_PTP_SUPPORT */
#endif /* !BMSM_MODE */
	return 1;
}
