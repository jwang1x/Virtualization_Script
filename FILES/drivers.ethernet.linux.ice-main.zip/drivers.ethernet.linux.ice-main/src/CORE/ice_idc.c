/* Inter-Driver Communication */
#include "ice.h"
#include "ice_lib.h"
#include "ice_fltr.h"
#ifdef VIRTCHNL_IPSEC
#include "ice_ipsec.h"
#endif /* VIRTCHNL_IPSEC */
#ifndef NO_DCB_SUPPORT
#include "ice_dcb_lib.h"
#endif /* !NO_DCB_SUPPORT */
#ifdef SWITCH_MODE
#include "ice_common.h"
#ifndef BMSM_MODE
#include "ice_base.h"
#endif /* !BMSM_MODE */
#endif /* SWITCH_MODE */
#ifdef BMSM_MODE
#include "ice_vf_veb.h"
#include "ice_external_bridge.h"
#endif /* BMSM_MODE */
#ifndef NO_PTP_SUPPORT
#include "ice_ptp.h"
#endif
#ifdef IEPS_SUPPORT
#include "ice_ieps.h"
#endif /* IEPS_SUPPORT */

static DEFINE_IDA(ice_cdev_info_ida);
#ifndef EXTERNAL_RELEASE
/* FIXME: this define will be included in the PTP code. Just placing it here
 * to not have an undefined value. Remove when define added elsewhere.
 */
#endif /* !EXTERNAL_RELEASE */
#ifdef SWITCH_MODE
DECLARE_WAIT_QUEUE_HEAD(peer_wait);
#ifndef BMSM_MODE
DECLARE_WAIT_QUEUE_HEAD(fp_wait);
#endif /* !BMSM_MODE */
#endif /* SWITCH_MODE */

#ifndef EXTERNAL_RELEASE
/* Dedicated resources in SWITCH mode, Max length in bytes : 0x3FFFF
 * Dedicated resource (in CSR space) for HLP (Switch), starts at 0x2000000
 * Dedicated resource (in CSR space) for AE (DSC), starts at 0x2040000
 * Dedicated resource (in CSR space) for CRYPTO (IPSec), starts at 0x2080000
 */
#endif /* EXTERNAL_RELEASE */

#ifdef SWITCH_MODE
#define ICE_PEER_PCI_RES_LEN (BIT_ULL(18) - 1)
#define ICE_PEER_SW_RES_START 0x02D00000
#define ICE_PEER_INLINE_CRYPTO_RES_START (ICE_PEER_SW_RES_START | BIT_ULL(19))
#ifndef BMSM_MODE
#define ICE_PEER_AE_RES_START (ICE_PEER_SW_RES_START | BIT_ULL(18))
#endif /* !BMSM_MODE */
#endif /* SWITCH_MODE */

#ifdef MULTI_PEER_SUPPORT
static struct cdev_info_id ice_cdev_ids[] = ASSIGN_IIDC_INFO;
#endif

/**
 * ice_get_auxiliary_drv - retrieve iidc_auxiliary_drv struct
 * @cdev_info: pointer to iidc_core_dev_info struct
 *
 * This function has to be called with a device_lock on the
 * cdev_info->adev.dev to avoid race conditions for auxiliary
 * driver unload, and the mutex pf->adev_mutex locked to avoid
 * plug/unplug race conditions..
 */
struct iidc_auxiliary_drv
*ice_get_auxiliary_drv(struct iidc_core_dev_info *cdev_info)
{
	struct auxiliary_device *adev;
#ifndef SWITCH_MODE
	struct ice_pf *pf;

	if (!cdev_info)
		return NULL;
	pf = pci_get_drvdata(cdev_info->pdev);

	lockdep_assert_held(&pf->adev_mutex);
#endif /* !SWITCH_MODE */

	adev = cdev_info->adev;
	if (!adev || !adev->dev.driver)
		return NULL;

	return container_of(adev->dev.driver, struct iidc_auxiliary_drv,
			    adrv.driver);
}

#ifdef SWITCH_MODE
#ifdef ADK_SUPPORT
/**
 * ice_vsi_from_port_info - return the PF VSI's ID from port_info
 * @pf: pointer to the PF that contains VSIs
 * @port_info: pointer to the port_info struct
 */
static int
ice_vsi_from_port_info(struct ice_pf *pf, struct ice_port_info *port_info)
{
	int i;

	ice_for_each_vsi(pf, i)
		if (pf->vsi[i]->port_info == port_info &&
		    pf->vsi[i]->type == ICE_VSI_PF)
			return i;

	/* No VSI found */
	return -EINVAL;
}

/**
 * ice_peer_adk_setup - setup resources for ADK peer
 * @cdev_info: pointer to the ADK cdev_info
 */
static void ice_peer_adk_setup(struct iidc_core_dev_info *cdev_info)
{
	struct iidc_port_info *iidc_p;
	struct ice_port_info *p;
	struct ice_pf *pf;
	int i;

	/* If this is not an ADK peer - do not complete setup */
	if (cdev_info->cdev_info_id != IIDC_ADK_ID)
		return;

	pf = pci_get_drvdata(cdev_info->pdev);
	if (!pf)
		return;

	p = pf->hw.port_info;
	iidc_p = cdev_info->port_info;

#ifndef EXTERNAL_RELEASE
/* TODO: Following code should be refactored to use ice_for_each_set_bit
 * once supported.
 */
#endif /* !EXTERNAL_RELEASE */
	for (i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++) {
		int vsi_num;

		if (!(pf->hw.ena_lports & BIT(i)))
			continue;
		vsi_num = ice_vsi_from_port_info(pf, &p[i]);

		if (vsi_num < 0)
			continue;
		iidc_p[i].lwr_netdev = pf->vsi[vsi_num]->netdev;
		iidc_p[i].vport_num = vsi_num;
		iidc_p[i].is_internal = p[i].is_internal_port;
		iidc_p[i].lport = p[i].lport;
		/* bank_id is a value from 0-4.
		 * Bank 0 and 1 are on PHY 0
		 * Bank 2 and 3 are on PHY 1
		 * Bank 4 is on PHY 2.
		 */
		iidc_p[i].bank_id = p[i].lport / ICE_PORTS_PER_QUAD;
#ifndef ICE_TDD
		ether_addr_copy(iidc_p[i].mac_addr, p[i].mac.lan_addr);
#endif /* !ICE_TDD */
		pf->vsi[vsi_num]->adk_cdev_info = cdev_info;
		bitmap_zero(iidc_p[i].ena, IIDC_PORT_NBITS);
	}
}

/**
 * ice_clear_port_info - helper to clear data structure
 * @cdev_info: cdev_info to clear port info from
 */
static void ice_clear_port_info(struct iidc_core_dev_info *cdev_info)
{
	/* There is an expectation in 'stack mode' that after
	 * reset/init VSI is in down state and it is a user
	 * application resposibility to bring VSI back up.
	 * Here, we clear only state of the cdev_info port info to
	 * be consistent with the state of cdev_info object. All
	 * clean up is done at VSI close call.
	 */
	if (!ice_is_nd_vis() && cdev_info->cdev_info_id == IIDC_ADK_ID) {
		int i;

		for (i = 0; i < IIDC_MAX_NUM_LPORTS; i++)
			bitmap_zero(cdev_info->port_info[i].ena,
				    IIDC_PORT_NBITS);
	}
}
#endif /* ADK_SUPPORT */
#endif /* SWITCH_MODE */

#ifdef MULTI_PEER_SUPPORT
/**
 * ice_for_each_aux - iterate across and call function for each aux driver
 * @pf: pointer to private board struct
 * @data: data to pass to function on each call
 * @fn: pointer to function to call for each peer
 */
int
ice_for_each_aux(struct ice_pf *pf, void *data,
		 int (*fn)(struct iidc_core_dev_info *, void *))
{
	unsigned int i;

	if (!pf->cdev_infos)
		return 0;

	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
		struct iidc_core_dev_info *cdev_info;

		cdev_info = pf->cdev_infos[i];
		if (cdev_info) {
			int ret = fn(cdev_info, data);
			if (ret)
				return ret;
		}
	}

	return 0;
}
#endif /* MULTI_PEER_SUPPORT */

#ifdef MULTI_PEER_SUPPORT
/**
 * ice_send_event_to_aux - send event to a specific aux driver
 * @cdev_info: pointer to iidc_core_dev_info struct for this aux
 * @data: opaque pointer used to pass event struct
 */
#ifndef OLD_IDC_SUPPORT
static int
ice_send_event_to_aux(struct iidc_core_dev_info *cdev_info, void *data)
#else /* OLD_IDC_SUPPORT */
static int
ice_send_event_to_aux(struct ice_peer_obj *cdev_info, void *data)
#endif /* OLD_IDC_SUPPORT */
#else
/**
 * ice_send_event_to_aux - send event to a specific aux driver
 * @cdev_info: pointer to iidc_core_dev_info struct for this aux
 * @event: event struct
 */
#ifndef OLD_IDC_SUPPORT
void
ice_send_event_to_aux(struct iidc_core_dev_info *cdev_info,
		      struct iidc_event *event)
#else /* OLD_IDC_SUPPORT */
void
ice_send_event_to_aux(struct ice_peer_obj *cdev_info,
		      struct ice_event *event)
#endif /* OLD_IDC_SUPPORT */
#endif /* MULTI_PEER_SUPPORT */
{
#ifdef MULTI_PEER_SUPPORT
#ifndef OLD_IDC_SUPPORT
	struct iidc_event *event = (struct iidc_event *)data;
#else /* OLD_IDC_SUPPORT */
	struct ice_event *event = (struct ice_event *)data;
#endif /* OLD_IDC_SUPPORT */
#endif
	struct iidc_auxiliary_drv *iadrv;
#ifndef SWITCH_MODE
	struct ice_pf *pf;

	if (WARN_ON_ONCE(!in_task()))
#ifdef MULTI_PEER_SUPPORT
		return -EINVAL;
#else
		return;
#endif /* MULTI_PEER_SUPPORT */

	if (!cdev_info)
#ifdef MULTI_PEER_SUPPORT
		return -EINVAL;
#else
		return;
#endif /* MULTI_PEER_SUPPORT */
	pf = pci_get_drvdata(cdev_info->pdev);

	if (!pf)
#ifdef MULTI_PEER_SUPPORT
		return -EINVAL;
#else
		return;
#endif /* MULTI_PEER_SUPPORT */
	mutex_lock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */

	if (!cdev_info->adev || !event) {
#ifndef SWITCH_MODE
		mutex_unlock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
#ifdef MULTI_PEER_SUPPORT
		return 0;
#else
		return;
#endif /* MULTI_PEER_SUPPORT */
	}

#ifdef SWITCH_MODE
	if (cdev_info == event->reporter)
		return 0;

#endif /* SWITCH_MODE */
	device_lock(&cdev_info->adev->dev);
	iadrv = ice_get_auxiliary_drv(cdev_info);
	if (iadrv && iadrv->event_handler)
		iadrv->event_handler(cdev_info, event);
	device_unlock(&cdev_info->adev->dev);
#ifndef SWITCH_MODE
	mutex_unlock(&pf->adev_mutex);
#endif /* SWITCH_MODE */
#ifdef MULTI_PEER_SUPPORT

	return 0;
#endif
}

#ifdef LAG_SUPPORT
/**
 * ice_send_event_to_aux_no_lock - send event to aux dev without taking dev_lock
 * @cdev: pointer to iidc_core_dev_info struct
 * @data: opaque poiner used to pass event struct
 */
void ice_send_event_to_aux_no_lock(struct iidc_core_dev_info *cdev, void *data)
{
	struct iidc_event *event = (struct iidc_event *)data;
	struct iidc_auxiliary_drv *iadrv;

	iadrv = ice_get_auxiliary_drv(cdev);
	if (iadrv && iadrv->event_handler)
		iadrv->event_handler(cdev, event);
}

#endif /* LAG_SUPPORT */
#ifdef MULTI_PEER_SUPPORT
/**
 * ice_send_event_to_auxs - send event to all auxiliary drivers
 * @pf: pointer to PF struct
 * @event: pointer to iidc_event to propagate
 *
 * event struct to be populated by caller
 */
#ifndef OLD_IDC_SUPPORT
void ice_send_event_to_auxs(struct ice_pf *pf, struct iidc_event *event)
#else /* OLD_IDC_SUPPORT */
void ice_send_event_to_auxs(struct ice_pf *pf, struct ice_event *event)
#endif /* OLD_IDC_SUPPORT */
{
	if (!event || !pf)
		return;

	if (bitmap_weight(event->type, IIDC_EVENT_NBITS) != 1) {
		dev_warn(ice_pf_to_dev(pf), "Event with not exactly one type bit set\n");
		return;
	}

	ice_for_each_aux(pf, event, ice_send_event_to_aux);
}

/**
 * ice_unroll_cdev_info - destroy cdev_info resources
 * @cdev_info: ptr to cdev_info struct
 * @data: ptr to opaque data
 *
 * This function releases resources for cdev_info objects.
 * Meant to be called from a ice_for_each_aux invocation
 */
int ice_unroll_cdev_info(struct iidc_core_dev_info *cdev_info,
			 void __always_unused *data)
{
	if (!cdev_info)
		return 0;

	kfree(cdev_info);

	return 0;
}

#endif /* MULTI_PEER_SUPPORT */
#ifdef CONFIG_PM
/**
 * ice_cdev_info_refresh_msix - load new values into iidc_core_dev_info structs
 * @pf: pointer to private board struct
 */
void ice_cdev_info_refresh_msix(struct ice_pf *pf)
{
#ifdef MULTI_PEER_SUPPORT
	struct iidc_core_dev_info *cdev_info;
	unsigned int i;

	if (!pf->cdev_infos)
		return;

	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
		if (!pf->cdev_infos[i])
			continue;

		cdev_info = pf->cdev_infos[i];

		switch (cdev_info->cdev_info_id) {
#ifdef SWITCH_MODE
#ifndef BMSM_MODE
		case IIDC_AE_ID:
			cdev_info->msix_count = pf->num_ae_msix;
			cdev_info->msix_entries =
				&pf->msix_entries[pf->ae_base_vector];
			break;
#endif /* !BMSM_MODE */
		case IIDC_IPSEC_ID:
			cdev_info->msix_count = pf->num_crypto_msix;
			cdev_info->msix_entries =
				&pf->msix_entries[pf->crypto_base_vector];
			break;
		case IIDC_SW_ID:
			cdev_info->msix_count = pf->num_swt_msix;
			cdev_info->msix_entries =
				&pf->msix_entries[pf->swt_base_vector];
			break;
#endif /* SWITCH_MODE */
#ifdef RDMA_SUPPORT
		case IIDC_RDMA_ID:
			cdev_info->msix_count = pf->num_rdma_msix;
			cdev_info->msix_entries =
				&pf->msix_entries[pf->rdma_base_vector];
			break;
#endif /* RDMA_SUPPORT */
		default:
			break;
		}
	}
#else
#ifdef RDMA_SUPPORT
	if (!pf->cdev_info)
		return;

	pf->cdev_info->msix_count = pf->num_rdma_msix;
	pf->cdev_info->msix_entries = &pf->msix_entries[pf->rdma_base_vector];
#endif /* RDMA_SUPPORT */
#endif /* MULTI_PEER_SUPPORT */
}

#endif /* CONFIG_PM */
#ifndef SWITCH_MODE
#ifdef RDMA_SUPPORT
/**
 * ice_alloc_rdma_qsets - Allocate Leaf Nodes for RDMA Qset
 * @cdev_info: aux driver that is requesting the Leaf Nodes
 * @qset: Resource to be allocated
 *
 * This function allocates Leaf Nodes for given RDMA Qset resources
 * for the peer object.
 */
static int
ice_alloc_rdma_qsets(struct iidc_core_dev_info *cdev_info,
		     struct iidc_rdma_qset_params *qset)
{
	u16 max_rdmaqs[ICE_MAX_TRAFFIC_CLASS];
#ifdef HAVE_NETDEV_UPPER_INFO
	struct ice_lag *lag;
#endif /* HAVE_NETDEV_UPPER_INFO */
	struct ice_vsi *vsi;
	struct device *dev;
	struct ice_pf *pf;
	u32 qset_teid;
	u16 qs_handle;
	int i, status;

	if (!cdev_info || !qset)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	dev = ice_pf_to_dev(pf);

	if (!ice_chk_rdma_cap(pf))
		return -EINVAL;

	ice_for_each_traffic_class(i)
		max_rdmaqs[i] = 0;

	max_rdmaqs[qset->tc]++;
	qs_handle = qset->qs_handle;

	vsi = ice_find_vsi(pf, qset->vport_id);
	if (!vsi) {
		dev_err(dev, "RDMA QSet invalid VSI\n");
		return -EINVAL;
	}

	status = ice_cfg_vsi_rdma(vsi->port_info, vsi->idx, vsi->tc_cfg.ena_tc,
				  max_rdmaqs);
	if (status) {
		dev_err(dev, "Failed VSI RDMA qset config\n");
		return status;
	}

	status = ice_ena_vsi_rdma_qset(vsi->port_info, vsi->idx, qset->tc,
				       &qs_handle, 1, &qset_teid);
	if (status) {
		dev_err(dev, "Failed VSI RDMA qset enable\n");
		return status;
	}
	vsi->qset_handle[qset->tc] = qset->qs_handle;
	qset->teid = qset_teid;

#ifdef HAVE_NETDEV_UPPER_INFO
	lag = pf->lag;
	if (lag && lag->bonded) {
		mutex_lock(&pf->lag_mutex);
		lag->rdma_qset[qset->tc] = *qset;

		if (cdev_info->rdma_active_port != pf->hw.port_info->lport &&
		    cdev_info->rdma_active_port != ICE_LAG_INVALID_PORT) {
			struct net_device *tmp_nd;

			rcu_read_lock();
			for_each_netdev_rcu(&init_net, tmp_nd) {
				struct ice_netdev_priv *tmp_ndp;
				struct ice_lag *tmp_lag;
				struct ice_vsi *tmp_vsi;
				struct ice_hw *tmp_hw;

				if (!netif_is_ice(tmp_nd))
					continue;

				tmp_ndp = netdev_priv(tmp_nd);
				tmp_vsi = tmp_ndp->vsi;
				tmp_lag = tmp_vsi->back->lag;

				if (!tmp_lag->bonded ||
				    tmp_lag->bond_id != lag->bond_id)
					continue;

				tmp_hw = &tmp_vsi->back->hw;

				if (cdev_info->rdma_active_port ==
				    tmp_hw->port_info->lport)
					status = ice_lag_move_node_sync(&pf->hw,
									tmp_hw,
									tmp_vsi,
									qset);
			}
			rcu_read_unlock();
		}
		mutex_unlock(&pf->lag_mutex);
	}

#endif /* HAVE_NETDEV_UPPER_INFO */
	return status;
}

/**
 * ice_free_rdma_qsets - Free leaf nodes for RDMA Qset
 * @cdev_info: aux driver that requested qsets to be freed
 * @qset: Resource to be freed
 */
static int
ice_free_rdma_qsets(struct iidc_core_dev_info *cdev_info,
		    struct iidc_rdma_qset_params *qset)
{
	struct ice_vsi *vsi;
	struct device *dev;
	struct ice_pf *pf;
	u16 vsi_id;
	int status;
	u32 teid;
	u16 q_id;

	if (!cdev_info || !qset)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	dev = ice_pf_to_dev(pf);

	vsi_id = qset->vport_id;
	vsi = ice_find_vsi(pf, vsi_id);
	if (!vsi) {
		dev_err(dev, "RDMA Invalid VSI\n");
		return -EINVAL;
	}

	if (qset->vport_id != vsi_id) {
		dev_err(dev, "RDMA Invalid VSI ID\n");
		return -EINVAL;
	}
	q_id = qset->qs_handle;
	teid = qset->teid;

	vsi->qset_handle[qset->tc] = 0;

#ifdef HAVE_NETDEV_UPPER_INFO
	if (pf->lag && pf->lag->bonded) {
		mutex_lock(&pf->lag_mutex);

		if (cdev_info->rdma_active_port != pf->hw.port_info->lport &&
		    cdev_info->rdma_active_port != ICE_LAG_INVALID_PORT) {
			struct net_device *tmp_nd;

			rcu_read_lock();
			for_each_netdev_rcu(&init_net, tmp_nd) {
				struct ice_netdev_priv *tmp_ndp;
				struct ice_lag *tmp_lag;
				struct ice_vsi *tmp_vsi;
				struct ice_hw *tmp_hw;

				if (!netif_is_ice(tmp_nd))
					continue;

				tmp_ndp = netdev_priv(tmp_nd);
				tmp_vsi = tmp_ndp->vsi;
				tmp_lag = tmp_vsi->back->lag;
				tmp_hw = &tmp_vsi->back->hw;

				if (!tmp_lag->bonded ||
				    tmp_lag->bond_id != pf->lag->bond_id)
					continue;

				if (cdev_info->rdma_active_port ==
				    tmp_hw->port_info->lport)
					ice_lag_move_node_sync(tmp_hw, &pf->hw,
							       pf->vsi[0],
							       qset);
			}
			rcu_read_unlock();
		}
		mutex_unlock(&pf->lag_mutex);
	}

#endif /* HAVE_NETDEV_UPPER_INFO */
	status = ice_dis_vsi_rdma_qset(vsi->port_info, 1, &teid, &q_id);
	if (status)
		return -EINVAL;

#ifdef HAVE_NETDEV_UPPER_INFO
	memset(&pf->lag->rdma_qset[qset->tc], 0, sizeof(*qset));
#endif /* HAVE_NETDEV_UPPER_INFO */
	return 0;
}

#endif /* RDMA_SUPPORT */
/**
 * ice_cdev_info_alloc_res - Allocate requested resources for aux driver
 * @cdev_info: struct for aux driver that is requesting resources
 * @qset: Resource to be allocated
 */
static int
ice_cdev_info_alloc_res(struct iidc_core_dev_info *cdev_info,
			struct iidc_rdma_qset_params *qset)
{
	struct ice_pf *pf;

	if (!cdev_info || !qset)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	if (!ice_pf_state_is_nominal(pf))
		return -EBUSY;

#ifdef RDMA_SUPPORT
	return ice_alloc_rdma_qsets(cdev_info, qset);
#else
	return -EINVAL;
#endif /* RDMA_SUPPORT */
}

/**
 * ice_cdev_info_free_res - Free resources associated with aux driver
 * @cdev_info: struct for aux driver that is requesting freeing of resources
 * @qset: Resource to be freed
 */
static int
ice_cdev_info_free_res(struct iidc_core_dev_info *cdev_info,
		       struct iidc_rdma_qset_params *qset)
{
#ifdef RDMA_SUPPORT
	if (!cdev_info || !qset)
		return -EINVAL;

	return ice_free_rdma_qsets(cdev_info, qset);
#else
	return -EINVAL;
#endif /* RDMA_SUPPORT */
}
#endif /* SWITCH_MODE */

#ifdef SWITCH_MODE
/**
 * ice_cdev_info_report_event - accept report of an aux event
 * @cdev_info: aux driver that is sending notification about state change
 * @event: ice_event holding info on what the state change is
 *
 * Generate an event and broadcast the event.
 */
#ifndef OLD_IDC_SUPPORT
static void
ice_cdev_info_report_event(struct iidc_core_dev_info *cdev_info,
			   struct iidc_event *event)
#else /* OLD_IDC_SUPPORT */
ice_cdev_info_report_event(struct ice_peer_obj *cdev_info,
			   struct ice_event *event)
#endif /* OLD_IDC_SUPPORT */
{
	unsigned int e_type;
	struct ice_pf *pf;

	if (!cdev_info || !event)
		return;

	pf = pci_get_drvdata(cdev_info->pdev);
	if (!pf)
		return;

	e_type = find_first_bit(event->type, IIDC_EVENT_NBITS);
	if (!e_type)
		return;

	switch (e_type) {
	/* Check for drv events */
	case IIDC_EVENT_API_QUERY:
		break;

	/* Check for cdev_info events */
	case IIDC_EVENT_API_CHANGE:
		if (!event->info.api_rdy)
			pf->block_mtu_change = false;
		break;
	case IIDC_EVENT_MBX_EVENT:
		if (event->info.msg.msg_opcode ==
		    PEERCHNL_OP_ADD_PRE_VEB_ENTRY_RESP) {
#ifdef SWITCH_MODE
			struct peerchnl_add_pre_veb_entry_resp *pv_resp;
			struct ice_vf *vf;

			pv_resp = (struct peerchnl_add_pre_veb_entry_resp *)
				event->info.msg.buffer;

			vf = ice_get_vf_by_id(pf, pv_resp->fn);
			if (!vf) {
				dev_dbg(ice_pf_to_dev(pf), "Failed to locate VF ID %u\n",
					pv_resp->fn);
				return;
			}

			ice_vf_update_pre_veb_status(vf, pv_resp->vlan_id,
						     pv_resp->mac_addr,
						     pv_resp->rule_id, true);

			ice_put_vf(vf);
#endif /* SWITCH_MODE */
			/* this message is for PF - do not propagate */
			return;
		}
#ifndef EXTERNAL_RELEASE
	/* FIXME:
	 * case IIDC_EVENT_TC_CHANGE:
	 */
#endif
	default:
		return;
	}

#ifdef MULTI_PEER_SUPPORT
	ice_send_event_to_auxs(pf, event);
#endif /* MULTI_PEER_SUPPORT */
#ifdef BMSM_MODE

	/* sync Pre-VEB function should be called after ice_peer_check_for_reg
	 * to avoid crash due to uninitialized peer
	 */
#ifndef EXTERNAL_RELEASE
	/* TODO: since we are not keeping state info anymore, should we always
	 * do this?
	 */
#endif /* !EXTERNAL_RELEASE */
	ice_vf_sync_pre_veb_peer(pf);
#endif /* BMSM_MODE */
}

#endif /* SWITCH_MODE */

#if defined(BMSM_MODE)
/**
 * ice_cdev_info_sw_clean_cfg - clean NIC cfg created by switch peer obj
 * @pf: ptr to struct ice_pf
 *
 * switch peer objeect can create configuration on NIC that goes away during
 * peer reset. This function rolls back such configuration changes to reach
 * back consistent state between NIC and switch
 */
void ice_cdev_info_sw_clean_cfg(struct ice_pf *pf)
{
	ice_bridge_clean(pf);
#ifndef NO_HW_LAG_SUPPORT
	ice_hw_lag_clean(pf);
#endif
}
#endif /* BMSM_MODE */

/**
 * ice_cdev_info_request_reset - accept request from peer to perform a reset
 * @cdev_info: struct for aux driver that is requesting a reset
 * @reset_type: type of reset the peer is requesting
 */
static int
ice_cdev_info_request_reset(struct iidc_core_dev_info *cdev_info,
			    enum iidc_reset_type reset_type)
{
	enum ice_reset_req reset;
	struct ice_pf *pf;
#ifdef SWITCH_MODE
	int err;
#endif /* SWITCH_MODE */

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	switch (reset_type) {
#ifndef SWITCH_MODE
	case IIDC_PFR:
		reset = ICE_RESET_PFR;
		break;
#endif /* !SWITCH_MODE */
	case IIDC_CORER:
		reset = ICE_RESET_CORER;
		break;
#ifdef SWITCH_MODE
	case IIDC_CORER_SW_CORE:
		reset = ICE_RESET_CORER;
		break;
	case IIDC_CORER_SW_FULL:
		reset = ICE_RESET_CORER;
		break;
#endif /* SWITCH_MODE */
	case IIDC_GLOBR:
		reset = ICE_RESET_GLOBR;
		break;
#ifdef INTERNAL_ONLY
	case IIDC_EMPR:
		reset = ICE_RESET_EMPR;
		break;
#endif /* INTERNAL_ONLY */
	default:
		dev_err(ice_pf_to_dev(pf), "incorrect reset request from peer\n");
		return -EINVAL;
	}

#ifdef BMSM_MODE
#ifndef EXTERNAL_RELEASE
	/* When IES requests CPK reset or when other peer requests both CPK
	 * and HLP reset we need to reflect HLP reset behaviour that affects
	 * CPK side configuration.
	 */
#endif /* !EXTERNAL_RELEASE */
	if (reset_type == IIDC_CORER_SW_CORE ||
#ifdef INTERNAL_ONLY
	    reset_type == IIDC_EMPR ||
#endif /* INTERNAL_ONLY */
	    reset_type == IIDC_CORER_SW_FULL)
		ice_cdev_info_sw_clean_cfg(pf);
#endif /* BMSM_MODE */
#ifdef SWITCH_MODE
	err = ice_schedule_reset(pf, reset);
	if (err)
		return err;

	if (reset_type == IIDC_CORER_SW_CORE)
		wr32(&pf->hw, GLGEN_ASSERT_HLP, GLGEN_ASSERT_HLP_CORE_ON_RST_M);

	if (reset_type == IIDC_CORER_SW_FULL)
		wr32(&pf->hw, GLGEN_ASSERT_HLP, GLGEN_ASSERT_HLP_CORE_ON_RST_M |
		     GLGEN_ASSERT_HLP_FULL_ON_RST_M);

	return 0;
#else
	return ice_schedule_reset(pf, reset);
#endif /* SWITCH_MODE */
}

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
/**
 * ice_cdev_info_request_vf_reset - accept request from aux to perform VF reset
 * @cdev_info: struct for aux driver that is requesting a reset
 * @vf_id: VF ID of VF to reset
 */
static int
ice_cdev_info_request_vf_reset(struct iidc_core_dev_info *cdev_info, u32 vf_id)
{
	struct ice_pf *pf;
	struct ice_vf *vf;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	vf = ice_get_vf_by_id(pf, vf_id);
	if (!vf)
		return -EINVAL;

	ice_reset_vf(vf, ICE_VF_RESET_NOTIFY | ICE_VF_RESET_LOCK);
	mutex_unlock(&pf->vfs.table_lock);

	ice_put_vf(vf);

	return 0;
}
#endif /* SWITCH_MODE && !BMSM_MODE */

#ifdef RDMA_SUPPORT
/**
 * ice_cdev_info_update_vsi_filter - update main VSI filters for RDMA
 * @cdev_info: pointer to struct for aux device updating filters
 * @vsi_id: vsi HW idx to update filter on
 * @enable: bool whether to enable or disable filters
 */
static int
ice_cdev_info_update_vsi_filter(struct iidc_core_dev_info *cdev_info,
				u16 vsi_id, bool enable)
{
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	int ret;

	if (!cdev_info)
		return -EINVAL;

#ifdef SV_SUPPORT
	pr_info("Aux driver requesting filters %sABLE\n",
		enable ? "EN" : "DIS");
#endif /* SV_SUPPORT */
	pf = pci_get_drvdata(cdev_info->pdev);

	vsi = ice_find_vsi(pf, vsi_id);
	if (!vsi)
		return -EINVAL;

	ret = ice_cfg_iwarp_fltr(&pf->hw, vsi->idx, enable);

	if (ret) {
		dev_err(ice_pf_to_dev(pf), "Failed to  %sable iWARP filtering\n",
			enable ? "en" : "dis");
	} else {
		if (enable)
			vsi->info.q_opt_flags |= ICE_AQ_VSI_Q_OPT_PE_FLTR_EN;
		else
			vsi->info.q_opt_flags &= ~ICE_AQ_VSI_Q_OPT_PE_FLTR_EN;
	}

	return ret;
}
#endif /* RDMA_SUPPORT */

/**
 * ice_cdev_info_vc_send - send a virt channel message from an aux driver
 * @cdev_info: pointer to cdev_info struct for aux driver
 * @vf_id: the VF ID of recipient of message
 * @msg: pointer to message contents
 * @len: len of message
 *
 * Note that the VF ID is absolute for RDMA operations, but a relative ID for
 * IPSEC operations.
 */
static int
ice_cdev_info_vc_send(struct iidc_core_dev_info *cdev_info, u32 vf_id,
		      u8 *msg, u16 len)
{
	struct ice_pf *pf;
#ifdef RDMA_SUPPORT
	u32 rel_vf_id;
#endif
	int status;

	if (!cdev_info)
		return -EINVAL;
	if (!msg || !len)
		return -ENOMEM;

	pf = pci_get_drvdata(cdev_info->pdev);
	if (len > ICE_AQ_MAX_BUF_LEN)
		return -EINVAL;

	if (ice_is_reset_in_progress(pf->state))
		return -EBUSY;

	switch (cdev_info->cdev_info_id) {
#ifdef RDMA_SUPPORT
	case IIDC_RDMA_ID:
		/* The ID is absolute so it must be converted first */
		rel_vf_id = ice_rel_vf_id(&pf->hw, vf_id);

		if (!ice_is_valid_vf_id(pf, rel_vf_id))
			return -ENODEV;

		/* VIRTCHNL_OP_RDMA is being used for RoCEv2 msg also */
		status = ice_aq_send_msg_to_vf(&pf->hw, rel_vf_id,
					       VIRTCHNL_OP_RDMA, 0, msg, len,
					       NULL);
		break;
#endif /* RDMA_SUPPORT */
#ifdef VIRTCHNL_IPSEC
	case IIDC_IPSEC_ID:
		if (vf_id != VIRTCHNL_IPSEC_BROADCAST_VFID &&
		    !ice_is_valid_vf_id(pf, vf_id))
			return -ENODEV;

		status = ice_ipsec_send_vc_msg(pf, msg, len, vf_id);
		break;
#endif /* VIRTCHNL_IPSEC */
	default:
		dev_err(ice_pf_to_dev(pf), "Can't send message to VF, Aux not supported, %u\n",
			(u32)cdev_info->cdev_info_id);
		return -ENODEV;
	}

	if (status)
		dev_err(ice_pf_to_dev(pf), "Unable to send msg to VF, error %d\n",
			status);
	return status;
}

/**
 * ice_reserve_cdev_info_qvector - Reserve vector resources for aux drivers
 * @pf: board private structure to initialize
 */
static int ice_reserve_cdev_info_qvector(struct ice_pf *pf)
{
#ifdef SWITCH_MODE
	int index;

#ifndef EXTERNAL_RELEASE
	/* TODO: work with peer driver teams and figure out what they need and
	 * provide necessary base vector information. IDC header file might
	 * get changed.
	 */
#endif /* !EXTERNAL_RELEASE */
	/* reserve vectors in irq_tracker for aux drivers */
	index = ice_get_res(pf, pf->irq_tracker, ICE_MAX_SWT_VEC,
			    ICE_RES_SWT_VEC_ID);
	if (index < 0)
		return index;
	pf->swt_base_vector = (u16)index;
	pf->num_avail_sw_msix -= ICE_MAX_SWT_VEC;
#ifndef BMSM_MODE
	index = ice_get_res(pf, pf->irq_tracker, ICE_MAX_AE_VEC,
			    ICE_RES_AE_VEC_ID);
	if (index < 0)
		return index;
	pf->ae_base_vector = (u16)index;
#endif /* !BMSM_MODE */
	index = ice_get_res(pf, pf->irq_tracker, ICE_MAX_CRYPTO_VEC,
			    ICE_RES_CRYPTO_VEC_ID);
	if (index < 0)
		return index;
	pf->crypto_base_vector = (u16)index;
	pf->num_avail_sw_msix -= ICE_MAX_CRYPTO_VEC;
#elif defined(RDMA_SUPPORT)
	if (ice_chk_rdma_cap(pf)) {
		int index;

#ifndef EXTERNAL_RELEASE
		/* TODO: work with RDMA team and figure out what they need
		 * and provide necessary base vector information. IDC header
		 * file might get changed. Current change won't effect RDMA
		 * if SRIOV and RDMA won't co-exist.
		 */
#endif
		index = ice_get_res(pf, pf->irq_tracker, pf->num_rdma_msix, ICE_RES_RDMA_VEC_ID);
		if (index < 0)
			return index;
		pf->num_avail_sw_msix -= pf->num_rdma_msix;
		pf->rdma_base_vector = (u16)index;
	}
#endif /* SWITCH_MODE */
	return 0;
}

#ifdef VF_RDMA_SUPPORT
/**
 * ice_send_vf_reset_to_aux - send a VF reset notification to the aux driver
 * @cdev_info: pointer to the cdev_info object
 * @vf_id: VF ID to query
 *
 * Tell the RDMA auxiliary driver that a VF is resetting
 */
#ifndef OLD_IDC_SUPPORT
void ice_send_vf_reset_to_aux(struct iidc_core_dev_info *cdev_info, u16 vf_id)
#else /* OLD_IDC_SUPPORT */
void ice_send_vf_reset_to_aux(struct ice_peer_obj *cdev_info, u16 vf_id)
#endif /* OLD_IDC_SUPPORT */
{
#ifndef OLD_IDC_SUPPORT
	struct iidc_event *event;

	event = (struct iidc_event *)kzalloc(sizeof(*event), GFP_KERNEL);
#else /* OLD_IDC_SUPPORT */
	struct ice_event *event;

	event = (struct ice_event *)kzalloc(sizeof(*event), GFP_KERNEL);
#endif /* OLD_IDC_SUPPORT */
	if (!event)
		return;
	set_bit(IIDC_EVENT_VF_RESET, event->type);
	event->info.vf_id = (u32)vf_id;
	ice_send_event_to_aux(cdev_info, event);
	kfree(event);
}

/**
 * ice_cdev_info_get_vf_port_info - get a VF's information
 * @cdev_info: pointer to the cdev_info object
 * @abs_vf_id: Absolute VF ID to query
 * @vf_port_info: structure to populate for the caller
 *
 * Allow the RDMA auxiliary driver to query a VF's information
 */
static int
ice_cdev_info_get_vf_port_info(struct iidc_core_dev_info *cdev_info,
			       u16 abs_vf_id,
			       struct iidc_vf_port_info *vf_port_info)
{
	struct ice_pf *pf;

	if (!cdev_info || !vf_port_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	return ice_get_vf_port_info(pf, ice_rel_vf_id(&pf->hw, abs_vf_id),
				    vf_port_info);
}
#endif /* VF_RDMA_SUPPORT */

#ifdef MULTI_PEER_SUPPORT
/**
 * ice_find_cdev_info_by_id - find cdev_info instance by its id
 * @pf: pointer to private board struct
 * @cdev_info_id: peer driver ID
 */
struct iidc_core_dev_info
*ice_find_cdev_info_by_id(struct ice_pf *pf, int cdev_info_id)
{
	struct iidc_core_dev_info *cdev_info = NULL;
	unsigned int i;

	if (!pf->cdev_infos)
		return NULL;

	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
		cdev_info = pf->cdev_infos[i];
		if (cdev_info &&
		    cdev_info->cdev_info_id == cdev_info_id)
			break;
		cdev_info = NULL;
	}
	return cdev_info;
}
#endif /* MULTI_PEER_SUPPORT */

#ifdef SWITCH_MODE
/**
 * ice_send_vf_reset_to_auxs - inform aux drivers about VF getting reset
 * @pf: pointer to pf struct
 * @vf_id: VF's id in PF space
 */
void ice_send_vf_reset_to_auxs(struct ice_pf *pf, u16 vf_id)
{
	u32 aux_vf_id = (u32)vf_id;
#ifndef OLD_IDC_SUPPORT
	struct iidc_event *event;

	event = (struct iidc_event *)kzalloc(sizeof(*event), GFP_KERNEL);
#else /* OLD_IDC_SUPPORT */
	struct ice_event *event;

	event = (struct ice_event *)kzalloc(sizeof(*event), GFP_KERNEL);
#endif /* OLD_IDC_SUPPORT */
	if (!event)
		return;
	set_bit(IIDC_EVENT_VF_RESET, event->type);
	event->info.vf_id = aux_vf_id;
#ifdef MULTI_PEER_SUPPORT
	ice_send_event_to_auxs(pf, event);
#endif /* MULTI_PEER_SUPPORT */
	kfree(event);
}

#ifndef BMSM_MODE
static void
ice_setup_ae_data_q_info(struct ice_pf *pf,
			 struct iidc_core_dev_info *cdev_info)
{
	u16 num_rx = 0, num_tx = 0;
	unsigned long idx = 0;
	u16 off_tx, off_rx;

	mutex_lock(&pf->avail_q_mutex);

	/* find out number of Tx/Rx queues used */
	for_each_set_bit(idx, pf->avail_txqs, pf->max_pf_txqs)
		num_tx++;
	for_each_set_bit(idx, pf->avail_rxqs, pf->max_pf_rxqs)
		num_rx++;

	/* find out number of Tx/Rx queues available */
	num_tx = pf->max_pf_txqs - num_tx;
	num_rx = pf->max_pf_rxqs - num_rx;

	if (lan_vf_qps_rsvd > num_tx) {
		dev_err(ice_pf_to_dev(pf),
			"TxQs deficiency (lan_vf_qps_rsvd=%u, num_tx=%u)\n",
			lan_vf_qps_rsvd, num_tx);
		goto out_unlock;
	}

	if (lan_vf_qps_rsvd > num_rx) {
		dev_err(ice_pf_to_dev(pf),
			"RxQs deficiency (lan_vf_qps_rsvd=%u, num_rx=%u)\n",
			lan_vf_qps_rsvd, num_rx);
		goto out_unlock;
	}

	num_tx -= lan_vf_qps_rsvd;
	num_rx -= lan_vf_qps_rsvd;

	/* look for contiguous block of queues for Tx */
	off_tx = bitmap_find_next_zero_area(pf->avail_txqs, pf->max_pf_txqs, 0,
					    num_tx, 0);

	/* look for contiguous block of queues for Rx */
	off_rx = bitmap_find_next_zero_area(pf->avail_rxqs, pf->max_pf_rxqs, 0,
					    num_rx, 0);

	/* if Tx/Rx queues available, acquire them */
	if (off_tx < pf->max_pf_txqs && off_rx < pf->max_pf_rxqs) {
		bitmap_set(pf->avail_txqs, off_tx, num_tx);
		bitmap_set(pf->avail_rxqs, off_rx, num_rx);

		cdev_info->start_txq = off_tx;
		cdev_info->start_rxq = off_rx;
		cdev_info->num_txq = num_tx;
		cdev_info->num_rxq = num_rx;
	} else {
		dev_err(ice_pf_to_dev(pf), "failed to get data Tx/Rx queues: Tx %u, Rx %u\n",
			off_tx, off_rx);
	}

out_unlock:
	mutex_unlock(&pf->avail_q_mutex);
}

#endif /* !BMSM_MODE */
#ifdef ADK_SUPPORT
/**
 * ice_aux_req_free_irq - req/free IRQs for a lower netdevs VSI
 * @vsi: VSI to req/fre IRQs for
 * @ena: boolean whether to req or free
 */
static int ice_aux_req_free_irq(struct ice_vsi *vsi, bool ena)
{
	if (ena) {
		char int_name[ICE_INT_NAME_STR_LEN];
		int ret;

		snprintf(int_name, sizeof(int_name), "ice_sw-port%d",
			 vsi->port_info->lport);

		/* Get vectors from OS for VSI */
		ret = ice_vsi_req_irq_msix(vsi, int_name);
		if (ret)
			return ret;

		/* Enable interrupts in the HW */
		ice_vsi_ena_irq(vsi);
	} else {
		/* Mask off int cause and turn off ints */
		ice_vsi_dis_irq(vsi);

		/* Free OS association with IRQs */
		ice_vsi_free_irq(vsi);
	}

	return 0;
}

/**
 * ice_aux_cfg_irq_per_q - enable/disable IRQ for a single queue in VSI
 * @vsi: VSI to enable/disable
 * @q_id: index of the queue in VSI
 * @ena: boolean whether to enable or disable IRQ
 */
static int
ice_aux_cfg_irq_per_q(struct ice_vsi *vsi, u16 q_id, bool ena)
{
	struct ice_ring *ring = vsi->tx_rings[q_id];
	struct ice_q_vector *q_vector;
	u16 v_idx;

	if (!ring)
		return -EINVAL;

	v_idx = ring->q_vector->v_idx;
	q_vector = vsi->q_vectors[v_idx];

	if (ena) {
		if (!test_and_set_bit(v_idx, vsi->sw_irq_ena_map)) {
			char int_name[ICE_INT_NAME_STR_LEN];
			struct ice_hw *hw = &vsi->back->hw;
			int err;

			snprintf(int_name, sizeof(int_name),
				 "ice_sw-port%d", vsi->port_info->lport);

			clear_bit(ICE_VSI_DOWN, vsi->state);

			err = ice_vsi_req_single_irq_msix(vsi, int_name, v_idx);
			if (err)
				return err;

			ice_irq_dynamic_ena(hw, vsi, q_vector);

			ice_flush(hw);

			ice_vsi_cfg_single_msix(vsi, v_idx);

			if (vsi->netdev)
				ice_napi_enable(q_vector);
		}
	} else {
		if (test_bit(v_idx, vsi->sw_irq_ena_map)) {
			u16 i;

			/* If the interrupt vector is being shared by any other
			 * enabled queues, do not disable it.
			 */
			for_each_set_bit(i, vsi->sw_q_ena_map, ICE_SW_VSI_Q_NUM)
				if (vsi->tx_rings[i]->q_vector == q_vector)
					return 0;

			clear_bit(v_idx, vsi->sw_irq_ena_map);

			/* Mask off int cause and turn off the int */
			ice_vsi_dis_single_irq(vsi, v_idx);

			/* Free OS association with IRQ */
			ice_vsi_free_single_irq(vsi, v_idx);

			if (vsi->netdev) {
				if (q_vector->rx.ring || q_vector->tx.ring)
					napi_disable(&q_vector->napi);

				cancel_work_sync(&q_vector->tx.dim.work);
				cancel_work_sync(&q_vector->rx.dim.work);
			}

			if (bitmap_empty(vsi->sw_irq_ena_map, ICE_SW_VSI_Q_NUM))
				set_bit(ICE_VSI_DOWN, vsi->state);
		}
	}

	return 0;
}

/**
 * ice_aux_cfg_irq - enable/disable IRQ for a VSI based on peer context
 * @pp: port_info context
 * @vsi: VSI to enable/disable
 * @ena: boolean whether to enable or disable IRQ
 */
static int
ice_aux_cfg_irq(struct iidc_port_info *pp, struct ice_vsi *vsi, bool ena)
{
	if (ena) {
		/* only enable IRQ if both Tx and Rx enabled */
		if (!test_bit(IIDC_TX, pp->ena) || !test_bit(IIDC_RX, pp->ena))
			return 0;

		if (!test_and_set_bit(IIDC_IRQ, pp->ena)) {
			int ret;

			clear_bit(ICE_VSI_DOWN, vsi->state);

			ret = ice_aux_req_free_irq(vsi, ena);
			if (ret)
				return ret;

			ice_vsi_cfg_msix(vsi);
			ice_napi_enable_all(vsi);
		}
	} else {
		/* disable irq if either Tx or Rx disabled */
		if (test_bit(IIDC_TX, pp->ena) && test_bit(IIDC_RX, pp->ena))
			return 0;

		if (test_and_clear_bit(IIDC_IRQ, pp->ena)) {
			ice_aux_req_free_irq(vsi, ena);
			ice_napi_disable_all(vsi);
			set_bit(ICE_VSI_DOWN, vsi->state);
		}
	}

	return 0;
}

/**
 * ice_aux_ena_single_txq - enable Tx for a single queue on a given port
 * @vsi: VSI struct for port to enable Tx
 * @q_id: index of the queue in VSI
 * @ena_irq: boolean whether to enable IRQ or not
 */
static int ice_aux_ena_single_txq(struct ice_vsi *vsi, u16 q_id, bool ena_irq)
{
	struct ice_ring *ring = vsi->tx_rings[q_id];
	int err;

	if (!ring)
		return -EINVAL;

	if (vsi->netdev)
		ring->netdev = vsi->netdev;

	err = ice_setup_tx_ring(ring);
	if (err)
		goto err_txq_setup;

	err = ice_vsi_cfg_single_txq(vsi, vsi->tx_rings, q_id);
	if (err)
		goto err_txq_setup;

	if (ena_irq) {
		err = ice_aux_cfg_irq_per_q(vsi, q_id, true);
		if (err)
			goto err_txq_setup;
	}

	return 0;

err_txq_setup:
	if (ring && ring->desc)
		ice_free_tx_ring(ring);
	return err;
}

/**
 * ice_aux_ena_tx - enable Tx on a given port
 * @vsi: VSI struct for port to enable Tx
 * @pp: port_info struct for port
 */
static int ice_aux_ena_tx(struct ice_vsi *vsi, struct iidc_port_info *pp)
{
	int err = 0;

	if (test_and_set_bit(IIDC_TX, pp->ena))
		return err;

	err = ice_vsi_setup_tx_rings(vsi);
	if (err)
		goto err_tx_setup;

	err = ice_vsi_cfg_lan_txqs(vsi);
	if (err)
		goto err_tx_setup;

	err = ice_aux_cfg_irq(pp, vsi, true);
	if (err)
		goto err_tx_setup;

	return err;

err_tx_setup:
	ice_vsi_free_tx_rings(vsi);
	return err;
}

/**
 * ice_aux_ena_single_rxq - enable Rx for a single queue on a given port
 * @vsi: VSI struct for port to enable Rx
 * @q_id: index of the queue in VSI
 * @ena_irq: boolean whether to enable IRQ or not
 */
static int ice_aux_ena_single_rxq(struct ice_vsi *vsi, u16 q_id, bool ena_irq)
{
	struct ice_ring *ring = vsi->rx_rings[q_id];
	int err;

	if (!ring)
		return -EINVAL;

	if (vsi->netdev)
		ring->netdev = vsi->netdev;

	err = ice_setup_rx_ring(ring);
	if (err)
		goto err_rxq_setup;

	ice_vsi_cfg_frame_size(vsi);

	err = ice_vsi_cfg_single_rxq(vsi, q_id);
	if (err)
		goto err_rxq_setup;

	if (ena_irq) {
		err = ice_aux_cfg_irq_per_q(vsi, q_id, true);
		if (err)
			goto err_rxq_setup;
	}

	ice_vsi_ctrl_one_rx_ring(vsi, true, q_id, false);

	ice_flush(&vsi->back->hw);

	err = ice_vsi_wait_one_rx_ring(vsi, true, q_id);
	if (err)
		goto err_rxq_setup;

	return 0;

err_rxq_setup:
	if (ring && ring->desc)
		ice_free_rx_ring(ring);
	return err;
}

/**
 * ice_aux_ena_rx - enable Rx on a given port
 * @vsi: VSI struct for port to enable Rx
 * @pp: port_info struct for port
 */
static int ice_aux_ena_rx(struct ice_vsi *vsi, struct iidc_port_info *pp)
{
	int err = 0;

	if (test_and_set_bit(IIDC_RX, pp->ena))
		return err;

	err = ice_vsi_setup_rx_rings(vsi);
	if (err)
		goto err_rx_setup;

	err = ice_vsi_cfg_rxqs(vsi);
	if (err)
		goto err_rx_setup;

	err = ice_aux_cfg_irq(pp, vsi, true);
	if (err)
		goto err_rx_setup;

	err = ice_vsi_start_all_rx_rings(vsi);
	if (err)
		goto err_rx_setup;

	return err;

err_rx_setup:
	ice_vsi_free_rx_rings(vsi);
	return err;
}

/**
 * ice_aux_dis_single_txq - disable a single Tx queue on a given port
 * @vsi: VSI struct for the port to disable Tx
 * @q_id: index of the queue in VSI
 * @dis_irq: boolean whether to disable IRQ or not
 */
static int ice_aux_dis_single_txq(struct ice_vsi *vsi, u16 q_id, bool dis_irq)
{
	struct ice_ring *ring = vsi->tx_rings[q_id];
	struct ice_txq_meta txq_meta = { };
	int err;

	if (!ring)
		return -EINVAL;

	ice_fill_txq_meta(vsi, ring, &txq_meta);
	err = ice_vsi_stop_tx_ring(vsi, ICE_NO_RESET, 0, ring, &txq_meta);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back),
			"Failed to disable Tx ring %u\n", q_id);

	if (dis_irq)
		err = ice_aux_cfg_irq_per_q(vsi, q_id, false);

	ice_clean_tx_ring(ring);

	if (ring->desc)
		ice_free_tx_ring(ring);

	return err;
}

/**
 * ice_aux_dis_tx - disable Tx on a given port
 * @vsi: VSI struct for the port to disable Tx
 * @pp: port_info struct for port
 */
static int ice_aux_dis_tx(struct ice_vsi *vsi, struct iidc_port_info *pp)
{
	int err = 0, i;

	if (!test_and_clear_bit(IIDC_TX, pp->ena))
		return err;

	err = ice_vsi_stop_lan_tx_rings(vsi, ICE_NO_RESET, 0);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back), "Failed to disable Tx rings\n");

	err = ice_aux_cfg_irq(pp, vsi, false);

#ifdef TXPP_SUPPORT
	ice_for_each_txq(vsi, i) {
		if (vsi->tx_rings[i]->flags & ICE_TX_FLAGS_TXTIME)
			ice_clean_tx_ring(vsi->tx_rings[i],
					  vsi->tstamp_rings[i]);
		else
			ice_clean_tx_ring(vsi->tx_rings[i], NULL);
	}
#else
	ice_for_each_txq(vsi, i)
		ice_clean_tx_ring(vsi->tx_rings[i]);
#endif /* TXPP_SUPPORT */

	ice_vsi_free_tx_rings(vsi);

	return err;
}

/**
 * ice_aux_dis_single_rxq - disable a single Rx queue on a given port
 * @vsi: VSI struct for the port to disable Rx
 * @q_id: index of the queue in VSI
 * @dis_irq: boolean whether to disable IRQ or not
 */
static int ice_aux_dis_single_rxq(struct ice_vsi *vsi, u16 q_id, bool dis_irq)
{
	struct ice_ring *ring = vsi->rx_rings[q_id];
	int err;

	if (!ring)
		return -EINVAL;

	ice_vsi_ctrl_one_rx_ring(vsi, false, q_id, false);

	ice_flush(&vsi->back->hw);

	err = ice_vsi_wait_one_rx_ring(vsi, false, q_id);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back),
			"Failed to disable Rx ring %u\n", q_id);

	if (dis_irq)
		err = ice_aux_cfg_irq_per_q(vsi, q_id, false);

	ice_clean_rx_ring(ring);

	if (ring->desc)
		ice_free_rx_ring(ring);

	return err;
}

/**
 * ice_aux_dis_rx - disable Rx on a given port
 * @vsi: VSI struct for the port to disable Rx
 * @pp: port_info struct for port
 */
static int ice_aux_dis_rx(struct ice_vsi *vsi, struct iidc_port_info *pp)
{
	int err = 0, i;

	if (!test_and_clear_bit(IIDC_RX, pp->ena))
		return err;

	err = ice_vsi_stop_all_rx_rings(vsi);
	if (err)
		dev_dbg(ice_pf_to_dev(vsi->back), "Failed to disable Rx rings\n");

	err = ice_aux_cfg_irq(pp, vsi, false);

	ice_for_each_rxq(vsi, i)
		ice_clean_rx_ring(vsi->rx_rings[i]);

	ice_vsi_free_rx_rings(vsi);

	return err;
}

/**
 * ice_adk_is_vsi_ready - query if VSI in nominal state
 * @cdev_info: pointer to ADK's cdev_info struct
 * @port_id: number of the port to check VSI state
 */
static bool
ice_adk_is_vsi_ready(struct iidc_core_dev_info *cdev_info, u8 port_id)
{
	struct ice_port_info *pi;
	struct ice_vsi *vsi;
	struct ice_pf *pf;

	if (!cdev_info)
		return false;

	pf = pci_get_drvdata(cdev_info->pdev);
	pi = &pf->hw.port_info[port_id];
	vsi = ice_find_vsi_from_pi(pf, pi);

	if (!vsi)
		return false;

	if (test_bit(ICE_VSI_DOWN, vsi->state) ||
	    test_bit(ICE_VSI_NEEDS_RESTART, vsi->state))
		return false;

	return true;
}

/**
 * ice_adk_vsi_q_cfg - iidc_ops callback for ADK peer to enable/disable queues
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: pointer to CPK's lower net_device
 * @q_type: Tx, Rx, or Tx+Rx
 * @enable: is this call to enable or disable queues
 *
 * Returns 0 on success and negative on any error.
 */
static int
ice_adk_vsi_q_cfg(struct iidc_core_dev_info *cdev_info,
		  struct net_device *lwr_netdev, u8 q_type, bool enable)
{
	struct iidc_port_info *pp;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int ret = 0;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (vsi->port_info->is_internal_port)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	pp = &cdev_info->port_info[vsi->port_info->lport];

	if (enable) {
		if (!test_bit(ICE_VSI_DOWN, vsi->state))
			return 0;

		switch (q_type) {
		case IIDC_TX:
			return ice_aux_ena_tx(vsi, pp);
		case IIDC_RX:
			return ice_aux_ena_rx(vsi, pp);
		case IIDC_TXRX:
			ret = ice_aux_ena_tx(vsi, pp);
			if (ret)
				return ret;
			return ice_aux_ena_rx(vsi, pp);
		default:
			return -EINVAL;
		}
	} else {
		if (test_bit(ICE_VSI_DOWN, vsi->state))
			return 0;

		switch (q_type) {
		case IIDC_TX:
			return ice_aux_dis_tx(vsi, pp);
		case IIDC_RX:
			return ice_aux_dis_rx(vsi, pp);
		case IIDC_TXRX:
			ret = ice_aux_dis_tx(vsi, pp);
			if (ret)
				return ret;
			return ice_aux_dis_rx(vsi, pp);
		default:
			return -EINVAL;
		}
	}
}

#ifdef ADK_SUPPORT
/**
 * ice_adk_vsi_get_q_sel_mode - get the queue selection mode of PF VSI
 * @vsi: pointer to the PF VSI
 * @mode: queue selection mode to be obtained
 *
 * Helper function that does not do any VSI related checks and just gets
 * the value corresponding to the currently chosen queue selection mode.
 * If there is no mode set or there is more than 1 mode set, then mode
 * returned to the function caller is set to NUM_IIDC_VSI_Q_SEL_MODE.
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_get_q_sel_mode(struct ice_vsi *vsi, enum iidc_vsi_q_sel_mode *mode)
{
	if (vsi->is_rss_lut_ena == vsi->is_vlan_pcp_q_sel_ena)
		*mode = NUM_IIDC_VSI_Q_SEL_MODE;
	else if (vsi->is_rss_lut_ena)
		*mode = IIDC_VSI_Q_SEL_MODE_RSS;
	else if (vsi->is_vlan_pcp_q_sel_ena)
		*mode = IIDC_VSI_Q_SEL_MODE_PRIO;
	else
		*mode = NUM_IIDC_VSI_Q_SEL_MODE;

	return 0;
}

/**
 * ice_adk_vsi_get_q_cfg - get the queue configuration of PF VSI.
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_cfg: PF VSI queue configuration
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_get_q_cfg(struct iidc_core_dev_info *cdev_info,
		      struct net_device *lwr_netdev,
		      struct iidc_vsi_q_cfg *q_cfg)
{
	enum iidc_vsi_q_sel_mode mode;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int err;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi || !q_cfg)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	err = ice_adk_vsi_get_q_sel_mode(vsi, &mode);
	if (err)
		return err;

	q_cfg->mode = mode;

	/* vsi->alloc_rxq and vsi->alloc_txq are the same at this point */
	q_cfg->q_num = vsi->alloc_rxq;

#ifndef EXTERNAL_RELEASE
	/* IIDC_ADK_PRIO_NUM should always be equal to ICE_VLAN_PCP_NUM */
#endif /* !EXTERNAL_RELEASE */
	memcpy(q_cfg->prio_map, vsi->vlan_pcp_q_sel_map, IIDC_ADK_PRIO_NUM);

	return 0;
}

/**
 * ice_adk_vsi_sw_is_q_enabled - check if a Switch VSI queue is enabled
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_id: Switch VSI queue index
 * @enabled: pointer to a bool return value
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_sw_is_q_enabled(struct iidc_core_dev_info *cdev_info,
			    struct net_device *lwr_netdev, u8 q_id,
			    bool *enabled)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi || q_id >= ICE_SW_VSI_Q_NUM || !enabled)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

	*enabled = test_bit(q_id, vsi->sw_q_ena_map);

	return 0;
}

/**
 * ice_adk_vsi_sw_q_ena_dis - enable/disable a Switch VSI queue
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_id: Switch VSI queue index
 * @enable: true for enable, false for disable
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_sw_q_ena_dis(struct iidc_core_dev_info *cdev_info,
			 struct net_device *lwr_netdev, u8 q_id,
			 bool enable)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int err = 0;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi || q_id >= ICE_SW_VSI_Q_NUM)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

	if (enable) {
		if (test_bit(q_id, vsi->sw_q_ena_map))
			return 0;

		/* Enable Tx queue and do not enable IRQ yet */
		err = ice_aux_ena_single_txq(vsi, q_id, false);
		if (err)
			return err;

		/* Enable Rx queue and enable IRQ right after */
		err = ice_aux_ena_single_rxq(vsi, q_id, true);
		if (err) {
			struct ice_ring *ring = vsi->tx_rings[q_id];

			if (ring && ring->desc)
				ice_free_tx_ring(ring);
			return err;
		}

		set_bit(q_id, vsi->sw_q_ena_map);
	} else {
		if (!test_and_clear_bit(q_id, vsi->sw_q_ena_map))
			return 0;

		/* Disable Tx queue and disable IRQ */
		ice_aux_dis_single_txq(vsi, q_id, true);

		/* Disable Rx queue and do not disable IRQ (already disabled) */
		ice_aux_dis_single_rxq(vsi, q_id, false);

		if (vsi->sw_q_cfg[q_id].mask)
			err = ice_fltr_remove_mac_to_q(vsi,
						       vsi->sw_q_cfg[q_id].mac,
						       q_id);
	}

	return err;
}

/**
 * ice_adk_vsi_sw_set_q_cfg - set configuration of a Switch VSI queue
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_id: Switch VSI queue index
 * @q_cfg: pointer to a configuration structure
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_sw_set_q_cfg(struct iidc_core_dev_info *cdev_info,
			 struct net_device *lwr_netdev, u8 q_id,
			 struct iidc_vsi_sw_q_cfg *q_cfg)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int status;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi || !q_cfg || q_id >= ICE_SW_VSI_Q_NUM)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

#ifndef EXTERNAL_RELEASE
	/* TODO: only MAC to queue forwarding supported for now.
	 * MAC/VLAN filters to be added.
	 */
#endif /* EXTERNAL_RELEASE */
	if (!q_cfg->mask)
		return -EINVAL;

	status = ice_fltr_add_mac_to_q(vsi, q_cfg->mac, q_id);
	if (status) {
		dev_err(ice_pf_to_dev(vsi->back), "Failed to add filter, error %d\n",
			status);
		return status;
	}

	vsi->sw_q_cfg[q_id] = *q_cfg;

	return 0;
}

/**
 * ice_adk_vsi_sw_get_q_cfg - get configuration of a Switch VSI queue
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_id: Switch VSI queue index
 * @q_cfg: pointer to a return configuration structure
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_sw_get_q_cfg(struct iidc_core_dev_info *cdev_info,
			 struct net_device *lwr_netdev, u8 q_id,
			 struct iidc_vsi_sw_q_cfg *q_cfg)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi || !q_cfg || q_id >= ICE_SW_VSI_Q_NUM)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

	*q_cfg = vsi->sw_q_cfg[q_id];

	return 0;
}

/**
 * ice_adk_vsi_set_q_num - set the queue configuration of PF VSI
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @q_num: the number of Rx/Tx queue pairs
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_set_q_num(struct iidc_core_dev_info *cdev_info,
		      struct net_device *lwr_netdev, u8 q_num)
{
	u8 prio_map[IIDC_ADK_PRIO_NUM];
	struct ice_netdev_priv *np;
	struct iidc_port_info *pp;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	bool prev_rx;
	bool prev_tx;
	int err = 0;
	u8 i;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;

	if (!vsi)
		return -EINVAL;

	pf = vsi->back;
	if (ice_is_safe_mode(pf))
		return -EOPNOTSUPP;

	if (ice_is_reset_in_progress(pf->state))
		return -EBUSY;

	if (q_num == vsi->alloc_rxq /* <- also equal to alloc_txq */)
		return 0;

#ifndef EXTERNAL_RELEASE
	/* IIDC_ADK_PRIO_NUM should always be equal to ICE_VLAN_PCP_NUM */
#endif /* !EXTERNAL_RELEASE */
	/* Obtain the old prio map before the queue reconfiguration */
	memcpy(prio_map, vsi->vlan_pcp_q_sel_map, IIDC_ADK_PRIO_NUM);

	pp = &cdev_info->port_info[vsi->port_info->lport];
	prev_rx = test_bit(IIDC_RX, pp->ena);
	prev_tx = test_bit(IIDC_TX, pp->ena);

#ifndef EXTERNAL_RELEASE
	/* equivalent of ice_vsi_close in stacked mode, for unstacked
	 * mode it's called in ice_vsi_recfg_qs.
	 */
#endif
	if (prev_rx)
		err = ice_aux_dis_rx(vsi, pp);
	if (err)
		return err;

	if (prev_tx)
		err = ice_aux_dis_tx(vsi, pp);
	if (err)
		return err;

	err = ice_vsi_recfg_qs(vsi, q_num, q_num);
	if (err)
		return err;

#ifndef EXTERNAL_RELEASE
	/* equivalent of ice_vsi_open in stacked mode, for unstacked
	 * mode it's called in ice_vsi_recfg_qs.
	 */
#endif
	if (prev_rx)
		err = ice_aux_ena_rx(vsi, pp);
	if (err)
		return err;

	if (prev_tx)
		err = ice_aux_ena_tx(vsi, pp);
	if (err)
		return err;

	/* set new RSS LUT parameters */
	if (!test_bit(ICE_FLAG_RSS_ENA, pf->flags))
		vsi->rss_size = 1;
	else
		vsi->rss_size = ice_get_valid_rss_size(&pf->hw, q_num);

	/* Clear the previous vsi->rss_lut_user because
	 * it is assumed to be invalid at this point.
	 */
	if (vsi->rss_lut_user) {
		devm_kfree(ice_pf_to_dev(pf), vsi->rss_lut_user);
		vsi->rss_lut_user = NULL;
	}

	/* Reconfigure the RSS (only if it is enabled) */
	if (vsi->is_rss_lut_ena)
		ice_vsi_manage_rss_lut(vsi, true);

#ifndef EXTERNAL_RELEASE
	/* IIDC_ADK_PRIO_NUM should always be equal to ICE_VLAN_PCP_NUM */
#endif /* !EXTERNAL_RELEASE */

	/* Set each no longer valid queue mapping to zero */
	for (i = 0; i < IIDC_ADK_PRIO_NUM; i++)
		if (!(prio_map[i] < vsi->alloc_rxq))
			prio_map[i] = 0;

	/* Reconfigure the PRIO map */
	return ice_vsi_map_vlan_pcp_q_sel(vsi, prio_map);
}

/**
 * ice_adk_vsi_set_q_prio_map - set the queue priority map for prio mode
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @prio_map: priority map of size IIDC_ADK_PRIO_NUM
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_set_q_prio_map(struct iidc_core_dev_info *cdev_info,
			   struct net_device *lwr_netdev, u8 *prio_map)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	u8 i;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	/* Don't set any netdev advanced features with device in Safe Mode */
	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

#ifndef EXTERNAL_RELEASE
	/* IIDC_ADK_PRIO_NUM should always be equal to ICE_VLAN_PCP_NUM */
#endif /* !EXTERNAL_RELEASE */

	/* Check if each mapped queue is valid */
	for (i = 0; i < IIDC_ADK_PRIO_NUM; i++)
		if (!(prio_map[i] < vsi->alloc_rxq))
			return -EINVAL;

	return ice_vsi_map_vlan_pcp_q_sel(vsi, prio_map);
}

/**
 * ice_adk_vsi_set_q_sel_mode - set the queue selection mode
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: network interface device structure
 * @mode: queue selection mode (RSS or priority-based)
 *
 * Returns 0 for success and negative values for errors.
 */
static int
ice_adk_vsi_set_q_sel_mode(struct iidc_core_dev_info *cdev_info,
			   struct net_device *lwr_netdev,
			   enum iidc_vsi_q_sel_mode mode)
{
	enum iidc_vsi_q_sel_mode _mode;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	int err;

	if (!lwr_netdev || !cdev_info)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	/* Don't set any netdev advanced features with device in Safe Mode */
	if (ice_is_safe_mode(vsi->back))
		return -EOPNOTSUPP;

	err = ice_adk_vsi_get_q_sel_mode(vsi, &_mode);
	if (err)
		return err;

	if (_mode != NUM_IIDC_VSI_Q_SEL_MODE && _mode == mode)
		return 0;

	switch (mode) {
	case IIDC_VSI_Q_SEL_MODE_RSS:
		err = ice_vsi_manage_vlan_pcp_q_sel(vsi, false);
		if (err)
			return err;
		ice_vsi_manage_rss_lut(vsi, true);
		break;
	case IIDC_VSI_Q_SEL_MODE_PRIO:
		ice_vsi_manage_rss_lut(vsi, false);
		err = ice_vsi_manage_vlan_pcp_q_sel(vsi, true);
		if (err)
			return err;
		break;
	default:
		return -EINVAL;
	}

	return 0;
}
#endif /* ADK_SUPPORT */

/**
 * ice_adk_strt_xmit_internal - transmit a SKB received from ADK object
 * @cdev_info: pointer to ADK's cdev_info struct
 * @skb: sk_buff to transmit
 * @txmd: Tx metadata about sk_buff
 * @netdev: lower net_device
 *
 * The ADK driver populates the SKB's dev field with a pointer
 * to the upper (ADK specific) netdev. The additional netdev
 * passed in (lower netdev) contains the ICE specific tx_ring and VSI.
 *
 * Returns 0 on success and negative value on error.
 */
static int
ice_adk_strt_xmit_internal(struct iidc_core_dev_info *cdev_info,
			   struct sk_buff *skb,
			   struct iidc_nd_tx_md __maybe_unused *txmd,
			   struct net_device *netdev)
{
	struct ice_netdev_priv *np;
	struct ice_ring *tx_ring;
	struct ice_vsi *vsi;
	u8 lport;

	if (!netdev)
		return -EINVAL;

	np = netdev_priv(netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (!cdev_info)
		return -EINVAL;

	lport = vsi->port_info->lport;

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	if (test_bit(ICE_VSI_DOWN, vsi->state))
		return -ENODEV;

	if (vsi->port_info->is_internal_port) {
		if (!test_bit(skb->queue_mapping, vsi->sw_q_ena_map))
			return -EIO;
	} else if (!test_bit(IIDC_TX,
			     vsi->adk_cdev_info->port_info[lport].ena))
		return -EIO;

	if (skb->queue_mapping >= vsi->alloc_rxq)
		return -EINVAL;
#ifndef NO_PTP_SUPPORT
	if (txmd->ts_index >= INDEX_PER_QUAD)
		return -EINVAL;
#endif
	tx_ring = vsi->tx_rings[skb->queue_mapping];
#ifndef NO_PTP_SUPPORT
	tx_ring->ptp_ts_ena = txmd->ts_ena;
	tx_ring->ptp_ts_idx = txmd->ts_index;
#endif /* !NO_PTP_SUPPORT */
#ifdef IPSEC_OVRLD_SUPPORT
	/* Enable IPsec descriptor overload when Inline IPsec is disabled */
	if (!vsi->back->ipsec_enabled) {
		tx_ring->ipsec_offload = txmd->ipsec_offload;
		tx_ring->ipsec_flex_param_2 = txmd->flex_param_2;
	} else {
		tx_ring->ipsec_offload = false;
	}
#endif /* IPSEC_OVRLD_SUPPORT */
	return ice_start_xmit(skb, netdev);
}

/**
 * ice_adk_get_port_id - provide port ID
 * @netdev: netdev to evaluate
 */
static int ice_adk_get_port_id(struct net_device *netdev)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	if (!netdev)
		return -EINVAL;

	np = netdev_priv(netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (vsi->type != ICE_VSI_PF)
		return -EINVAL;

	if (!vsi->port_info)
		return -EINVAL;

	return vsi->port_info->lport;
}

/**
 * ice_adk_add_mac_port - add a MAC filter for a port
 * @cdev_info: pointer to ADK's cdev_info struct
 * @lwr_netdev: pointer to lower net_device
 * @mac_addr: MAC address to add a filter for
 *
 * Returns 0 on success and negative on any error
 */
static int
ice_adk_add_mac_port(struct iidc_core_dev_info *cdev_info,
		     struct net_device *lwr_netdev, u8 *mac_addr)
{
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	struct device *dev;
	struct ice_pf *pf;
	int status;

	if (!lwr_netdev || !mac_addr)
		return -EINVAL;

	np = netdev_priv(lwr_netdev);
	vsi = np->vsi;
	if (!vsi)
		return -EINVAL;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	dev = ice_pf_to_dev(pf);

	if (ice_is_reset_in_progress(vsi->back->state))
		return -EBUSY;

	/* Add a unicast MAC filter so the VSI can get its packets */
	status = ice_fltr_add_mac(vsi, mac_addr, ICE_FWD_TO_VSI);
	if (status)
		dev_err(dev, "failed to add MAC(%pM) filter for vsi_num %u\n",
			mac_addr, vsi->vsi_num);

	return status;
}

#endif /* ADK_SUPPORT */
#ifndef NO_SBQ_SUPPORT
/**
 * ice_cdev_info_sbq_rw_reg - Send message to PHY
 * @cdev_info: The cdev_info
 * @msg: message read or write
 *
 * Send the message received from aux driver to the destination object.
 * Could be PHY or CGU
 */
static int
ice_cdev_info_sbq_rw_reg(struct iidc_core_dev_info *cdev_info, void *msg)
{
	struct ice_hw *hw;
	struct ice_pf *pf;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	hw = &pf->hw;

	return ice_sbq_rw_reg(hw, (struct ice_sbq_msg_input *)msg);
}

#endif /* !NO_SBQ_SUPPORT */
#ifndef NO_PTP_SUPPORT
/**
 * ice_cdev_info_update_incval - Update INCVAL according to new freq and mode
 * @cdev_info: The cdev_info object
 * @time_ref_freq: TIME_REF frequency to use
 * @src_tmr_mode: Source timer mode (nanoseconds or locked)
 *
 * Update INCVAL to match the specified TIME_REF frequency and mode.
 */
static int
ice_cdev_info_update_incval(struct iidc_core_dev_info *cdev_info,
			    enum iidc_time_ref_freq time_ref_freq,
			    enum iidc_src_tmr_mode src_tmr_mode)
{
	struct ice_pf *pf;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	return ice_ptp_update_incval(pf, (enum ice_time_ref_freq)time_ref_freq,
				     (enum ice_src_tmr_mode)src_tmr_mode);
}

/**
 * ice_cdev_info_get_incval - Get current configured INCVAL parameters
 * @cdev_info: The cdev_info object
 * @time_ref_freq: TIME_REF frequency
 * @src_tmr_mode: Source timer mode (nanoseconds or locked)
 *
 * Update INCVAL to match the specified TIME_REF frequency and mode.
 */
static int
ice_cdev_info_get_incval(struct iidc_core_dev_info *cdev_info,
			 enum iidc_time_ref_freq *time_ref_freq,
			 enum iidc_src_tmr_mode *src_tmr_mode)
{
	struct ice_pf *pf;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	return ice_ptp_get_incval(pf, (enum ice_time_ref_freq *)time_ref_freq,
				  (enum ice_src_tmr_mode *)src_tmr_mode);
}

/**
 * ice_cdev_info_match_and_adj - Perform PTP match and adjust operation
 * @cdev_info: The cdev_info object
 * @at_time: The time at which to perform the adjustment
 * @offset: The adjustment to apply
 *
 * Adjust the source timer by the specified offset at the specified time.
 */
static int
ice_cdev_info_match_and_adj(struct iidc_core_dev_info *cdev_info,
			    struct ptp_clock_time *at_time,
			    struct ptp_clock_time *offset)
{
	struct ice_pf *pf;
	u64 at_time_ns;
	s64 offset_ns;

	if (!cdev_info)
		return -EINVAL;
	if (!at_time || !offset)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	at_time_ns = ((u64)at_time->sec * NSEC_PER_SEC) + at_time->nsec;
	offset_ns = ((s64)offset->sec * NSEC_PER_SEC) + offset->nsec;

	return ice_ptp_match_and_adj(pf, at_time_ns, offset_ns);
}

/**
 * ice_cdev_info_cfg_1588_clk_out_to_cgu - Configure 1588 freq out pin to CGU
 * @cdev_info: The cdev_info struct for this aux driver
 * @ena: True to enable; false to disable
 * @period_ns: Period in nanoseconds
 *
 * Configure the 1588_freq_out signal to the CGU.
 */
static int
ice_cdev_info_cfg_1588_clk_out_to_cgu(struct iidc_core_dev_info *cdev_info,
				      bool ena, u64 period_ns)
{
	struct ice_perout_channel config;
	struct ice_pf *pf;

	if (!cdev_info)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

#define CLK_OUT_1588_CHANNEL 2
#define CLK_OUT_1588_GPIO_PIN 6 /* CLK_SYNCE */

	/* wait a bit before starting the output */
	config.start_time = ice_ptp_read_src_clk_reg(pf, NULL) + START_OFFS_NS;
	config.gpio_pin = CLK_OUT_1588_GPIO_PIN;
	config.period = period_ns;
	config.ena = ena;

	return ice_ptp_cfg_clkout(pf, CLK_OUT_1588_CHANNEL, &config, true);
}

/**
 * ice_cdev_info_get_src_phy_tmr_val - Synch read of source/PHY timers
 * @cdev_info: The cdev_info object
 * @ts: pointer to iidc_ptp_timer_info structure (out param)
 *
 * Perform a synchronized read of the source and PHY timers.  Used for debug
 * purposes.
 */
static int
ice_cdev_info_get_src_phy_tmr_val(struct iidc_core_dev_info *cdev_info,
				  struct iidc_ptp_timer_info *ts)
{
	struct ice_pf *pf;

	if (!cdev_info)
		return -EINVAL;
	if (!ts)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);

	return ice_ptp_get_src_phy_time(pf, ts);
}

#endif /* !NO_PTP_SUPPORT */
/**
 * ice_sched_tree_size - calculate required buffer for the sched tree struct
 * @pf: PF which we are building tree for
 *
 * returns buffer size in bytes needed to accommodate tree
 */
static unsigned int ice_sched_tree_size(struct ice_pf *pf)
{
	unsigned int size = 0;
	int i;

	size = sizeof(struct iidc_sched_tree);
	size += sizeof(struct iidc_sched_tree_port) * pf->hw.num_total_ports;

	for (i = 0; i < pf->hw.num_total_ports; i++) {
		size += sizeof(struct iidc_sched_tree_branch) *
			ICE_TXSCHED_MAX_BRANCHES;

		size += sizeof(struct iidc_sched_tree_elem) *
			ICE_AQC_TOPO_MAX_LEVEL_NUM * ICE_TXSCHED_MAX_BRANCHES;
	}
#ifndef EXTERNAL_RELEASE
	/* TODO: Dead code, should be removed in future */
#ifndef SWITCH_MODE
	size = sizeof(struct iidc_sched_tree);
	size += sizeof(struct iidc_sched_tree_port);
	size += sizeof(struct iidc_sched_tree_elem) *
		ICE_AQC_TOPO_MAX_LEVEL_NUM * ICE_TXSCHED_MAX_BRANCHES;
#endif /* !SWITCH_MODE */
#endif
	return size;
}

/**
 * ice_sched_tree_alloc_from_buf - set up tree xfer structures inside buffer
 * @pf: PF which we are building tree for
 * @buf: buffer in which to store tree parameters, usually allocated by the
 *        AE driver. Note: buff must be large enough to hold the tree; it
 *        should be sized according to ice_sched_tree_size().
 * @tree_out: pointer to where the struct sched_tree was created within the
 *            buffer (currently, the start of the buffer).
 */
static void
ice_sched_tree_alloc_from_buf(struct ice_pf *pf, void *buf,
			      struct iidc_sched_tree **tree_out)
{
#ifndef EXTERNAL_RELEASE
/* FIXME - For NIC mode, num_ports is always 1, so this function should be
 * rewritten to use num_ports only in case of switch mode.
 */
#endif
	struct iidc_sched_tree *tree;
	u32 offset = 0;
	int i, j;

	tree = (struct iidc_sched_tree *)buf;
	offset += sizeof(*tree);

	tree->num_ports = pf->hw.num_total_ports;
#ifndef EXTERNAL_RELEASE
	/* TODO: Dead code, should be removed in future */
#ifndef SWITCH_MODE
	tree->num_ports = 1;
#endif /* !SWITCH_MODE */
#endif

	tree->ports = (struct iidc_sched_tree_port *)((u8 *)buf + offset);
	offset += sizeof(struct iidc_sched_tree_port) * tree->num_ports;

	for (i = 0; i < tree->num_ports; i++) {
		tree->ports[i].branches = (struct iidc_sched_tree_branch *)
					  (u8 *)buf + offset;
		offset += sizeof(struct iidc_sched_tree_branch) *
			ICE_TXSCHED_MAX_BRANCHES;
		tree->ports[i].num_branches = 0;

		for (j = 0; j < ICE_TXSCHED_MAX_BRANCHES; j++) {
			tree->ports[i].branches[j].elems =
			    (struct iidc_sched_tree_elem *)((u8 *)buf + offset);
			offset += (sizeof(struct iidc_sched_tree_elem) *
				   ICE_AQC_TOPO_MAX_LEVEL_NUM);
			tree->ports[i].branches[j].num_elems = 0;
		}
	}

	*tree_out = tree;
}

/**
 * ice_build_node_branch - traverse a sched branch and tally elements
 * @node: pointer to ice_sched_node to traverse and tally
 * @branch: pointer to the branch we are tallying into
 *
 * This function is intended to be called with the sched_lock held for
 * the sched tree which contains node
 */
static void
ice_build_node_branch(struct ice_sched_node *node,
		      struct iidc_sched_tree_branch *branch)
{
	int i;

	/* tally this element */
	memcpy(&branch->elems[branch->num_elems], &node->info,
	       IIDC_AE_ELEMENT_SIZE);
	branch->num_elems++;

	for (i = 0; i < node->num_children; i++)
		ice_build_node_branch(node->children[i], branch);
}

/**
 * ice_build_node_port - traverse a root node's branches to build sched tree
 * @node: pointer to ice_sched_node to use for root of tree
 * @port: pointer to sched_tree_port to be filled
 *
 * This function is intended to be called with the sched_lock held for
 * the sched tree which has node as its root
 */
static void
ice_build_node_port(struct ice_sched_node *node,
		    struct iidc_sched_tree_port *port)
{
	int i;

	port->num_branches = node->num_children;
	memcpy(&port->root.raw, &node->info, IIDC_AE_ELEMENT_SIZE);

	for (i = 0; i < port->num_branches; i++) {
		port->branches[i].num_elems = 0;
		ice_build_node_branch(node->children[i], &port->branches[i]);
	}
}

/**
 * ice_cdev_info_report_txsched_config - fill buffer with TXSched tree topology
 * @cdev_info: cdev_info struct for aux drv requesting tree
 * @buf: pointer to supplied memory to fill with topology elements
 * @buf_size: size of buffer in bytes
 *
 * Returns 0 on success, and -ENOMEM if the trees won't fit in buff or
 * cannot allocate memory to locally build the tree and -ENVAL if
 * cdev_info is invalid or retrieved logical port index is invalid
 */
static int
ice_cdev_info_report_txsched_config(struct iidc_core_dev_info *cdev_info,
				    void *buf, u32 buf_size)
{
	struct iidc_sched_tree *tree;
	unsigned int tree_size = 0;
	struct device *dev;
	struct ice_pf *pf;
	u8 i;

	if (!cdev_info)
		return -EINVAL;

	if (!buf)
		return -ENOMEM;

	pf = pci_get_drvdata(cdev_info->pdev);
	dev = ice_pf_to_dev(pf);

	tree_size = ice_sched_tree_size(pf);

	dev_dbg(dev, "Tree size: %u\n", tree_size);

	if (buf_size < tree_size) {
		dev_err(dev, "xfer buff too small to fit tree\n");
		return -ENOMEM;
	}

	ice_sched_tree_alloc_from_buf(pf, buf, &tree);

#ifdef SV_SUPPORT
	dev_info(dev, "TXSched ports: %d\n", tree->num_ports);
#endif /* SV_support */

	/* Loop through logical ports */
	for (i = 0; i < tree->num_ports; i++) {
		s8 pi_idx = ice_get_port_info_idx(&pf->hw, i);

		if (pi_idx < 0) {
			dev_err(dev, "txsched config: invalid port number %d\n", i);
			return -EINVAL;
		}
#ifdef SV_SUPPORT
		dev_info(dev, "Building Port: %d\n", pi_idx);
#endif /* SV_support */
		/* Reading the root node and subsequent children must
		 * be controlled with the sched_lock for the port.
		 * Locking here so that all subsequent calls to nodes
		 * in this tree are also locked in the recursive calls
		 * from within ice_build_node_* functions
		 */
		ice_acquire_lock(&pf->hw.port_info[pi_idx].sched_lock);
		/* get the txsched tree for  port i */
		ice_build_node_port(pf->hw.port_info[pi_idx].root, &tree->ports[i]);
		ice_release_lock(&pf->hw.port_info[pi_idx].sched_lock);
	}
	memcpy(buf, tree, tree_size);

#ifdef SV_SUPPORT
	dev_info(dev, "TXSCHED CONFIG:\n");
	dev_info(dev, "Num Ports: %d\n", tree->num_ports);
	for (i = 0; i < tree->num_ports; i++) {
		struct ice_aqc_txsched_elem_data elem;
		int j;

		dev_info(dev, "PORT %d:\n", i);
		memcpy(&elem, &tree->ports[i].root, IIDC_AE_ELEMENT_SIZE);
		dev_info(dev, "Root: %d\n", elem.node_teid);
		dev_info(dev, "Num Branches %d:\n",
			 tree->ports[i].num_branches);
		for (j = 0; j < tree->ports[i].num_branches; j++) {
			int k = 0;

			dev_info(dev, "\tBranch: %d\n", j);
			dev_info(dev, "\tNode_id\tParent_id\n");
			for (; k < tree->ports[i].branches[j].num_elems; k++) {
				memcpy(&elem, &tree->ports[i].branches[j].elems[k],
				       IIDC_AE_ELEMENT_SIZE);
				dev_info(dev, "%d\t%d\t%d\n", k, elem.node_teid, elem.parent_teid);
			}
		}
	}

#endif /* SV_SUPPORT */
	return 0;
}

#else /* !SWITCH_MODE */
/**
 * ice_cdev_info_update_vsi - update the pf_vsi info in cdev_info struct
 * @cdev_info: pointer to cdev_info struct
 * @vsi: VSI to be updated
 */
void ice_cdev_info_update_vsi(struct iidc_core_dev_info *cdev_info,
			      struct ice_vsi *vsi)
{
	if (!cdev_info)
		return;

	cdev_info->vport_id = vsi->vsi_num;
}

#endif /* SWITCH_MODE */
#ifndef ICE_TDD
/* Initialize the ice_ops struct, which is used in 'ice_init_aux_devices' */
static const struct iidc_core_ops iidc_ops = {
#ifndef SWITCH_MODE
	.alloc_res			= ice_cdev_info_alloc_res,
	.free_res			= ice_cdev_info_free_res,
#endif /* SWITCH_MODE */
	.request_reset			= ice_cdev_info_request_reset,
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
	.request_vf_reset		= ice_cdev_info_request_vf_reset,
#endif /* SWITCH_MODE && !BMSM_MODE */
#ifdef SWITCH_MODE
	.notify_event			= ice_cdev_info_report_event,
	.query_sched_tree		= ice_cdev_info_report_txsched_config,
#ifdef ADK_SUPPORT
	.is_vsi_ready			= ice_adk_is_vsi_ready,
	.vport_q_cfg			= ice_adk_vsi_q_cfg,
	.vsi_set_q_sel_mode		= ice_adk_vsi_set_q_sel_mode,
	.vsi_set_q_num			= ice_adk_vsi_set_q_num,
	.vsi_set_q_prio_map		= ice_adk_vsi_set_q_prio_map,
	.vsi_get_q_cfg			= ice_adk_vsi_get_q_cfg,
	.vsi_sw_q_ena_dis		= ice_adk_vsi_sw_q_ena_dis,
	.vsi_sw_is_q_enabled		= ice_adk_vsi_sw_is_q_enabled,
	.vsi_sw_set_q_cfg		= ice_adk_vsi_sw_set_q_cfg,
	.vsi_sw_get_q_cfg		= ice_adk_vsi_sw_get_q_cfg,
	.strt_xmit_internal		= ice_adk_strt_xmit_internal,
	.get_stats64			= ice_get_stats64,
	.get_port_id			= ice_adk_get_port_id,
	.add_mac_port			= ice_adk_add_mac_port,
#ifndef NO_PTP_SUPPORT
	.ptp_get_tx_hwtstamp_ready	= ice_ptp_adk_tx_hwtstamp_ready,
	.ptp_get_tx_hwtstamp_ver	= ice_ptp_adk_tx_hwtstamp_ver,
	.ptp_get_tx_hwtstamp		= ice_ptp_adk_tx_hwtstamp,
	.ptp_ts_ena_intr		= ice_ptp_ts_ena_intr,
	.ptp_convert_ts			= ice_ptp_convert_ts,
#endif /* !NO_PTP_SUPPORT */
#endif /* ADK_SUPPORT */
#ifndef NO_SBQ_SUPPORT
	.sbq_rw_reg			= ice_cdev_info_sbq_rw_reg,
#endif /* !NO_SBQ_SUPPORT */
#ifndef NO_PTP_SUPPORT
	.update_incval			= ice_cdev_info_update_incval,
	.get_incval			= ice_cdev_info_get_incval,
	.match_and_adj			= ice_cdev_info_match_and_adj,
	.cfg_1588_clk_out_to_cgu	= ice_cdev_info_cfg_1588_clk_out_to_cgu,
	.get_src_phy_tmr_val		= ice_cdev_info_get_src_phy_tmr_val,
#endif /* !NO_PTP_SUPPORT */
#endif /* SWITCH_MODE */
#ifdef RDMA_SUPPORT
	.update_vport_filter		= ice_cdev_info_update_vsi_filter,
#endif /* RDMA_SUPPORT */
#ifdef VF_RDMA_SUPPORT
	.get_vf_info			= ice_cdev_info_get_vf_port_info,
#endif /* VF_RDMA_SUPPORT */
	.vc_send			= ice_cdev_info_vc_send,
#ifdef IEPS_SUPPORT
	.ieps_entry			= ice_ieps_entry,
#endif /* IEPS_SUPPORT */

#ifndef EXTERNAL_RELEASE
	/* FIXME: Initialize remaining functions later */
#endif
};
#endif /* ICE_TDD */

/**
 * ice_cdev_info_adev_release - function to be mapped to aux dev's release op
 * @dev: pointer to device to free
 */
static void ice_cdev_info_adev_release(struct device *dev)
{
	struct iidc_auxiliary_dev *iadev;

	iadev = container_of(dev, struct iidc_auxiliary_dev, adev.dev);
	kfree(iadev);
}

/* ice_plug_aux_dev - allocate and register aux dev for cdev_info
 * @cdev_info: pointer to cdev_info struct
 * @name: name of peer_aux_dev
 *
 * The cdev_info must be setup before calling this function
 */
int ice_plug_aux_dev(struct iidc_core_dev_info *cdev_info, const char *name)
{
	struct iidc_auxiliary_dev *iadev;
	struct auxiliary_device *adev;
	struct ice_pf *pf;
	int ret = 0;

	if (!cdev_info || !name)
		return -EINVAL;

	pf = pci_get_drvdata(cdev_info->pdev);
	if (!pf)
		return -EINVAL;

	/* if this PF does not support a technology that requires auxiliary
	 * devices, then exit gracefully
	 */
	if (!ice_is_aux_ena(pf))
		return ret;
#ifndef SWITCH_MODE
	mutex_lock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
#ifndef EXTERNAL_RELEASE
	/* if aux dev is already initialized, skip it */
#endif /* EXTERNAL_RELEASE */
	if (cdev_info->adev)
		goto aux_plug_out;

#ifndef EXTERNAL_RELEASE
	/* if the driver is loaded in nd_vis=1 (unstacked) mode, it's
	 * 'our' driver responsibility to register and handle netdevs.
	 * Don't register ADK aux device to avoid ambiguity when adk_netd
	 * driver is loaded anyway.
	 */
#endif
#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
	if (cdev_info->cdev_info_id == IIDC_ADK_ID && ice_is_nd_vis())
		return 0;
#endif

#ifdef RDMA_SUPPORT
#ifndef EXTERNAL_RELEASE
	/* if RDMA disabled, return cleanly */
#endif /* !EXTERNAL_RELEASE */
	if (cdev_info->cdev_info_id == IIDC_RDMA_ID && !ice_chk_rdma_cap(pf))
		goto aux_plug_out;

#endif /* RDMA_SUPPORT */
	iadev = (struct iidc_auxiliary_dev *)kzalloc(sizeof(*iadev),
						     GFP_KERNEL);
	if (!iadev) {
		ret = -ENOMEM;
		goto aux_plug_out;
	}

	adev = &iadev->adev;
	cdev_info->adev = adev;
	iadev->cdev_info = cdev_info;

	adev->id = pf->aux_idx;
	adev->dev.release = ice_cdev_info_adev_release;
	adev->dev.parent = &cdev_info->pdev->dev;
	adev->name = name;

	ret = auxiliary_device_init(adev);
	if (ret) {
		cdev_info->adev = NULL;
		kfree(iadev);
		goto aux_plug_out;
	}

	ret = auxiliary_device_add(adev);
	if (ret) {
		cdev_info->adev = NULL;
		auxiliary_device_uninit(adev);
	}

aux_plug_out:
#ifndef SWITCH_MODE
	mutex_unlock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
	return ret;
}

/* ice_unplug_aux_dev - unregister and free aux dev
 * @cdev_info: pointer cdev_info struct
 */
void ice_unplug_aux_dev(struct iidc_core_dev_info *cdev_info)
{
#ifndef SWITCH_MODE
	struct ice_pf *pf;

	if (!cdev_info)
		return;
	pf = pci_get_drvdata(cdev_info->pdev);

	/* if this aux dev has already been unplugged move on */
	mutex_lock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
	if (!cdev_info->adev) {
#ifndef SWITCH_MODE
		mutex_unlock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
		return;
	}

	auxiliary_device_delete(cdev_info->adev);
	auxiliary_device_uninit(cdev_info->adev);
	cdev_info->adev = NULL;
#ifndef SWITCH_MODE
	mutex_unlock(&pf->adev_mutex);
#endif /* !SWITCH_MODE */
}

#ifdef MULTI_PEER_SUPPORT
/* ice_plug_aux_devs - allocate and register aux dev for cdev_info
 * @pf: pointer to pf struct
 *
 * The PFs cdev_infos array must be setup before calling this function
 */
int ice_plug_aux_devs(struct ice_pf *pf)
{
	int ret;
	u8 i;

	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
#ifdef RDMA_SUPPORT
		const char *name;

#endif /* RDMA_SUPPORT */
		if (!pf->cdev_infos[i])
			continue;

#ifdef RDMA_SUPPORT
		if (pf->cdev_infos[i]->cdev_info_id == IIDC_RDMA_ID) {
			if (pf->cdev_infos[i]->rdma_protocol ==
			    IIDC_RDMA_PROTOCOL_IWARP)
				name = IIDC_RDMA_IWARP_NAME;
			else
				name = IIDC_RDMA_ROCE_NAME;
		} else {
			name = ice_cdev_ids[i].name;
		}

		ret = ice_plug_aux_dev(pf->cdev_infos[i], name);
#else
		ret = ice_plug_aux_dev(pf->cdev_infos[i], ice_cdev_ids[i].name);
#endif /* RDMA_SUPPORT */
		if (ret)
			return ret;
	}

	return 0;
}

/* ice_unplug_aux_devs - unregister and free aux devs
 * @pf: pointer to pf struct
 */
void ice_unplug_aux_devs(struct ice_pf *pf)
{
	u8 i;

	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
		ice_unplug_aux_dev(pf->cdev_infos[i]);
#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
		ice_clear_port_info(pf->cdev_infos[i]);
#endif /* SWITCH_MODE && ADK_SUPPORT */
	}
}
#endif /* MULTI_PEER_SUPPORT */

#ifdef RDMA_SUPPORT
/**
 * ice_cdev_init_rdma_qos_info - initialize qos_info for RDMA peer
 * @pf: pointer to ice_pf
 * @qos_info: pointer to qos_info struct
 */
static void ice_cdev_init_rdma_qos_info(struct ice_pf *pf,
					struct iidc_qos_params *qos_info)
{
	int j;

	/* setup qos_info fields with defaults */
	qos_info->num_apps = 0;
	qos_info->num_tc = 1;

	for (j = 0; j < IIDC_MAX_USER_PRIORITY; j++)
		qos_info->up2tc[j] = 0;

	qos_info->tc_info[0].rel_bw = 100;
	for (j = 1; j < IEEE_8021QAZ_MAX_TCS; j++)
		qos_info->tc_info[j].rel_bw = 0;
#ifndef NO_DCB_SUPPORT
	/* for DCB, override the qos_info defaults. */
	ice_setup_dcb_qos_info(pf, qos_info);
#endif /* !NO_DCB_SUPPORT */

}
#endif /* RDMA_SUPPORT */

/**
 * ice_init_aux_devices - initializes cdev_info objects and aux devices
 * @pf: ptr to ice_pf
 */
int ice_init_aux_devices(struct ice_pf *pf)
{
#if defined(SWITCH_MODE) && defined(BMSM_MODE)
	struct ice_hw_dev_caps *dev_caps = &pf->hw.dev_caps;
#endif /* SWITCH_MODE && BMSM_MODE */
#ifndef SWITCH_MODE
#ifndef EXTERNAL_RELEASE
	/* In NIC mode, there is one port_info per PF and one VSI per port_info.
	 * The PF's port_info VSI always is a control VSI.
	 */
#endif /* EXTERNAL_RELEASE */
	struct ice_vsi *vsi = pf->vsi[0];
#endif /* !SWITCH_MODE */
#ifndef MULTI_PEER_SUPPORT
	struct iidc_core_dev_info *cdev_info;
	struct msix_entry *entry = NULL;
#endif /* !MULTI_PEER_SUPPORT */
	struct pci_dev *pdev = pf->pdev;
	struct device *dev = &pdev->dev;
	int err;
#ifdef MULTI_PEER_SUPPORT
	unsigned int i;
#endif /* MULTI_PEER_SUPPORT */

	/* Reserve vector resources */
	err = ice_reserve_cdev_info_qvector(pf);
	if (err < 0) {
		dev_err(dev, "failed to reserve vectors for aux drivers\n");
		return err;
	}

	/* This PFs auxiliary id value */
	pf->aux_idx = ida_alloc(&ice_cdev_info_ida, GFP_KERNEL);
	if (pf->aux_idx < 0) {
		dev_err(dev, "failed to allocate device ID for aux drvs\n");
		return -ENOMEM;
	}

#ifdef MULTI_PEER_SUPPORT
	for (i = 0; i < ARRAY_SIZE(ice_cdev_ids); i++) {
		struct msix_entry *entry = NULL;
		struct iidc_core_dev_info *cdev_info;

		/* structure layout needed for container_of's looks like:
		 * iidc_auxiliary_dev (container_of super-struct for adev)
		 * |--> auxiliary_device
		 * |--> *iidc_core_dev_info (pointer from cdev_info struct)
		 *
		 * The iidc_auxiliary_device has a lifespan as long as it
		 * is on the bus.  Once removed it will be freed and a new
		 * one allocated if needed to re-add.
		 *
		 * The iidc_core_dev_info is tied to the life of the PF, and
		 * will exist as long as the PF driver is loaded.  It will be
		 * freed in the remove flow for the PF driver.
		 */
		cdev_info = (struct iidc_core_dev_info *)
			kzalloc(sizeof(*cdev_info), GFP_KERNEL);
		if (!cdev_info) {
			ida_simple_remove(&ice_cdev_info_ida, pf->aux_idx);
			pf->aux_idx = -1;
			return -ENOMEM;
		}

		pf->cdev_infos[i] = cdev_info;

		cdev_info->hw_addr = (u8 __iomem *)pf->hw.hw_addr;
		cdev_info->ver.major = IIDC_MAJOR_VER;
		cdev_info->ver.minor = IIDC_MINOR_VER;
		cdev_info->cdev_info_id = ice_cdev_ids[i].id;
		cdev_info->pdev = pdev;
#ifndef EXTERNAL_RELEASE
		/* FIXME: Call function to init callbacks */
#endif
#ifndef ICE_TDD
		/* Initialize ice_ops */
		cdev_info->ops = &iidc_ops;
#endif
#if defined(SWITCH_MODE) && defined(BMSM_MODE)
		cdev_info->nac_topo_mode = dev_caps->nac_topo.mode;
		cdev_info->nac_id = dev_caps->nac_topo.id;
#endif
		/* make sure peer specific resources such as msix_count and
		 * msix_entries are initialized
		 */
		switch (ice_cdev_ids[i].id) {
#ifdef SWITCH_MODE
#ifndef BMSM_MODE
		case IIDC_AE_ID:
			cdev_info->res_start = ICE_PEER_AE_RES_START;
			cdev_info->res_len = ICE_PEER_PCI_RES_LEN;
			cdev_info->msix_count = pf->num_ae_msix;
			entry = &pf->msix_entries[pf->ae_base_vector];

			/* initialize Tx/Rx data queues available for AE driver,
			 * which will eventually be mapped to user space ADK
			 * applications
			 */
			ice_setup_ae_data_q_info(pf, cdev_info);
			break;
#endif /* !BMSM_MODE */
		case IIDC_IPSEC_ID:
			cdev_info->res_start = ICE_PEER_INLINE_CRYPTO_RES_START;
			cdev_info->res_len = ICE_PEER_PCI_RES_LEN;
			cdev_info->msix_count = pf->num_crypto_msix;
			entry = &pf->msix_entries[pf->crypto_base_vector];
			break;
		case IIDC_SW_ID:
			cdev_info->res_start = ICE_PEER_SW_RES_START;
			cdev_info->res_len = ICE_PEER_PCI_RES_LEN;
			cdev_info->msix_count = pf->num_swt_msix;
			entry = &pf->msix_entries[pf->swt_base_vector];
			break;
#ifdef ADK_SUPPORT
		case IIDC_ADK_ID:
			/* Need to cache this peer for later access in
			 * the hot path
			 */
			ice_peer_adk_setup(cdev_info);
			break;
#endif /* ADK_SUPPORT */
#endif /* SWITCH_MODE */

#ifdef RDMA_SUPPORT
		case IIDC_RDMA_ID:
			if (!ice_chk_rdma_cap(pf)) {
				pf->cdev_infos[i] = NULL;
				kfree(cdev_info);
				continue;
			}
			cdev_info->vport_id = vsi->vsi_num;
			cdev_info->netdev = vsi->netdev;
			cdev_info->rdma_protocol = IIDC_RDMA_PROTOCOL_ROCEV2;
			cdev_info->rdma_caps.gen = IIDC_RDMA_GEN_2;
			cdev_info->ftype = IIDC_FUNCTION_TYPE_PF;
			cdev_info->cdev_info_id = IIDC_RDMA_ID;
			cdev_info->pf_id = pf->hw.pf_id;
#ifdef HAVE_NETDEV_UPPER_INFO
			cdev_info->rdma_active_port = ICE_LAG_INVALID_PORT;
			cdev_info->main_pf_port = pf->hw.port_info->lport;
#endif /* HAVE_NETDEV_UPPER_INFO */
			ice_cdev_init_rdma_qos_info(pf, &cdev_info->qos_info);
			/* make sure peer specific resources such as msix_count
			 * and msix_entries are initialized
			 */
#ifndef EXTERNAL_RELEASE
			/* FIXME: initialize res_start, res_len */
#endif
			cdev_info->msix_count = pf->num_rdma_msix;
			entry = &pf->msix_entries[pf->rdma_base_vector];
			break;
#endif /* RDMA_SUPPORT */
		default:
			break;
		}
		cdev_info->msix_entries = entry;
	}
#else /* !MULTI_PEER_SUPPORT */
	cdev_info = (struct iidc_core_dev_info *)kzalloc(sizeof(*cdev_info),
							 GFP_KERNEL);
	if (!cdev_info) {
		ida_simple_remove(&ice_cdev_info_ida, pf->aux_idx);
		pf->aux_idx = -1;
		return -ENOMEM;
	}

	pf->cdev_info = cdev_info;

	cdev_info->hw_addr = (u8 __iomem *)pf->hw.hw_addr;
#ifdef NOT_FOR_UPSTREAM
	cdev_info->ver.major = IIDC_MAJOR_VER;
	cdev_info->ver.minor = IIDC_MINOR_VER;
#endif /* NOT_FOR_UPSTREAM */
#ifndef SWITCH_MODE
	cdev_info->vport_id = vsi->vsi_num;
	cdev_info->netdev = vsi->netdev;
#endif /* !SWITCH_MODE */
	cdev_info->pdev = pdev;
#ifndef EXTERNAL_RELEASE
	/* FIXME: Call function to init callbacks */
#endif
#ifndef ICE_TDD
	/* Initialize ice_ops */
	cdev_info->ops = &iidc_ops;
#endif

	/* make sure peer specific resources such as msix_count and
	 * msix_entries are initialized
	 */
#ifdef RDMA_SUPPORT
	ice_cdev_init_rdma_qos_info(pf, &cdev_info->qos_info);
#ifndef EXTERNAL_RELEASE
	/* FIXME: initialize res_start, res_len */
#endif
	if (ice_chk_rdma_cap(pf)) {
		cdev_info->msix_count = pf->num_rdma_msix;
		entry = &pf->msix_entries[pf->rdma_base_vector];
	}
	cdev_info->rdma_protocol = IIDC_RDMA_PROTOCOL_IWARP;
	cdev_info->cdev_info_id = IIDC_RDMA_ID;
#endif /* RDMA_SUPPORT */

	cdev_info->msix_entries = entry;
#endif /* MULTI_PEER_SUPPORT */
	set_bit(ICE_FLAG_PLUG_AUX_DEV, pf->flags);

	return err;
}

#ifdef VF_RDMA_SUPPORT
/**
 * ice_is_rdma_aux_loaded - check if RDMA auxiliary driver is loaded
 * @pf: ptr to ice_pf
 */
bool ice_is_rdma_aux_loaded(struct ice_pf *pf)
{
	struct iidc_core_dev_info *rcdi;
	struct iidc_auxiliary_drv *iadrv;
	bool loaded;

#ifdef MULTI_PEER_SUPPORT
	rcdi = ice_find_cdev_info_by_id(pf, IIDC_RDMA_ID);
#else
	rcdi = pf->cdev_info;
#endif /* MULTI_PEER_SUPPORT */
	if (!rcdi)
		return false;

	mutex_lock(&pf->adev_mutex);
	device_lock(&rcdi->adev->dev);
	iadrv = ice_get_auxiliary_drv(rcdi);
	loaded = iadrv ? true : false;
	device_unlock(&rcdi->adev->dev);
	mutex_unlock(&pf->adev_mutex);

	dev_dbg(ice_pf_to_dev(pf), "RDMA Auxiliary Driver status: %s\n",
		loaded ? "loaded" : "not loaded");

	return loaded;
}
#endif /* VF_RDMA_SUPPORT */

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
/**
 * ice_get_ae_aux_and_lock - look up AE aux driver and lock the device for use
 * @pf: ptr to ice_pf
 * @adrv: out param for AE auxiliary_drv struct
 * @cdev_info: out param for AE cdev_info struct
 *
 * If the AE driver is found and all the required IIDC callbacks are available,
 * keep the device locked and return 0. Otherwise, unlock the device and return
 * an error code.
 */
int ice_get_ae_aux_and_lock(struct ice_pf *pf,
			    struct iidc_auxiliary_drv **adrv,
			    struct iidc_core_dev_info **cdev_info)
{
	struct iidc_auxiliary_drv *ae_iadrv;
	struct iidc_core_dev_info *ae_cdi;

	ae_cdi = ice_find_cdev_info_by_id(pf, IIDC_AE_ID);
	if (!ae_cdi)
		return -ENOENT;

	device_lock(&ae_cdi->adev->dev);
	ae_iadrv = ice_get_auxiliary_drv(ae_cdi);
	if (!ae_iadrv) {
		device_unlock(&ae_cdi->adev->dev);
		return -EUNATCH;
	}

	if (!ae_iadrv->ae_create_lan_vfs ||
	    !ae_iadrv->ae_destroy_lan_vfs ||
	    !ae_iadrv->ae_init_lan_vf_hier ||
	    !ae_iadrv->ae_teardown_lan_vf_hier ||
	    !ae_iadrv->ae_cfg_lan_vf_txq ||
	    !ae_iadrv->ae_destroy_lan_vf_txq) {
		device_unlock(&ae_cdi->adev->dev);
		return -EOPNOTSUPP;
	}

	*adrv = ae_iadrv;
	*cdev_info = ae_cdi;

	return 0;
}
#endif /* SWITCH_MODE && !BMSM_MODE */
