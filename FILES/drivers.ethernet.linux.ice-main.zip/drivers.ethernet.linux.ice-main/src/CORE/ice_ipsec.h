#ifndef _ICE_IPSEC_H_
#define _ICE_IPSEC_H_
#include "ice.h"

#define ICE_MAX_IPSEC_CAPABLE_VF_ID	127

#ifndef ICE_TDD
bool ice_is_vf_ipsec_capable(struct ice_vf *vf);
int ice_ipsec_handle_idc_msg(struct ice_vf *vf, u8 *msg, u16 len);
int ice_ipsec_handle_vc_msg(struct ice_vf *vf, u8 *msg, u16 len);
int ice_ipsec_send_vc_unicast_msg(struct ice_vf *vf, u8 *msg, u16 len);
int ice_ipsec_send_vc_broadcast_msg(struct ice_pf *pf, u8 *msg, u16 len);
int ice_ipsec_send_vc_msg(struct ice_pf *pf, u8 *msg, u16 len, u32 vf_id);
#ifndef BMSM_MODE
void ice_ipsec_ena_dis(struct ice_pf *pf, bool enable);
#endif /* !BMSM_MODE */
#endif /* ICE_TDD */
#endif
