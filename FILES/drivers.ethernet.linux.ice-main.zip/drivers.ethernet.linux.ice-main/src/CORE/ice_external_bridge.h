#ifndef _ICE_EXTERNAL_BRIDGE_H_
#define _ICE_EXTERNAL_BRIDGE_H_
#include "peerchnl.h"

int ice_handle_ies_bridge_event(struct ice_pf *pf, struct peerchnl_event *event);
void ice_bridge_clean(struct ice_pf *pf);

#endif /* _ICE_EXTERNAL_BRIDGE_H_ */
