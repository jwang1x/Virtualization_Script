#ifndef _PEERCHNL_H_
#define _PEERCHNL_H_

#include "ice_adminq_cmd.h"

/* Description:
 * This header file describes the Peer driver communication protocol.
 *
 * Mailbox queue descriptor usage:
 * The opcode field for both the Send to Peer Driver command and the Message
 * from Peer Driver event is always ice_mbx_opc_send_to_peer_drv (0x0804).
 *
 * The flags, opcode, length, and data addr high/low fields are all used the
 * same as with other Control Queue descriptors (e.g. FW Admin Queue) for
 * both the Send to Peer Driver command and Message from Peer Driver event.
 *
 * The retval field is used the same as the FW Admin Queue descriptor for
 * the Send to Peer Driver command (i.e. driver sets to zero, MBX returns
 * error value or zero); when a driver receives a Message from Peer Driver
 * event, this field (set by MBX) is the driver ID of the sending peer.
 *
 * Drivers must set the DRID field in the Send Message to Peer Driver command
 * to the driver ID of the peer driver to which the message should be sent.
 *
 * The cookie high/low fields are not used by the MBX; instead the fields
 * are copied by MBX into the completion of the Send to Peer Driver command
 * and into the descriptor of the Message from Peer Driver event. This allows
 * these fields to be used to hold opaque peer driver communication protocol
 * information defined below. If more space is needed, an indirect buffer is
 * used the same way as with other Control Queue descriptors (i.e. set the
 * appropriate flags and data addr high/low fields).
 */

#if defined(FW_SUPPORT) || defined(SV_SUPPORT)
/* This macro is used to generate a compilation error if a structure
 * is not the correct size. It gives a divide by zero error if not,
 * otherwise it creates an enum that is never used.
 */
#define PEERCHNL_CHECK_STRUCT_SIZE(n, X) enum foo_static_assert_enum_##X \
	{ foo_static_assert_##X = (n) / ((sizeof(struct X) == (n)) ? 1 : 0) }

/* Check the entire descriptor structure is 32-bytes */
#define PEERCHNL_CHECK_DESC_SIZE(X)	PEERCHNL_CHECK_STRUCT_SIZE(32, X)
#endif /* FW_SUPPORT || SV_SUPPORT */

/* Status/Error Codes */
enum peerchnl_status_code {
	PEERCHNL_STATUS_SUCCESS			= 0,
	PEERCHNL_STATUS_ERR_OPCODE_UNKNOWN	= 1,
	PEERCHNL_STATUS_ERR_INVAL_PARAM		= 2,	/* bad message data */
	PEERCHNL_STATUS_ERR_VER_MISMATCH	= 3,
	PEERCHNL_STATUS_ERR_CMD_FAIL		= 4,
};

/* Opcodes for Peer-Peer communication. These are placed in the msg_opcode
 * field of the peerchnl_mbx_desc structure.
 * Opcode defines should maintain binary comaptibility as the peerchnl
 * API version is updated.
 */
enum peerchnl_ops {
	/* This opcode is sent by the Switch driver to the LAN driver to
	 * request issuing a FW AdminQ command such as port mapping, port
	 * mgmt, read NVM sections, link mgmt etc.
	 * Uses indirect message struct peerchnl_fw_data.
	 */
	PEERCHNL_OP_FW_CMD_REQ = 2,
#define PEERCHNL_OP_FW_CMD_REQ_VER	1

	/* This is the async response sent by the LAN driver to the Switch
	 * driver once it has the completion/writeback from FW in response
	 * to the FW command associated with a PEERCHNL_OP_FW_CMD_REQ.
	 * Any FW command that also results in an event that is not an
	 * immediate response to the command will be played to the peers
	 * as a PEERCHNL_OP_FW_EVENT message.
	 * Uses indirect message struct peerchnl_fw_data; cookie low has
	 * enum peerchnl_status_code.
	 */
	PEERCHNL_OP_FW_CMD_RESP = 3,
#define PEERCHNL_OP_FW_CMD_RESP_VER	1

	/* This is for async events received by the LAN driver when a FW
	 * event occurs that might be of interest to peer drivers, e.g.
	 * a link change event.
	 * As a policy the LAN driver will play all FW events to all peer
	 * drivers; peer drivers can ignore events they don't care about.
	 * Uses indirect message struct peerchnl_fw_data.
	 * No response is expected from peer for this message.
	 */
	PEERCHNL_OP_FW_EVENT = 4,
#define PEERCHNL_OP_FW_EVENT_VER	1

	/* A generic event mechanism can be used for things like Administrative
	 * link changes. Peer driver sends this message to inform other peer
	 * drivers of events that may affect it.
	 * The response to this event command is done by the receiver with
	 * a PEERCHNL_OP_ACK indicating the appropriate status.
	 * Uses indirect message struct peerchnl_event.
	 */
#ifndef EXTERNAL_RELEASE
	 /* FIXME: elaborate as events are defined. */
#endif
	PEERCHNL_OP_EVENT = 5,
#define PEERCHNL_OP_EVENT_VER		1

	/* Anything that needs an asynchronous acknowledgment (ACK or NAK)
	 * will carry the sequence number for the mailbox message that is
	 * acknowledged.
	 * Uses direct message with data of type enum peerchnl_status_code.
	 */
	PEERCHNL_OP_ACK = 6,
#define PEERCHNL_OP_ACK_VER		1

	/* This is an opcode sent by AE driver to Switch driver when there is
	 * an update in queue mapping. The Switch driver sends an ACK back with
	 * the Sequence number copied back in response.
	 * Uses indirect message struct peerchnl_vsi_entry
	 */
	PEERCHNL_OP_QMAPPING = 7,
#define PEERCHNL_OP_QMAPPING_VER	1

#ifndef EXTERNAL_RELEASE
	/* This is an opcode sent to peer drivers from CPK driver in BTS
	 * product family to indicate that MTU size has been changed.
	 */
#endif
	PEERCHNL_OP_MTU_CHANGE = 8,
#define PEERCHNL_OP_MTU_CHANGE_VER	1

	/* This is an opcode sent by the IES API to the AE driver to lock out
	 * any L2 node operations so the IES API can perform operations on
	 * shared pin-based flow control registers.  The AE driver sends an ACK
	 * back with the sequence number copied into the response.
	 */
	PEERCHNL_OP_L2_LOCK = 9,
#define PEERCHNL_OP_L2_LOCK_VER	1

	/* This is an opcode sent by the IES API to the AE driver to query an
	 * L2 node's physical ID given its logical ID.  The AE driver sends
	 * back the L2 physical ID.  This operation must be performed while L2
	 * operations are locked out.
	 * Uses indirect message struct peerchnl_l2_node_phys_id_req
	 */
	PEERCHNL_OP_L2_NODE_PHYS_ID_REQ = 10,
#define PEERCHNL_OP_L2_NODE_PHYS_ID_REQ_VER	1

	/* This is an opcode sent by the AE driver to the IES API in response to
	 * a query for an L2 node's physical ID.
	 * Uses indirect message struct peerchnl_l2_node_phys_id_resp
	 */
	PEERCHNL_OP_L2_NODE_PHYS_ID_RESP = 11,
#define PEERCHNL_OP_L2_NODE_PHYS_ID_RESP_VER	1

	/* This is an opcode sent by the IES API to the AE driver to reallow L2
	 * node operations after the IES API has finished operations on shared
	 * pin-based flow control registers.  The AE driver sends an ACK back
	 * with the sequence number copied into the response.
	 */
	PEERCHNL_OP_L2_UNLOCK = 12,
#define PEERCHNL_OP_L2_UNLOCK_VER	1

	/* This is an opcode sent by the IES API to the CPK driver when the user
	 * application wants to obtain the WoL wake up reason using
	 * IES_SA_WOL_WAKE_UP_REASON attribute. The CPK driver sends an ACK back
	 * with the reason copied into the response.
	 */
	PEERCHNL_OP_WOL_WAKEUP_REASON_REQ = 13,
#define PEERCHNL_OP_WOL_WAKEUP_REASON_REQ_VER	1

	/* This is an opcode sent by the CPK driver to the IES API in response
	 * to wake up reason request.
	 */
	PEERCHNL_OP_WOL_WAKEUP_REASON_RESP = 14,
#define PEERCHNL_OP_WOL_WAKEUP_REASON_RESP_VER	1

	/* This is an opcode sent by the IES API to the CPK driver to notify it
	 * of a link state change. No ACK is required.
	 * Uses indirect message struct peerchnl_port_state_change.
	 */
	PEERCHNL_OP_PORT_STATE_CHANGE = 15,
#define PEERCHNL_OP_PORT_STATE_CHANGE_VER	1

	/* In BMSM, when MTU settings are managed by HLP (aka Centralized mode)
	 * this is an opcode sent by the IES API to CPK driver to change
	 * MTU setting on a port. Upon receiving this, CPK shall block MTU
	 * update through netdev.
	 */
	PEERCHNL_OP_SET_MAX_FRM_SIZE = 16,
#define PEERCHNL_OP_SET_MAX_FRM_SIZE_VER	1

	/* This is an opcode sent by the CPK driver to the IES API in response
	 * to set max frame size request when in Centralized mode.
	 */
	PEERCHNL_OP_SET_MAX_FRM_SIZE_RESP = 17,
#define PEERCHNL_OP_SET_MAX_FRM_SIZE_VER	1

	/* This is an opcode sent by the IES API to the NIS driver to indicate
	 * that an RX_CODE_ERROR occurred on a port.
	 * Uses direct message with data indicating the logical port number.
	 */
	PEERCHNL_OP_RX_CODE_ERR = 18,
#define PEERCHNL_OP_RX_CODE_ERR_VER		1

	/* This is an opcode sent by the IES API to the NIS driver to enable
	 * timestamping on a given port.
	 * Uses direct message with data indicating the logical port number.
	 */
	PEERCHNL_OP_TIMESTAMP_ENABLE = 19,
#define PEERCHNL_OP_TIMESTAMP_ENABLE_VER	1

	/* This is an opcode sent by the IES API to the NIS driver to disable
	 * timestamping on a given port.
	 * Uses direct message with data indicating the logical port number.
	 */
	PEERCHNL_OP_TIMESTAMP_DISABLE = 20,
#define PEERCHNL_OP_TIMESTAMP_DISABLE_VER	1

	/* This is an opcode sent by the NIS driver to the IES API to indicate
	 * that PHY state is prepared to be changed on given ports.
	 * Uses indirect message.
	 */
	PEERCHNL_OP_PHY_STATE_CHANGE = 21,
#define PEERCHNL_OP_PHY_STATE_CHANGE_VER	1

	/* This is an opcode sent by the IES API to the NIS driver to indicate
	 * that PHY state can be changed on given ports.
	 * Uses indirect message.
	 */
	PEERCHNL_OP_PHY_STATE_CHANGE_RESP = 22,
#define PEERCHNL_OP_PHY_STATE_CHANGE_RESP_VER	1

#ifndef EXTERNAL_RELEASE
	/* Rest of the Opcodes are specific for RoW use case */
#endif
	/* This message is to support Inline Ipsec usage.
	 * Uses indirect message struct peerchnl_ether_addr_list.
	 */
	PEERCHNL_OP_MAC_VLAN_ALLOWLIST = 102,
#define PEERCHNL_OP_MAC_VLAN_ALLOWLIST_VER	1

	/* This is an opcode sent by the CPK driver to the IES API to notify it
	 * of a new crypto-enabled VF addition and to add a PRE_VEB rule so that
	 * all traffic to and from this VF goes via the CPM module.
	 * Uses indirect message struct peerchnl_add_pre_veb_entry.
	 */
	PEERCHNL_OP_ADD_PRE_VEB_ENTRY = 103,
#define PEERCHNL_OP_ADD_PRE_VEB_ENTRY_VER	1

	/* This is an opcode sent by the IES API to the CPK driver in response
	 * to PRE_VEB entry addition request.
	 */
	PEERCHNL_OP_ADD_PRE_VEB_ENTRY_RESP = 104,
#define PEERCHNL_OP_ADD_PRE_VEB_ENTRY_RESP_VER	1

	/* This is an opcode sent by the CPK driver to the IES API to notify it
	 * of a new crypto-enabled VF deletion and to delete a PRE_VEB rule.
	 * Uses indirect message struct peerchnl_del_pre_veb_entry.
	 */
	PEERCHNL_OP_DEL_PRE_VEB_ENTRY = 105,
#define PEERCHNL_OP_DEL_PRE_VEB_ENTRY_VER	1

	/* This is an opcode sent by the IES API to the CPK driver in response
	 * to PRE_VEB entry deletion request.
	 */
	PEERCHNL_OP_DEL_PRE_VEB_ENTRY_RESP = 106,
#define PEERCHNL_OP_DEL_PRE_VEB_ENTRY_RESP_VER	1

	PEERCHNL_OP_ADD_ALLOWLIST = 107,
#define PEERCHNL_OP_ADD_ALLOWLIST_VER	1
	PEERCHNL_OP_ADD_ALLOWLIST_RESP = 108,
#define PEERCHNL_OP_ADD_ALLOWLIST_RESP_VER	1
	PEERCHNL_OP_DEL_ALLOWLIST = 109,
#define PEERCHNL_OP_DEL_ALLOWLIST_VER	1
	PEERCHNL_OP_DEL_ALLOWLIST_RESP = 110,
#define PEERCHNL_OP_DEL_ALLOWLIST_RESP_VER	1

	/* This is an opcode sent by the IES API to the ice driver to enable
	 * Inline IPsec support.
	 */
	PEERCHNL_OP_IPSEC_ENABLE = 111,
#define PEERCHNL_OP_IPSEC_ENABLE_VER	1

	/* This is an opcode sent by the IES API to the ice driver to disable
	 * Inline IPsec support.
	 */
	PEERCHNL_OP_IPSEC_DISABLE = 112,
#define PEERCHNL_OP_IPSEC_DISABLE_VER	1
#ifndef EXTERNAL_RELEASE
	/* New opcode entries must always be placed here at the end of the enum
	 * to prevent compatibility issues.
	 * DO NOT exceed 0xFFFF since this value goes into a 16-bit field.
	 */
#endif
};

#ifndef EXTERNAL_RELEASE
/* For switch mode peers that utilize the mailbox for a communication
 * channel, the driver_id should match IDs known to MBX - see the table
 * of Driver IDs in the EAS' Send Message to Peer Driver Admin command
 * section. Peer drivers are expected to set driver_id in their struct
 * ice_peer_drv structure during registration and can be used by the CPK
 * LAN driver to determine the applicable struct ice_peer_drv structure
 * when a mailbox message is received from a peer driver.
 */
#endif
#ifndef ICE_PEER_LAN_DRIVER
#define ICE_PEER_LAN_DRIVER		0
#endif
#ifndef ICE_PEER_INLINECRYPTO_DRIVER
#define ICE_PEER_INLINECRYPTO_DRIVER	1	/* IPSec */
#endif
#ifndef ICE_PEER_SWITCH_DRIVER
#define ICE_PEER_SWITCH_DRIVER		2
#endif
#ifndef ICE_PEER_AE_DRIVER
#define ICE_PEER_AE_DRIVER		3	/* DSI and DSC (DSI config) */
#endif
#ifdef INTERNAL_ONLY
/* Driver ID 4 reserved for ICE_PEER_RDMA_DRIVER */
#endif

/* The Cookie High field in the peer communication channel Mailbox descriptor
 * is an opaque value copied by MBX from the Send Message to Peer Driver
 * command (source) descriptor to the completion of that command and to the
 * Message from Peer Driver event (target) descriptor. This little-endian
 * field is defined by SW to always contain the peerchnl_ops message opcode
 * and sequence number for all peerchnl messages.
 */
struct peerchnl_desc_cookie_high {
	__le16 msg_opcode;
	__le16 seq_num;
};

/* The Cookie Low field (like Cookie High) is an opaque value copied by MBX.
 * It is defined by SW to contain a message-specific version number and
 * direct command data (e.g. virtchnl_p_status_code).
 * The sender must set the version of the opcode it is sending.
 * The receiver must validate the version received matches a known version of
 * the opcode. If the receiver doesn't recognize the version of the opcode,
 * it shall reply with a PEERCHNL_OP_ACK message with the status code
 * PEERCHNL_STATUS_ERR_VER_MISMATCH.
 */
struct peerchnl_desc_cookie_low {
	u8 ver;
	u8 data;
	__le16 reserved;
};

/* peerchnl Mailbox control queue descriptor */
struct peerchnl_mbx_desc {
	__le16 flags;
	__le16 opcode;
	__le16 datalen;

	union {
		/* Send to Peer Driver command - completion return value */
		__le16 cmd_retval;

		/* Msg from Peer Driver event - MBX sets to sender peer ID */
		__le16 event_sender_id;
	} mbx_data;

	/* Opaque message data */
	struct peerchnl_desc_cookie_high cookie_high;
	struct peerchnl_desc_cookie_low cookie_low;

	union {
		/* Send to Peer Driver cmd  - set to ID of destination peer */
		__le32 cmd_peer_id;

		/* Message from Peer Driver event - reserved */
		__le32 event_reserved;
	} param0;

	__le32 reserved;
	__le32 addr_high;	/* High dword of indirect buffer address */
	__le32 addr_low;	/* Low dword of indirect buffer address */
};

#if defined(FW_SUPPORT) || defined(SV_SUPPORT)
PEERCHNL_CHECK_DESC_SIZE(peerchnl_mbx_desc);
#endif /* FW_SUPPORT || SV_SUPPORT */

/* Message data structures. */

/* This is the data structure for all FW-related indirect commands:
 * PEERCHNL_OP_FW_CMD_REQ
 * PEERCHNL_OP_FW_CMD_RESP
 * PEERCHNL_OP_FW_EVENT
 *
 * Note: For PEERCHNL_OP_FW_CMD_REQ, because the potential FW AdminQ command
 * indirect buffer contiguously follows the struct ice_aq_desc structure,
 * the peer driver that initiates this command does not need to set the
 * addr_high/addr_low fields in the last 2 dwords of struct ice_aq_desc
 * for indirect AQ commands.
 * For PEERCHNL_OP_FW_CMD_RESP and PEERCHNL_OP_FW_EVENT, any potential
 * indirect buffer will be located in buf and will be the size specified by
 * datalen in struct ice_aq_desc structure.
 */
struct peerchnl_fw_data {
	struct ice_aq_desc desc;
	u8 buf[1];
};

#define PEERCHNL_MAX_RXQS		2048
#define PEERCHNL_NUM_RXQ_PER_GROUP	32 /* Qs are in blocks of 32 */

/* Q group range: 0-63 */
#define PEERCHNL_MAX_QGROUP (PEERCHNL_MAX_RXQS / PEERCHNL_NUM_RXQ_PER_GROUP)
#define ICE_PEERCHNL_INVAL_QGROUP 0xFFFFFFFF

struct peerchnl_vsi_entry {
	u32 vsi;	/* VSI number (0-767) */
	u8 fn;		/* function number 0-255 for VF, 0-7 for PF */
	u8 pf;		/* 0:VF 1:PF */

	u16 rsvd;
#ifndef EXTERNAL_RELEASE
	/* this is a 64 bit boundary */
#endif

	/* Physical Q group (0..63) indexed by relative group number */
	u32 phys_q_group[PEERCHNL_MAX_QGROUP];
};

struct peerchnl_l2_node_phys_id_req {
	u32 logical_node_id;
	/* Indicates that the L2 node will have pin-based flow control mapped
	 * to it after the IES API unlocks
	 */
#define PEERCHNL_PBFC_STATE_MAPPED 0
	/* Indicates that the L2 node will not have pin-based flow control
	 * mapped to it after the IES API unlocks
	 */
#define PEERCHNL_PBFC_STATE_NOT_MAPPED 1
	u8 pbfc_state;
};

struct peerchnl_l2_node_phys_id_resp {
	u32 phys_node_id;
};

enum peerchnl_wol_wakeup_reason {
	PEERCHNL_WOL_WAKEUP_REASON_POWER_ON = 0,
	PEERCHNL_WOL_WAKEUP_REASON_LINK_STATUS_CHANGE,
	PEERCHNL_WOL_WAKEUP_REASON_MAGIC_PACKET,
	PEERCHNL_WOL_WAKEUP_REASON_MANAGEABILITY,
	PEERCHNL_WOL_WAKEUP_REASON_EMP_RESET
};

struct peerchnl_wol_wakeup_reason_resp {
	enum peerchnl_wol_wakeup_reason wakeup_reason;
};

struct peerchnl_mac_vlan_addr {
	u8 addr[ETH_ALEN];
	u16 vlan_id;
	u8 vlan_valid;
	u8 pad[3];
};

struct peerchnl_ether_addr_list {
	u16 vsi_id;
	u16 num_elements;
	struct peerchnl_mac_vlan_addr list[1];
};

struct peerchnl_add_pre_veb_entry {
	u8 addr[ETH_ALEN];
	u16 vlan_id;
	u8 vlan_valid;
	u8 fn;
	u8 pad[2];
};

struct peerchnl_add_pre_veb_entry_resp {
	u8 mac_addr[ETH_ALEN];
	u16 vlan_id;
	u8 fn;
	u32 rule_id;
};

struct peerchnl_del_pre_veb_entry {
	u32 rule_id;
};

struct peerchnl_add_allowlist_entry {
	u8 fn;
	u32 spi;
	u32 dip[4];
	/* Drop frame if true or redirect to QAT if false. */
	u8 drop;
	/* Congestion domain. For future use. */
	u8 cgd;
	/* 0 for IPv4 table, 1 for IPv6 table. */
	u8 table_id;
	/* Set TC (congestion domain) if true. For future use. */
	u8 set_tc;
	/* 0 for NAT-T unsupported, 1 for NAT-T supported */
	bool is_udp;
	/* NAT-T UDP port number. Only valid in case NAT-T supported */
	u16 udp_port;
};

struct peerchnl_del_allowlist_entry {
	/* 0 for IPv4 table, 1 for IPv6 table. */
	u8 table_id;
	u32 rule_id;
};

struct peerchnl_add_allowlist_entry_resp {
	u32 rule_id;
	u8  fn;
};

struct peerchnl_del_allowlist_entry_resp {
	u8  fn;
};

struct peerchnl_mtu_change {
	u8 lport;
	int new_mtu;
};

struct peerchnl_phy_state {
	u32 lports_map;
	u8 state;
};

enum peerchnl_event_data {
	PEERCHNL_EVENT_DATA_LINK_DOWN = 0,
	PEERCHNL_EVENT_DATA_LINK_UP
};

/* In case of PEERCHNL_EVENT_CRYPTO_ON event_data follows
 * below encoding scheme:
 * bit0: 0 for 1-queue, 1 for 8-queue.
 * bit1: 0 for 32-bit spi, 1 for 24-bit spi.
 */
#define PEERCHNL_EVENT_CRYPTO_ON_EVENT_DATA_8Q		BIT(0)
#define PEERCHNL_EVENT_CRYPTO_ON_EVENT_DATA_24BIT_SPI	BIT(1)

/* PEERCHNL_OP_EVENT indirect command */
enum peerchnl_event_codes {
	PEERCHNL_EVENT_UNKNOWN = 0,
	PEERCHNL_EVENT_ADMIN_LINK_CHANGE,
	PEERCHNL_EVENT_CRYPTO_ON,
	PEERCHNL_EVENT_CRYPTO_OFF,
	PEERCHNL_EVENT_LAG_ADD_PORT,
	PEERCHNL_EVENT_LAG_DEL_PORT,
	PEERCHNL_EVENT_BRIDGE_ADD_PORT,
	PEERCHNL_EVENT_BRIDGE_DEL_PORT,
};

struct peerchnl_event {
	enum peerchnl_event_codes event;
	u32 event_data;
	u32 severity;
#define PEERCHNL_EVENT_SEVERITY_INFO			0
#define PEERCHNL_EVENT_SEVERITY_ATTENTION		1
#define PEERCHNL_EVENT_SEVERITY_ACTION_REQUIRED	2
#define PEERCHNL_EVENT_SEVERITY_CERTAIN_DOOM		255
};

/* PEERCHNL_OP_PORT_STATE_CHANGE indirect command struct */
struct peerchnl_port_state_change {
#ifndef EXTERNAL_RELEASE
	/* must be opcode 0x0607 */
#endif
	struct ice_aq_desc desc;
	struct ice_aqc_get_link_status_data data;
};

#ifndef EXTERNAL_RELEASE
/* FIXME:
 * PEERCHNL_OP_STATS_REQ
 * PEERCHNL_OP_STATS_RESP
 * VF sends this message to request stats for the selected VSI. VF uses
 * the virtchnl_queue_select struct to specify the VSI. The q_id
 * field is ignored by the PF.
 *
 * PF replies with struct eth_stats in an external buffer.
 */
#endif

#ifndef EXTERNAL_RELEASE
/**
 * FIXME: virtchnl_vc_validate_vf_msg
 * @vf: pointer to the VF info
 * @msg: pointer to the msg buffer
 * @msglen: msg length
 * @msghndl: msg handle
 *
 * validate msg
 */
#endif

#ifdef VALIDATE_PEER_MSG_IMPLEMENTED
/**
 * virtchnl_vc_validate_peer_msg
 * @ver: version struct
 * @msg_opcode: command asked to issue
 * @data: direct data
 * @msg: pointer to the msg buffer
 * @msglen: msg length
 *
 * FIXME: someday this will say something useful
 */
static inline int
virtchnl_vc_validate_peer_msg(struct virtchnl_version_info *ver,
			      u16 msg_opcode, u8 data, u8 *msg, u16 msglen)
{
	bool err_msg_format = false;
	int valid_len = 0;

#ifndef EXTERNAL_RELEASE
	/* FIXME: need a caller and a test of implementation */
#endif

	/* Validate message length. */
	switch (msg_opcode) {
	/* These are always errors coming from the VF. */
	case PEERCHNL_OP_EVENT:
	default:
		return -EPERM;
	}

	if ((valid_len != msglen) || (err_msg_format))
		return -EINVAL;

#ifndef EXTERNAL_RELEASE
	/* FIXME: can't return a non-int here */
#endif
	return PEERCHNL_STATUS_SUCCESS;
}
#endif /* VALIDATE_PEER_MSG_IMPLEMENTED */
#endif /*_PEERCHNL_H_*/
