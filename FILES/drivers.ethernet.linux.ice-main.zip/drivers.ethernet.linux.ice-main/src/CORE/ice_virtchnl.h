#ifndef _ICE_VIRTCHNL_H_
#define _ICE_VIRTCHNL_H_

#include <linux/types.h>
#include <linux/bitops.h>
#include <linux/if_ether.h>
#include "virtchnl.h"
#include "ice_vf_lib.h"

/* Restrict number of MAC Addr and VLAN that non-trusted VF can programmed */
#define ICE_MAX_VLAN_PER_VF		8

/* MAC filters: 1 is reserved for the VF's default/perm_addr/LAA MAC, 1 for
 * broadcast, and 16 for additional unicast/multicast filters
 */
#define ICE_MAX_MACADDR_PER_VF		18

/* Maximum number of queue pairs to configure by default for a VF */
#define ICE_MAX_DFLT_QS_PER_VF		16

#ifdef RSS_GLOBAL_LUT_SUPPORT
#define ICE_MAX_RSS_QS_PER_LARGE_VF	64
#endif /* RSS_GLOBAL_LUT_SUPPORT */
#define ICE_MAX_RSS_QS_PER_VF		16

#ifdef ADV_AVF_SUPPORT_FLEX_DESC
/* Max number of flexible descriptor rxdid */
#define ICE_FLEX_DESC_RXDID_MAX_NUM 64
#endif /* ADV_AVF_SUPPORT_FLEX_DESC */

#ifdef ADV_AVF_SUPPORT
#define ICE_DFLT_QUANTA 1024
#define ICE_MAX_QUANTA_SIZE 4096
#define ICE_MIN_QUANTA_SIZE 256
#ifndef EXTERNAL_RELEASE
/* This calculation expression is recommended by CPK_HAS chapter 10.6.6.3 */
#endif
#define calc_quanta_desc(x)	\
	max_t(u16, 12, min_t(u16, 63, ((x + 66) / 132) * 2 + 4))
#endif /*  ADV_AVF_SUPPORT */

#define ICE_VF_UCAST_PROMISC_BITS ICE_PROMISC_UCAST_RX
#define ICE_VF_UCAST_VLAN_PROMISC_BITS	(ICE_PROMISC_UCAST_RX | \
					 ICE_PROMISC_VLAN_RX)

#ifndef EXTERNAL_RELEASE
/* Don't forget to update both virthcnl ops implementations if you add a new
 * op function to this table.
 */
#endif /* !EXTERNAL_RELEASE */
struct ice_virtchnl_ops {
	int (*get_ver_msg)(struct ice_vf *vf, u8 *msg);
	int (*get_vf_res_msg)(struct ice_vf *vf, u8 *msg);
	void (*reset_vf)(struct ice_vf *vf);
	int (*add_mac_addr_msg)(struct ice_vf *vf, u8 *msg);
	int (*del_mac_addr_msg)(struct ice_vf *vf, u8 *msg);
	int (*cfg_qs_msg)(struct ice_vf *vf, u8 *msg);
	int (*ena_qs_msg)(struct ice_vf *vf, u8 *msg);
	int (*dis_qs_msg)(struct ice_vf *vf, u8 *msg);
	int (*request_qs_msg)(struct ice_vf *vf, u8 *msg);
	int (*cfg_irq_map_msg)(struct ice_vf *vf, u8 *msg);
	int (*config_rss_key)(struct ice_vf *vf, u8 *msg);
	int (*config_rss_lut)(struct ice_vf *vf, u8 *msg);
	int (*get_stats_msg)(struct ice_vf *vf, u8 *msg);
	int (*cfg_promiscuous_mode_msg)(struct ice_vf *vf, u8 *msg);
	int (*add_vlan_msg)(struct ice_vf *vf, u8 *msg);
	int (*remove_vlan_msg)(struct ice_vf *vf, u8 *msg);
#ifdef ADV_AVF_SUPPORT_FLEX_DESC
	int (*query_rxdid)(struct ice_vf *vf);
#endif /* ADV_AVF_SUPPORT_FLEX_DESC */
#ifndef NO_RSS_SUPPORT
	int (*get_rss_hena)(struct ice_vf *vf);
	int (*set_rss_hena_msg)(struct ice_vf *vf, u8 *msg);
#endif /* !NO_RSS_SUPPORT */
	int (*ena_vlan_stripping)(struct ice_vf *vf);
	int (*dis_vlan_stripping)(struct ice_vf *vf);
#ifdef ADQ_SUPPORT
#ifdef HAVE_TC_SETUP_CLSFLOWER
	int (*add_qch_msg)(struct ice_vf *vf, u8 *msg);
	int (*add_switch_filter_msg)(struct ice_vf *vf, u8 *msg);
	int (*del_switch_filter_msg)(struct ice_vf *vf, u8 *msg);
	int (*del_qch_msg)(struct ice_vf *vf, u8 *msg);
#endif /* HAVE_TC_SETUP_CLSFLOWER */
#endif /* ADQ_SUPPORT */
#ifdef VF_RDMA_SUPPORT
	int (*rdma_msg)(struct ice_vf *vf, u8 *msg, u16 msglen);
	int (*cfg_rdma_irq_map_msg)(struct ice_vf *vf, u8 *msg);
	int (*clear_rdma_irq_map)(struct ice_vf *vf);
#endif /* VF_RDMA_SUPPORT */
#ifdef DCF_SUPPORT
#ifdef VF_QINQ_SUPPORT
	int (*dcf_vlan_offload_msg)(struct ice_vf *vf, u8 *msg);
#endif /* VF_QINQ_SUPPORT */
	int (*dcf_cmd_desc_msg)(struct ice_vf *vf, u8 *msg, u16 msglen);
	int (*dcf_cmd_buff_msg)(struct ice_vf *vf, u8 *msg, u16 msglen);
	int (*dis_dcf_cap)(struct ice_vf *vf);
	int (*dcf_get_vsi_map)(struct ice_vf *vf);
	int (*dcf_query_pkg_info)(struct ice_vf *vf);
	int (*dcf_config_vf_tc)(struct ice_vf *vf, u8 *msg);
#endif /* DCF_SUPPORT */
#ifdef VIRTCHNL_IPSEC
	int (*ipsec_handle_vc_msg)(struct ice_vf *vf, u8 *msg, u16 msglen);
#endif /* VIRTCHNL_IPSEC */
#ifdef ADV_AVF_SUPPORT
	int (*handle_rss_cfg_msg)(struct ice_vf *vf, u8 *msg, bool add);
	int (*get_qos_caps)(struct ice_vf *vf);
	int (*cfg_q_tc_map)(struct ice_vf *vf, u8 *msg);
	int (*cfg_q_bw)(struct ice_vf *vf, u8 *msg);
	int (*cfg_q_quanta)(struct ice_vf *vf, u8 *msg);
#endif /* ADV_AVF_SUPPORT */
#if defined(FDIR_SUPPORT) && defined(ADV_AVF_SUPPORT)
	int (*add_fdir_fltr_msg)(struct ice_vf *vf, u8 *msg);
	int (*del_fdir_fltr_msg)(struct ice_vf *vf, u8 *msg);
#endif /* FDIR_SUPPORT && ADV_AVF_SUPPORT */
#if defined(DPDK_SUPPORT) || defined(ADV_AVF_SUPPORT)
	int (*flow_sub_fltr_msg)(struct ice_vf *vf, u8 *msg);
	int (*flow_unsub_fltr_msg)(struct ice_vf *vf, u8 *msg);
#endif /* DPDK_SUPPORT || ADV_AVF_SUPPORT */
#ifdef VF_LARGE_NUM_QPAIRS_SUPPORT
	int (*get_max_rss_qregion)(struct ice_vf *vf);
	int (*ena_qs_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*dis_qs_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*map_q_vector_msg)(struct ice_vf *vf, u8 *msg);
#endif /* VF_LARGE_NUM_QPAIRS_SUPPORT */
#ifdef VF_QINQ_SUPPORT
	int (*get_offload_vlan_v2_caps)(struct ice_vf *vf);
	int (*add_vlan_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*remove_vlan_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*ena_vlan_stripping_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*dis_vlan_stripping_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*ena_vlan_insertion_v2_msg)(struct ice_vf *vf, u8 *msg);
	int (*dis_vlan_insertion_v2_msg)(struct ice_vf *vf, u8 *msg);
#endif /* VF_QINQ_SUPPORT */
};

#ifdef ADQ_SUPPORT
/**
 * ice_vc_get_max_chnl_tc_allowed
 * @vf: pointer to the VF info
 *
 * This function returns max channel TC allowed depends upon "driver_caps"
 */
static inline u32 ice_vc_get_max_chnl_tc_allowed(struct ice_vf *vf)
{
	if (vf->driver_caps & VIRTCHNL_VF_OFFLOAD_ADQ_V2)
		return VIRTCHNL_MAX_ADQ_V2_CHANNELS;
	else
		return VIRTCHNL_MAX_ADQ_CHANNELS;
}
#endif /* ADQ_SUPPORT */

#ifdef CONFIG_PCI_IOV
void ice_virtchnl_set_dflt_ops(struct ice_vf *vf);
#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
void ice_virtchnl_set_repr_ops(struct ice_vf *vf);
#endif /* ESWITCH_SUPPORT || BMSM_MODE */
void
ice_vc_vf_broadcast(struct ice_pf *pf, enum virtchnl_ops v_opcode,
		    enum virtchnl_status_code v_retval, u8 *msg, u16 msglen);
void ice_vc_notify_vf_link_state(struct ice_vf *vf);
void ice_vc_notify_link_state(struct ice_pf *pf);
void ice_vc_notify_reset(struct ice_pf *pf);
int
ice_vc_send_msg_to_vf(struct ice_vf *vf, u32 v_opcode,
		      enum virtchnl_status_code v_retval, u8 *msg, u16 msglen);
#ifdef ADV_AVF_SUPPORT
#ifdef FDIR_SUPPORT
bool ice_vc_isvalid_vsi_id(struct ice_vf *vf, u16 vsi_id);
#endif /* FDIR_SUPPORT */
#endif /* ADV_AVF_SUPPORT */
#else /* CONFIG_PCI_IOV */
static inline void ice_virtchnl_set_dflt_ops(struct ice_vf *vf) { }
#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
static inline void ice_virtchnl_set_repr_ops(struct ice_vf *vf) { }
#endif /* ESWITCH_SUPPORT || BMSM_MODE */
static inline void
ice_vc_vf_broadcast(struct ice_pf *pf, enum virtchnl_ops v_opcode,
		    enum virtchnl_status_code v_retval, u8 *msg, u16 msglen)
{
}

static inline void ice_vc_notify_vf_link_state(struct ice_vf *vf) { }
static inline void ice_vc_notify_link_state(struct ice_pf *pf) { }
static inline void ice_vc_notify_reset(struct ice_pf *pf) { }

static inline int
ice_vc_send_msg_to_vf(struct ice_vf *vf, u32 v_opcode,
		      enum virtchnl_status_code v_retval, u8 *msg, u16 msglen)
{
	return -EOPNOTSUPP;
}

#ifdef ADV_AVF_SUPPORT
#ifdef FDIR_SUPPORT
static inline bool ice_vc_isvalid_vsi_id(struct ice_vf *vf, u16 vsi_id)
{
	return 0;
}
#endif /* FDIR_SUPPORT */
#endif /* ADV_AVF_SUPPORT */
#endif /* !CONFIG_PCI_IOV */

#endif /* _ICE_VIRTCHNL_H_ */
