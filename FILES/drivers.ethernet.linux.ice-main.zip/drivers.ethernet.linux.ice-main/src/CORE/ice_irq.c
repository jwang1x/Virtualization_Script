#include "ice.h"
#include "ice_lib.h"
#include "ice_irq.h"

#ifdef PEER_SUPPORT
#ifdef HAVE_PCI_ALLOC_IRQ
static int ice_alloc_and_fill_msix_entries(struct ice_pf *pf, int nvec)
{
	int i;

	pf->msix_entries = (struct msix_entry *)
		kcalloc(nvec, sizeof(*pf->msix_entries), GFP_KERNEL);
	if (!pf->msix_entries)
		return -ENOMEM;

	for (i = 0; i < nvec; i++) {
		pf->msix_entries[i].entry = i;
		pf->msix_entries[i].vector = ice_get_irq_num(pf, i);
	}

	return 0;
}
#endif /* HAVE_PCI_ALLOC_IRQ */
#endif /* PEER_SUPPORT */

#ifndef HAVE_PCI_ALLOC_IRQ
static int ice_alloc_msix_entries(struct ice_pf *pf, u16 num_entries)
{
	u16 i;

	pf->msix_entries = (struct msix_entry *)
		devm_kcalloc(ice_pf_to_dev(pf), num_entries,
			     sizeof(*pf->msix_entries), GFP_KERNEL);
	if (!pf->msix_entries)
		return -ENOMEM;

	for (i = 0; i < num_entries; i++)
		pf->msix_entries[i].entry = i;

	return 0;
}

static void ice_free_msix_entries(struct ice_pf *pf)
{
	devm_kfree(ice_pf_to_dev(pf), pf->msix_entries);
	pf->msix_entries = NULL;
}
#endif /* HAVE_PCI_ALLOC_IRQ */

static void ice_dis_msix(struct ice_pf *pf)
{
#ifdef HAVE_PCI_ALLOC_IRQ
	pci_free_irq_vectors(pf->pdev);
#else
	ice_free_msix_entries(pf);
	pci_disable_msix(pf->pdev);
#endif /* HAVE_PCI_ALLOC_IRQ */
}

static int ice_ena_msix(struct ice_pf *pf, int nvec)
{
#ifdef HAVE_PCI_ALLOC_IRQ
	return pci_alloc_irq_vectors(pf->pdev, ICE_MIN_MSIX, nvec,
				     PCI_IRQ_MSIX);
#else
	int vectors;
	int err;

	err = ice_alloc_msix_entries(pf, nvec);
	if (err)
		return err;

	vectors = pci_enable_msix_range(pf->pdev, pf->msix_entries,
					ICE_MIN_MSIX, nvec);
	if (vectors < 0)
		ice_free_msix_entries(pf);

	return vectors;
#endif /* HAVE_PCI_ALLOC_IRQ */
}

#if defined(SWITCH_MODE) || defined(BMSM_MODE)
static int ice_reserve_vectors(u16 needed, int *v_left, int *v_budget)
{
	if (*v_left < needed)
		return -1;
	*v_budget += needed;
	*v_left -= needed;

	return 0;
}
#endif /* SWITCH_MODE || BMSM_MODE */

#ifndef EXTERNAL_RELEASE
/* enable different amount of msix with different
 * fallback for each device type
 */
#endif /* !EXTERNAL_RELEASE */
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
/**
 * ice_ena_msix_range - request a range of MSI-X vectors from the OS
 * @pf: board private structure
 *
 * Enable msix only if system returns requested number of irqs.
 */
static int ice_ena_msix_range(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);
	int v_left, v_actual, v_budget = 0;
	struct ice_hw *hw = &pf->hw;
	int err = -ENOSPC;
	u16 needed;

	v_left = hw->func_caps.common_cap.num_msix_vectors;

	/* misc handler */
	if (ice_reserve_vectors(1, &v_left, &v_budget))
		goto err;

	/* LAN traffic */
	if (!ice_is_safe_mode(pf)) {
		needed = hw->num_lports * min_t(u16, pf->max_qps,
						(u16)num_online_cpus());
		/* switch VSI has its own queues configuration, different
		 * than PF VSIs (logical ports).
		 */
		needed += min_t(u16, (u16)ICE_SW_VSI_Q_NUM,
				(u16)num_online_cpus());
	} else {
		needed = hw->num_total_ports;
	}

	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_lan_msix = needed;

	/* switch */
	needed = ICE_MAX_SWT_VEC;
	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_swt_msix = needed;

	/* crypto */
	needed = ICE_MAX_CRYPTO_VEC;
	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_crypto_msix = needed;

#ifdef FDIR_SUPPORT
	/* flow director */
	if (test_bit(ICE_FLAG_FD_ENA, pf->flags) &&
	    ice_reserve_vectors(ICE_FDIR_MSIX, &v_left, &v_budget))
		goto err;

#endif /* FDIR_SUPPORT */
	/* AE */
	needed = ICE_MAX_AE_VEC;
	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_ae_msix = needed;

	v_actual = ice_ena_msix(pf, v_budget);
	if (v_actual < 0) {
		err = v_actual;
		goto err;
	} else if (v_actual < v_budget) {
		ice_dis_msix(pf);
		goto err;
	}

	return v_actual;

err:
	dev_err(dev, "Failed to enable MSI-X vectors\n");
	pf->num_lan_msix = 0;
	pf->num_swt_msix = 0;
	pf->num_crypto_msix = 0;
	pf->num_ae_msix = 0;
	return err;
}
#elif defined(BMSM_MODE)
/**
 * ice_ena_msix_range - request a range of MSI-X vectors from the OS
 * @pf: board private structure
 *
 * If enabling max msix fails, check if the number of irqs is greater than
 * minimum value (one irq per port and needed irqs for switch and crypto)
 */
static int ice_ena_msix_range(struct ice_pf *pf)
{
#define V_NON_LAN (ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC + 1) /* 1 for misc */
	struct device *dev = ice_pf_to_dev(pf);
	int v_left, v_actual, v_budget = 0;
	struct ice_hw *hw = &pf->hw;
	int err = -ENOSPC;
	u16 needed;

	v_left = hw->func_caps.common_cap.num_msix_vectors;

	/* misc handler */
	if (ice_reserve_vectors(1, &v_left, &v_budget))
		goto err;

	/* LAN traffic */
	if (!ice_is_safe_mode(pf))
		needed = min_t(int, num_online_cpus() * hw->num_total_ports,
			       v_left);
	else
		needed = hw->num_lports;

	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_lan_msix = needed;

	/* switch */
	needed = ICE_MAX_SWT_VEC;
	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_swt_msix = needed;

	/* crypto */
	needed = ICE_MAX_CRYPTO_VEC;
	if (ice_reserve_vectors(needed, &v_left, &v_budget))
		goto err;
	pf->num_crypto_msix = needed;

	v_actual = ice_ena_msix(pf, v_budget);
	if (v_actual < 0) {
		err = v_actual;
		goto err;
	} else if (v_actual < (hw->num_lports + V_NON_LAN)) {
#ifndef EXTERNAL_RELEASE
		/* at the least, we need num_lports + V_NON_LAN number
		 * of vectors. If we don't have this, disable MSIX and bail
		 */
#endif /* !EXTERNAL_RELEASE */
		ice_dis_msix(pf);
		goto err;
	} else if (v_actual < v_budget) {
		/* reduce number of lan msix to minimum */
		pf->num_lan_msix = hw->num_lports;
	}

	return v_actual;

err:
	dev_err(dev, "Failed to enable MSI-X vectors\n");
	pf->num_lan_msix = 0;
	pf->num_swt_msix = 0;
	pf->num_crypto_msix = 0;
	return err;
}
#else
static void ice_adj_vec_clear(int *src, int size)
{
	int i;

	for (i = 0; i < size; i++)
		src[i] = 0;
}

static void ice_adj_vec_sum(int *dst, int *src, int size)
{
	int i;

	for (i = 0; i < size; i++)
		dst[i] += src[i];
}

#ifdef ADQ_SUPPORT
/*
 * Allow 256 queue pairs for ADQ only if the PF has at least
 * 1024 msix vectors (1 or 2 port NIC).
 */
static int ice_adq_max_qps(struct ice_pf *pf)
{
	if (pf->hw.func_caps.common_cap.num_msix_vectors >= 1024)
		return ICE_ADQ_MAX_QPS;

	return num_online_cpus();
}
#endif /* ADQ_SUPPORT */

/**
 * ice_ena_msix_range - request a range of MSI-X vectors from the OS
 * @pf: board private structure
 *
 * The driver tries to enable best-case scenario MSI-X vectors. If that doesn't
 * succeed than adjust to irqs number returned by kernel.
 *
 * The fall-back logic is described below with each [#] represented needed irqs
 * number for the step. If any of the steps is lower than received number, then
 * return the number of MSI-X. If any of the steps is greater, then check next
 * one. If received value is lower than irqs value in last step return error.
 *
 * Step [0]: Enable the best-case scenario MSI-X vectors.
 *
 * Step [1]: Enable MSI-X vectors with eswitch support disabled
 *
 * Step [2]: Enable MSI-X vectors with the number of vectors reserved for
 * MACVLAN and Scalable IOV support reduced by a factor of 2.
 *
 * Step [3]: Enable MSI-X vectors with the number of vectors reserved for
 * MACVLAN and Scalable IOV support reduced by a factor of 4.
 *
 * Step [4]: Enable MSI-X vectors with MACVLAN and Scalable IOV support
 * disabled.
 *
 * Step [5]: Enable MSI-X vectors with the number of pf->num_lan_msix reduced
 * by a factor of 2 from the previous step (i.e. num_online_cpus() / 2).
 * Also, with the number of pf->num_rdma_msix reduced by a factor of ~2 from the
 * previous step (i.e. num_online_cpus() / 2 + ICE_RDMA_NUM_AEQ_MSIX).
 *
 * Step [6]: Same as step [3], except reduce both by a factor of 4.
 *
 * Step [7]: Enable the bare-minimum MSI-X vectors.
 *
 * Each feature has separate table with needed irqs in each step. Sum of these
 * tables is tracked in adj_vec to show needed irqs in each step. Separate
 * tables are later use to set correct number of irqs for each feature based on
 * choosed step.
 */
static int ice_ena_msix_range(struct ice_pf *pf)
{
#define ICE_ADJ_VEC_STEPS 8
#define ICE_ADJ_VEC_WORST_CASE 0
#define ICE_ADJ_VEC_BEST_CASE (ICE_ADJ_VEC_STEPS - 1)
	int num_cpus = num_online_cpus();
#ifdef RDMA_SUPPORT
	int rdma_adj_vec[ICE_ADJ_VEC_STEPS] = {
		ICE_MIN_RDMA_MSIX,
		num_cpus / 4 > ICE_MIN_RDMA_MSIX ?
			num_cpus / 4 + ICE_RDMA_NUM_AEQ_MSIX :
			ICE_MIN_RDMA_MSIX,
		num_cpus / 2 > ICE_MIN_RDMA_MSIX ?
			num_cpus / 2 + ICE_RDMA_NUM_AEQ_MSIX :
			ICE_MIN_RDMA_MSIX,
		num_cpus > ICE_MIN_RDMA_MSIX ?
			num_cpus + ICE_RDMA_NUM_AEQ_MSIX : ICE_MIN_RDMA_MSIX,
		num_cpus > ICE_MIN_RDMA_MSIX ?
			num_cpus + ICE_RDMA_NUM_AEQ_MSIX : ICE_MIN_RDMA_MSIX,
		num_cpus > ICE_MIN_RDMA_MSIX ?
			num_cpus + ICE_RDMA_NUM_AEQ_MSIX : ICE_MIN_RDMA_MSIX,
		num_cpus > ICE_MIN_RDMA_MSIX ?
			num_cpus + ICE_RDMA_NUM_AEQ_MSIX : ICE_MIN_RDMA_MSIX,
		num_cpus > ICE_MIN_RDMA_MSIX ?
			num_cpus + ICE_RDMA_NUM_AEQ_MSIX : ICE_MIN_RDMA_MSIX,
	};
#endif /* RDMA SUPPORT */
	int lan_adj_vec[ICE_ADJ_VEC_STEPS] = {
		ICE_MIN_LAN_MSIX,
		max_t(int, num_cpus / 4, ICE_MIN_LAN_MSIX),
		max_t(int, num_cpus / 2, ICE_MIN_LAN_MSIX),
		max_t(int, num_cpus, ICE_MIN_LAN_MSIX),
		max_t(int, num_cpus, ICE_MIN_LAN_MSIX),
		max_t(int, num_cpus, ICE_MIN_LAN_MSIX),
		max_t(int, num_cpus, ICE_MIN_LAN_MSIX),
#ifdef ADQ_SUPPORT
		max_t(int, ice_adq_max_qps(pf), ICE_MIN_LAN_MSIX),
#else /* !ADQ_SUPPORT */
		max_t(int, num_cpus, ICE_MIN_LAN_MSIX),
#endif /* ADQ_SUPPORT */
	};
#ifdef FDIR_SUPPORT
	int fdir_adj_vec[ICE_ADJ_VEC_STEPS] = {
		ICE_FDIR_MSIX, ICE_FDIR_MSIX, ICE_FDIR_MSIX,
		ICE_FDIR_MSIX, ICE_FDIR_MSIX, ICE_FDIR_MSIX,
		ICE_FDIR_MSIX, ICE_FDIR_MSIX,
	};
#endif /* FDIR_SUPPORT */
	int adj_vec[ICE_ADJ_VEC_STEPS] = {
		ICE_OICR_MSIX, ICE_OICR_MSIX, ICE_OICR_MSIX,
		ICE_OICR_MSIX, ICE_OICR_MSIX, ICE_OICR_MSIX,
		ICE_OICR_MSIX, ICE_OICR_MSIX,
	};
#ifdef OFFLOAD_MACVLAN_SUPPORT
#ifdef HAVE_NDO_DFWD_OPS
	int macvlan_adj_vec[ICE_ADJ_VEC_STEPS] = {
		0, 0, 0, 0,
		(ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI) / 4,
		(ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI) / 2,
		ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI,
		ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI,
	};
#endif /* OFFLOAD_MACVLAN_SUPPORT */
#endif /* HAVE_NETDEV_SV_DEV */
#ifdef ESWITCH_SUPPORT
	int eswitch_adj_vec[ICE_ADJ_VEC_STEPS] = {
		0, 0, 0, 0, 0, 0, 0,
		ICE_ESWITCH_MSIX,
	};
#endif /* ESWITCH_SUPPORT */
#ifdef SIOV_SUPPORT
	int scalable_adj_vec[ICE_ADJ_VEC_STEPS] = {
		0, 0, 0, 0,
		(ICE_MAX_SCALABLE * ICE_NUM_VF_MSIX_SMALL) / 4,
		(ICE_MAX_SCALABLE * ICE_NUM_VF_MSIX_SMALL) / 2,
		ICE_MAX_SCALABLE * ICE_NUM_VF_MSIX_SMALL,
		ICE_MAX_SCALABLE * ICE_NUM_VF_MSIX_SMALL,
	};
#endif
	struct device *dev = ice_pf_to_dev(pf);
	int adj_step = ICE_ADJ_VEC_BEST_CASE;
	int err = -ENOSPC;
	int v_actual, i;
	int needed = 0;

	needed += ICE_OICR_MSIX;

	needed += lan_adj_vec[ICE_ADJ_VEC_BEST_CASE];
	ice_adj_vec_sum(adj_vec, lan_adj_vec, ICE_ADJ_VEC_STEPS);
#ifdef ESWITCH_SUPPORT

	if (test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags)) {
		needed += eswitch_adj_vec[ICE_ADJ_VEC_BEST_CASE];
		ice_adj_vec_sum(adj_vec, eswitch_adj_vec, ICE_ADJ_VEC_STEPS);
	} else {
		ice_adj_vec_clear(eswitch_adj_vec, ICE_ADJ_VEC_STEPS);
	}
#endif /* ESWITCH_SUPPORT */
#ifdef OFFLOAD_MACVLAN_SUPPORT
#ifdef HAVE_NDO_DFWD_OPS

	if (test_bit(ICE_FLAG_VMDQ_ENA, pf->flags)) {
		needed += macvlan_adj_vec[ICE_ADJ_VEC_BEST_CASE];
		ice_adj_vec_sum(adj_vec, macvlan_adj_vec, ICE_ADJ_VEC_STEPS);
	} else {
		ice_adj_vec_clear(macvlan_adj_vec, ICE_ADJ_VEC_STEPS);
	}
#endif /* OFFLOAD_MACVLAN_SUPPORT */
#endif /* HAVE_NDO_DFWD_OPS */
#ifdef RDMA_SUPPORT

	if (ice_chk_rdma_cap(pf)) {
		needed += rdma_adj_vec[ICE_ADJ_VEC_BEST_CASE];
		ice_adj_vec_sum(adj_vec, rdma_adj_vec, ICE_ADJ_VEC_STEPS);
	} else {
		ice_adj_vec_clear(rdma_adj_vec, ICE_ADJ_VEC_STEPS);
	}
#endif /* RDMA_SUPPORT */
#ifdef FDIR_SUPPORT

	if (test_bit(ICE_FLAG_FD_ENA, pf->flags)) {
		needed += fdir_adj_vec[ICE_ADJ_VEC_BEST_CASE];
		ice_adj_vec_sum(adj_vec, fdir_adj_vec, ICE_ADJ_VEC_STEPS);
	} else {
		ice_adj_vec_clear(fdir_adj_vec, ICE_ADJ_VEC_STEPS);
	}
#endif /* FDIR_SUPPORT */
#ifdef SIOV_SUPPORT

	if (test_bit(ICE_FLAG_SIOV_CAPABLE, pf->flags)) {
		needed += scalable_adj_vec[ICE_ADJ_VEC_BEST_CASE];
		ice_adj_vec_sum(adj_vec, scalable_adj_vec, ICE_ADJ_VEC_STEPS);
	} else {
		ice_adj_vec_clear(scalable_adj_vec, ICE_ADJ_VEC_STEPS);
	}
#endif /* SIOV_SUPPORT */

	v_actual = ice_ena_msix(pf, needed);
	if (v_actual < 0) {
		err = v_actual;
		goto err;
	} else if (v_actual < adj_vec[ICE_ADJ_VEC_WORST_CASE]) {
		ice_dis_msix(pf);
		goto err;
	}

	for (i = ICE_ADJ_VEC_WORST_CASE + 1; i < ICE_ADJ_VEC_STEPS; i++) {
		if (v_actual < adj_vec[i]) {
			adj_step = i - 1;
			break;
		}
	}

	pf->num_lan_msix = lan_adj_vec[adj_step];
#ifdef RDMA_SUPPORT
	pf->num_rdma_msix = rdma_adj_vec[adj_step];
#endif /* RDMA_SUPPORT */
#ifdef ESWITCH_SUPPORT
	if (test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags) &&
	    !eswitch_adj_vec[adj_step]) {
		dev_warn(dev, "Not enough MSI-X for eswitch support, disabling feature\n");
		clear_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);
	}
#endif /* ESWITCH_SUPPORT */
#ifdef OFFLOAD_MACVLAN_SUPPORT
#ifdef HAVE_NDO_DFWD_OPS
	if (test_bit(ICE_FLAG_VMDQ_ENA, pf->flags) &&
	    !macvlan_adj_vec[adj_step]) {
		dev_warn(dev, "Not enough MSI-X for hardware MACVLAN support, disabling feature\n");
		clear_bit(ICE_FLAG_VMDQ_ENA, pf->flags);
	}
#endif /* OFFLOAD_MACVLAN_SUPPORT */
#endif /* HAVE_NDO_DFWD_OPS */
#ifdef ADQ_SUPPORT
	pf->max_adq_qps = lan_adj_vec[adj_step];
#endif /* ADQ_SUPPORT */
#ifdef SIOV_SUPPORT
	if (test_bit(ICE_FLAG_SIOV_CAPABLE, pf->flags) &&
	    !scalable_adj_vec[adj_step]) {
		dev_warn(dev, "Not enough MSI-X for Scalable IOV support, disabling feature\n");
		clear_bit(ICE_FLAG_SIOV_CAPABLE, pf->flags);
	}
#endif
	return v_actual;

err:
	dev_err(dev, "Failed to enable MSI-X vectors\n");
	return  err;
}
#endif /* Switching between different device type */

/**
 * ice_init_interrupt_scheme - Determine proper interrupt scheme
 * @pf: board private structure to initialize
 */
int ice_init_interrupt_scheme(struct ice_pf *pf)
{
	int vectors = ice_ena_msix_range(pf);

	if (vectors < 0)
		return vectors;

#ifdef PEER_SUPPORT
	/* pf->msix_entries is used in idc and needs to be filled on kernel
	 * with new irq alloc API
	 */
#ifdef HAVE_PCI_ALLOC_IRQ
	if (ice_alloc_and_fill_msix_entries(pf, vectors)) {
		ice_dis_msix(pf);
		return -ENOMEM;
	}
#endif /* HAVE_PCI_ALLOC_IRQ */
#endif /* PEER_SUPPORT */
	/* set up vector assignment tracking */
#ifndef EXTERNAL_RELEASE
	/* FIXME: For some reason coccinelle could not handle this transform so
	 * go back to the old and dirty way for now...
	 */
#endif
#ifdef ICE_TDD
	pf->irq_tracker = (struct ice_res_tracker *)
#else
	pf->irq_tracker =
#endif
		devm_kzalloc(ice_pf_to_dev(pf),
			     struct_size(pf->irq_tracker, list, vectors),
			     GFP_KERNEL);
	if (!pf->irq_tracker) {
		ice_dis_msix(pf);
		return -ENOMEM;
	}

	/* populate SW interrupts pool with number of OS granted IRQs. */
	pf->num_avail_sw_msix = (u16)vectors;
	pf->irq_tracker->num_entries = (u16)vectors;
	pf->irq_tracker->end = pf->irq_tracker->num_entries;

	return 0;
}

/**
 * ice_clear_interrupt_scheme - Undo things done by ice_init_interrupt_scheme
 * @pf: board private structure
 */
void ice_clear_interrupt_scheme(struct ice_pf *pf)
{
#ifdef PEER_SUPPORT
#ifdef HAVE_PCI_ALLOC_IRQ
	kfree(pf->msix_entries);
	pf->msix_entries = NULL;

#endif /* PEER_SUPPORT */
#endif /* HAVE_PCI_ALLOC_IRQ */
	ice_dis_msix(pf);

	if (pf->irq_tracker) {
		devm_kfree(ice_pf_to_dev(pf), pf->irq_tracker);
		pf->irq_tracker = NULL;
	}
}

/**
 * ice_get_irq_num - get system irq number based on index from driver
 * @pf: board private structure
 * @idx: driver irq index
 */
int ice_get_irq_num(struct ice_pf *pf, int idx)
{
#ifdef HAVE_PCI_ALLOC_IRQ
	return pci_irq_vector(pf->pdev, idx);
#else
	if (!pf->msix_entries)
		return -EINVAL;

	return pf->msix_entries[idx].vector;
#endif /* HAVE_PCI_ALLOC_IRQ */
}
