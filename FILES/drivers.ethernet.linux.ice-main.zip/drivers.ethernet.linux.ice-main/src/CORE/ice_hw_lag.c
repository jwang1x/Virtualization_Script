#include "ice_lib.h"
#include "ice_hw_lag.h"

/* service ports reserved for LAG usecase */
#define ICE_HW_LAG_PORT_MIN	16
#define ICE_HW_LAG_PORT_MAX	19
#define ICE_HW_LAG_PORT_NUM	(ICE_HW_LAG_PORT_MAX - ICE_HW_LAG_PORT_MIN + 1)

/**
 * ice_hw_lag_nop_handler - no-op Rx handler to disable software LAG
 * @pskb: pointer to skb pointer
 */
static rx_handler_result_t ice_hw_lag_nop_handler(struct sk_buff __always_unused **pskb)
{
	return RX_HANDLER_PASS;
}

#ifndef EXTERNAL_RELEASE
/**
 * Software based link aggregation (bonding/teaming drivers) does not play well with hardware
 * accelerated LAG. As the latter is POR for BMSM disable software based bonding completely.
 * Both bonding and teaming drivers try to register own RX handler which is not possible when there
 * is one registered already.
 */
#endif /* !EXTERNAL_RELEASE */
/**
 * ice_hw_lag_disable_sw_bonding - disable software bonding drivers on netdevice
 * @netdev: netdev structure
 *
 * Disable software bonding by registering stub RX handler
 */
void ice_hw_lag_disable_sw_bonding(struct net_device *netdev)
{
	rtnl_lock();
	netdev_rx_handler_register(netdev, ice_hw_lag_nop_handler, NULL);
	rtnl_unlock();
}

/**
 * ice_hw_lag_get_idx - get LAG struct index from lport number
 * @lag_lport: LAG lport number
 *
 * Returns lag struct index on success, negative on failure
 */
static inline s8 ice_hw_lag_get_idx(u8 lag_lport)
{
	if (lag_lport >= ICE_HW_LAG_PORT_MIN && lag_lport <= ICE_HW_LAG_PORT_MAX)
		return lag_lport - ICE_HW_LAG_PORT_MIN;
	else
		return -1;
}

/**
 * ice_hw_lag_move_cgd - move congestion domain configuration from bonded port to LAG port
 * @pf: board private structure
 * @lag: LAG information structure
 * @pi: port information structure
 *
 * Returns 0 on success, negative on failure
 */
static int ice_hw_lag_move_cgd(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info *pi)
{
	struct device *dev = ice_pf_to_dev(pf);
	int err;

	err = ice_sched_copy_cgd(pi, lag->lag_port, ICE_MAX_CGD_PER_PORT);
	if (err) {
		dev_err(dev, "failed to reapply congestion domain config to LAG port\n");
		return err;
	}

	err = ice_sched_clear_l2_nodes(pi);
	if (err) {
		dev_err(dev, "failed to clear port TC nodes config\n");
		return err;
	}

	return 0;
}

/**
 * ice_hw_lag_create - create LAG netdevice
 * @pf: board private structure
 * @lag: LAG information structure
 *
 * Returns 0 on success, negative on failure
 */
static int ice_hw_lag_create(struct ice_pf *pf, struct ice_hw_lag *lag)
{
	struct ice_vsi *vsi;
	int err;

	err = ice_sched_add_dflt_l2_nodes(lag->lag_port);
	if (err)
		return err;

	err = ice_setup_pf_sw(pf, ice_find_port_info_idx(&pf->hw, lag->lag_port->lport));
	if (err)
		goto err_create_nodes;

	vsi = ice_find_vsi_from_pi_and_type(pf, lag->lag_port, ICE_VSI_PF);
	if (!vsi || !vsi->netdev) {
		err = -EIO;
		goto err_create_nodes;
	}

	lag->lag_port->vf_allowed = true;

	if (test_bit(ICE_VSI_NETDEV_REGISTERED, vsi->state))
		return 0;

	err = register_netdev(vsi->netdev);
	if (err)
		goto err_create_vsi;

	set_bit(ICE_VSI_NETDEV_REGISTERED, vsi->state);
	ice_hw_lag_disable_sw_bonding(vsi->netdev);
	netif_carrier_off(vsi->netdev);
	netif_tx_stop_all_queues(vsi->netdev);

	return 0;

err_create_vsi:
	ice_vsi_release(vsi);
err_create_nodes:
	ice_sched_clear_l2_nodes(lag->lag_port);
	lag->lag_port->vf_allowed = false;

	return err;
}

/**
 * ice_hw_lag_destroy - destroy LAG netdevice
 * @pf: board private structure
 * @lag: LAG information structure
 * @is_reset: true when called during reset preparation
 *
 * Returns 0 on success, negative on failure
 */
static void ice_hw_lag_destroy(struct ice_pf *pf, struct ice_hw_lag *lag, bool is_reset)
{
	struct ice_vsi *vsi;
	struct ice_vf *vf;
	unsigned int bkt;

	lag->lag_port->vf_allowed = false;

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf)
		if (vf->port_assoc == lag->lag_port->lport) {
			vf->port_assoc = 0;
			vf->port_invalid = true;

			if (!is_reset)
				ice_reset_vf(vf, ICE_VF_RESET_LOCK);
		}
	mutex_unlock(&pf->vfs.table_lock);

	vsi = ice_find_vsi_from_pi_and_type(pf, lag->lag_port, ICE_VSI_PF);

	if (vsi) {
		dev_warn(ice_pf_to_dev(pf),
			 "The LAG port has been removed; all VFs bound to this port should be removed\n");
		ice_vsi_release(vsi);
	}

	if (!is_reset) {
		ice_sched_clear_l2_nodes(lag->lag_port);
		ice_deinit_lag_sw(pf, lag->lag_port);
	}
}

/**
 * ice_hw_lag_add_port - add port to LAG
 * @pf: board private structure
 * @lag: LAG information structure
 * @pi: port information structure
 *
 * Returns 0 on success, negative on failure
 */
static int ice_hw_lag_add_port(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info *pi)
{
	struct ice_vf *vf;
	unsigned int bkt;

	if (pi->is_lag_member || pi->is_bridge_member)
		return -EEXIST;

	if (!bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS)) {
		int err = ice_hw_lag_create(pf, lag);

		if (err) {
			dev_err(ice_pf_to_dev(pf), "could not create LAG netdevice\n");
			return err;
		}

		err = ice_hw_lag_move_cgd(pf, lag, pi);
		if (err) {
			ice_hw_lag_destroy(pf, lag, false);
			return err;
		}

		lag->primary_lport = pi->lport;
	}

	pi->vf_allowed = false;
	pi->is_lag_member = true;
	set_bit(pi->lport, lag->ports);

	dev_warn(ice_pf_to_dev(pf),
		 "The port is being add to a LAG; Any VFs bound to this port should be removed and added to the LAG netdev");

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf) {
		if (vf->port_assoc == pi->lport)
			ice_reset_vf(vf, ICE_VF_RESET_LOCK);
	}
	mutex_unlock(&pf->vfs.table_lock);

	return 0;
}

/**
 * ice_hw_lag_del_port - remove port from LAG
 * @pf: board private structure
 * @lag: LAG information structure
 * @pi: port information structure
 *
 * Returns 0 on success, negative on failure
 */
static int ice_hw_lag_del_port(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info *pi)
{
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_port_info *next_pi;
	u8 next_lport, primary_lport;
	int weight, err = 0;

	if (!test_bit(pi->lport, lag->ports))
		return -EINVAL;

	pi->vf_allowed = true;
	pi->is_lag_member = false;
	clear_bit(pi->lport, lag->ports);

	weight = bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS);
	primary_lport = lag->primary_lport;

	if (pi->lport == primary_lport && weight) {
		next_lport = find_first_bit(lag->ports, ICE_NUM_EXTERNAL_PORTS);
		next_pi = ice_find_port_info(&pf->hw, next_lport);
		if (!next_pi)
			goto err_del_port;

		err = ice_hw_lag_move_cgd(pf, lag, next_pi);
		if (err) {
			dev_warn(dev, "congestion domain remap from port %d to LAG port failed\n",
				 next_pi->lport);
			goto err_del_port;
		}

		lag->primary_lport = next_pi->lport;
	}

	if (pi->lport == primary_lport) {
		err = ice_sched_add_dflt_l2_nodes(pi);
		if (err) {
			dev_warn(dev,
				 "failed to recreate default congestion domain nodes on port %d\n",
				 pi->lport);
			goto err_del_port;
		}

		err = ice_sched_set_dflt_cgd_to_tc_map(pi);
		if (err)
			dev_warn(dev, "failed to recreate congestion domain mapping on port %d\n",
				 pi->lport);
	}

err_del_port:
	if (err || !weight)
		ice_hw_lag_destroy(pf, lag, false);

	return err;
}

/**
 * ice_handle_ies_hw_lag_event - handle LAG event send by IES API
 * @pf: board private structure
 * @event: event structure containing LAG event info
 *
 * Returns 0 on success, negative on failure
 */
int ice_handle_ies_hw_lag_event(struct ice_pf *pf, struct peerchnl_event *event)
{
	struct ice_port_info *pi;
	struct ice_hw_lag *lag;
	u16 lport, lag_lport;
	struct device *dev;
	s8 lag_idx;
	int err;

	dev = ice_pf_to_dev(pf);
	lport = event->event_data & 0xFF;
	lag_lport = (event->event_data >> 8);
	pi = ice_find_port_info(&pf->hw, lport);
	lag_idx = ice_hw_lag_get_idx(lag_lport);

	if (!pi || lag_idx < 0)
		return -EINVAL;

	dev_dbg(dev, "Handling LAG event: lport %u, LAG lport %u\n", lport, lag_lport);

	lag = &pf->hw_lag[lag_idx];

	switch (event->event) {
	case PEERCHNL_EVENT_LAG_ADD_PORT:
		err = ice_hw_lag_add_port(pf, lag, pi);
		break;
	case PEERCHNL_EVENT_LAG_DEL_PORT:
		err = ice_hw_lag_del_port(pf, lag, pi);
		break;
	default:
		err = -EINVAL;
	}

	return err;
}

/**
 * ice_hw_lag_init - allocate memory for LAG structs and set default states
 * @pf: board private structure
 *
 * Returns 0 on success, negative on failure
 */
int ice_hw_lag_init(struct ice_pf *pf)
{
	struct device *dev = ice_pf_to_dev(pf);
	struct ice_port_info *pi;
	u8 i;

	pf->hw_lag = (struct ice_hw_lag *)
		devm_kcalloc(dev, ICE_HW_LAG_PORT_NUM, sizeof(*pf->hw_lag), GFP_KERNEL);

	if (!pf->hw_lag)
		return -ENOMEM;

	for (i = ICE_HW_LAG_PORT_MIN; i <= ICE_HW_LAG_PORT_MAX; i++) {
		pi = ice_find_port_info(&pf->hw, i);
		if (!pi) {
			devm_kfree(dev, pf->hw_lag);
			return -EINVAL;
		}

		eth_random_addr(pi->mac.perm_addr);
		pf->hw_lag[ice_hw_lag_get_idx(i)].lag_port = pi;
	}

	return 0;
}

/**
 * ice_hw_lag_deinit - free LAG structs memory
 * @pf: board private structure
 */
inline void ice_hw_lag_deinit(struct ice_pf *pf)
{
	devm_kfree(ice_pf_to_dev(pf), pf->hw_lag);
}

/**
 * ice_hw_lag_clean - clean LAG configuration
 * @pf: board private structure
 *
 * Intended use is to clean all LAG configuration that is not handled by other
 * cleanup routines in process of preparing for aux driver initiated reset
 */
void ice_hw_lag_clean(struct ice_pf *pf)
{
	struct ice_port_info *pi;
	u16 lport;
	int i;

	for (i = 0; i < ICE_HW_LAG_PORT_NUM; i++) {
		struct ice_hw_lag *lag = &pf->hw_lag[i];

		for_each_set_bit(lport, lag->ports, ICE_NUM_EXTERNAL_PORTS) {
			pi = ice_find_port_info(&pf->hw, lport);
			if (pi) {
				pi->vf_allowed = true;
				pi->is_lag_member = false;
			}
		}

		bitmap_zero(lag->ports, ICE_NUM_EXTERNAL_PORTS);
		ice_hw_lag_destroy(pf, lag, true);
	}
}
