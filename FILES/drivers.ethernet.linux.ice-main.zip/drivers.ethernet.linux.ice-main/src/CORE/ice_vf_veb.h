#ifndef _ICE_VF_VEB_H_
#define _ICE_VF_VEB_H_

#define ICE_UNKNOWN_PRE_VEB_ID -1

struct ice_vf;
struct ice_pf;

struct vf_pre_veb_rule {
	u8 mac_addr[ETH_ALEN];
	u16 vlan_id;
	int rule_id;
	bool sent_state;
	spinlock_t list_lock; /* protects Pre-VEB list from race conditions */
	struct list_head head;
};

void ice_vf_del_pre_veb(struct ice_pf *pf, int rule_id);
int
ice_vf_update_pre_veb_status(struct ice_vf *vf, u16 vlan_id,
			     u8 *mac_addr, int rule_id, bool sent_state);
void ice_vf_sync_pre_veb_peer(struct ice_pf *pf);
void ice_vf_free_pre_veb(struct ice_vf *vf);
void ice_vf_send_del_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr);
void ice_vf_send_add_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr);

#endif /* _ICE_VF_VEB_H_ */
