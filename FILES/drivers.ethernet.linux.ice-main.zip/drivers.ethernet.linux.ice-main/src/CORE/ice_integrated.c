#include "ice_main.c"
#include "ice_controlq.c"
#include "ice_common.c"
#include "ice_nvm.c"
#include "ice_switch.c"
#include "ice_sched.c"
#include "ice_base.c"
#include "ice_lib.c"
#include "ice_txrx_lib.c"
#include "ice_txrx.c"
#include "ice_fltr.c"
#include "ice_pf_vsi_vlan_ops.c"
#include "ice_vsi_vlan_ops.c"
#include "ice_vsi_vlan_lib.c"
#include "ice_irq.c"
#ifdef FDIR_SUPPORT
#include "ice_fdir.c"
#include "ice_ethtool_fdir.c"
#ifndef NO_ACL_SUPPORT
#include "ice_acl_main.c"
#endif
#endif /* FDIR_SUPPORT */
#ifdef SIOV_SUPPORT
#if IS_ENABLED(CONFIG_VFIO_MDEV) && defined(HAVE_PASID_SUPPORT)
#include "ice_vdcm.c"
#include "ice_siov.c"
#endif /* CONFIG_VFIO_MDEV && HAVE_PASID_SUPPORT */
#endif /* SIOV_SUPPORT */
#ifdef LM_SUPPORT
#if IS_ENABLED(CONFIG_VFIO_PCI_CORE) && defined(HAVE_LMV1_SUPPORT)
#include "ice_vfio_pci.c"
#include "ice_migration.c"
#endif /* CONFIG_VFIO_PCI_CORE && HAVE_LMV1_SUPPORT */
#endif /* LM_SUPPORT */
#ifndef NO_ACL_SUPPORT
#include "ice_acl.c"
#include "ice_acl_ctrl.c"
#endif /* NO_ACL_SUPPORT */
#include "ice_vlan_mode.c"
#ifdef DDP_SUPPORT
#include "ice_ddp.c"
#endif /* DDP_SUPPORT */
#ifndef NO_FLEXP_SUPPORT
#include "ice_flex_pipe.c"
#include "ice_flow.c"
#if defined(ADV_AVF_SUPPORT) && defined(FDIR_SUPPORT)
#include "ice_parser.c"
#include "ice_imem.c"
#include "ice_pg_cam.c"
#include "ice_metainit.c"
#include "ice_bst_tcam.c"
#include "ice_ptype_mk.c"
#include "ice_mk_grp.c"
#include "ice_proto_grp.c"
#include "ice_flg_rd.c"
#include "ice_xlt_kb.c"
#include "ice_parser_rt.c"
#endif /* ADV_AVF_SUPPORT && FDIR_SUPPORT */
#endif /* NO_FLEXP_SUPPORT */
#ifdef SWITCH_MODE
#include "ice_mbx.c"
#endif /* SWITCH MODE */
#ifdef BMSM_MODE
#include "ice_repr.c"
#include "ice_external_bridge.c"
#include "ice_hw_lag.c"
#endif /* BMSM_MODE */
#ifdef VIRTCHNL_IPSEC
#include "ice_ipsec.c"
#endif /* VIRTCHNL_IPSEC */
#if defined(ESWITCH_SUPPORT) || defined(ADQ_SUPPORT)
#include "ice_tc_lib.c"
#endif /* ESWITCH_SUPPORT || ADQ_SUPPORT */
#ifdef ESWITCH_SUPPORT
#include "ice_eswitch.c"
#include "ice_repr.c"
#endif /* ESWITCH_SUPPORT */
#ifdef LAG_SUPPORT
#include "ice_lag.c"
#endif /* LAG_SUPPORT */
#include "ice_ethtool.c"
#if defined(DEVLINK_SUPPORT)
#if IS_ENABLED(CONFIG_NET_DEVLINK)
#include "ice_devlink.c"
#include "ice_fw_update.c"
#endif /* CONFIG_NET_DEVLINK */
#endif
#ifdef PEER_SUPPORT
#ifndef OLD_IDC_SUPPORT
#include "ice_idc.c"
#else /* OLD_IDC_SUPPORT */
#include "ice_mfd_idc.c"
#endif /* !OLD_IDC_SUPPORT */
#endif
#if IS_ENABLED(CONFIG_DEBUG_FS)
#include "ice_debugfs.c"
#endif
#if IS_ENABLED(CONFIG_PCI_IOV)
#include "ice_virtchnl_allowlist.c"
#ifdef DCF_SUPPORT
#include "ice_dcf.c"
#endif
#if defined(FDIR_SUPPORT) && defined(ADV_AVF_SUPPORT)
#include "ice_virtchnl_fdir.c"
#endif
#if defined(DPDK_SUPPORT) || defined(ADV_AVF_SUPPORT)
#include "ice_virtchnl_fsub.c"
#endif
#include "ice_vf_lib.c"
#ifdef ADQ_SUPPORT
#include "ice_vf_adq.c"
#endif /* ADQ_SUPPORT */
#include "ice_virtchnl.c"
#include "ice_sriov.c"
#include "ice_vf_mbx.c"
#include "ice_vf_vsi_vlan_ops.c"
#ifdef SWITCH_MODE
#include "ice_vf_veb.c"
#endif /* SWITCH_MODE */
#endif
#ifndef NO_PTP_SUPPORT
#if IS_ENABLED(CONFIG_PTP_1588_CLOCK)
#include "ice_ptp_hw.c"
#include "ice_ptp.c"
#endif
#endif /* NO_PTP_SUPPORT */
#ifndef NO_DCB_SUPPORT
#if IS_ENABLED(CONFIG_DCB)
#include "ice_dcb.c"
#include "ice_dcb_nl.c"
#include "ice_dcb_lib.c"
#endif
#endif
#if defined(ARFS_SUPPORT) && defined(FDIR_SUPPORT)
#if IS_ENABLED(CONFIG_RFS_ACCEL)
#include "ice_arfs.c"
#endif
#endif
#ifdef XDP_SUPPORT
#if IS_ENABLED(CONFIG_XDP_SOCKETS)
#include "ice_xsk.c"
#endif
#endif
#include "kcompat.c"
#ifdef DEVLINK_SUPPORT
#if !IS_ENABLED(CONFIG_PLDMFW)
#include "kcompat_pldmfw.c"
#endif
#endif
#if !IS_ENABLED(CONFIG_DIMLIB)
#include "kcompat_dim.c"
#include "kcompat_net_dim.c"
#endif
#ifdef FWLOG_SUPPORT_V2
#include "ice_fwlog.c"
#endif /* FWLOG_SUPPORT_V2 */
#ifdef IEPS_SUPPORT
#include "ice_ieps.c"
#endif /* IEPS_SUPPORT */
#ifdef GNSS_SUPPORT
#include "ice_gnss.c"
#endif /* GNSS_SUPPORT */
