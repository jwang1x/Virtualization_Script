#ifndef EXTERNAL_RELEASE
/* If ICE_TRACEPOINTS_ENABLED is not defined, this include file
 * defines no trace points, and stubs out the wrapper macros so they
 * won't emit any code.
 */
#endif /* !EXTERNAL_RELEASE */
#ifndef ICE_TRACEPOINTS_ENABLED
#ifndef EXTERNAL_RELEASE
/* Note there is another (necessarily different) guard ifdef below for
 * the case where tracepoints are enabled at build time.
 */
#endif
#if !defined(_ICE_TRACE_H_)
#define _ICE_TRACE_H_
/* Linux kernel tracepoints not used in this version of the @DRIVER@ driver. */

#define ice_trace(trace_name, args...)
#define ice_trace_enabled(trace_name) (0)
#endif /* !defined(_ICE_TRACE_H_) */
#else /* ICE_TRACEPOINTS_ENABLED */
#if !IS_ENABLED(CONFIG_TRACEPOINTS) || defined(__CHECKER__)
#ifndef EXTERNAL_RELEASE
/* This is the case where ICE_TRACEPOINTS_ENABLED is enabled in build.mk but
 * the kernel does not have dynamic trace event support.  This is so that we 1)
 * can turn tracepoint stripping on or off from build.mk 2) provide
 * compatibility for older kernels that do not have the required tracepoint
 * macros defined.
 */
#endif /* EXTERNAL_RELEASE */
#if !defined(_ICE_TRACE_H_)
#define _ICE_TRACE_H_
/* If the Linux kernel tracepoints are not available then the ice_trace*
 * macros become nops.
 */

#define ice_trace(trace_name, args...)
#define ice_trace_enabled(trace_name) (0)
#endif /* !defined(_ICE_TRACE_H_) */
#else /* CONFIG_TRACEPOINTS */
/*
 * Modeled on trace-events-sample.h
 */

/*
 * The trace subsystem name for @DRIVER@ will be "@DRIVER@".
 *
 * This file is named ice_trace.h.
 *
 * Since this include file's name is different from the trace
 * subsystem name, we'll have to define TRACE_INCLUDE_FILE at the end
 * of this file.
 */
#undef TRACE_SYSTEM
#ifndef EXTERNAL_RELEASE
/*
 * Recall that the build script replaces @DRIVER@ with ice
 */
#endif
#define TRACE_SYSTEM @DRIVER@

/*
 * See trace-events-sample.h for a detailed description of why this
 * guard clause is different from most normal include files.
 */
#if !defined(_ICE_TRACE_H_) || defined(TRACE_HEADER_MULTI_READ)
#define _ICE_TRACE_H_

#include "ice_txrx.h"
#include <linux/tracepoint.h>

/**
 * ice_trace() enables trace points
 * like:
 *
 * trace_ice_example(args...)
 *
 * ... as:
 *
 * ice_trace(example, args...)
 *
 * ... to resolve to the PF version of the tracepoint without
 * ifdefs, and to allow tracepoints to be disabled entirely at build
 * time.
 *
 * Trace point should always be referred to in the driver via this
 * macro.
 *
 * Similarly, ice_trace_enabled(trace_name) wraps references to
 * trace_ice_<trace_name>_enabled() functions.
 * @trace_name: name of tracepoint
 */
#define _ICE_TRACE_NAME(trace_name) (trace_##@DRIVER@##_##trace_name)
#define ICE_TRACE_NAME(trace_name) _ICE_TRACE_NAME(trace_name)

#define ice_trace(trace_name, args...) ICE_TRACE_NAME(trace_name)(args)

#define ice_trace_enabled(trace_name) ICE_TRACE_NAME(trace_name##_enabled)()

/*
 * This is for events common to PF. Corresponding versions will be named
 * trace_ice_*. The ice_trace() macro above will select the right trace point
 * name for the driver.
 */

/* Begin tracepoints */

#ifndef EXTERNAL_RELEASE
/*
 * We use the build-time replacement of @DRIVER@ here, because
 * token-pasting is problematic (doesn't work) in these tracepoint
 * macros which are redefined several times by trace/define_trace.h.
 *
 * In this example the tracepoint args are the main objects involved
 * at the trace point. Printing these addresses is perhaps not that
 * useful, but the TP_printk() function below could display any
 * interesting field inside these objects instead of or in addition to
 * the object address.  More importantly, passing the whole object's
 * address here means a developer provided probe function (e.g. via
 * BPF or systemtap), which is compiled separately from the tapped
 * function, will have access to the whole object.
 *
 * See CORE/example_tp_bpf.py for an example of a BPF program that
 * accesses the structures in the tracepoint args (of
 * ice_clean_rx_irq, below).
 */
#endif
/* Global tracepoints */
DECLARE_EVENT_CLASS(@DRIVER@_print_msg,
		    TP_PROTO(char *msg),

		    TP_ARGS(msg),

		    TP_STRUCT__entry(__string(msg, msg)),

		    TP_fast_assign(__assign_str(msg, msg);),

		    TP_printk("%s", __get_str(msg))
);

#define DEFINE_PRINT_MSG_EVENT(name) \
DEFINE_EVENT(@DRIVER@_print_msg, name, \
	     TP_PROTO(char *msg), \
	     TP_ARGS(msg))

DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_err);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_warn);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_adminq_msg);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_adminq_desc);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_netdev_err);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_netdev_warn);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_netdev_info);
DEFINE_PRINT_MSG_EVENT(@DRIVER@_print_peer_err);

/* Events related to DIM, q_vectors and ring containers */
DECLARE_EVENT_CLASS(@DRIVER@_rx_dim_template,
		    TP_PROTO(struct ice_q_vector *q_vector, struct dim *dim),
		    TP_ARGS(q_vector, dim),
		    TP_STRUCT__entry(__field(struct ice_q_vector *, q_vector)
				     __field(struct dim *, dim)
				     __string(devname, q_vector->rx.ring->netdev->name)),

		    TP_fast_assign(__entry->q_vector = q_vector;
				   __entry->dim = dim;
				   __assign_str(devname, q_vector->rx.ring->netdev->name);),

		    TP_printk("netdev: %s Rx-Q: %d dim-state: %d dim-profile: %d dim-tune: %d dim-st-right: %d dim-st-left: %d dim-tired: %d",
			      __get_str(devname),
			      __entry->q_vector->rx.ring->q_index,
			      __entry->dim->state,
			      __entry->dim->profile_ix,
			      __entry->dim->tune_state,
			      __entry->dim->steps_right,
			      __entry->dim->steps_left,
			      __entry->dim->tired)
);

DEFINE_EVENT(@DRIVER@_rx_dim_template, @DRIVER@_rx_dim_work,
	     TP_PROTO(struct ice_q_vector *q_vector, struct dim *dim),
	     TP_ARGS(q_vector, dim)
);

DECLARE_EVENT_CLASS(@DRIVER@_tx_dim_template,
		    TP_PROTO(struct ice_q_vector *q_vector, struct dim *dim),
		    TP_ARGS(q_vector, dim),
		    TP_STRUCT__entry(__field(struct ice_q_vector *, q_vector)
				     __field(struct dim *, dim)
				     __string(devname, q_vector->tx.ring->netdev->name)),

		    TP_fast_assign(__entry->q_vector = q_vector;
				   __entry->dim = dim;
				   __assign_str(devname, q_vector->tx.ring->netdev->name);),

		    TP_printk("netdev: %s Tx-Q: %d dim-state: %d dim-profile: %d dim-tune: %d dim-st-right: %d dim-st-left: %d dim-tired: %d",
			      __get_str(devname),
			      __entry->q_vector->rx.ring->q_index,
			      __entry->dim->state,
			      __entry->dim->profile_ix,
			      __entry->dim->tune_state,
			      __entry->dim->steps_right,
			      __entry->dim->steps_left,
			      __entry->dim->tired)
);

DEFINE_EVENT(@DRIVER@_tx_dim_template, @DRIVER@_tx_dim_work,
	     TP_PROTO(struct ice_q_vector *q_vector, struct dim *dim),
	     TP_ARGS(q_vector, dim)
);

/* Events related to a vsi & ring */
DECLARE_EVENT_CLASS(@DRIVER@_tx_template,
		    TP_PROTO(struct ice_ring *ring, struct ice_tx_desc *desc,
			     struct ice_tx_buf *buf),

		    TP_ARGS(ring, desc, buf),
#ifndef EXTERNAL_RELEASE
		    /*
		     * The convention here is to make the first fields in the
		     * TP_STRUCT match the TP_PROTO exactly. This enables the use
		     * of the args struct generated by the tplist tool (from the
		     * bcc-tools package) to be used for those fields. To access
		     * fields other than the tracepoint args will require the
		     * tplist output to be adjusted.
		     */
#endif
		    TP_STRUCT__entry(__field(void *, ring)
				     __field(void *, desc)
				     __field(void *, buf)
				     __string(devname, ring->netdev->name)),

		    TP_fast_assign(__entry->ring = ring;
				   __entry->desc = desc;
				   __entry->buf = buf;
				   __assign_str(devname, ring->netdev->name);),

		    TP_printk("netdev: %s ring: %p desc: %p buf %p", __get_str(devname),
			      __entry->ring, __entry->desc, __entry->buf)
);

#define DEFINE_TX_TEMPLATE_OP_EVENT(name) \
DEFINE_EVENT(@DRIVER@_tx_template, name, \
	     TP_PROTO(struct ice_ring *ring, \
		      struct ice_tx_desc *desc, \
		      struct ice_tx_buf *buf), \
	     TP_ARGS(ring, desc, buf))

DEFINE_TX_TEMPLATE_OP_EVENT(@DRIVER@_clean_tx_irq);
DEFINE_TX_TEMPLATE_OP_EVENT(@DRIVER@_clean_tx_irq_unmap);
DEFINE_TX_TEMPLATE_OP_EVENT(@DRIVER@_clean_tx_irq_unmap_eop);

DECLARE_EVENT_CLASS(@DRIVER@_rx_template,
		    TP_PROTO(struct ice_ring *ring, union ice_32b_rx_flex_desc *desc),

		    TP_ARGS(ring, desc),

		    TP_STRUCT__entry(__field(void *, ring)
				     __field(void *, desc)
				     __string(devname, ring->netdev->name)),

		    TP_fast_assign(__entry->ring = ring;
				   __entry->desc = desc;
				   __assign_str(devname, ring->netdev->name);),

		    TP_printk("netdev: %s ring: %p desc: %p", __get_str(devname),
			      __entry->ring, __entry->desc)
);
DEFINE_EVENT(@DRIVER@_rx_template, @DRIVER@_clean_rx_irq,
	     TP_PROTO(struct ice_ring *ring, union ice_32b_rx_flex_desc *desc),
	     TP_ARGS(ring, desc)
);

DECLARE_EVENT_CLASS(@DRIVER@_rx_indicate_template,
		    TP_PROTO(struct ice_ring *ring, union ice_32b_rx_flex_desc *desc,
			     struct sk_buff *skb),

		    TP_ARGS(ring, desc, skb),

		    TP_STRUCT__entry(__field(void *, ring)
				     __field(void *, desc)
				     __field(void *, skb)
				     __string(devname, ring->netdev->name)),

		    TP_fast_assign(__entry->ring = ring;
				   __entry->desc = desc;
				   __entry->skb = skb;
				   __assign_str(devname, ring->netdev->name);),

		    TP_printk("netdev: %s ring: %p desc: %p skb %p", __get_str(devname),
			      __entry->ring, __entry->desc, __entry->skb)
);

DEFINE_EVENT(@DRIVER@_rx_indicate_template, @DRIVER@_clean_rx_irq_indicate,
	     TP_PROTO(struct ice_ring *ring, union ice_32b_rx_flex_desc *desc,
		      struct sk_buff *skb),
	     TP_ARGS(ring, desc, skb)
);

DECLARE_EVENT_CLASS(@DRIVER@_xmit_template,
		    TP_PROTO(struct ice_ring *ring, struct sk_buff *skb),

		    TP_ARGS(ring, skb),

		    TP_STRUCT__entry(__field(void *, ring)
				     __field(void *, skb)
				     __string(devname, ring->netdev->name)),

		    TP_fast_assign(__entry->ring = ring;
				   __entry->skb = skb;
				   __assign_str(devname, ring->netdev->name);),

		    TP_printk("netdev: %s skb: %p ring: %p", __get_str(devname),
			      __entry->skb, __entry->ring)
);

#define DEFINE_XMIT_TEMPLATE_OP_EVENT(name) \
DEFINE_EVENT(@DRIVER@_xmit_template, name, \
	     TP_PROTO(struct ice_ring *ring, struct sk_buff *skb), \
	     TP_ARGS(ring, skb))

DEFINE_XMIT_TEMPLATE_OP_EVENT(@DRIVER@_xmit_frame_ring);
DEFINE_XMIT_TEMPLATE_OP_EVENT(@DRIVER@_xmit_frame_ring_drop);

DECLARE_EVENT_CLASS(@DRIVER@_tx_tstamp_template,
		    TP_PROTO(struct sk_buff *skb, int idx),

		    TP_ARGS(skb, idx),

		    TP_STRUCT__entry(__field(void *, skb)
				     __field(int, idx)),

		    TP_fast_assign(__entry->skb = skb;
				   __entry->idx = idx;),

		    TP_printk("skb %pK idx %d",
			      __entry->skb, __entry->idx)
);
#define DEFINE_TX_TSTAMP_OP_EVENT(name) \
DEFINE_EVENT(@DRIVER@_tx_tstamp_template, name, \
	     TP_PROTO(struct sk_buff *skb, int idx), \
	     TP_ARGS(skb, idx))

DEFINE_TX_TSTAMP_OP_EVENT(@DRIVER@_tx_tstamp_request);
DEFINE_TX_TSTAMP_OP_EVENT(@DRIVER@_tx_tstamp_complete);
DEFINE_TX_TSTAMP_OP_EVENT(@DRIVER@_tx_tstamp_fw_req);
DEFINE_TX_TSTAMP_OP_EVENT(@DRIVER@_tx_tstamp_fw_done);

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
#if IS_ENABLED(CONFIG_TRACEPOINTS)
#define BUF_SIZE 160
#undef dev_err
#define dev_err(dev, format, ...)					\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, format, ##__VA_ARGS__);		\
	dev_printk(							\
		   KERN_ERR, dev, "%s", print_buf);			\
	ice_trace(print_err, print_buf);				\
} while(0)
#undef dev_warn
#define dev_warn(dev, format, ...)					\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, format, ##__VA_ARGS__);		\
	dev_printk(							\
		   KERN_WARNING, dev, "%s", print_buf);			\
	ice_trace(print_warn, print_buf);				\
} while(0)
#undef netdev_err
#define netdev_err(netdev, format, ...)				\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, format, ##__VA_ARGS__);		\
	netdev_printk(							\
		   KERN_ERR, netdev, "%s", print_buf);			\
	ice_trace(print_netdev_err, print_buf);				\
} while(0)
#undef netdev_info
#define netdev_info(netdev, format, ...)				\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, format, ##__VA_ARGS__);		\
	netdev_printk(							\
		   KERN_INFO, netdev, "%s", print_buf);			\
	ice_trace(print_netdev_info, print_buf);			\
} while(0)
#undef netdev_warn
#define netdev_warn(netdev, format, ...)				\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, format, ##__VA_ARGS__);		\
	netdev_printk(							\
		   KERN_WARNING, netdev, "%s", print_buf);		\
	ice_trace(print_netdev_warn, print_buf);			\
} while(0)
#ifdef pr_err
#undef pr_err
#endif
#define pr_err(fmt, ...)						\
do {									\
	char print_buf[BUF_SIZE];					\
	snprintf(print_buf, BUF_SIZE, fmt, ##__VA_ARGS__);		\
	printk(KERN_ERR "%s", print_buf);				\
	ice_trace(print_peer_err, print_buf);				\
} while(0)
#endif /* IS_ENABLED(CONFIG_TRACEPOINTS) */
#endif /* SWITCH_MODE && !BMSM_MODE */

/* End tracepoints */

#endif /* _ICE_TRACE_H_ */
/* This must be outside ifdef _ICE_TRACE_H */

/* This trace include file is not located in the .../include/trace
 * with the kernel tracepoint definitions, because we're a loadable
 * module.
 */
#undef TRACE_INCLUDE_PATH
#define TRACE_INCLUDE_PATH .
#undef TRACE_INCLUDE_FILE
#define TRACE_INCLUDE_FILE ice_trace
#include <trace/define_trace.h>
#endif /* CONFIG_TRACEPOINTS */
#endif /* ICE_TRACEPOINTS_ENABLED */
