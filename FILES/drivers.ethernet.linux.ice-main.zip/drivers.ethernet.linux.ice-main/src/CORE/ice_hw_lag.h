#ifndef _ICE_HW_LAG_H_
#define _ICE_HW_LAG_H_

#include "ice.h"

struct ice_hw_lag {
	struct ice_port_info *lag_port;
	DECLARE_BITMAP(ports, ICE_NUM_EXTERNAL_PORTS);
	u8 primary_lport;
};

int ice_hw_lag_init(struct ice_pf *pf);
void ice_hw_lag_deinit(struct ice_pf *pf);
void ice_hw_lag_clean(struct ice_pf *pf);
int ice_handle_ies_hw_lag_event(struct ice_pf *pf, struct peerchnl_event *event);
void ice_hw_lag_disable_sw_bonding(struct net_device *netdev);

#endif /* _ICE_HW_LAG_H_ */
