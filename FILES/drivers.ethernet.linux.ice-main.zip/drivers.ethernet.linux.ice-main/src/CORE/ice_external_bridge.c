#include "ice_lib.h"
#include "ice_external_bridge.h"

static struct ice_port_info *ice_bridge_get_br_port(struct ice_pf *pf)
{
	return &pf->hw.port_info[ICE_INTERNAL_PORT_TO_SWITCH];
}

/**
 * ice_bridge_create - create VSI and netdev for external bridge
 * @pf: pointer to an ice_pf instance
 * @br_pi: pointer to port_info struct associated with bridge
 *
 * Returns 0 on success and negative on failure
 */
static int ice_bridge_create(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	struct ice_vsi *vsi;
	int err;

	if (!pf || !br_pi)
		return -EINVAL;

	vsi = ice_find_vsi_from_pi(pf, br_pi);

	if (vsi) {
		dev_warn(ice_pf_to_dev(pf), "VSI for external bridge already exists");
		goto register_netdev;
	}

	err = ice_setup_pf_sw(pf, ice_find_port_info_idx(&pf->hw,
							 br_pi->lport));
	if (err)
		return err;

	/* a VSI for the port should be present now. Get it */
	vsi = ice_find_vsi_from_pi(pf, br_pi);
	if (!vsi)
		return -EIO;

register_netdev:
	if (!vsi->netdev)
		return -EINVAL;

	if (test_bit(ICE_VSI_NETDEV_REGISTERED, vsi->state))
		return 0;

	err = register_netdev(vsi->netdev);
	if (err)
		return err;

	set_bit(ICE_VSI_NETDEV_REGISTERED, vsi->state);
#ifndef NO_HW_LAG_SUPPORT
	ice_hw_lag_disable_sw_bonding(vsi->netdev);
#endif
	netif_carrier_off(vsi->netdev);
	netif_tx_stop_all_queues(vsi->netdev);

	return 0;
}

/**
 * ice_bridge_destroy - destroy VSI and netdev for external bridge
 * @pf: pointer to an ice_pf instance
 * @br_pi: pointer to port_info struct associated with bridge
 *
 * Returns 0 on success and negative on failure
 */
static int ice_bridge_destroy(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	struct ice_vsi *vsi;

	if (!pf || !br_pi)
		return -EINVAL;

	vsi = ice_find_vsi_from_pi(pf, br_pi);

	if (!vsi)
		return 0;

	return ice_vsi_release(vsi);
}

/**
 * ice_bridge_add_port - add port to the bridge
 * @pf: pointer to an ice_pf instance
 * @pi: pointer to port_info struct associated with port
 * @br_pi: pointer to port_info struct associated with bridge port
 *
 * Returns 0 on success and negative on failure
 */
static int
ice_bridge_add_port(struct ice_pf *pf, struct ice_port_info *pi,
		    struct ice_port_info *br_pi)
{
	struct ice_vf *vf;
	unsigned int bkt;
	int weight;

	if (pi->is_bridge_member || pi->is_lag_member)
		return -EEXIST;

	weight = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	if (weight == 0) {
		int err;

		pf->br.first_lport = pi->lport;
		err = ice_sched_copy_cgd(pi, br_pi, 1);
		if (err)
			dev_warn(ice_pf_to_dev(pf), "CGD remap failed!");
	}

	pi->vf_allowed = false;
	pi->is_bridge_member = true;
	set_bit(pi->lport, pf->br.ports);

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf)
		if (vf->port_assoc == pi->lport)
			ice_reset_vf(vf, ICE_VF_RESET_LOCK);
	mutex_unlock(&pf->vfs.table_lock);

	return 0;
}

/**
 * ice_bridge_del_port - del port from the bridge
 * @pf: pointer to an ice_pf instance
 * @pi: pointer to port_info struct associated with port
 * @br_pi: pointer to port_info struct associated with bridge port
 *
 * Returns 0 on success and negative on failure
 */
static int
ice_bridge_del_port(struct ice_pf *pf, struct ice_port_info *pi,
		    struct ice_port_info *br_pi)
{
	struct ice_port_info *next_pi;
	u16 next_lport;
	int weight;

	if (!pi->is_bridge_member)
		return -EINVAL;

	pi->vf_allowed = true;
	pi->is_bridge_member = false;
	clear_bit(pi->lport, pf->br.ports);

	weight = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	if (pi->lport == pf->br.first_lport && weight) {
		int err;

		next_lport = find_first_bit(pf->br.ports,
					    ICE_MAX_PORT_PER_PCI_DEV);
		next_pi = ice_find_port_info(&pf->hw, next_lport);
		if (!next_pi)
			return -EINVAL;

		err = ice_sched_copy_cgd(next_pi, br_pi, 1);
		if (err)
			dev_warn(ice_pf_to_dev(pf), "Congestion Domain remap failed!");

		pf->br.first_lport = next_pi->lport;
	}

	return 0;
}

/**
 * ice_bridge_del_all_ports - del all ports from the bridge
 * @pf: pointer to an ice_pf instance
 * @br_pi: pointer to port_info struct associated with bridge port
 *
 * Returns 0 on success and negative on failure
 */
static int ice_bridge_del_all_ports(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	u16 lport;

	if (!pf || !br_pi)
		return -EINVAL;

	for_each_set_bit(lport, pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV) {
		struct ice_port_info *pi = ice_find_port_info(&pf->hw, lport);
		int err;

		if (!pi)
			return -EINVAL;

		err = ice_bridge_del_port(pf, pi, br_pi);
		if (err)
			return err;
	}

	return 0;
}

/**
 * ice_bridge_clean - cleanup all external bridge configuration
 * @pf: pointer to an ice_pf instance
 */
void ice_bridge_clean(struct ice_pf *pf)
{
	struct ice_port_info *br_pi;
	struct device *dev;
	int err;

	if (!pf)
		return;

	dev = ice_pf_to_dev(pf);
	br_pi = ice_bridge_get_br_port(pf);
	if (!br_pi)
		return;

	err = ice_bridge_del_all_ports(pf, br_pi);
	if (err)
		dev_err(dev, "Failed to remove all ports from the bridge!");

	err = ice_bridge_destroy(pf, br_pi);
	if (err)
		dev_err(dev, "Failed to remove bridge netdev!");
}

/**
 * ice_handle_ies_bridge_event - handle bridge event from IES API
 * @pf: PF that the link event is associated with
 * @event: event structure containing bridge event info
 *
 * Returns 0 on success and negative on failure
 */
int ice_handle_ies_bridge_event(struct ice_pf *pf, struct peerchnl_event *event)
{
	struct ice_port_info *br_pi;
	struct ice_port_info *pi;
	int err = -EINVAL;
	u16 lport, br_id;

	if (!pf || !event)
		return -EINVAL;

	lport = event->event_data & 0xFF;
	br_id = (event->event_data >> 8) & 0xFF;
	br_pi = ice_bridge_get_br_port(pf);
	pi = ice_find_port_info(&pf->hw, lport);

	if (!pi)
		return -EINVAL;

	dev_dbg(ice_pf_to_dev(pf), "Handling bridge event, port ID %u bridge ID %u",
		lport, br_id);

#ifndef EXTERNAL_RELEASE
	/* IES sends event with port 20 as soon as user calls 'create bridge'.
	 * This is a signal to create netdev.
	 * IES 'remove bridge' triggers event with port 20 that means that
	 * netdev should be removed.
	 * Each bridged port should be disabled from VF round robin assignment.
	 */
#endif
	switch (event->event) {
	case PEERCHNL_EVENT_BRIDGE_ADD_PORT:
		if (lport == br_pi->lport)
			err = ice_bridge_create(pf, br_pi);
		else
			err = ice_bridge_add_port(pf, pi, br_pi);
		break;
	case PEERCHNL_EVENT_BRIDGE_DEL_PORT:
		if (lport == br_pi->lport)
			err = ice_bridge_destroy(pf, br_pi);
		else
			err = ice_bridge_del_port(pf, pi, br_pi);
		break;
	default:
		break;
	}

	return err;
}

