#include "ice_ipsec.h"

/**
 * ice_is_vf_ipsec_capable - check if VF is IPSec capable
 * @vf: pointer to the VF info
 */
bool ice_is_vf_ipsec_capable(struct ice_vf *vf)
{
#ifndef BMSM_MODE
	return !!(vf->pf->ipsec_enabled &&
		  (vf->driver_caps & VIRTCHNL_VF_OFFLOAD_INLINE_IPSEC_CRYPTO) &&
		  vf->vf_id <= ICE_MAX_IPSEC_CAPABLE_VF_ID);
#else
	return !!((vf->driver_caps & VIRTCHNL_VF_OFFLOAD_INLINE_IPSEC_CRYPTO) &&
		  vf->vf_id <= ICE_MAX_IPSEC_CAPABLE_VF_ID);
#endif /* !BMSM_MODE */
}

#ifndef OLD_IDC_SUPPORT
/**
 * ice_is_ipsec_registered - check if ipsec peer is registered
 * @ipsec_cdev_info: pointer to ipsec cdev_info struct
 */
static bool ice_is_ipsec_registered(struct iidc_core_dev_info *ipsec_cdev_info)
{
	struct iidc_auxiliary_drv *iadrv;

	if (!ipsec_cdev_info)
		return false;
	device_lock(&ipsec_cdev_info->adev->dev);
	iadrv = ice_get_auxiliary_drv(ipsec_cdev_info);
	device_unlock(&ipsec_cdev_info->adev->dev);

	return (iadrv && iadrv->vc_receive);
}
#else /* OLD_IDC_SUPPORT */
/**
 * ice_is_ipsec_registered - check if ipsec peer is registered
 * @ipsec_peer: pointer to ipsec peer driver struct
 */
static bool ice_is_ipsec_registered(struct ice_peer_obj *ipsec_peer)
{
	return (ipsec_peer && ipsec_peer->peer_ops &&
		ipsec_peer->peer_ops->vc_receive);
}
#endif /* OLD_IDC_SUPPORT */

/**
 * ice_ipsec_send_response_to_vc - send IPSec response to vc
 * @vf: pointer to the VF info
 * @req_id: request ID from vc message
 * @resp: response value to be sent
 */
static int
ice_ipsec_send_response_to_vc(struct ice_vf *vf, u16 req_id, u32 resp)
{
	struct inline_ipsec_msg *msg;
	u16 msg_len;
	int ret;

	msg = (struct inline_ipsec_msg *)
		kzalloc(sizeof(*msg) + sizeof(struct virtchnl_ipsec_resp),
			GFP_KERNEL);
	if (!msg)
		return VIRTCHNL_STATUS_ERR_NO_MEMORY;

	msg->ipsec_opcode = INLINE_IPSEC_OP_RESP;
	msg->req_id = req_id;
	msg->ipsec_data.ipsec_resp->resp = resp;

	msg_len = virtchnl_inline_ipsec_val_msg_len(msg->ipsec_opcode);
	ret = ice_vc_send_msg_to_vf(vf, VIRTCHNL_OP_INLINE_IPSEC,
				    VIRTCHNL_STATUS_ERR_PARAM,
				    (u8 *)msg, msg_len);

	kfree(msg);
	return ret;
}

/**
 * ice_ipsec_handle_vc_msg - process message to the IPSec driver
 * @vf: pointer to the VF
 * @msg: pointer to msg buffer
 * @len: length of the message
 */
int ice_ipsec_handle_vc_msg(struct ice_vf *vf, u8 *msg, u16 len)
{
#ifndef OLD_IDC_SUPPORT
	struct iidc_core_dev_info *ipsec =
		ice_find_cdev_info_by_id(vf->pf, IIDC_IPSEC_ID);
#else /* OLD_IDC_SUPPORT */
	struct ice_peer_obj *ipsec = vf->pf->ipsec_peer;
#endif /* OLD_IDC_SUPPORT */
	int ret;

	if (!ice_is_vf_ipsec_capable(vf)) {
		pr_err("VF %d is not capable of handling IPSec\n", vf->vf_id);
		return VIRTCHNL_STATUS_ERR_NOT_SUPPORTED;
	}

	if (!ice_is_ipsec_registered(ipsec)) {
		pr_err("IPSec peer is not able to receive messages\n");
		ret = VIRTCHNL_STATUS_ERR_NOT_SUPPORTED;
	} else {
#ifndef OLD_IDC_SUPPORT
		struct iidc_auxiliary_drv *iadrv;

		device_lock(&ipsec->adev->dev);
		iadrv = ice_get_auxiliary_drv(ipsec);
		if (iadrv && iadrv->vc_receive) {
			ret = iadrv->vc_receive(ipsec, vf->vf_id, msg, len);
		} else {
			pr_err("IPSec peer is not able to receive messages\n");
			ret = VIRTCHNL_STATUS_ERR_NOT_SUPPORTED;
		}
		device_unlock(&ipsec->adev->dev);
#else /* OLD_IDC_SUPPORT */
		ret = ipsec->peer_ops->vc_receive(ipsec, vf->vf_id, msg, len);
#endif /* OLD_IDC_SUPPORT */
	}

	if (ret) {
		u16 req_id = ((struct inline_ipsec_msg *)msg)->req_id;

		pr_err("Failed to send message to IPSec peer, error %d\n", ret);
		return ice_ipsec_send_response_to_vc(vf, req_id, ret);
	}

	return ice_vc_send_msg_to_vf(vf, VIRTCHNL_OP_INLINE_IPSEC,
				     VIRTCHNL_STATUS_SUCCESS, NULL, 0);
}

/**
 * ice_ipsec_send_vc_unicast_msg - send msg from IPsec drv to one VF through vc
 * @vf: pointer to VF structure
 * @msg: pointer to message start
 * @len: length of the message
 */
int ice_ipsec_send_vc_unicast_msg(struct ice_vf *vf, u8 *msg, u16 len)
{
	return ice_vc_send_msg_to_vf(vf, VIRTCHNL_OP_INLINE_IPSEC,
				     VIRTCHNL_STATUS_SUCCESS, msg, len);
}

/**
 * ice_ipsec_send_vc_broadcast_msg - send msg from IPsec drv to all VFs
 * @pf: pointer to PF structure
 * @msg: pointer to message start
 * @len: length of the message
 */
int ice_ipsec_send_vc_broadcast_msg(struct ice_pf *pf, u8 *msg, u16 len)
{
	struct ice_vf *vf;
	unsigned int bkt;
	int err = 0;

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf) {
		/* Skip inactive and non-IPsec capable VFs */
		if ((!test_bit(ICE_VF_STATE_INIT, vf->vf_states) &&
		     !test_bit(ICE_VF_STATE_ACTIVE, vf->vf_states)) ||
		     !ice_is_vf_ipsec_capable(vf))
			continue;

		err = ice_ipsec_send_vc_unicast_msg(vf, msg, len);

		/* In case of error continue sending the msg to the rest of VFs
		 * but note the error code and return it to IPsec driver.
		 */
		if (err) {
			ice_dev_err_errno(ice_pf_to_dev(pf), err,
					  "Failed to send IPsec msg to VF%d",
					  vf->vf_id);
		}
	}
	mutex_unlock(&pf->vfs.table_lock);

	return err;
}

/**
 * ice_ipsec_send_vc_msg - send msg from IPsec drv to VF through virt chnl
 * @pf: pointer to PF structure
 * @msg: pointer to message start
 * @len: length of the message
 * @vf_id: absolute VF ID
 *
 * vf_id can indicate it is a broadcast msg then we should send the msg
 * to all VFs supporting IPsec
 */
int ice_ipsec_send_vc_msg(struct ice_pf *pf, u8 *msg, u16 len, u32 vf_id)
{
	struct ice_vf *vf;
	int err;

	if (vf_id == VIRTCHNL_IPSEC_BROADCAST_VFID)
		return ice_ipsec_send_vc_broadcast_msg(pf, msg, len);

	vf = ice_get_vf_by_id(pf, vf_id);
	if (!vf)
		return -EINVAL;

#if defined(SWITCH_MODE) && !defined(BMSM_MODE) && !defined(OLD_IDC_SUPPORT)
	if (!ice_is_vf_ipsec_capable(vf)) {
		dev_err(ice_pf_to_dev(pf), "VF %d is not capable of handling IPSec\n",
			vf_id);
		err = -EOPNOTSUPP;
	} else {
		err = ice_ipsec_send_vc_unicast_msg(vf, msg, len);
	}
#else
	err = ice_ipsec_send_vc_unicast_msg(vf, msg, len);
#endif /* SWITCH_MODE && !BMSM_MODE && !OLD_IDC_SUPPORT */
	ice_put_vf(vf);

	return err;
}

#ifndef BMSM_MODE
/**
 * ice_ipsec_ena_dis - Enable/disable Inline IPsec support for PF
 * @pf: Board private structure
 * @enable: bool value to enable or disable Inline IPsec support.
 *
 * Enable or disable Inline IPsec support for PF and reset all the VFs in order
 * to force renegotiation of the Inline IPsec capability.
 *
 * By default, Inline IPsec support is disabled.
 */
void ice_ipsec_ena_dis(struct ice_pf *pf, bool enable)
{
	struct ice_vf *vf;
	unsigned int bkt;

	pf->ipsec_enabled = enable;

	mutex_lock(&pf->vfs.table_lock);
	ice_for_each_vf(pf, bkt, vf)
		ice_reset_vf(vf, ICE_VF_RESET_NOTIFY | ICE_VF_RESET_LOCK);
	mutex_unlock(&pf->vfs.table_lock);
}

#endif /* !BMSM_MODE */
