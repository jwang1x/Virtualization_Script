#ifndef _ICE_QOS_STATIC_CFG_H_
#define _ICE_QOS_STATIC_CFG_H_

#define ICE_MAX_STATIC_TRAFFIC_CLASS 4	/* MAX number of TCs */
					/* allowed for configuration */

struct ice_qos_vf {
	__u8 vf_id;
	__u8 port_num;
	__u16 num_qs[ICE_MAX_STATIC_TRAFFIC_CLASS];
};

static struct ice_qos_vf ice_vfs_qos_config[] = {
	{0, 0, .num_qs = {64, 64, 64, 64}}
};

#endif /* _ICE_QOS_STATIC_CFG_H_ */
