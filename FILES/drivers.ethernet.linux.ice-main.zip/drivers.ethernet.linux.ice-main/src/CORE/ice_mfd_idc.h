#ifndef _ICE_MFD_IDC_H_
#define _ICE_MFD_IDC_H_

#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/dcbnl.h>

#ifndef NO_PTP_SUPPORT
#include <linux/ptp_clock_kernel.h>
#endif

/* This major and minor version represent IDC API version information.
 * During peer driver registration, peer driver specifies major and minor
 * version information (via. peer_driver:ver_info). It gets checked against
 * following defines and if mismatch, then peer driver registration
 * fails and appropriate message gets logged.
 */
#define ICE_PEER_MAJOR_VER		7
#define ICE_PEER_MINOR_VER		1

enum ice_peer_features {
	ICE_PEER_FEATURE_ADK_SUPPORT,
	ICE_PEER_FEATURE_PTP_SUPPORT,
	ICE_PEER_FEATURE_SRIOV_SUPPORT,
	ICE_PEER_FEATURE_PCIIOV_SUPPORT,
	ICE_PEER_FEATURE_NBITS
};

#define ICE_ADK_SUP		0

#ifndef NO_PTP_SUPPORT
#define ICE_PTP_SUP		BIT(ICE_PEER_FEATURE_PTP_SUPPORT)
#else
#define ICE_PTP_SUP		0
#endif /* !NO_PTP_SUPPORT */

#define ICE_SRIOV_SUP		BIT(ICE_PEER_FEATURE_SRIOV_SUPPORT)

#ifdef CONFIG_PCI_IOV
#define ICE_PCIIOV_SUP		BIT(ICE_PEER_FEATURE_PCIIOV_SUPPORT)
#else
#define ICE_PCIIOV_SUP		0
#endif /* CONFIG_PCI_IOV */

#define ICE_IDC_FEATURES (ICE_ADK_SUP | ICE_PTP_SUP | ICE_SRIOV_SUP |\
			  ICE_PCIIOV_SUP)

enum ice_event_type {
	ICE_EVENT_LINK_CHANGE = 0x0,
	ICE_EVENT_MTU_CHANGE,
	ICE_EVENT_TC_CHANGE,
	ICE_EVENT_API_CHANGE,
	ICE_EVENT_MBX_CHANGE,
	ICE_EVENT_NBITS		/* must be last */
};

#ifndef EXTERNAL_RELEASE
/* FIXME: Delete some more res type which are not meant to be consumed */
#endif
enum ice_res_type {
	ICE_INVAL_RES = 0x0,
	ICE_VSI,
	ICE_VEB,
	ICE_EVENT_Q,
	ICE_EGRESS_CMPL_Q,
	ICE_CMPL_EVENT_Q,
	ICE_ASYNC_EVENT_Q,
	ICE_DOORBELL_Q,
	ICE_RDMA_QSETS_TXSCHED,
};

enum ice_peer_reset_type {
	ICE_PEER_PFR = 0,
	ICE_PEER_CORER,
	ICE_PEER_CORER_SW_CORE,
	ICE_PEER_CORER_SW_FULL,
	ICE_PEER_GLOBR,
#ifdef INTERNAL_ONLY
	ICE_PEER_EMPR,
#endif
};

/* reason notified to peer driver as part of event handling */
enum ice_close_reason {
	ICE_REASON_INVAL = 0x0,
	ICE_REASON_HW_UNRESPONSIVE,
	ICE_REASON_INTERFACE_DOWN, /* Administrative down */
	ICE_REASON_PEER_DRV_UNREG, /* peer driver getting unregistered */
	ICE_REASON_PEER_OBJ_UNINIT,
	ICE_REASON_GLOBR_REQ,
	ICE_REASON_CORER_REQ,
	ICE_REASON_EMPR_REQ,
	ICE_REASON_PFR_REQ,
	ICE_REASON_HW_RESET_PENDING,
#ifndef NO_RECOVERY_MODE_SUPPORT
	ICE_REASON_RECOVERY_MODE,
#endif /* !NO_RECOVERY_MODE_SUPPORT */
#ifndef EXTERNAL_RELEASE
	/* FIXME: need to re-evaluate */
#endif
	ICE_REASON_PARAM_CHANGE,
};

/* This information is needed to handle peer driver registration,
 * instead of adding more params to peer_drv_registration function,
 * let's get it thru' peer_drv object.
 */
struct ice_ver_info {
	u16 major;
	u16 minor;
	u64 support;
};

/* Struct to hold per DCB APP info */
struct ice_dcb_app_info {
	u8  priority;
	u8  selector;
	u16 prot_id;
};

struct ice_peer_obj;
struct ice_peer_obj_int;

#define ICE_IDC_MAX_USER_PRIORITY        8
#define ICE_IDC_MAX_APPS		64
#define ICE_IDC_DSCP_NUM_VAL		64

#ifndef NO_PTP_SUPPORT
/* Source timer mode */
enum ice_src_tmr_mode {
	ICE_SRC_TMR_MODE_NANOSECONDS,
	ICE_SRC_TMR_MODE_LOCKED,

	NUM_ICE_SRC_TMR_MODE
};

#define IDC_NUM_PHY_PORTS 20
struct ice_src_timer {
	u32 time_zo;
	u32 time_lo;
	u32 time_hi;
	u32 inc_lo;
	u32 inc_hi;
};

struct ice_port_timer {
	u64 tx_time;
	u64 rx_time;
	u64 sh_inc;
};

struct ice_ptp_timer_info {
	struct ice_src_timer m_timer;
	struct ice_port_timer p_timer[IDC_NUM_PHY_PORTS];
};
#endif /* !NO_PTP_SUPPORT */

#ifdef CONFIG_PCI_IOV
struct ice_vf_caps {
	/* FIXME: */
};

#endif /* CONFIG_PCI_IOV */

/* Struct to hold per RDMA Qset info */
struct ice_rdma_qset_params {
	u32 teid;	/* qset TEID */
	u16 qs_handle; /* RDMA driver provides this */
	u16 vsi_id; /* VSI index */
	u8 tc; /* TC branch the QSet should belong to */
	u8 reserved[3];
};

struct ice_res_base {
	/* Union for future provision e.g. other res_type */
	union {
		struct ice_rdma_qset_params qsets;
	} res;
};

struct ice_res {
	/* Type of resource. Filled by peer driver */
	enum ice_res_type res_type;
	/* Count requested by peer driver */
	u16 cnt_req;

#ifndef EXTERNAL_RELEASE
	/* FIXME: Do we need following 2 variables if so why? */
#endif

	/* Number of resources allocated. Filled in by callee.
	 * Based on this value, caller to fill up "resources"
	 */
	u16 res_allocated;

	/* Unique handle to resources allocated. Zero if call fails.
	 * Allocated by callee and for now used by caller for internal
	 * tracking purpose.
	 */
	u32 res_handle;

	/* Peer driver has to allocate sufficient memory, to accommodate
	 * cnt_requested before calling this function.
	 * Memory has to be zero initialized. It is input/output param.
	 * As a result of alloc_res API, this structures will be populated.
	 */
	struct ice_res_base res[1];
};

struct ice_qos_info {
	u64 tc_ctx;
	u8 rel_bw;
	u8 prio_type;
	u8 egress_virt_up;
	u8 ingress_virt_up;
};

#define IDC_QOS_MODE_VLAN       0x0
#define IDC_QOS_MODE_DSCP       0x1

/* Struct to hold QoS info */
struct ice_qos_params {
	struct ice_qos_info tc_info[IEEE_8021QAZ_MAX_TCS];
	u8 up2tc[ICE_IDC_MAX_USER_PRIORITY];
	u8 vsi_relative_bw;
	u8 vsi_priority_type;
	u32 num_apps;
	u8 pfc_mode;
	u8 dscp_map[ICE_IDC_DSCP_NUM_VAL];
	struct ice_dcb_app_info apps[ICE_IDC_MAX_APPS];
	u8 num_tc;
};

union ice_event_info {
	/* ICE_EVENT_LINK_CHANGE */
	struct {
		struct net_device *lwr_nd;
		u16 vsi_num; /* HW index of VSI corresponding to lwr ndev */
		u8 new_link_state;
		u8 lport;
	} link_info;
	/* ICE_EVENT_MTU_CHANGE */
	u16 mtu;
	/* ICE_EVENT_TC_CHANGE */
	struct ice_qos_params port_qos;
	/* ICE_EVENT_API_CHANGE */
	u8 api_rdy;
	/* ICE_EVENT_MBX_CHANGE */
	u8 mbx_rdy;
	/* ICE_EVENT_CRIT_ERR */
	u32 reg;
};

/* ice_event elements are to be passed back and forth between the ice driver
 * and the peer drivers. They are to be used to both register/unregister
 * for event reporting and to report an event (events can be either ice
 * generated or peer generated).
 *
 * For (un)registering for events, the structure needs to be populated with:
 *   reporter - pointer to the ice_peer_obj struct of the peer (un)registering
 *   type - bitmap with bits set for event types to (un)register for
 *
 * For reporting events, the structure needs to be populated with:
 *   reporter - pointer to peer that generated the event (NULL for ice)
 *   type - bitmap with single bit set for this event type
 *   info - union containing data relevant to this event type
 */
struct ice_event {
	struct ice_peer_obj *reporter;
	DECLARE_BITMAP(type, ICE_EVENT_NBITS);
	union ice_event_info info;
};

/* Following APIs are implemented by ICE driver and invoked by peer drivers */
struct ice_ops {
	/* APIs to allocate resources such as VEB, VSI, Doorbell queues,
	 * completion queues, Tx/Rx queues, etc...
	 */
	int (*alloc_res)(struct ice_peer_obj *peer_obj,
			 struct ice_res *res,
			 int partial_acceptable);
	int (*free_res)(struct ice_peer_obj *peer_obj,
			struct ice_res *res);

	int (*is_vsi_ready)(struct ice_peer_obj *peer_obj, u8 portnum);
	int (*peer_register)(struct ice_peer_obj *peer_obj);
	int (*peer_unregister)(struct ice_peer_obj *peer_obj);
	int (*request_reset)(struct ice_peer_obj *obj,
			     enum ice_peer_reset_type reset_type);

	void (*notify_state_change)(struct ice_peer_obj *obj,
				    struct ice_event *event);

	/* ack_reset_prep is for a peer to notify the ice driver that
	 * the peer has finished prepping for reset (started by a
	 * call to the peer's prep_for_reset API interface.
	 *
	 * This calls primary purpose in the ice flow is to move the
	 * peer's state (internal to ice) from _RESET_PREP to
	 * _PREPPED. Once all peers have ack'd, the ice driver can
	 * ignore any time left on the software timeout wait queue
	 * and proceed with the reset of the reset flow.
	 *
	 * This function is meant to be called on the peer's
	 * individual work queue so that it does not block the
	 * calling of the other peers' interface, or the progression of
	 * the ice driver's flow.
	 */
	void (*ack_reset_prep)(struct ice_peer_obj *obj);

	/* Notification APIs */
	void (*reg_for_notification)(struct ice_peer_obj *obj,
				     struct ice_event *event);
	void (*unreg_for_notification)(struct ice_peer_obj *obj,
				       struct ice_event *event);

	/* QoS API */
	int (*query_sched_tree)(struct ice_peer_obj *obj, void *buf,
				u32 buf_size);
	int (*sbq_rw_reg)(struct ice_peer_obj *obj, void *msg);
#ifndef NO_PTP_SUPPORT
	int (*update_incval)(struct ice_peer_obj *obj,
			     enum ice_time_ref_freq time_ref_freq,
			     enum ice_src_tmr_mode src_tmr_mode);
	int (*get_incval)(struct ice_peer_obj *obj,
			  enum ice_time_ref_freq *time_ref_freq,
			  enum ice_src_tmr_mode *src_tmr_mode);
	int (*match_and_adj)(struct ice_peer_obj *obj,
			     struct ptp_clock_time *at_time,
			     struct ptp_clock_time *offset);
	int (*cfg_1588_clk_out_to_cgu)(struct ice_peer_obj *obj,
				       bool ena, u64 period_ns);
	int (*get_src_phy_tmr_val)(struct ice_peer_obj *obj,
				   struct ice_ptp_timer_info *ts);
#endif /* !NO_PTP_SUPPORT */
	int (*vc_send)(struct ice_peer_obj *peer_obj, u32 vf_id, u8 *msg,
		       u16 len);
};

/* Following APIs are implemented by peer drivers and invoked by ICE driver */
struct ice_peer_ops {
	void (*event_handler)(struct ice_peer_obj *peer_obj,
			      struct ice_event *event);

	/* Why we have 'open' and when it is expected to be called:
	 * 1. symmetric set of API w.r.t close
	 * 2. To be invoked form driver initialization path
	 *     - call peer_driver:open once ice driver is fully initialized
	 * 3. To be invoked upon RESET complete
	 *
	 * Calls to open are performed from ice_finish_init_peer_obj
	 * which is invoked from the service task. This helps keep objects
	 * from having their open called until the ice driver is ready and
	 * has scheduled its service task.
	 */
	int (*open)(struct ice_peer_obj *peer_obj);

	/* If this function ptr is valid, it will be invoked by ice LAN driver
	 * when it receives a SW (ice or peer driver) initiated reset. If
	 * the reset is FW generated, the call to close after the OICR is
	 * received by ice is the only call into the peer.
	 *
	 * Peer driver can choose to not implement this call if those drivers
	 * handle RESET notification via. respective interrupt handler
	 * for OICR (specific vector:misc_interrupt) or if the peer determines
	 * that it does not need to perform advance preparation for the reset.
	 *
	 * After a call to prep_for_reset, the peer's state (internal to ice)
	 * will be set to _PREP_RST until the peer responds with a IDC call to
	 * ack_reset_prep.
	 *
	 * The parameter *reason* is expected to be the type of reset that the
	 * peer should be prepping for.
	 *
	 * The parameter *timeout* is how long (in msecs) the ice driver will
	 * wait for an ACK before proceeding with the rest of the RESET
	 * flow (including calling the peer's close function).
	 */
	void (*prep_for_reset)(struct ice_peer_obj *peer_obj,
			       enum ice_close_reason reason, u16 timeout);

	/* Peer's close function is to be called when the peer needs to be
	 * quiesced. This can be for a variety of reasons (enumerated in the
	 * ice_close_reason enum struct). A call to close will only be
	 * followed by a call to either remove or open. No IDC calls from the
	 * peer should be accepted until it is re-opened.
	 *
	 * The *reason* parameter is the reason for the call to close. This
	 * can be for any reason enumerated in the ice_close_reason struct.
	 * It's primary reason is for the peer's bookkeeping and in case the
	 * peer want to perform any different tasks dictated by the reason.
	 *
	 * In the reset flow, a peer's close will be called on that peer's
	 * individual work queue. This allows all of the peers to have
	 * their closes called and spread the work out over multiple CPU's
	 * so as to not block the progression of the ice driver's
	 * progression.
	 */
	void (*close)(struct ice_peer_obj *peer_obj,
		      enum ice_close_reason reason);

#ifdef CONFIG_PCI_IOV
	int (*vf_reset)(struct ice_peer_obj *peer_obj, u32 vf_id);
	int (*vf_ena)(struct ice_peer_obj *peer_obj, u32 vf_id);
	int (*vf_capability)(struct ice_peer_obj *peer_obj,
			     struct ice_vf_caps *caps);
#endif /* CONFIG_PCI_IOV */
	int (*vc_receive)(struct ice_peer_obj *peer_obj, u32 vf_id, u8 *msg,
			  u16 len);
};

#define ICE_PEER_IPSEC_NAME	"ice_ipsec"
#define ICE_PEER_IPSEC_ID	0x00000012
#define ICE_PEER_SW_NAME	"ice_sw"
#define ICE_PEER_SW_ID		0x00000013
#define ICE_MAX_NUM_PEERS	4

/* The const struct that instantiates peer_obj_id needs to be initialized
 * in the .c with the macro ASSIGN_PEER_INFO.
 * For example:
 * static const struct peer_obj_id peer_obj_ids[] = ASSIGN_PEER_INFO;
 */
struct peer_obj_id {
	char *name;
	int id;
};

#ifndef EXTERNAL_RELEASE
/* we can't have #if checks inside of a define so use a helper define
 * to arrange the struct and allow stripping by unifdef correctly
 * even for TEST_BUILD builds which leave white space after unifdef
 * runs
 */
#endif /* EXTERNAL_RELEASE */
#ifndef ICE_TDD
#define IDC_AE_INFO
#define IDC_IPSEC_INFO \
	{ .name = ICE_PEER_IPSEC_NAME, .id = ICE_PEER_IPSEC_ID },
#define IDC_SWITCH_INFO { .name = ICE_PEER_SW_NAME,    .id = ICE_PEER_SW_ID },
/* this is a list of all possible peers, some are unused but left for clarity */
#define ASSIGN_PEER_INFO	\
{				\
	IDC_AE_INFO		\
	IDC_IPSEC_INFO		\
	IDC_SWITCH_INFO		\
}
#else /* ICE_TDD */
#define ASSIGN_PEER_INFO { {} }
#endif /* ICE_TDD */

#define ice_peer_priv(x) ((x)->peer_priv)

/* structure representing peer_object */
struct ice_peer_obj {
	struct ice_ver_info ver;
	struct pci_dev *pdev; /* PCI device of corresponding to main function */
	/* KVA / Linear address corresponding to BAR0 of underlying
	 * pci_device.
	 */
	u8 __iomem *hw_addr;
	int peer_obj_id;

	int index;

	/* Opaque pointer for peer specific data tracking.  This memory will
	 * be alloc'd and freed by the peer driver and used for private data
	 * accessible only to the specific peer.  It is stored here so that
	 * when this struct is passed to the peer via an IDC call, the data
	 * can be accessed by the peer at that time.
	 * The peers should only retrieve the pointer by the macro:
	 *    ice_peer_priv(struct ice_peer_obj *)
	 */
	void *peer_priv;

	/* Following 'res_start' and 'res_len' are applicable for peer
	 * drivers such as SWITCH, AE, IPSEC. 'res_start' points to dedicated
	 * resources in MEM BAR of main function for peer_object based on
	 * peer_object type
	 */
	u32 res_start;
	u32 res_len;

	/* This will be populated only in case of AE specific peer_object
	 * object since only AE driver will use those data queues
	 * for ADK applications
	 */
	u32 start_txq;
	u32 start_rxq;
	u32 num_txq;
	u32 num_rxq;

	/* Based on peer driver type, this shall point to corresponding MSIx
	 * entries in pf->msix_entries (which were allocated as part of driver
	 * initialization) e.g. for RDMA driver, msix_entries reserved will be
	 * num_online_cpus + 1.
	 */
	u16 msix_count; /* How many vectors are reserved for this device */
	struct msix_entry *msix_entries;

#ifndef EXTERNAL_RELEASE
	/* If needed, please derive "fid" using "pdev" if this is to
	 * be used as BDF (Bus Device Function)
	 * e.g. device = PCI_SLOT(pdev->devfn);
	 *      func = PCI_FUNC(pdev->devfn);
	 */
#endif /* EXTERNAL_RELEASE */
	/* Following struct contains function pointers to be initialized
	 * by ICE driver and called by peer driver
	 */
	const struct ice_ops *ops;

	/* Following struct contains function pointers to be initialized
	 * by peer driver and called by ICE driver
	 */
	const struct ice_peer_ops *peer_ops;

	/* Pointer to peer_drv struct to be populated by peer driver */
	struct ice_peer_drv *peer_drv;
};

struct ice_peer_obj_platform_data {
	struct ice_peer_obj *peer_obj;
};

/* structure representing peer driver
 * Peer driver to initialize those function ptrs and
 * it will be invoked by ICE as part of driver_registration
 * via bus infrastructure
 */
struct ice_peer_drv {
	u16 driver_id;
#ifndef EXTERNAL_RELEASE
	/* For switch mode peers that utilize the mailbox for a communication
	 * channel, the driver_id should match IDs known to MBX - see the table
	 * of Driver IDs in the EAS' Send Message to Peer Driver Admin command
	 * section. Peer drivers are expected to set driver_id in their struct
	 * ice_peer_drv structure during registration and can be used by the ice
	 * LAN driver to determine the applicable struct ice_peer_drv structure
	 * when a mailbox message is received from a peer driver.
	 * RDMA and ADK do not use a mailbox so they can be any other ID.
	 */
#endif
#define ICE_PEER_LAN_DRIVER		0
#define ICE_PEER_INLINECRYPTO_DRIVER	1	/* IPSec */
#define ICE_PEER_SWITCH_DRIVER		2
#define ICE_PEER_AE_DRIVER		3	/* DSI and DSC (DSI cfg) */
#define ICE_PEER_ADK_DRIVER		5

	struct ice_ver_info ver;
	const char *name;

	u16 msg_seq_num;	/* Peer channel message sequence number */
};

/* ICE_AE_ELEMENT_SIZE is the size of ice_aqc_txsched_elem_data
 * in bytes.
 *  4 - parent_teid
 *  4 - node_teid
 *  1 - element_type
 *  1 - valid sections
 *  1 - generic
 *  1 - reserved
 *  4 - cir_bw (2+2)
 *  4 - eir_bw (2+2)
 *  2 - srl_id
 *  2 - reserved2
 */
#define ICE_AE_ELEMENT_SIZE	24

struct ice_sched_tree_elem {
	u8 raw[ICE_AE_ELEMENT_SIZE];
};

struct ice_sched_tree_branch {
	u8 num_elems; /* number of elements in this ports sched tree */
	struct ice_sched_tree_elem *elems;
};

struct ice_sched_tree_port {
	u8 num_branches; /* number of TC level nodes */
	struct ice_sched_tree_elem root; /* root node for this port */
	struct ice_sched_tree_branch *branches;
};

struct ice_sched_tree {
	u8 num_ports; /* number of logical ports on this PF */
	struct ice_sched_tree_port *ports;
};

#endif /* _ICE_MFD_IDC_H_ */
