#ifndef _ICE_IDC_INT_H_
#define _ICE_IDC_INT_H_

#ifndef OLD_IDC_SUPPORT
#include "iidc.h"
#else
#include "ice_mfd_idc.h"

enum ice_peer_obj_state {
	ICE_PEER_OBJ_STATE_INIT,
	ICE_PEER_OBJ_STATE_PROBED,
	ICE_PEER_OBJ_STATE_OPENING,
	ICE_PEER_OBJ_STATE_OPENED,
	ICE_PEER_OBJ_STATE_PREP_RST,
	ICE_PEER_OBJ_STATE_PREPPED,
	ICE_PEER_OBJ_STATE_CLOSING,
	ICE_PEER_OBJ_STATE_CLOSED,
	ICE_PEER_OBJ_STATE_REMOVED,
	ICE_PEER_OBJ_STATE_API_RDY,
	ICE_PEER_OBJ_STATE_NBITS,               /* must be last */
};

enum ice_peer_drv_state {
	ICE_PEER_DRV_STATE_MBX_RDY,
	ICE_PEER_DRV_STATE_NBITS,               /* must be last */
};

struct ice_peer_drv_int {
	struct ice_peer_drv *peer_drv;

	/* States associated with peer driver */
	DECLARE_BITMAP(state, ICE_PEER_DRV_STATE_NBITS);

	/* if this peer_obj is the originator of an event, these are the
	 * most recent events of each type
	 */
	struct ice_event current_events[ICE_EVENT_NBITS];

	u16 msg_seq_num;        /* Peer channel message sequence number */
};

#define ICE_MAX_PEER_NAME 64

struct ice_peer_obj_int {
	struct ice_peer_obj peer_obj;
	struct ice_peer_drv_int *peer_drv_int; /* driver private structure */
	char plat_name[ICE_MAX_PEER_NAME];
	struct ice_peer_obj_platform_data plat_data;

	/* if this peer_obj is the originator of an event, these are the
	 * most recent events of each type
	 */
	struct ice_event current_events[ICE_EVENT_NBITS];
	/* Events a peer has registered to be notified about */
	DECLARE_BITMAP(events, ICE_EVENT_NBITS);

	/* States associated with peer_obj */
	DECLARE_BITMAP(state, ICE_PEER_OBJ_STATE_NBITS);
	struct mutex peer_obj_state_mutex; /* peer_obj state mutex */

	/* per peer workqueue */
	struct workqueue_struct *ice_peer_wq;

	struct work_struct peer_prep_task;
	struct work_struct peer_close_task;

	enum ice_close_reason rst_type;
	u16 swto; /* SW timeout for SW initiated resets */
};

static inline struct
ice_peer_obj_int *peer_to_ice_obj_int(struct ice_peer_obj *peer_obj)
{
	return peer_obj ? container_of(peer_obj, struct ice_peer_obj_int,
				       peer_obj) : NULL;
}

static inline struct
ice_peer_obj *ice_get_peer_obj(struct ice_peer_obj_int *peer_obj_int)
{
	if (peer_obj_int)
		return &peer_obj_int->peer_obj;
	else
		return NULL;
}

int ice_close_peer_for_reset(struct ice_peer_obj_int *peer_obj_int, void *data);
int ice_unroll_peer(struct ice_peer_obj_int *peer_obj_int, void *data);
int ice_unreg_peer_obj(struct ice_peer_obj_int *peer_obj_int, void *data);
int ice_peer_close(struct ice_peer_obj_int *peer_obj_int, void *data);
int ice_peer_check_for_reg(struct ice_peer_obj_int *peer_obj_int, void *data);
int
ice_finish_init_peer_obj(struct ice_peer_obj_int *peer_obj_int, void *data);
struct ice_vf;
struct ice_pf;
int
ice_send_add_pre_veb_to_peer_drv(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr);
int
ice_send_del_pre_veb_to_peer_drv(struct ice_pf *pf, int rule_id);
void ice_peer_sw_clean_cfg(struct ice_pf *pf);
int ice_process_msg_from_peer_drv(struct ice_peer_drv *peer_drv, void *data);
int
ice_send_link_event_to_peers(struct ice_vsi *vsi, struct ice_port_info *pi,
			     bool link_up);
int ice_prep_peer_for_reset(struct ice_peer_obj_int *peer_obj_int, void *data);
struct ice_pf;
void ice_send_vf_reset_to_peers(struct ice_pf *pf, u16 vf_id);
int ice_peer_vf_reset(struct ice_peer_obj_int *peer_obj_int, void *data);
static inline bool ice_validate_peer_obj(struct ice_peer_obj *peer_obj)
{
	struct ice_peer_obj_int *peer_obj_int;
	struct ice_pf *pf;

	if (!peer_obj || !peer_obj->pdev)
		return false;

	if (!peer_obj->peer_ops)
		return false;

	pf = pci_get_drvdata(peer_obj->pdev);
	if (!pf)
		return false;

	peer_obj_int = peer_to_ice_obj_int(peer_obj);
	if (!peer_obj_int)
		return false;

	if (test_bit(ICE_PEER_OBJ_STATE_REMOVED, peer_obj_int->state) ||
	    test_bit(ICE_PEER_OBJ_STATE_INIT, peer_obj_int->state))
		return false;

	return true;
}
#endif /* OLD_IDC_SUPPORT */

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
extern int lan_vf_qps_rsvd;
#endif /* SWITCH_MODE && !BMSM_MODE */
#define ICE_MAX_NUM_AUX		4

struct ice_pf;
#ifndef ICE_TDD
#ifdef MULTI_PEER_SUPPORT
#ifndef OLD_IDC_SUPPORT
void ice_send_event_to_auxs(struct ice_pf *pf, struct iidc_event *event);
#else /* OLD_IDC_SUPPORT */
void ice_send_event_to_auxs(struct ice_pf *pf, struct ice_event *event);
#endif /* OLD_IDC_SUPPORT */
#else
void ice_send_event_to_aux(struct iidc_core_dev_info *cdev_info,
			   struct iidc_event *event);
#endif /* MULTI_PEER_SUPPORT */
#ifndef OLD_IDC_SUPPORT
struct iidc_auxiliary_drv
*ice_get_auxiliary_drv(struct iidc_core_dev_info *cdev_info);
#endif /* OLD_IDC_SUPPORT */
#ifdef LAG_SUPPORT
#ifdef RDMA_SUPPORT
void ice_send_event_to_aux_no_lock(struct iidc_core_dev_info *cdev, void *data);
#endif /* RDMA_SUPPORT */
#endif /* LAG_SUPPORT */

#ifndef SWITCH_MODE
void ice_cdev_info_update_vsi(struct iidc_core_dev_info *cdev_info,
			      struct ice_vsi *vsi);
#endif /* !SWITCH_MODE */
#ifdef MULTI_PEER_SUPPORT
#ifndef OLD_IDC_SUPPORT
int ice_unroll_cdev_info(struct iidc_core_dev_info *cdev_info, void *data);
struct iidc_core_dev_info
*ice_find_cdev_info_by_id(struct ice_pf *pf, int cdev_info_id);
#else /* OLD_IDC_SUPPORT */
int ice_unroll_cdev_info(struct ice_peer_obj *cdev_info, void *data);
#endif /* OLD_IDC_SUPPORT */
#endif /* MULTI_PEER_SUPPORT */
#ifdef BMSM_MODE
struct ice_vf;
void ice_cdev_info_sw_clean_cfg(struct ice_pf *pf);
#ifndef OLD_IDC_SUPPORT
int ice_aux_vf_reset(struct iidc_core_dev_info *cdev_info, void *data);
#else /* OLD_IDC_SUPPORT */
int ice_aux_vf_reset(struct ice_peer_obj *cdev_info, void *data);
#endif /* OLD_IDC_SUPPORT */
#endif
#ifdef SWITCH_MODE
struct ice_pf;
void ice_send_vf_reset_to_auxs(struct ice_pf *pf, u16 vf_id);
#endif /* SWITCH_MODE */
#ifdef VF_RDMA_SUPPORT
void ice_send_vf_reset_to_aux(struct iidc_core_dev_info *cdev_info, u16 vf_id);
bool ice_is_rdma_aux_loaded(struct ice_pf *pf);
#endif /* VF_RDMA_SUPPORT */
#endif /* !ICE_TDD */

#ifdef SWITCH_MODE
#ifdef ADK_SUPPORT
bool ice_is_nd_vis(void);
#ifdef LOOPBACK_MODE
bool ice_is_loopback_mode(void);
#endif /* LOOPBACK_MODE */
#endif /* ADK_SUPPORT */
#ifndef BMSM_MODE
int ice_get_ae_aux_and_lock(struct ice_pf *pf, struct iidc_auxiliary_drv **adrv,
			    struct iidc_core_dev_info **cdev_info);
#endif /* !BMSM_MODE */
#endif /* SWITCH_MODE */
#endif /* !_ICE_IDC_INT_H_ */
