#   SPDX-License-Identifier: GPL-2.0
#   Copyright(c) 2020 Intel Corporation. All rights reserved.

#!/bin/sh

error()
{
	echo "$@"
	exit 1
}

if [ -z "$1" ] ; then
	error "Usage: $0 <outfile>"
fi

touch "$1" || error "Cannot write to file $1"

ICE_SW_BASE_DIR=$(dirname "$0")/..
INFILE=$ICE_SW_BASE_DIR/ice_trace.h
OUTFILE=$1

cp "$INFILE" "$OUTFILE"

sed -i '1,/^\/\* Begin tracepoints \*\/$/d' "$OUTFILE"
sed -i '/^\/\* End tracepoints \*\/$/,$d' "$OUTFILE"
perl -p -i -e 's/__field\((\w+), (\w+)\)/ctf_integer($1, $2, $2)/g' "$OUTFILE"
perl -p -i -e 's/__field\(void \*, (\w+)\)/ctf_integer_hex(void *, $1, $1)/g' "$OUTFILE"
perl -p -i -e 's/__string/ctf_string/g' "$OUTFILE"
perl -p -i -e 's/__dynamic_array\((\w+), (\w+), (\w+)\)/ctf_sequence($1, $2, $2, u32, $3)/g' "$OUTFILE"
perl -p -i -e 's/TP_STRUCT__entry/TP_FIELDS/g' "$OUTFILE"
perl -p -i -e 's/TRACE_EVENT/LTTNG_TRACEPOINT_EVENT/g' "$OUTFILE"
perl -p -i -e 's/DECLARE_EVENT_CLASS/LTTNG_TRACEPOINT_EVENT_CLASS/g' "$OUTFILE"
perl -0777 -p -i -e 's/DEFINE_EVENT\((\w+,[\n\s]+\w+,[\n\s]+TP_PROTO\(.*?\),[\n\s]+TP_ARGS\(.*?\)[\n\s]+)\);/LTTNG_TRACEPOINT_EVENT_INSTANCE($1)/gms' "$OUTFILE"
perl -p -i -e 's/DEFINE_EVENT/LTTNG_TRACEPOINT_EVENT_INSTANCE/g' "$OUTFILE"
perl -p -i -e 's/DEFINE_(\w+)_EVENT\((\w+)\);?/DEFINE_$1_EVENT_TP($2)/g' "$OUTFILE"
perl -0777 -p -i -e 's/,[\n\s]*TP_fast_assign\(.*?^\);/\n)/gms' "$OUTFILE"

cat "$ICE_SW_BASE_DIR/lttng/kmod_header.txt" "$OUTFILE" > "$OUTFILE.tmp"
mv "$OUTFILE.tmp" "$OUTFILE"
