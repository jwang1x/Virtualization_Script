#ifdef DEVLINK_SUPPORT
/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_devlink {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "linux/log2.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/compiler.h>
#include <linux/bitmap.h>
#include <linux/kobject.h>

#include "../src/CORE/ice.h"

#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"

#include "CORE_MOCKS/mock_ice_fw_update.cpp"

#include "CORE_MOCKS/stdmock_ice_devlink.cpp"

#include "../src/CORE/ice_devlink.c"
}
/////////////////////////////////////////////////
using namespace ns_devlink;

TEST_GROUP(allocate_pf)
{
	struct pci_dev pdev;
	struct device *dev;

	TEST_SETUP()
	{
		memset(&pdev, 0, sizeof(pdev));
		dev = &pdev.dev;
	}
};

static const size_t devlink_alloc_size = sizeof(struct devlink) + \
					 sizeof(struct ice_pf);

TEST(allocate_pf, allocate_pf)
{
	u8 __aligned(__alignof__(struct devlink)) alloc_data[devlink_alloc_size] = {};
	struct devlink *devlink = (struct devlink *)alloc_data;
	struct ice_pf *expected_pf = (struct ice_pf *)devlink_priv(devlink);
	struct ice_pf *actual_pf;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(*expected_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

	actual_pf = ice_allocate_pf(dev);
	CHECK_EQUAL(expected_pf, actual_pf);
}

TEST(allocate_pf, allocate_pf_fail_alloc)
{
	struct ice_pf *expected_pf;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue((void *)NULL);

	expected_pf = ice_allocate_pf(dev);
	CHECK_EQUAL((void *)NULL, expected_pf);
}

TEST(allocate_pf, allocate_pf_fail_add_action)
{
	u8 __aligned(__alignof__(struct devlink)) alloc_data[devlink_alloc_size] = {};
	struct devlink *devlink = (struct devlink *)alloc_data;
	struct ice_pf *expected_pf;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(*expected_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink)
		.andReturnValue(-ENOMEM);

	mock().expectOneCall("devlink_free")
		.withParameter("devlink", devlink);

	expected_pf = ice_allocate_pf(dev);
	CHECK_EQUAL((void *)NULL, expected_pf);
}

TEST_GROUP_BASE(devlink, TGN(allocate_pf))
{
	u8 __aligned(__alignof__(struct devlink)) alloc_data[devlink_alloc_size] = {};
	struct netlink_ext_ack *extack;
	struct ice_vsi *vsi_list[2];
	struct devlink *devlink;
	struct ice_vsi main_vsi, vf_vsi;
	struct ice_port_info pi;
	struct ice_pf *pf;
	struct ice_vf vf;
	const u8 lport_num = 0;
	const u8 pf_id = 3;
	const u8 vf_id = 0;

	TEST_SETUP()
	{
		TGN(allocate_pf)::setup();

		memset(alloc_data, 0, sizeof(alloc_data));

		memset(vsi_list, 0, sizeof(vsi_list));
		memset(&main_vsi, 0, sizeof(main_vsi));
		memset(&pi, 0, sizeof(pi));
		memset(&vf, 0, sizeof(vf));
		memset(&vf_vsi, 0, sizeof(vf_vsi));

		extack = NULL;

		devlink = (struct devlink *)alloc_data;
		pf = (struct ice_pf *)devlink_priv(devlink);

		pf->pdev = &pdev;
		pf->hw.pf_id = pf_id;

		pf->vsi = vsi_list;
		vsi_list[0] = &main_vsi;
		main_vsi.idx = 0;
		pf->hw.port_info = &pi;
		pi.lport = lport_num;
		main_vsi.port_info = &pi;

		vf.vf_id = vf_id;
		vf.lan_vsi_idx = 1;
		vf_vsi.idx = vf.lan_vsi_idx;
		vf.pf = pf;
		vsi_list[1] = &vf_vsi;
		pf->hw.bus.func = 0;
	}

#ifdef ESWITCH_SUPPORT
	void expect_devlink_port_attrs_set_vf()
	{
		struct devlink_port_attrs expected = {};

		expected.flavour = DEVLINK_PORT_FLAVOUR_PCI_VF;
		expected.pci_vf.pf = pf->hw.bus.func;
		expected.pci_vf.vf = vf.vf_id;

		mock().expectOneCall("devlink_port_attrs_set")
			.withParameter("devlink_port", &vf.devlink_port)
			.withParameter("attrs", (u8 *)&expected, sizeof(expected));
	}

	MockExpectedCall& expect_devlink_port_register_vf()
	{
		return mock().expectOneCall("devlink_port_register")
			.withParameter("devlink", devlink)
			.withParameter("devlink_port", &vf.devlink_port)
			.withParameter("port_index", vf_vsi.idx);
	}
#endif /* ESWITCH_SUPPORT */

#ifndef SWITCH_MODE
	void expect_devlink_port_attrs_set_pf()
	{
		struct devlink_port_attrs expected = {};
		struct devlink_port *devlink_port;

		expected.flavour = DEVLINK_PORT_FLAVOUR_PHYSICAL;
		expected.phys.port_number = lport_num;
		devlink_port = &pf->devlink_port;

		mock().expectOneCall("devlink_port_attrs_set")
			.withParameter("devlink_port", devlink_port)
			.withParameter("attrs", (u8 *)&expected, sizeof(expected));
	}

	MockExpectedCall& expect_devlink_port_register_pf()
	{
		struct devlink_port *devlink_port;

		devlink_port = &pf->devlink_port;

		return mock().expectOneCall("devlink_port_register")
			.withParameter("devlink", devlink)
			.withParameter("devlink_port", devlink_port)
			.withParameter("port_index", main_vsi.idx);
	}
#endif /* !SWITCH_MODE */
};

TEST(devlink, devlink_register)
{
	mock().expectOneCall("devlink_set_features")
		.withParameter("devlink", devlink)
		.withParameter("features", DEVLINK_F_RELOAD);

	mock().expectOneCall("devlink_register")
		.withParameter("devlink", devlink);

	ice_devlink_register(pf);
}

TEST(devlink, devlink_unregister)
{
	mock().expectOneCall("devlink_unregister")
		.withParameter("devlink", devlink);

	ice_devlink_unregister(pf);
}

TEST(devlink, devlink_register_params)
{
	mock().expectOneCall("devlink_params_register")
		.withParameter("devlink", devlink)
		.withParameter("params", ice_devlink_params)
		.withParameter("params_count", ARRAY_SIZE(ice_devlink_params));

	ice_devlink_register_params(pf);
}

TEST(devlink, devlink_unregister_params)
{
	mock().expectOneCall("devlink_params_unregister")
		.withParameter("devlink", devlink)
		.withParameter("params", ice_devlink_params)
		.withParameter("params_count", ARRAY_SIZE(ice_devlink_params));

	ice_devlink_unregister_params(pf);
}

#ifdef ESWITCH_SUPPORT
TEST(devlink, devlink_create_port_vf)
{
	int err;

	expect_devlink_port_attrs_set_vf();
	expect_devlink_port_register_vf();

	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", &vf)
		.andReturnValue(&vf_vsi);
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pf->pdev)
		.andReturnValue(0);

	err = ice_devlink_create_vf_port(&vf);
	CHECK_EQUAL(0, err);
}

TEST(devlink, devlink_create_port_vf_register_fails)
{
	int err;

	expect_devlink_port_attrs_set_vf();
	expect_devlink_port_register_vf()
		.andReturnValue(-ENODEV);

	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", &vf)
		.andReturnValue(&vf_vsi);
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pf->pdev)
		.andReturnValue(0);

	err = ice_devlink_create_vf_port(&vf);
	CHECK_EQUAL(-ENODEV, err);
}

TEST(devlink, devlink_destroy_port_vf)
{
	mock().expectOneCall("devlink_port_type_clear")
		.withParameter("devlink_port", &vf.devlink_port);

	mock().expectOneCall("devlink_port_unregister")
		.withParameter("devlink_port", &vf.devlink_port);

	ice_devlink_destroy_vf_port(&vf);
}
#endif /* ESWITCH_SUPPORT */

#ifndef SWITCH_MODE
TEST(devlink, devlink_create_port_pf)
{
	int err;

	expect_devlink_port_attrs_set_pf();
	expect_devlink_port_register_pf();

	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pf->pdev)
		.andReturnValue(0);

	err = ice_devlink_create_pf_port(pf);

	CHECK_EQUAL(0, err);

}

TEST(devlink, devlink_create_port_pf_register_fails)
{
	int err;

	expect_devlink_port_attrs_set_pf();
	expect_devlink_port_register_pf()
		.andReturnValue(-ENODEV);

	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pf->pdev)
		.andReturnValue(0);

	err = ice_devlink_create_pf_port(pf);

	CHECK_EQUAL(-ENODEV, err);
}

TEST(devlink, devlink_destroy_port_pf)
{

	mock().expectOneCall("devlink_port_type_clear")
		.withParameter("devlink_port", &pf->devlink_port);

	mock().expectOneCall("devlink_port_unregister")
		.withParameter("devlink_port", &pf->devlink_port);

	ice_devlink_destroy_pf_port(pf);
}
#endif /* !SWITCH_MODE */

static u64 fake_pci_get_dsn(struct pci_dev *dev)
{
	if (mock().hasData("pci_dsn"))
		return *((u64 *)mock().getData("pci_dsn").getObjectPointer());
	else
		return 0;
}

static enum ice_status
fake_ice_read_pba_string(struct ice_hw *hw, u8 *pba_num, u32 pba_num_size)
{
	if (mock().hasData("pba_string"))
		strlcpy((char *)pba_num, mock().getData("pba_string").getStringValue(), pba_num_size);

	return ICE_SUCCESS;
}

static enum ice_status
fake_ice_discover_dev_caps(struct ice_hw *hw, struct ice_hw_dev_caps *dev_caps)
{
	if (mock().hasData("dev_caps"))
		memcpy(dev_caps, mock().getData("dev_caps").getObjectPointer(), sizeof(*dev_caps));

	return ICE_SUCCESS;
}

static enum ice_fw_modes fake_ice_get_fw_mode(struct ice_hw *hw)
{
	if (mock().hasData("fw_mode"))
		return (enum ice_fw_modes)mock().getData("fw_mode").getIntValue();
	else
		return ICE_FW_MODE_NORMAL;
}

TEST_GROUP_BASE(info_get, TGN(devlink))
{
	detour_function *pci_get_dsn_detour, *read_pba_string_detour, *dev_caps_detour, *get_fw_mode;
	struct ice_hw_dev_caps dev_caps;
	struct devlink_info_req req;
	struct ice_hw *hw;

	TEST_SETUP()
	{
		TGN(devlink)::setup();

		memset(&req, 0, sizeof(req));
		memset(&dev_caps, 0, sizeof(dev_caps));

		hw = &pf->hw;

		mock().setDataObject("dev_caps", "struct ice_hw_dev_caps", &dev_caps);

		ALLOC_NEW_MOCK(pci_get_dsn_detour, pci_get_dsn, fake_pci_get_dsn);
		ALLOC_NEW_MOCK(read_pba_string_detour, ice_read_pba_string, fake_ice_read_pba_string);
		ALLOC_NEW_MOCK(dev_caps_detour, ice_discover_dev_caps, fake_ice_discover_dev_caps);
		ALLOC_NEW_MOCK(get_fw_mode, ice_get_fw_mode, fake_ice_get_fw_mode);
	}

	TEST_TEARDOWN()
	{
		DELETE_MOCK(pci_get_dsn_detour);
		DELETE_MOCK(read_pba_string_detour);
		DELETE_MOCK(dev_caps_detour);
		DELETE_MOCK(get_fw_mode);
	}
};

TEST(info_get, recovery_mode_not_supported)
{
	int err;

	mock().setData("fw_mode", ICE_FW_MODE_REC);

	err = ice_devlink_info_get(devlink, &req, extack);
	CHECK_EQUAL(-EOPNOTSUPP, err);
};

TEST(info_get, basic_info_get)
{
	u64 pci_dsn;
	int err;

	/*** Driver Name ***/

	mock().expectOneCall("devlink_info_driver_name_put")
		.withParameter("req", &req)
		.withParameter("name", KBUILD_MODNAME);

	/*** PCI Serial Number ***/

	pci_dsn = 0x0102030405060708;
	mock().setDataObject("pci_dsn", "u64 *", &pci_dsn);

	mock().expectOneCall("devlink_info_serial_number_put")
		.withParameter("req", &req)
		.withParameter("sn", "01-02-03-04-05-06-07-08");

	/*** Product Board Assembly identifier ***/

	mock().setData("pba_string", "K65390-000");

	mock().expectOneCall("devlink_info_version_fixed_put")
		.withParameter("req", &req)
		.withParameter("version_name", DEVLINK_INFO_VERSION_GENERIC_BOARD_ID)
		.withParameter("version_value", "K65390-000");

	/*** Management firmware version ***/

	mock().expectOneCall("ice_wait_for_reset")
		.andReturnValue(0);
	hw->fw_maj_ver = 1;
	hw->fw_min_ver = 16;
	hw->fw_patch = 10;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", DEVLINK_INFO_VERSION_GENERIC_FW_MGMT)
		.withParameter("version_value", "1.16.10");

	/*** Firmware API version ***/

	hw->api_maj_ver = 1;
	hw->api_min_ver = 5;
	hw->api_patch = 0;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.mgmt.api")
		.withParameter("version_value", "1.5.0");

	/*** Firmware build identifier ***/

	hw->fw_build = 0xecabd066;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.mgmt.build")
		.withParameter("version_value", "0xecabd066");

	/*** NVM and Firmware security revision ***/

	hw->flash.nvm.srev = 5;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.mgmt.srev")
		.withParameter("version_value", "5");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.mgmt.srev")
		.withParameter("version_value", "5");

	/*** NVM format version ***/

	hw->flash.nvm.major = 0;
	hw->flash.nvm.minor = 0x50;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.psid.api")
		.withParameter("version_value", "0.50");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.psid.api")
		.withParameter("version_value", "0.50");

	/*** NVM EETRACK identifier ***/

	hw->flash.nvm.eetrack = 0x80001e09;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.bundle_id")
		.withParameter("version_value", "0x80001e09");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.bundle_id")
		.withParameter("version_value", "0x80001e09");

	/*** Option ROM version number ***/

	hw->flash.orom.major = 1;
	hw->flash.orom.build = 2186;
	hw->flash.orom.patch = 0;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi")
		.withParameter("version_value", "1.2186.0");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi")
		.withParameter("version_value", "1.2186.0");

	/*** Option ROM security revision ***/

	hw->flash.orom.srev = 3;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi.srev")
		.withParameter("version_value", "3");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi.srev")
		.withParameter("version_value", "3");

	/*** DDP package name ***/

	snprintf((char *)hw->active_pkg_name, sizeof(hw->active_pkg_name),
		 "ICE OS Package");

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.app.name")
		.withParameter("version_value", "ICE OS Package");

	/*** DDP package version ***/

	hw->active_pkg_ver.major = 1;
	hw->active_pkg_ver.minor = 3;
	hw->active_pkg_ver.update = 4;
	hw->active_pkg_ver.draft = 2;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.app")
		.withParameter("version_value", "1.3.4.2");

	/*** DDP package bundle identifier ***/

	hw->active_track_id = 0x43df9103;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.app.bundle_id")
		.withParameter("version_value", "0x43df9103");

	/*** Netlist version data ***/

	/* Note that these values are BCD encoded */
	hw->flash.netlist.major = 0x1;
	hw->flash.netlist.minor = 0x5;

	hw->flash.netlist.type = 0x20000003;

	hw->flash.netlist.rev = 0x14;
	hw->flash.netlist.cust_ver = 0x2;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist")
		.withParameter("version_value", "1.5.2000-3.14.2");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist")
		.withParameter("version_value", "1.5.2000-3.14.2");

	/*** Netlist hash identifier ***/

	hw->flash.netlist.hash = 0xcbd33f8f;

	mock().expectOneCall("devlink_info_version_running_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist.build")
		.withParameter("version_value", "0xcbd33f8f");

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist.build")
		.withParameter("version_value", "0xcbd33f8f");

	/*******************************/

	err = ice_devlink_info_get(devlink, &req, extack);
	CHECK_EQUAL(0, err);
}

TEST(info_get, basic_info_get_pending_orom)
{
	struct ice_orom_info expected_pending_orom = {};
	int err;

	dev_caps.common_cap.nvm_update_pending_orom = true;

	mock().expectOneCall("ice_get_inactive_orom_ver")
		.withParameter("hw", hw)
		.withOutputParameterReturning("orom", &expected_pending_orom, sizeof(expected_pending_orom));

	/*** Pending Option ROM version ***/

	expected_pending_orom.major = 2;
	expected_pending_orom.build = 3478;
	expected_pending_orom.patch = 1;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi")
		.withParameter("version_value", "2.3478.1");

	/*** Pending Option ROM security revision ***/

	expected_pending_orom.srev = 4;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.undi.srev")
		.withParameter("version_value", "4");

	/********************************************/

	/* Account for the other calls to devlink_info_version_stored_put */
	mock().expectNCalls(5, "devlink_info_version_stored_put")
		.ignoreOtherParameters();

	/* Don't bother repeating expectations for regular running versions */
	mock().ignoreOtherCalls();

	err = ice_devlink_info_get(devlink, &req, extack);
	CHECK_EQUAL(0, err);
}

TEST(info_get, basic_info_get_pending_nvm)
{
	struct ice_nvm_info expected_pending_nvm = {};
	int err;

	dev_caps.common_cap.nvm_update_pending_nvm = true;

	mock().expectOneCall("ice_get_inactive_nvm_ver")
		.withParameter("hw", hw)
		.withOutputParameterReturning("nvm", &expected_pending_nvm, sizeof(expected_pending_nvm));

	/*** Pending NVM format version ***/

	expected_pending_nvm.major = 0x5;
	expected_pending_nvm.minor = 0x02;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.psid.api")
		.withParameter("version_value", "5.02");

	/*** Pending NVM EETRACK identifier ***/

	expected_pending_nvm.eetrack = 0x800034FB;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", DEVLINK_INFO_VERSION_GENERIC_FW_BUNDLE_ID)
		.withParameter("version_value", "0x800034fb");

	/*** Pending NVM security revision ***/

	expected_pending_nvm.srev = 4;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.mgmt.srev")
		.withParameter("version_value", "4");

	/**************************************/

	/* Account for the other calls to devlink_info_version_stored_put */
	mock().expectNCalls(4, "devlink_info_version_stored_put")
		.ignoreOtherParameters();

	/* Don't bother repeating expectations for regular running versions */
	mock().ignoreOtherCalls();

	err = ice_devlink_info_get(devlink, &req, extack);
	CHECK_EQUAL(0, err);
}

TEST(info_get, basic_info_get_pending_netlist)
{
	struct ice_netlist_info expected_pending_netlist = {};
	int err;

	dev_caps.common_cap.nvm_update_pending_netlist = true;

	mock().expectOneCall("ice_get_inactive_netlist_ver")
		.withParameter("hw", hw)
		.withOutputParameterReturning("netlist", &expected_pending_netlist, sizeof(expected_pending_netlist));

	/*** Pending netlist version ***/

	/* The netlist fields are all BCD formatted */
	expected_pending_netlist.major = 0x1;
	expected_pending_netlist.minor = 0x7;

	expected_pending_netlist.type = 0x20000009;

	expected_pending_netlist.rev = 0x16;
	expected_pending_netlist.cust_ver = 0x5;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist")
		.withParameter("version_value", "1.7.2000-9.16.5");

	/*** Pending Netlist hash identifier ***/

	expected_pending_netlist.hash = 0xcba33f5f;

	mock().expectOneCall("devlink_info_version_stored_put")
		.withParameter("req", &req)
		.withParameter("version_name", "fw.netlist.build")
		.withParameter("version_value", "0xcba33f5f");

	/**************************************/

	/* Account for the other calls to devlink_info_version_stored_put */
	mock().expectNCalls(5, "devlink_info_version_stored_put")
		.ignoreOtherParameters();

	/* Don't bother repeating expectations for regular running versions */
	mock().ignoreOtherCalls();

	err = ice_devlink_info_get(devlink, &req, extack);
	CHECK_EQUAL(0, err);
}


TEST_GROUP_BASE(minsrev_params, TGN(devlink))
{
	struct devlink_param_gset_ctx ctx;
	struct ice_minsrev_info minsrevs;
	struct ice_hw *hw;

	TEST_SETUP()
	{
		TGN(devlink)::setup();

		memset(&ctx, 0, sizeof(ctx));
		memset(&minsrevs, 0, sizeof(minsrevs));
		hw = &pf->hw;

		minsrevs.nvm_valid = true;
		minsrevs.orom_valid = true;
		minsrevs.nvm = 30;
		minsrevs.orom = 25;

		hw->flash.nvm.srev = 40;
		hw->flash.orom.srev = 30;

	}
};

TEST(minsrev_params, get_nvm_minsrev)
{
	int err;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_get(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(30, ctx.val.vu32);
};

TEST(minsrev_params, get_nvm_minsrev_invalid)
{
	int err;

	minsrevs.nvm_valid = false;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_get(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, ctx.val.vu32);
};

TEST(minsrev_params, get_orom_minsrev)
{
	int err;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_get(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(25, ctx.val.vu32);
};

TEST(minsrev_params, get_orom_minsrev_invalid)
{
	int err;

	minsrevs.orom_valid = false;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_get(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, ctx.val.vu32);
};

TEST(minsrev_params, set_nvm_minsrev)
{
	struct ice_minsrev_info expected = {};
	int err;

	ctx.val.vu32 = 37;

	expected.nvm = 37;
	expected.nvm_valid = true;

	mock().expectOneCall("ice_update_nvm_minsrevs")
		.withParameter("hw", hw)
		.withParameter("minsrevs", (u8 *)&expected, sizeof(expected));
	mock().expectOneCall("ice_aq_wait_for_event").ignoreOtherParameters();

	err = ice_devlink_minsrev_set(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
};

TEST(minsrev_params, set_orom_minsrev)
{
	struct ice_minsrev_info expected = {};
	int err;

	ctx.val.vu32 = 37;

	expected.orom = 37;
	expected.orom_valid = true;

	mock().expectOneCall("ice_update_nvm_minsrevs")
		.withParameter("hw", hw)
		.withParameter("minsrevs", (u8 *)&expected, sizeof(expected));
	mock().expectOneCall("ice_aq_wait_for_event").ignoreOtherParameters();

	err = ice_devlink_minsrev_set(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV, &ctx);
	CHECK_EQUAL(0, err);
};

TEST(minsrev_params, validate_nvm_minsrev_update)
{
	int err;

	ctx.val.vu32 = 39;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(0, err);
}

TEST(minsrev_params, validate_nvm_minsrev_update_match_current)
{
	int err;

	ctx.val.vu32 = 40;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(0, err);
}

TEST(minsrev_params, validate_nvm_minsrev_update_cannot_reduce)
{
	int err;

	ctx.val.vu32 = 5;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(-EPERM, err);
}

TEST(minsrev_params, validate_nvm_minsrev_update_cannot_go_above_active)
{
	int err;

	ctx.val.vu32 = 75;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_MGMT_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(-EPERM, err);
}

TEST(minsrev_params, validate_orom_minsrev_update)
{
	int err;

	ctx.val.vu32 = 28;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(0, err);
}

TEST(minsrev_params, validate_orom_minsrev_update_match_current)
{
	int err;

	ctx.val.vu32 = 30;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(0, err);
}

TEST(minsrev_params, validate_orom_minsrev_update_cannot_reduce)
{
	int err;

	ctx.val.vu32 = 5;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(-EPERM, err);
}

TEST(minsrev_params, validate_orom_minsrev_update_cannot_go_above_active)
{
	int err;

	ctx.val.vu32 = 75;

	mock().expectOneCall("ice_get_nvm_minsrevs")
		.withParameter("hw", hw)
		.withOutputParameterReturning("minsrevs", &minsrevs, sizeof(minsrevs));

	err = ice_devlink_minsrev_validate(devlink, ICE_DEVLINK_PARAM_ID_FW_UNDI_MINSREV,
					   ctx.val, NULL);
	CHECK_EQUAL(-EPERM, err);
}

TEST_GROUP_BASE(regions, TGN(devlink))
{
	struct netlink_ext_ack *extack;
	u8 *nvm_snapshot, *devcaps_snapshot;
	u8 zero_devcaps[ICE_AQ_MAX_BUF_LEN] = {};

	TEST_SETUP()
	{
		TGN(devlink)::setup();

		pf->hw.flash.flash_size = 8000;
		pf->hw.flash.sr_words = 1024;

		extack = NULL;
		nvm_snapshot = NULL;
		devcaps_snapshot = NULL;

		memset(zero_devcaps, 0, sizeof(zero_devcaps));
	}

	TEST_TEARDOWN()
	{
		TGN(devlink)::teardown();

		if (nvm_snapshot) {
			vfree(nvm_snapshot);
			nvm_snapshot = NULL;
		}

		if (devcaps_snapshot) {
			vfree(devcaps_snapshot);
			devcaps_snapshot = NULL;
		}
	}
};

TEST(regions, init_regions)
{
	struct devlink_region nvm = {};
	struct devlink_region sram = {};
	struct devlink_region devcaps = {};

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_nvm_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 8000)
		.andReturnValue(&nvm);

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_sram_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 2048)
		.andReturnValue(&sram);

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_devcaps_region_ops)
		.withParameter("region_max_snapshots", 10)
		.withParameter("region_size", ICE_AQ_MAX_BUF_LEN)
		.andReturnValue(&devcaps);

	ice_devlink_init_regions(pf);

	POINTERS_EQUAL(&nvm, pf->nvm_region);
	POINTERS_EQUAL(&sram, pf->sram_region);
	POINTERS_EQUAL(&devcaps, pf->devcaps_region);
}

TEST(regions, init_regions_nvm_region_fails)
{
	struct devlink_region devcaps = {};

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_nvm_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 8000)
		.andReturnValue((__force void *)ERR_PTR(-EINVAL));

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_sram_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 2048)
		.andReturnValue((__force void *)ERR_PTR(-EINVAL));

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_devcaps_region_ops)
		.withParameter("region_max_snapshots", 10)
		.withParameter("region_size", ICE_AQ_MAX_BUF_LEN)
		.andReturnValue(&devcaps);

	ice_devlink_init_regions(pf);

	POINTERS_EQUAL(NULL, pf->nvm_region);
	POINTERS_EQUAL(NULL, pf->sram_region);
	POINTERS_EQUAL(&devcaps, pf->devcaps_region);
}

TEST(regions, destroy_regions_releases_all_regions)
{
	mock().setData("devlink_region_allocate_memleak_canary", true);

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_nvm_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 8000);

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_sram_region_ops)
		.withParameter("region_max_snapshots", 1)
		.withParameter("region_size", 2048);

	mock().expectOneCall("devlink_region_create")
		.withParameter("devlink", devlink)
		.withParameter("ops", &ice_devcaps_region_ops)
		.withParameter("region_max_snapshots", 10)
		.withParameter("region_size", ICE_AQ_MAX_BUF_LEN);

	ice_devlink_init_regions(pf);

	mock().checkExpectations();

	mock().expectOneCall("devlink_region_destroy")
		.withParameter("region", pf->nvm_region);

	mock().expectOneCall("devlink_region_destroy")
		.withParameter("region", pf->sram_region);

	mock().expectOneCall("devlink_region_destroy")
		.withParameter("region", pf->devcaps_region);

	ice_devlink_destroy_regions(pf);
}

TEST(regions, nvm_snapshot)
{
	u8 nvm_contents[] = { 0xDE, 0xAD, 0xBE, 0xEF };
	u32 nvm_size = sizeof(nvm_contents);
	int err;

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_read_flat_nvm")
		.withParameter("hw", &pf->hw)
		.withParameter("offset", 0)
		.withParameter("length", 8000)
		.withOutputParameterReturning("length", &nvm_size, sizeof(nvm_size))
		.withOutputParameterReturning("data", nvm_contents, sizeof(nvm_contents))
		.withParameter("read_shadow_ram", false);

	mock().expectOneCall("ice_release_nvm");

	err = ice_devlink_nvm_snapshot(devlink, &ice_nvm_region_ops, extack, &nvm_snapshot);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(nvm_contents, nvm_snapshot, sizeof(nvm_contents));
}

TEST(regions, nvm_snapshot_fails)
{
	u32 nvm_size = 0;
	int err;

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_read_flat_nvm")
		.withParameter("hw", &pf->hw)
		.withParameter("offset", 0)
		.withParameter("length", 8000)
		.withOutputParameterReturning("length", &nvm_size, sizeof(nvm_size))
		.withOutputParameterReturning("data", NULL, 0)
		.withParameter("read_shadow_ram", false)
		.andReturnValue(ICE_ERR_PARAM);

	mock().expectOneCall("ice_release_nvm");

	err = ice_devlink_nvm_snapshot(devlink, &ice_nvm_region_ops, extack, &nvm_snapshot);
	CHECK_EQUAL(-EIO, err);

	POINTERS_EQUAL((void *)NULL, nvm_snapshot);
}

TEST_GROUP_BASE(devlink_reload, TGN(devlink))
{
	struct netlink_ext_ack *extack;
	struct ice_hw *hw;

	TEST_SETUP()
	{
		TGN(devlink)::setup();

		extack = NULL;
		hw = &pf->hw;
	}
};

TEST(devlink_reload, fw_activate_no_reset)
{
	u8 zero = 0;
	int err;

	mock().expectOneCall("ice_get_pending_updates")
		.withParameter("pf", pf)
		.withOutputParameterReturning("pending", &zero, sizeof(zero))
		.withParameter("extack", extack);

	err = ice_devlink_reload_empr_start(devlink, false,
					    DEVLINK_RELOAD_ACTION_FW_ACTIVATE,
					    DEVLINK_RELOAD_LIMIT_UNSPEC, extack);
	CHECK_EQUAL(-ECANCELED, err);
}

TEST(devlink_reload, fw_activate_empr_disabled)
{
	u8 nvm_pending =  ICE_AQC_NVM_ACTIV_SEL_NVM;
	int err;

	pf->fw_emp_reset_disabled = true;

	mock().expectOneCall("ice_get_pending_updates")
		.withParameter("pf", pf)
		.withOutputParameterReturning("pending", &nvm_pending, sizeof(nvm_pending))
		.withParameter("extack", extack);

	err = ice_devlink_reload_empr_start(devlink, false,
					    DEVLINK_RELOAD_ACTION_FW_ACTIVATE,
					    DEVLINK_RELOAD_LIMIT_UNSPEC, extack);
	CHECK_EQUAL(-ECANCELED, err);
}

TEST(devlink_reload, fw_activate_empr_enabled)
{
	u8 nvm_pending =  ICE_AQC_NVM_ACTIV_SEL_NVM;
	int err;

	pf->fw_emp_reset_disabled = false;

	mock().expectOneCall("ice_get_pending_updates")
		.withParameter("pf", pf)
		.withOutputParameterReturning("pending", &nvm_pending, sizeof(nvm_pending))
		.withParameter("extack", extack);

	mock().expectOneCall("ice_aq_nvm_update_empr")
		.withParameter("hw", hw);

	err = ice_devlink_reload_empr_start(devlink, false,
					    DEVLINK_RELOAD_ACTION_FW_ACTIVATE,
					    DEVLINK_RELOAD_LIMIT_UNSPEC, extack);
	CHECK_EQUAL(0, err);
}

TEST(devlink_reload, reload_up)
{
	u32 actions_performed;
	int err;

	mock().expectOneCall("ice_wait_for_reset")
		.andReturnValue(0);

	err = ice_devlink_reload_empr_finish(devlink,
					     DEVLINK_RELOAD_ACTION_FW_ACTIVATE,
					     DEVLINK_RELOAD_LIMIT_UNSPEC,
					     &actions_performed, extack);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(BIT(DEVLINK_RELOAD_ACTION_FW_ACTIVATE), actions_performed);
}

TEST(regions, devcaps_snapshot)
{
	u8 devcaps[] = { 0xDE, 0xAD, 0xBE, 0xEF };
	int err;

	mock().expectOneCall("ice_aq_list_caps")
		.withParameter("hw", &pf->hw)
		.withOutputParameterReturning("buf", devcaps, sizeof(devcaps))
		.withParameter("buf_size", ICE_AQ_MAX_BUF_LEN)
		.withOutputParameterReturning("cap_count", (void *)NULL, 0)
		.withParameter("opc", ice_aqc_opc_list_dev_caps)
		.withParameter("cd", (void *)NULL);

	err = ice_devlink_devcaps_snapshot(devlink, &ice_devcaps_region_ops, extack, &devcaps_snapshot);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(devcaps, devcaps_snapshot, sizeof(devcaps));
}

TEST(regions, devcaps_snapshot_fails)
{
	int err;

	mock().expectOneCall("ice_aq_list_caps")
		.withParameter("hw", &pf->hw)
		.withOutputParameterReturning("buf", (void *)NULL, 0)
		.withParameter("buf_size", ICE_AQ_MAX_BUF_LEN)
		.withOutputParameterReturning("cap_count", (void *)NULL, 0)
		.withParameter("opc", ice_aqc_opc_list_dev_caps)
		.withParameter("cd", (void *)NULL)
		.andReturnValue(ICE_ERR_PARAM);

	err = ice_devlink_devcaps_snapshot(devlink, &ice_devcaps_region_ops, extack, &devcaps_snapshot);
	CHECK_EQUAL(ICE_ERR_PARAM, err);

	POINTERS_EQUAL((void *)NULL, devcaps_snapshot);
}

TEST_GROUP_BASE(txbalance_param, TGN(devlink))
{
	struct ice_aqc_nvm_tx_topo_user_sel usr_sel;
	struct devlink_param_gset_ctx ctx;
	struct netlink_ext_ack *extack;
	union devlink_param_value val;
	struct ice_hw *hw;

	TEST_SETUP()
	{
		TGN(devlink)::setup();
		memset(&usr_sel, 0, sizeof(usr_sel));
		memset(&ctx, 0, sizeof(ctx));
		hw = &pf->hw;
	}
};

TEST(txbalance_param, get_tx_topo_user_sel_enabled)
{
	u8 nvm_contents[] = { 0x01, 0x00, 0x10, 0x00 };
	bool txbalance_ena = false;
	int status;

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_aq_read_nvm")
		.withParameter("offset", 0)
		.withParameter("length", sizeof(usr_sel))
		.withOutputParameterReturning("data", nvm_contents, sizeof(nvm_contents))
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_release_nvm");

	status = ice_get_tx_topo_user_sel(pf, &txbalance_ena);

	CHECK_EQUAL(ICE_SUCCESS, status);
	CHECK_EQUAL(true, txbalance_ena);
}

TEST(txbalance_param, get_tx_topo_user_sel_disabled)
{
	u8 nvm_contents[] = { 0x01, 0x00, 0x00, 0x00 };
	bool txbalance_ena = true;
	int status;

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_aq_read_nvm")
		.withParameter("offset", 0)
		.withParameter("length", sizeof(usr_sel))
		.withOutputParameterReturning("data", nvm_contents, sizeof(nvm_contents))
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_release_nvm");

	status = ice_get_tx_topo_user_sel(pf, &txbalance_ena);

	CHECK_EQUAL(ICE_SUCCESS, status);
	CHECK_EQUAL(false, txbalance_ena);
}

TEST(txbalance_param, update_tx_topo_user_sel_set)
{
	bool txbalance_ena = true;
	int status;

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_aq_read_nvm")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_write_one_nvm_block")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_release_nvm");

	status = ice_update_tx_topo_user_sel(pf, txbalance_ena);

	CHECK_EQUAL(ICE_SUCCESS, status);
}

TEST(txbalance_param, ice_devlink_txbalance_get_enabled)
{
	bool txbalance_ena = true;
	int err;

	USE_STD_MOCK(ice_get_tx_topo_user_sel);

	mock().expectOneCall("ice_get_tx_topo_user_sel")
		.withParameter("pf", pf)
		.withOutputParameterReturning("txbalance_ena", &txbalance_ena, sizeof(txbalance_ena))
		.andReturnValue(ICE_SUCCESS);

	err = ice_devlink_txbalance_get(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE, &ctx);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(1, ctx.val.vbool);
}

TEST(txbalance_param, ice_devlink_txbalance_get_disabled)
{
	bool txbalance_ena = false;
	int err;

	USE_STD_MOCK(ice_get_tx_topo_user_sel);

	mock().expectOneCall("ice_get_tx_topo_user_sel")
		.withParameter("pf", pf)
		.withOutputParameterReturning("txbalance_ena", &txbalance_ena, sizeof(txbalance_ena))
		.andReturnValue(ICE_SUCCESS);

	err = ice_devlink_txbalance_get(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE, &ctx);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, ctx.val.vbool);
}

TEST(txbalance_param, ice_devlink_txbalance_set_success)
{
	bool txbalance_ena = false;
	int err;

	USE_STD_MOCK(ice_update_tx_topo_user_sel);

	mock().expectOneCall("ice_update_tx_topo_user_sel")
		.withParameter("pf", pf)
		.withParameter("txbalance_ena", txbalance_ena)
		.andReturnValue(ICE_SUCCESS);

	err = ice_devlink_txbalance_set(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE, &ctx);

	CHECK_EQUAL(0, err);
}

TEST(txbalance_param, ice_devlink_txbalance_set_error)
{
	bool txbalance_ena = false;
	int err;

	USE_STD_MOCK(ice_update_tx_topo_user_sel);

	mock().expectOneCall("ice_update_tx_topo_user_sel")
		.withParameter("pf", pf)
		.withParameter("txbalance_ena", txbalance_ena)
		.andReturnValue(ICE_ERR_PARAM);

	err = ice_devlink_txbalance_set(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE, &ctx);

	CHECK_EQUAL(-EIO, err);
}

TEST(txbalance_param, ice_devlink_txbalance_validate_success)
{
	int err;

	hw->func_caps.common_cap.tx_sched_topo_comp_mode_en = true;

	err = ice_devlink_txbalance_validate(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE,
					     val, extack);

	CHECK_EQUAL(0, err);
}

TEST(txbalance_param, ice_devlink_txbalance_validate_error)
{
	int err;

	hw->func_caps.common_cap.tx_sched_topo_comp_mode_en = false;

	err = ice_devlink_txbalance_validate(devlink, ICE_DEVLINK_PARAM_ID_TX_BALANCE,
					     val, extack);

	CHECK_EQUAL(-EOPNOTSUPP, err);
}
#endif /* DEVLINK_SUPPORT */
