#ifdef DEVLINK_SUPPORT
#include "ice_utest.h"

#define WQ_MEM_RECLAIM 0
#define KBUILD_MODNAME "ice_test"
#define CEE_DCBX_MAX_PRIO 8
#define IEEE_8021QAZ_MAX_TCS 8
#define DCB_CAP_DCBX_HOST 0x01
#define DCB_CAP_DCBX_VER_IEEE 0x08
#define DCB_CAP_DCBX_LLD_MANAGED 0x02

/* This test file is somewhat distinct from other tests in that it attempts to
 * load as much of the CORE .c files as possible in order to write tests that
 * catch issues that only occur when integrating files together. The primary
 * focus currently is on probe tests, allowing testing the full probe flow of
 * the core code, rather than having to test only ice_base.c, ice_lib.c, or
 * ice_main.c in isolation. A few of the .c files are not currently included
 * due to them causing unresolved compilation failures.
 */

/////////////////////////////////////////////////
namespace ns_integration {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_adminq_cmd.h"
#include "../src/SHARED/ice_sched.h"
#include "ice_osdep.h"
#include "ice_flex_pipe.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/dim.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/kernel.h>
#include <linux/cpumask.h>
#include <linux/pm_wakeup.h>
#include <sys/stat.h>
#include <linux/rtnetlink.h>
#include <net/act_api.h>
#include <net/pkt_cls.h>
#include <net/flow_dissector.h>
#include <net/flow_offload.h>
#include <net/tc_act/tc_gact.h>
#include <linux/pci_regs.h>
#include <linux/net.h>
#include <linux/netdevice.h>
#include <net/dst_metadata.h>
#include "include/asm-generic/bitops/const_hweight.h"

#include "../src/CORE/ice.h"
#include "../src/CORE/ice_txrx.h"
#include "../src/CORE/ice_vsi_vlan_ops.h"

#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "KERNEL_MOCKS/mock_workqueue.cpp"
#include "KERNEL_MOCKS/mock_pci.cpp"
#include "KERNEL_MOCKS/mock_netlink.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_net_core.cpp"
#include "KERNEL_MOCKS/mock_platform.cpp"
#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_dst.cpp"
#include "KERNEL_MOCKS/mock_flow.cpp"
#include "KERNEL_MOCKS/mock_ethtool.cpp"
#include "KERNEL_MOCKS/mock_kthread.cpp"
#include "KERNEL_MOCKS/mock_pkt_sched.cpp"

#include "KERNEL_LIBS/crc32.c"

#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_dcb.cpp"
#include "SHARED_MOCKS/mock_ice_ddp.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_acl.cpp"
#include "SHARED_MOCKS/mock_ice_vf_mbx.cpp"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "SHARED_MOCKS/mock_ice_fwlog.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "SHARED_MOCKS/mock_ice_bitops.cpp"
#include "SHARED_MOCKS/mock_ice_parser.cpp"
#include "local_ice_common.cpp"

static inline ice_fltr_ptype& operator++(ice_fltr_ptype& val, int)
{
	return val = ice_fltr_ptype(val + 1);
}

#include "../src/COMPAT/kcompat_pldmfw.c"

/* TODO: The following files need work in order to be directly included... */
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_dcb_nl.cpp"
#include "CORE_MOCKS/mock_ice_dcf.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fdir.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fsub.cpp"
#include "CORE_MOCKS/mock_ice_tc_lib.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#ifdef BMSM_MODE
#include "CORE_MOCKS/mock_ice_external_bridge.cpp"
#include "CORE_MOCKS/mock_ice_hw_lag.cpp"
#include "CORE_MOCKS/mock_ice_mbx.cpp"
#include "CORE_MOCKS/mock_ice_idc_int.cpp"
#endif /* BMSM_MODE */

#ifdef SIOV_SUPPORT
#include "CORE_MOCKS/mock_ice_siov.cpp"
#endif /* SIOV_SUPPORT */

#include "CORE_MOCKS/stdmock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_vdcm.cpp"

#include "../src/CORE/ice_fltr.c"
#include "../src/CORE/ice_xsk.c"
#include "../src/CORE/ice_txrx.c"
#include "../src/CORE/ice_txrx_lib.c"
#ifdef VIRTCHNL_IPSEC
#include "../src/CORE/ice_ipsec.c"
#endif /* VIRTCHNL_IPSEC */
#include "../src/CORE/ice_vf_lib.c"
#ifdef ADQ_SUPPORT
#include "../src/CORE/ice_vf_adq.c"
#endif /* ADQ_SUPPORT */
#include "../src/CORE/ice_virtchnl.c"
#include "../src/CORE/ice_sriov.c"
#include "../src/CORE/ice_virtchnl_allowlist.c"
// #include "../src/CORE/ice_dcb_nl.c"
// #include "../src/CORE/ice_dcb_lib.c"
#include "../src/CORE/ice_ethtool.c"
// #include "../src/CORE/ice_ethtool_fdir.c"
// #include "../src/CORE/ice_arfs.c"
#include "../src/CORE/ice_lib.c"
#include "../src/CORE/ice_base.c"
// #include "../src/CORE/ice_ptp.c"
#include "../src/CORE/ice_devlink.c"
#include "../src/CORE/ice_acl_main.c"
#if defined(ESWITCH_SUPPORT)
/* Temporary solution, #ifndef ICE_TDD needs to be removed
 * from these two functions in ice_main.c */
int
ice_del_cls_flower(struct ice_vsi *vsi, struct flow_cls_offload *cls_flower)
{
	return 0;
}

int
ice_add_cls_flower(struct net_device *netdev, struct ice_vsi *vsi,
		   struct flow_cls_offload *cls_flower)
{
	return 0;
}
#endif /* ESWITCH_SUPPORT */
#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
#include "../src/CORE/ice_repr.c"
#endif /* ESWITCH_SUPPORT || BMSM_MODE */
#ifdef ESWITCH_SUPPORT
#include "../src/CORE/ice_eswitch.c"
#endif /* ESWITCH_SUPPORT */
#ifdef BMSM_MODE
#include "../src/CORE/ice_vf_veb.c"
#endif
#include "../src/CORE/ice_fw_update.c"
#include "../src/CORE/ice_main.c"
#include "../src/CORE/ice_pf_vsi_vlan_ops.c"
#include "../src/CORE/ice_vf_vsi_vlan_ops.c"
#include "../src/CORE/ice_vsi_vlan_ops.c"
#include "../src/CORE/ice_vsi_vlan_lib.c"
#include "../src/CORE/ice_irq.c"
}
/////////////////////////////////////////////////
using namespace ns_integration;

static const size_t devlink_alloc_size = sizeof(struct devlink) + \
					 sizeof(struct ice_pf);

TEST_GROUP(full_probe)
{
	/* these stick around for the life of the test */
	struct pci_device_id ent;
	struct pci_dev pdev;
	struct device *dev;

	struct devlink *devlink;
	void *devlink_priv_ptr;
	void *devlink_data;

	void setup(void)
	{
		memset(&ent, 0, sizeof(struct pci_device_id));
		memset(&pdev, 0, sizeof(struct pci_dev));

		dev = &pdev.dev;

		devlink_data = calloc(1, devlink_alloc_size);
		devlink = (struct devlink *)devlink_data;
		devlink_priv_ptr = devlink_priv(devlink);

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
		global_vector_count = 130;
#else
		global_vector_count = 129;
#endif

#ifdef ADK_SUPPORT
		nd_vis = false;
#endif

		mock().setData("devlink_port_allocate_memleak_canary", true);
		mock().setData("devlink_register_allocate_memleak_canary", true);
	}

	void teardown(void)
	{
		global_vector_count = 0;

		if (devlink_data) {
			free(devlink_data);
			devlink_data = NULL;
			devlink = NULL;
			devlink_priv_ptr = NULL;
		}

		dev = NULL;
	}
};

TEST(full_probe, probe_succeeds)
{
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

#if defined(BMSM_MODE)
	int localvec = 78;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(SWITCH_MODE)
	int localvec = 94;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(FDIR_SUPPORT)
	int localvec = 11;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#else
	int localvec = 9;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#endif

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(0, err);

	/* Cleanup, to avoid memory leaks */
	ice_remove(&pdev);
}

#ifdef ADK_SUPPORT
TEST(full_probe, adk_netdev_registration_disabled)
{
	int localvec = 93;
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);

	/* netdevs are not registered if ND_VIS is unset */
	mock().expectNoCall("register_netdev");

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(0, err);

	/* Cleanup, to avoid memory leaks */
	ice_remove(&pdev);
}

TEST(full_probe, register_netdev_fails_with_nd_vis_enabled)
{
	int localvec = 93;
	int err;

	nd_vis = true;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);

	mock().expectOneCall("register_netdev")
		.andReturnValue(-EINVAL);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	/* The error is always converted */
	CHECK_EQUAL(-ENODEV, err);
}

#else /* ADK_SUPPORT */
TEST(full_probe, register_netdev_fails_default_mode)
{
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

#if defined(BMSM_MODE)
	int localvec = 78;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(SWITCH_MODE)
	int localvec = 94;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(FDIR_SUPPORT)
	int localvec = 11;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#else
	int localvec = 9;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#endif

	mock().expectOneCall("register_netdev")
		.andReturnValue(-EINVAL);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	/* The error is always converted */
	CHECK_EQUAL(-EINVAL, err);
}
#endif /* !ADK_SUPPORT */

/* Fail to completely initialize a VSI during ice_setup_vsi by forcing
 * ice_cfg_vsi_lan() to fail. The driver should gracefully handle this failure
 * without crashing.
 */
TEST(full_probe, ice_cfg_vsi_lan_fails)
{
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

#if defined(BMSM_MODE)
	int localvec = 78;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(SWITCH_MODE)
	int localvec = 94;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(FDIR_SUPPORT)
	int localvec = 11;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#else
	int localvec = 9;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#endif

	mock().expectOneCall("ice_cfg_vsi_lan")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_CFG);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(-ENOMEM, err);
}

TEST(full_probe, ice_vsi_alloc_q_vector_fails)
{
	int err;

	USE_STD_MOCK(ice_vsi_alloc_q_vector);

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

#if defined(BMSM_MODE)
	int localvec = 78;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(SWITCH_MODE)
	int localvec = 94;
	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#elif defined(FDIR_SUPPORT)
	int localvec = 11;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#else
	int localvec = 9;

	mock().expectOneCall("pci_enable_msix_range")
		.withIntParameter("maxvec", localvec)
		.ignoreOtherParameters()
		.andReturnValue(localvec);
#endif

	mock().expectOneCall("ice_vsi_alloc_q_vector")
		.ignoreOtherParameters()
		.andReturnValue(-ENOMEM);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(-ENOMEM, err);
}

#ifndef NO_RECOVERY_MODE_SUPPORT
TEST(full_probe, probe_recovery_mode)
{
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

	mock().expectOneCall("ice_get_fw_mode").andReturnValue(ICE_FW_MODE_REC);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(0, err);

	/* Cleanup, to avoid memory leaks */
	ice_remove(&pdev);
}


TEST(full_probe, probe_recovery_mode_fails)
{
	int err;

	mock().expectOneCall("devlink_alloc_ns")
		.withParameter("ops", &ice_devlink_ops)
		.withParameter("priv_size", sizeof(struct ice_pf))
		.withParameter("net", &init_net)
		.withParameter("dev", dev)
		.andReturnValue(devlink);

	mock().expectOneCall("devm_add_action")
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())&ice_devlink_free)
		.withParameter("data", devlink);

	mock().expectOneCall("ice_get_fw_mode").andReturnValue(ICE_FW_MODE_REC);

	mock().expectOneCall("register_netdev")
		.ignoreOtherParameters()
		.andReturnValue(-EIO);

	mock().ignoreOtherCalls();

	err = ice_probe(&pdev, &ent);
	CHECK_EQUAL(-EIO, err);
}
#endif /* !NO_RECOVERY_MODE_SUPPORT */
#endif /* DEVLINK_SUPPORT */
