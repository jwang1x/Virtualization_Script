struct metadata_dst *metadata_dst_alloc(u8 optslen, enum metadata_type type,
					gfp_t flags)
{
	mock().actualCall(__func__);
	return (struct metadata_dst *)mock().returnPointerValueOrDefault(NULL);
}

void metadata_dst_free(struct metadata_dst *)
{
	mock().actualCall(__func__);
}
