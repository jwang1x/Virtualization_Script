__printf(2, 3)
struct kthread_worker *
kthread_create_worker(unsigned int flags, const char namefmt[], ...)
{
	va_list args;

	va_start(args, namefmt);
	mock().actualCall(__func__)
		.withParameter("flags", flags)
		.withParameter("name", VStringFromFormat(namefmt, args).asCharString());
	va_end(args);

	return (struct kthread_worker *)mock().returnPointerValueOrDefault((void *)ERR_PTR(-ENOMEM));
}

bool kthread_queue_work(struct kthread_worker *worker,
			struct kthread_work *work)
{
	mock().actualCall(__func__)
		.withParameter("worker", worker)
		.withParameter("work", work);

	return mock().returnBoolValueOrDefault(true);
}

bool kthread_queue_delayed_work(struct kthread_worker *worker,
				struct kthread_delayed_work *dwork,
				unsigned long delay)
{
	mock().actualCall(__func__)
		.withParameter("worker", worker)
		.withParameter("dwork", dwork)
		.withParameter("delay", delay);

	return mock().returnBoolValueOrDefault(true);
}

bool kthread_mod_delayed_work(struct kthread_worker *worker,
			      struct kthread_delayed_work *dwork,
			      unsigned long delay)
{
	mock().actualCall(__func__)
		.withParameter("worker", worker)
		.withParameter("dwork", dwork)
		.withParameter("delay", delay);

	return mock().returnBoolValueOrDefault(true);
}

void kthread_flush_work(struct kthread_work *work)
{
	mock().actualCall(__func__)
		.withParameter("work", work);
}

void kthread_flush_worker(struct kthread_worker *worker)
{
	mock().actualCall(__func__)
		.withParameter("worker", worker);
}

void kthread_destroy_worker(struct kthread_worker *worker)
{
	mock().actualCall(__func__)
		.withParameter("worker", worker);
}

void kthread_delayed_work_timer_fn(struct timer_list *t)
{
	mock().actualCall(__func__)
		.withParameter("t", t);
}

bool kthread_cancel_work_sync(struct kthread_work *work)
{
	mock().actualCall(__func__)
		.withParameter("work", work);

	return mock().returnBoolValueOrDefault(false);
}

bool kthread_cancel_delayed_work_sync(struct kthread_delayed_work *work)
{
	mock().actualCall(__func__)
		.withParameter("work", work);

	return mock().returnBoolValueOrDefault(false);
}
