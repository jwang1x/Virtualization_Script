int vfio_pci_core_enable(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_pci_core_finish_enable(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);
}

void vfio_pci_core_init_device(struct vfio_pci_core_device *vdev,
			       struct pci_dev *pdev,
			       const struct vfio_device_ops *vfio_pci_ops)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev)
		.withParameter("pdev", pdev)
		.withParameter("vfio_pci_ops", vfio_pci_ops);
}

int vfio_pci_core_register_device(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_pci_core_uninit_device(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);
}

void vfio_pci_core_unregister_device(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);
}


static pci_ers_result_t vfio_pci_aer_err_detected(struct pci_dev *pdev,
						  pci_channel_state state)
{
	mock().actualCall(__func__)
		.withParameter("pdev", pdev)
		.withParameter("state", state);

	return mock().returnIntValueOrDefault(0);
}

const struct pci_error_handlers vfio_pci_core_err_handlers = {
	.error_detected = vfio_pci_aer_err_detected,
};

ssize_t vfio_pci_core_read(struct vfio_device *core_vdev, char __user *buf,
		size_t count, loff_t *ppos)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);

	return mock().returnIntValueOrDefault(0);
}

ssize_t vfio_pci_core_write(struct vfio_device *core_vdev, const char __user *buf,
		size_t count, loff_t *ppos)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);

	return mock().returnIntValueOrDefault(0);
}

long vfio_pci_core_ioctl(struct vfio_device *core_vdev, unsigned int cmd,
		unsigned long arg)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);

	return mock().returnIntValueOrDefault(0);
}

int vfio_pci_core_mmap(struct vfio_device *core_vdev, struct vm_area_struct *vma)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_pci_core_request(struct vfio_device *core_vdev, unsigned int count)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);
}

int vfio_pci_core_match(struct vfio_device *core_vdev, char *buf)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_pci_core_close_device(struct vfio_device *core_vdev)
{
	mock().actualCall(__func__)
		.withParameter("core_vdev", core_vdev);
}

int vfio_pci_register_dev_region(struct vfio_pci_core_device *vdev,
				 unsigned int type, unsigned int subtype,
				 const struct vfio_pci_regops *ops,
				 size_t size, u32 flags, void *data)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_pci_core_disable(struct vfio_pci_core_device *vdev)
{
	mock().actualCall(__func__)
		.withParameter("vdev", vdev);
}
