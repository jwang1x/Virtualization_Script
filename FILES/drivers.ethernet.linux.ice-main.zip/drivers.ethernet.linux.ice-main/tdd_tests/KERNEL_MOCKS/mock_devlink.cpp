#include "../include/net/devlink.h"

#define DEVLINK_RELOAD_STATS_ARRAY_SIZE \
	(__DEVLINK_RELOAD_LIMIT_MAX * __DEVLINK_RELOAD_ACTION_MAX)

struct devlink_dev_stats {
	u32 reload_stats[DEVLINK_RELOAD_STATS_ARRAY_SIZE];
	u32 remote_reload_stats[DEVLINK_RELOAD_STATS_ARRAY_SIZE];
};

struct devlink {
	u32 index;
	struct list_head port_list;
	struct list_head rate_list;
	struct list_head sb_list;
	struct list_head dpipe_table_list;
	struct list_head resource_list;
	struct list_head param_list;
	struct list_head region_list;
	struct list_head reporter_list;
	struct mutex reporters_lock; /* protects reporter_list */
	struct devlink_dpipe_headers *dpipe_headers;
	struct list_head trap_list;
	struct list_head trap_group_list;
	struct list_head trap_policer_list;
	const struct devlink_ops *ops;
	u64 features;
	struct xarray snapshot_ids;
	struct devlink_dev_stats stats;
	struct device *dev;
	possible_net_t _net;
	/* Serializes access to devlink instance specific objects such as
	 * port, sb, dpipe, resource, params, region, traps and more.
	 */
	struct mutex lock;
#ifndef NO_TDD_TEST_FRAMEWORK
       void *tdd_memleak_check;
#endif
	u8 reload_failed:1;
	refcount_t refcount;
	struct completion comp;
	char priv[] __aligned(NETDEV_ALIGN);
};

/* Historically, devlink_priv, priv_to_devlink and devlink_to_dev were
 * implemented in the devlink.h header. Now that devlink structure is opaque
 * and hidden from drivers, these are implemented here. To avoid re-writing
 * tests, these are implemented directly instead of using mock().actualCall().
 */
struct ice_pf *devlink_priv(struct devlink *devlink)
{
	return (struct ice_pf *)&devlink->priv;
}

struct devlink *priv_to_devlink(void *priv)
{
	return container_of(priv, struct devlink, priv);
}

struct device *devlink_to_dev(const struct devlink *devlink)
{
	return devlink->dev;
}

struct devlink_info_req {
};

struct devlink_region {
};

void devlink_free(struct devlink *devlink)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink);
}

struct devlink *devlink_alloc_ns(const struct devlink_ops *ops,
				 size_t priv_size, struct net *net,
				 struct device *dev)
{
	mock().actualCall(__func__)
		.withParameter("ops", ops)
		.withParameter("priv_size", priv_size)
		.withParameter("net", net)
		.withParameter("dev", dev);

	return (struct devlink *)mock().returnPointerValueOrDefault(NULL);
}

void devlink_register(struct devlink *devlink)
{
	int err;

	mock().actualCall(__func__)
		.withParameter("devlink", devlink);

	err = mock().returnIntValueOrDefault(0);

	if (!err && mock().hasData("devlink_register_allocate_memleak_canary")) {
		CHECK_FALSE_TEXT(devlink->tdd_memleak_check, "devlink was already registered");
		devlink->tdd_memleak_check = calloc(1, 1);
	}
}

void devlink_unregister(struct devlink *devlink)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink);

	if (mock().hasData("devlink_register_allocate_memleak_canary")) {
		CHECK_TRUE_TEXT(devlink->tdd_memleak_check, "devlink was not previously registered");
		free(devlink->tdd_memleak_check);
		devlink->tdd_memleak_check = NULL;
	}
}

int devlink_port_register(struct devlink *devlink,
			  struct devlink_port *devlink_port,
			  unsigned int port_index)
{
	int err;

	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("devlink_port", devlink_port)
		.withParameter("port_index", port_index);

	err = mock().returnIntValueOrDefault(0);

	if (!err && mock().hasData("devlink_port_allocate_memleak_canary")) {
		CHECK_FALSE_TEXT(devlink_port->tdd_memleak_check, "devlink_port was already registered");
		devlink_port->tdd_memleak_check = calloc(1, 1);
	}

	return err;
}

void devlink_port_type_eth_set(struct devlink_port *devlink_port,
			       struct net_device *netdev)
{
	mock().actualCall(__func__)
		.withParameter("devlink_port", devlink_port)
		.withParameter("netdev", netdev);
}

void devlink_port_attrs_set(struct devlink_port *devlink_port,
			    struct devlink_port_attrs *attrs)
{
	mock().actualCall(__func__)
		.withParameter("devlink_port", devlink_port)
		.withParameter("attrs", (u8 *)attrs, sizeof(*attrs));
}

void devlink_port_type_clear(struct devlink_port *devlink_port)
{
	mock().actualCall(__func__)
		.withParameter("devlink_port", devlink_port);
}

void devlink_port_unregister(struct devlink_port *devlink_port)
{
	mock().actualCall(__func__)
		.withParameter("devlink_port", devlink_port);

	if (mock().hasData("devlink_port_allocate_memleak_canary")) {
		CHECK_TRUE_TEXT(devlink_port->tdd_memleak_check, "devlink_port was not previously registered");
		free(devlink_port->tdd_memleak_check);
		devlink_port->tdd_memleak_check = NULL;
	}
}

int devlink_info_serial_number_put(struct devlink_info_req *req,
				   const char *sn)
{
	mock().actualCall(__func__)
		.withParameter("req", req)
		.withParameter("sn", sn);

	return mock().returnIntValueOrDefault(0);
}

int devlink_info_driver_name_put(struct devlink_info_req *req,
				 const char *name)
{
	mock().actualCall(__func__)
		.withParameter("req", req)
		.withParameter("name", name);

	return mock().returnIntValueOrDefault(0);
}

int devlink_info_version_fixed_put(struct devlink_info_req *req,
				   const char *version_name,
				   const char *version_value)
{
	mock().actualCall(__func__)
		.withParameter("req", req)
		.withParameter("version_name", version_name)
		.withParameter("version_value", version_value);

	return mock().returnIntValueOrDefault(0);
}

int devlink_info_version_stored_put(struct devlink_info_req *req,
				    const char *version_name,
				    const char *version_value)
{
	mock().actualCall(__func__)
		.withParameter("req", req)
		.withParameter("version_name", version_name)
		.withParameter("version_value", version_value);

	return mock().returnIntValueOrDefault(0);
}

int devlink_info_version_running_put(struct devlink_info_req *req,
				     const char *version_name,
				     const char *version_value)
{
	mock().actualCall(__func__)
		.withParameter("req", req)
		.withParameter("version_name", version_name)
		.withParameter("version_value", version_value);

	return mock().returnIntValueOrDefault(0);
}

struct devlink_region *
devlink_region_create(struct devlink *devlink,
		      const struct devlink_region_ops *ops,
		      u32 region_max_snapshots, u64 region_size)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("ops", ops)
		.withParameter("region_max_snapshots", region_max_snapshots)
		.withParameter("region_size", region_size);

	/* If requested, allocate memory for the devlink_region, to help
	 * create tests which catch cases where the memory was not released
	 * properly during unload.
	 */
	if (mock().hasData("devlink_region_allocate_memleak_canary")) {
		CHECK_FALSE_TEXT(mock().hasReturnValue(), "Don't specify a return value when using devlink_region_allocate_memleak_canary");
		return (struct devlink_region *)calloc(1, sizeof(struct devlink_region));
	} else {
		return (struct devlink_region *)mock().returnPointerValueOrDefault((void *)NULL);
	}
}

void devlink_region_destroy(struct devlink_region *region)
{
	mock().actualCall(__func__)
		.withParameter("region", region);

	if (mock().hasData("devlink_region_allocate_memleak_canary"))
		free(region);
}

void devlink_flash_update_status_notify(struct devlink *devlink,
					const char *status_msg,
					const char *component,
					unsigned long done,
					unsigned long total)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("status_msg", status_msg)
		.withParameter("component", component)
		.withParameter("done", done)
		.withParameter("total", total);
}

void devlink_flash_update_timeout_notify(struct devlink *devlink,
					 const char *status_msg,
					 const char *component,
					 unsigned long timeout)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("status_msg", status_msg)
		.withParameter("component", component)
		.withParameter("timeout", timeout);
}

int devlink_params_register(struct devlink *devlink,
			    const struct devlink_param *params,
			    size_t params_count)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("params", params)
		.withParameter("params_count", params_count);

	return mock().returnIntValueOrDefault(0);
}

void devlink_params_unregister(struct devlink *devlink,
			       const struct devlink_param *params,
			       size_t params_count)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("params", params)
		.withParameter("params_count", params_count);
}

void devlink_params_publish(struct devlink *devlink)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink);
}

void devlink_params_unpublish(struct devlink *devlink)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink);
}

void devlink_set_features(struct devlink *devlink, u64 features)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("features", features);
}
