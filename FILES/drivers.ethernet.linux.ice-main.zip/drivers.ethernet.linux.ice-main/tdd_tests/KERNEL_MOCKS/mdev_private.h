/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Mediated device internal definitions
 *
 * Copyright (c) 2016, NVIDIA CORPORATION. All rights reserved.
 *     Author: Neo Jia <cjia@nvidia.com>
 *             Kirti Wankhede <kwankhede@nvidia.com>
 */

#ifndef MDEV_PRIVATE_H
#define MDEV_PRIVATE_H

struct mdev_parent {
	struct device *dev;
	const struct mdev_parent_ops *ops;
	struct list_head next;
	struct kset *mdev_types_kset;
	struct list_head type_list;
};

struct mdev_type {
	struct kobject kobj;
	struct kobject *devices_kobj;
	struct mdev_parent *parent;
	struct list_head next;
	unsigned int type_group_id;
};

#endif /* MDEV_PRIVATE_H */
