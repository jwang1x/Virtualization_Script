#include "../include/linux/ptp_clock_kernel.h"
#include "../include/linux/skbuff.h"
#include "../include/linux/timecounter.h"
#include "../include/linux/wait.h"
#include "../include/linux/smp.h"
#include "../include/net/xdp.h"
#include "../include/net/xdp_sock.h"
#include "../include/linux/printk.h"
#include "../include/linux/sched.h"
#include "../include/linux/interrupt.h"
#include "../include/linux/dim.h"
#include "../include/linux/ktime.h"
#include "../include/net/net_namespace.h"

#define preempt_disable()
#define preempt_enable()
#define local_irq_save(_flags)
#define NL_SET_ERR_MSG_MOD(extack, str, args...) do {	\
	(void) extack; 					\
	fprintf(stderr, (str), ##args);			\
} while(0)

#ifndef ETH_P_LLDP
#define ETH_P_LLDP	0x88CC
#endif

struct net init_net = {
	.initialized = true,
};

int atomic_cmpxchg(atomic_t *reg, int oldval, int newval)
{
	int old_reg_val = reg->counter;
	if (old_reg_val == oldval)
		reg->counter = newval;
	return old_reg_val;
}

int register_netdev(struct net_device *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void unregister_netdev(struct net_device *dev)
{
	mock().actualCall(__func__);
}

int cpu_online(int cpu)
{
	mock().actualCall(__func__)
		.withParameter("cpu", cpu);
	return mock().intReturnValue();
}

static const char *pci_name(const struct pci_dev __always_unused *pdev)
{
	static const char foo[] = "0000:82:0.0";
	return foo;
}

static int pci_num_vf(struct pci_dev *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int pci_enable_sriov(struct pci_dev *dev, int nr_virtfn)
{
	mock().actualCall(__func__)
		.withParameter("nr_virtfn", nr_virtfn);
	return mock().returnIntValueOrDefault(0);
}

static __always_inline bool need_resched(void)
{
	return mock().actualCall(__func__).returnBoolValueOrDefault(false);
}

static bool is_broadcast_ether_addr(const u8 *addr)
{
	return (*(const u16 *)(addr + 0) &
		*(const u16 *)(addr + 2) &
		*(const u16 *)(addr + 4)) == 0xffff;
}

static bool netif_carrier_ok(const struct net_device *dev)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

static int bitmap_intersects(unsigned long *src1, unsigned long *src2,
			     unsigned int nbits)
{
	mock().actualCall(__func__);
	return 0;
}

static int dcb_ieee_setapp(struct net_device *dev, struct dcb_app *app)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int dev_mc_add_excl(struct net_device *dev, const unsigned char *addr)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int dev_mc_del(struct net_device *dev, const unsigned char *addr)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int dev_uc_add_excl(struct net_device *dev, const unsigned char *addr)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int dev_uc_del(struct net_device *dev, const unsigned char *addr)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int __dev_uc_sync(struct net_device *dev,
				int (*sync)(struct net_device *, const unsigned char *),
				int (*unsync)(struct net_device *, const unsigned char *))
{
	mock().actualCall(__func__);
	return 0;
}

static int __dev_mc_sync(struct net_device *dev,
		      int (*sync)(struct net_device *, const unsigned char *),
		      int (*unsync)(struct net_device *, const unsigned char *))
{
	mock().actualCall(__func__);
	return 0;
}

static inline void __dev_uc_unsync(struct net_device *dev,
				   int (*unsync)(struct net_device *,
						 const unsigned char *))
{
	mock().actualCall(__func__);
}

static inline void __dev_mc_unsync(struct net_device *dev,
				   int (*unsync)(struct net_device *,
						 const unsigned char *))
{
	mock().actualCall(__func__);
}

static u8 dcb_getapp(struct net_device *dev, struct dcb_app *app)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static bool netif_xmit_stopped(const struct netdev_queue *dev_queue)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

static u64 div_u64(u64 dividend, u32 divisor)
{
	return dividend / divisor;
}

static inline u64 div_u64_rem(u64 dividend, u32 divisor, u32 *remainder)
{
	*remainder = dividend % divisor;
	return dividend / divisor;
}
static s64 div_s64(s64 dividend, s32 divisor)
{
	return dividend / divisor;
}

static u64 lossy_mul_u64_u64_div_u64(u64 a, u64 mul, u64 div)
{
	u64 intermediate;

	/* The actual fallback kernel implementation is better than this
	 * approach but relies on ilog2. The approach taken here is equivalent
	 * to what we used to use in ice_ptp.c for frequency adjustments.
	 */

	/* Handle overflow by scaling down and losing some precision */
	while (mul > div64_u64(U64_MAX, a)) {
		mul >>= 2;
		div >>= 2;
	}

	intermediate = a * mul;

	return intermediate / div;
}

static u64 mul_u64_u64_div_u64(u64 a, u64 mul, u64 div)
{
#if defined(__SIZEOF_INT128__)
	__uint128_t intermediate, result;

	intermediate = ((__uint128_t)a) * ((__uint128_t)mul);
	result = intermediate / ((__uint128_t)div);

	CHECK_TRUE_TEXT(result < U64_MAX, "mul_u64_u64_div_u64 result overflowed");

	return (uint64_t)result;
#else
	return lossy_mul_u64_u64_div_u64(a, mul, div);
#endif
}

struct timespec64 ns_to_timespec64(s64 nsec)
{
	struct timespec64 ts = { 0, 0 };
	s32 rem;

	if (likely(nsec > 0)) {
		ts.tv_sec = div_u64_rem((u64)nsec, NSEC_PER_SEC, (u32 *)&rem);
		ts.tv_nsec = rem;
	} else if (nsec < 0) {
		/*
		 * With negative times, tv_sec points to the earlier
		 * second, and tv_nsec counts the nanoseconds since
		 * then, so tv_nsec is always a positive number.
		 */
		ts.tv_sec = -div_u64_rem(-(u64)nsec - 1, NSEC_PER_SEC, (u32 *)&rem) - 1;
		ts.tv_nsec = NSEC_PER_SEC - rem - 1;
	}

	return ts;
}

static struct timespec timespec64_to_timespec(const struct timespec64 ts64)
{
	struct timespec ret = { };
	return ret;
}

static struct timespec64 timespec_to_timespec64(const struct timespec ts)
{
	struct timespec64 ret = { };
	return ret;
}

static void timespec64_add_ns(struct timespec64 *a, u64 ns)
{
	a->tv_nsec = ns;
}

ktime_t ktime_get_with_offset(enum tk_offsets __always_unused offs)
{
	ktime_t t = 0;

	if (mock().hasData("current_ktime"))
		t = mock().getData("current_ktime").getLongIntValue();

	return t;
}

ktime_t ktime_get(void)
{
	ktime_t t = 0;

	if (mock().hasData("current_ktime"))
		t = mock().getData("current_ktime").getLongIntValue();

	return t;
}

/**
 * set_normalized_timespec - set timespec sec and nsec parts and normalize
 *
 * @ts:		pointer to timespec variable to be set
 * @sec:	seconds to set
 * @nsec:	nanoseconds to set
 *
 * Set seconds and nanoseconds field of a timespec variable and
 * normalize to the timespec storage format
 *
 * Note: The tv_nsec part is always in the range of
 *	0 <= tv_nsec < NSEC_PER_SEC
 * For negative values only the tv_sec field is negative !
 */
void set_normalized_timespec64(struct timespec64 *ts, time64_t sec, s64 nsec)
{
	while (nsec >= NSEC_PER_SEC) {
		/*
		 * The following asm() prevents the compiler from
		 * optimising this loop into a modulo operation. See
		 * also __iter_div_u64_rem() in include/linux/time.h
		 */
		asm("" : "+rm"(nsec));
		nsec -= NSEC_PER_SEC;
		++sec;
	}
	while (nsec < 0) {
		asm("" : "+rm"(nsec));
		nsec += NSEC_PER_SEC;
		--sec;
	}
	ts->tv_sec = sec;
	ts->tv_nsec = nsec;
}

static long
copy_to_user(void *to, const void *from, long n)
{
	memcpy(to, from, n);

	/* the copy_to_user interface returns number of bytes left that
	 * weren't copied. For TDD we just assume that all bytes can be copied
	 * safely.
	 */
	return 0;
}

static long
copy_from_user(void *to, const void *from, long n)
{
	memcpy(to, from, n);

	/* The copy_from_user interface returns the number of bytes left that
	 * weren't copied. For TDD we just assume that all bytes can be copied
	 * safely.
	 */
	return 0;
}

static void skb_tstamp_tx(struct sk_buff *orig_skb,
		   struct skb_shared_hwtstamps *hwtstamps)
{
	return;
}

static void dev_kfree_skb_any(struct sk_buff *skb)
{
	return;
}

static struct skb_shared_hwtstamps *skb_hwtstamps(struct sk_buff *skb)
{
	return &skb_shinfo(skb)->hwtstamps;
}

static bool IS_ERR_OR_NULL(__force const void *ptr)
{
	return !ptr;
}

static struct ptp_clock *ptp_clock_register(struct ptp_clock_info *info,
					    struct device *parent)
{
	struct ptp_clock *ptp = NULL;
	return ptp;
}

static int ptp_clock_unregister(struct ptp_clock *ptp)
{
	return 0;
}

static int ptp_clock_index(struct ptp_clock *ptp)
{
	return ptp->index;
}

static __always_inline void local_irq_restore(unsigned long flags)
{
	return;
}

void timecounter_init(struct timecounter *tc,
		      const struct cyclecounter *cc,
		      u64 start_tstamp)
{
	return;
}

u64 timecounter_read(struct timecounter *tc)
{
	return 0;
}

u64 timecounter_cyc2time(struct timecounter *tc,
			 cycle_t cycle_tstamp)
{
	return 0;
}
int ethtool_op_get_ts_info(struct net_device *dev, struct ethtool_ts_info *info)
{
	return 0;
}

static void udp_tunnel_get_rx_info(struct net_device *dev)
{
	mock().actualCall(__func__);
	return;
}

static inline int tc_classid_to_hwtc(struct net_device *dev, u32 classid)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(-1);
}

static inline void bpf_prog_put(struct bpf_prog *prog)
{
	mock().actualCall(__func__).withParameter("prog", prog);
}

static inline bool ip_is_fragment(const struct iphdr *iph)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

#ifdef CONFIG_RFS_ACCEL
static bool rps_may_expire_flow(struct net_device *dev, u16 rxq_index, u32 flow_id,
			 u16 filter_id)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}
#endif /* CONFIG_RFS_ACCEL */

inline void free_irq_cpu_rmap(struct cpu_rmap *rmap)
{
	mock().actualCall(__func__);
	free(rmap);
}

inline int irq_cpu_rmap_add(struct cpu_rmap *rmap, int irq)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

struct ice_pf *pci_get_drvdata_mock(struct pci_dev *pdev)
{
	mock().actualCall(__func__);
	return (struct ice_pf *)mock().returnPointerValueOrDefault((void *)NULL);
}

static int pci_enable_device_mem(struct pci_dev *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static void pci_restore_state(struct pci_dev *dev)
{
	mock().actualCall(__func__);
}

static void pci_restore_msi_state(struct pci_dev *dev)
{
	mock().actualCall(__func__);
}

static int pci_save_state(struct pci_dev *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int pci_wake_from_d3(struct pci_dev *dev, bool enable)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static inline char *xdp_umem_get_data(struct xdp_umem *umem, u64 addr)
{
	mock().actualCall(__func__);
	return (char *)mock().returnPointerValueOrDefault(NULL);
}

static inline dma_addr_t xdp_umem_get_dma(struct xdp_umem *umem, u64 addr)
{
	mock().actualCall(__func__);
	return (dma_addr_t)mock().returnIntValueOrDefault(0);
}
u64 *xsk_umem_peek_addr(struct xdp_umem *umem, u64 *addr)
{
	mock().actualCall(__func__);
	return (u64 *)mock().returnPointerValueOrDefault(NULL);
}
u64 *xsk_umem_peek_addr_rq(struct xdp_umem *umem, u64 *addr)
{
	mock().actualCall(__func__);
	return (u64 *)mock().returnPointerValueOrDefault(NULL);
}
void xsk_umem_release_addr(struct xdp_umem *umem)
{
	mock().actualCall(__func__);
	return;
}
void xsk_umem_release_addr_rq(struct xdp_umem *umem)
{
	mock().actualCall(__func__);
	return;
}

static inline bool xsk_umem_consume_tx(struct xdp_umem *umem, dma_addr_t *dma,
				       u32 *len)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

static inline void xsk_tx_release(struct xsk_buff_pool *pool)
{
	mock().actualCall(__func__);
}

static inline void xsk_tx_completed(struct xsk_buff_pool *pool, u32 nb_entries)
{
	mock().actualCall(__func__);
}

static inline bool xsk_tx_peek_desc(struct xsk_buff_pool *pool,
				    struct xdp_desc *desc)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}
static int xsk_pool_dma_map(struct xsk_buff_pool *pool, struct device *dev,
			    unsigned long attrs)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int pci_aer_clear_nonfatal_status(struct pci_dev *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static void pci_set_master(struct pci_dev *dev)
{
	mock().actualCall(__func__);
}

static void pci_clear_master(struct pci_dev *dev)
{
	mock().actualCall(__func__);
}

static void bpf_warn_invalid_xdp_action(net_device *dev, bpf_prog *prog,
					u32 act)
{
	mock().actualCall(__func__);
}

static int xdp_do_redirect(struct net_device *dev, struct xdp_buff *xdp,
			   struct bpf_prog *xdp_prog)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int trace_xdp_exception(struct net_device *netdev,
			       struct bpf_prog *xdp_prog,
			       u32 act)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void flow_rule_match_basic(const struct flow_rule *rule,
			   struct flow_match_basic *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_control(const struct flow_rule *rule,
                             struct flow_match_control *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_eth_addrs(const struct flow_rule *rule,
                               struct flow_match_eth_addrs *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_vlan(const struct flow_rule *rule,
                          struct flow_match_vlan *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_ipv4_addrs(const struct flow_rule *rule,
                                struct flow_match_ipv4_addrs *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_ipv6_addrs(const struct flow_rule *rule,
                                struct flow_match_ipv6_addrs *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_ports(const struct flow_rule *rule,
                           struct flow_match_ports *out)
{
	mock().actualCall(__func__);
}

void flow_rule_match_enc_keyid(const struct flow_rule *rule,
                               struct flow_match_enc_keyid *out)
{
	mock().actualCall(__func__);
}

int pci_find_ext_capability(struct pci_dev *dev, int cap)
{
	mock().actualCall(__func__);
	return 0;
}

static inline int pci_read_config_word(const struct pci_dev *dev, int where, u16 *val)
{
	return 0;
}

static inline int pci_read_config_dword(const struct pci_dev *dev, int where, u32 *val)
{
	return 0;
}

static __always_inline u16 get_unaligned_le16(const void *p)
{
	__le16 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return LE16_TO_CPU(tmp);
}

static __always_inline u32 get_unaligned_le32(const void *p)
{
	__le32 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return LE32_TO_CPU(tmp);
}

static __always_inline u64 get_unaligned_le64(const void *p)
{
	__le64 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return LE64_TO_CPU(tmp);
}

static __always_inline u16 get_unaligned_be16(const void *p)
{
	__be16 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return BE16_TO_CPU(tmp);
}

static __always_inline u32 get_unaligned_be32(const void *p)
{
	__be32 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return BE32_TO_CPU(tmp);
}

static __always_inline u64 get_unaligned_be64(const void *p)
{
	__be64 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return BE64_TO_CPU(tmp);
}

static __always_inline void put_unaligned_le16(u16 val, void *p)
{
	__le16 tmp;

	tmp = CPU_TO_LE16(val);
	memmove(p, &tmp, sizeof(tmp));
}

static __always_inline void put_unaligned_le32(u32 val, void *p)
{
	__le32 tmp;

	tmp = CPU_TO_LE32(val);
	memmove(p, &tmp, sizeof(tmp));
}

static __always_inline void put_unaligned_le64(u64 val, void *p)
{
	__le64 tmp;

	tmp = CPU_TO_LE64(val);
	memmove(p, &tmp, sizeof(tmp));
}

static __always_inline void put_unaligned_be16(u16 val, void *p)
{
	__be16 tmp;

	tmp = CPU_TO_BE16(val);
	memmove(p, &tmp, sizeof(tmp));
}

static __always_inline void put_unaligned_be32(u32 val, void *p)
{
	__be32 tmp;

	tmp = CPU_TO_BE32(val);
	memmove(p, &tmp, sizeof(tmp));
}

static __always_inline void put_unaligned_be64(u64 val, void *p)
{
	__be64 tmp;

	tmp = CPU_TO_BE64(val);
	memmove(p, &tmp, sizeof(tmp));
}

static inline struct pci_dev *
pci_get_device(unsigned int vendor, unsigned int device, struct pci_dev *from)
{
	struct pci_dev *pdev = NULL;
	return pdev;
}

void xdp_rxq_info_unreg_mem_model(struct xdp_rxq_info *xdp_rxq)
{
	mock().actualCall(__func__);
}

int netif_set_xps_queue(struct net_device *dev,
			const struct cpumask *mask,
			u16 index)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

u64 get_jiffies_64(void)
{
	mock().actualCall(__func__);
	return mock().returnUnsignedLongLongIntValueOrDefault(jiffies);
}

bool time_is_after_jiffies64(u64 time)
{
	mock().actualCall(__func__)
		.withParameter("time", time);

	/* There is no suitable default here, so instead force the tests to
	 * set time proper expectation
	 */
	return mock().boolReturnValue();
}

bool time_is_before_jiffies64(u64 time)
{
	mock().actualCall(__func__)
		.withParameter("time", time);

	/* There is no suitable default here, so instead force the tests to
	 * set time proper expectation
	 */
	return mock().boolReturnValue();
}

bool time_is_after_jiffies(unsigned long time)
{
	mock().actualCall(__func__)
		.withParameter("time", time);

	/* There is no suitable default here, so instead force the tests to
	 * set time proper expectation
	 */
	return mock().boolReturnValue();
}

bool time_is_before_jiffies(unsigned long time)
{
	mock().actualCall(__func__)
		.withParameter("time", time);

	/* There is no suitable default here, so instead force the tests to
	 * set time proper expectation
	 */
	return mock().boolReturnValue();
}

bool time_in_range64(u64 a, u64 b, u64 c)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool skb_flow_dissect_flow_keys(const struct sk_buff *skb,
				struct flow_keys *flow_keys,
				unsigned int flags)
{
	mock().actualCall(__func__)
		.withOutputParameter("flow_keys", flow_keys);
	return mock().returnBoolValueOrDefault(true);
}

#ifdef HAVE_DEVLINK_ESWITCH_OPS_EXTACK
int dev_change_flags(struct net_device *dev, unsigned int flags,
		     struct netlink_ext_ack *extack)
#else
int dev_change_flags(struct net_device *dev, unsigned int flags)
#endif
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int dev_set_mtu(struct net_device *dev, int new_mtu)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static u64 pci_get_dsn(struct pci_dev *dev)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev);

	return mock().returnLongLongIntValueOrDefault(0);
}

int devm_add_action(struct device *dev, void (*action)(void *), void *data)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withFunctionPointerParameter("action", (void (*)())action)
		.withParameter("data", data);

	return mock().returnIntValueOrDefault(0);
}

bool eth_type_vlan(__be16 ethertype)
{
	mock().actualCall(__func__)
		.withParameter("ethertype", ethertype);

	return mock().returnBoolValueOrDefault(true);
}

void xdp_return_frame(struct xdp_frame *xdpf)
{
	mock().actualCall(__func__)
		.withParameter("xdpf", xdpf);
}

void module_put(struct module *module)
{
	mock().actualCall(__func__)
		.withParameter("module", module);
}

int try_module_get(struct module *module)
{
	mock().actualCall(__func__)
		.withParameter("module", module);

	return mock().returnIntValueOrDefault(1);
}

int dma_set_mask_and_coherent(struct device *dev, u64 mask)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

int device_for_each_child(struct device *dev, void *data,
			  int (*fn)(struct device *dev, void *data))
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withParameter("data", data);

	return mock().intReturnValue();
}

static int
ndo_dflt_bridge_getlink(struct sk_buff *skb, u32 pid, u32 seq,
			struct net_device *dev, u16 mode)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(mode);
}

static int
devm_request_irq(struct device *dev, unsigned int irq, irq_handler_t handler,
		 unsigned long irqflags, const char *devname, void *dev_id)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int
request_irq(unsigned int irq, irq_handler_t handler, unsigned long irqflags,
	    const char *devname, void *dev_id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static void cpumask_copy(cpumask_t *newmask, const cpumask_t *oldmask)
{
	mock().actualCall(__func__);
}

static int num_online_cpus(void)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(8);
}

static void macvlan_count_rx(const struct macvlan_dev *vlan, unsigned int len, bool success,
			     bool multicast)
{
	mock().actualCall(__func__);
}

static void netdev_unbind_sb_channel(struct net_device *dev, struct net_device *sb_dev)
{
	mock().actualCall(__func__);
}

static int netdev_bind_sb_channel_queue(struct net_device *dev, struct net_device *sb_dev,
					u8 tc, u16 count, u16 offset)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int netdev_set_sb_channel(struct net_device *dev, u16 channel)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

static int macvlan_release_l2fw_offload(struct net_device *dev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

struct dim_cq_moder net_dim_get_def_rx_moderation(u8 cq_period_mode)
{
	struct dim_cq_moder moder = {};

	mock().actualCall(__func__)
		.withParameter("cq_period_mode", cq_period_mode);

	/* Bit of a hack, but we can use the mock 'return' value as the usec
	 * parameter of the structure. This won't work if we ever want to use
	 * multiple fields in the structure, but it is ok for now...
	 */
	moder.usec = mock().returnIntValueOrDefault(4);

	return moder;
}

struct dim_cq_moder net_dim_get_def_tx_moderation(u8 cq_period_mode)
{
	struct dim_cq_moder moder = {};

	mock().actualCall(__func__)
		.withParameter("cq_period_mode", cq_period_mode);

	/* Bit of a hack, but we can use the mock 'return' value as the usec
	 * parameter of the structure. This won't work if we ever want to use
	 * multiple fields in the structure, but it is ok for now...
	 */
	moder.usec = mock().returnIntValueOrDefault(4);

	return moder;
}

struct dim_cq_moder net_dim_get_rx_moderation(u8 cq_period_mode, int ix)
{
	struct dim_cq_moder moder = {};

	mock().actualCall(__func__)
		.withParameter("cq_period_mode", cq_period_mode)
		.withParameter("ix", ix);

	/* Bit of a hack, but we can use the mock 'return' value as the usec
	 * parameter of the structure. This won't work if we ever want to use
	 * multiple fields in the structure, but it is ok for now...
	 */
	moder.usec = mock().returnIntValueOrDefault(16);

	return moder;
}

struct dim_cq_moder net_dim_get_tx_moderation(u8 cq_period_mode, int ix)
{
	struct dim_cq_moder moder = {};

	mock().actualCall(__func__)
		.withParameter("cq_period_mode", cq_period_mode)
		.withParameter("ix", ix);

	/* Bit of a hack, but we can use the mock 'return' value as the usec
	 * parameter of the structure. This won't work if we ever want to use
	 * multiple fields in the structure, but it is ok for now...
	 */
	moder.usec = mock().returnIntValueOrDefault(8);

	return moder;
}

void net_dim(struct dim *dim, struct dim_sample end_sample)
{
	mock().actualCall(__func__)
		.withParameter("dim", dim)
		.withParameter("end_sample", (u8 *)&end_sample, sizeof(end_sample));
}

inline struct xsk_buff_pool *
xsk_get_pool_from_qid(struct net_device *dev, u16 queue_id)
{
	mock().actualCall(__func__);
	return (struct xsk_buff_pool *)mock().returnPointerValueOrDefault(NULL);
}

void kobject_del(struct kobject *kobj)
{
	mock().actualCall(__func__)
		.withParameter("kobj", kobj);
}

void kobject_put(struct kobject *kobj)
{
	mock().actualCall(__func__)
		.withParameter("kobj", kobj);
}

int sysfs_create_group(struct kobject *kobj,
		       const struct attribute_group *grp)
{
	mock().actualCall(__func__)
		.withParameter("kobj", kobj)
		.withParameter("grp", grp);
	return mock().returnIntValueOrDefault(0);
}

void sysfs_remove_group(struct kobject *kobj,
			const struct attribute_group *grp)
{
	mock().actualCall(__func__)
		.withParameter("kobj", kobj)
		.withParameter("grp", grp);
}

int sysfs_create_file(struct kobject *kobj,
		      const struct attribute *attr)
{
	mock().actualCall(__func__)
		.withParameter("kobj", kobj)
		.withParameter("attr", attr);
	return mock().returnIntValueOrDefault(0);
}

int sysfs_remove_file(struct kobject *kobj,
		      const struct attribute *attr)
{
	mock().actualCall(__func__).
		withParameter("kobj", kobj);
	return mock().returnIntValueOrDefault(0);
}

struct kobject *kobject_create_and_add(const char *name,
						struct kobject *parent)
{
	mock().actualCall(__func__)
		.withParameter("name", name)
		.withParameter("parent", parent);
	return (struct kobject *)mock().returnPointerValueOrDefault(NULL);
}

static inline int device_create_file(struct device *device,
				     const struct device_attribute *entry)
{
	mock().actualCall(__func__).
		withParameter("device", device);

	return mock().returnIntValueOrDefault(0);
}

static inline int device_remove_file(struct device *dev,
				     const struct device_attribute *attr)
{
	mock().actualCall(__func__).
		withParameter("device", dev);

	return mock().returnIntValueOrDefault(0);
}

void argv_free(char **argv)
{
	mock().actualCall(__func__);
}

char **argv_split_return;
int argc_split_return;
char **argv_split(gfp_t gfp, const char *str, int *argcp)
{
	mock().actualCall(__func__);

	char** ret = argv_split_return;
	*argcp = argc_split_return;

	return ret;
}

int kstrtou8(const char *s, unsigned int base, u8 *res)
{
	mock().actualCall(__func__);

	*res = (u8)atoi(s);

	return mock().returnIntValueOrDefault(0);
}

int kstrtou32(const char *s, unsigned int base, u32 *res)
{
	mock().actualCall(__func__);

	*res = (u32)atoi(s);

	return mock().returnIntValueOrDefault(0);
}

int kstrtos32(const char *s, unsigned int base, s32 *res)
{
        mock().actualCall(__func__);

        *res = (s32)atoi(s);

        return mock().returnIntValueOrDefault(0);
}

int kstrtobool(const char *s, bool *res)
{
	mock().actualCall(__func__)
		.withOutputParameter("res", res);

	return mock().returnIntValueOrDefault(0);
}

int vscnprintf(char *buf, size_t size, const char *fmt, va_list args)
{
	size_t i;

	i = vsnprintf(buf, size, fmt, args);

	if (i < size)
		return i;
	if (size != 0)
		return size - 1;
	return 0;
}

int scnprintf(char *buf, size_t size, const char *fmt, ...)
{
	va_list args;
	int i;

	va_start(args, fmt);
	i = vscnprintf(buf, size, fmt, args);
	va_end(args);

	return i;
}

char *kvasprintf(gfp_t gfp, const char *fmt, va_list ap)
{
	unsigned int first;
	char *p;
	va_list aq;

	va_copy(aq, ap);
	first = vsnprintf(NULL, 0, fmt, aq);
	va_end(aq);

	p = (char *)malloc(first+1);

	return p;
}

char *kasprintf(gfp_t gfp, const char *fmt, ...)
{
	va_list ap;
	char *p;

	va_start(ap, fmt);
	p = kvasprintf(gfp, fmt, ap);
	va_end(ap);

	return p;
}

char *devm_kasprintf(struct device __always_unused *dev, gfp_t gfp, const char *fmt, ...)
{
	va_list ap;
	char *p;

	va_start(ap, fmt);
	p = kasprintf(gfp, fmt, ap);
	va_end(ap);

	return p;
}
