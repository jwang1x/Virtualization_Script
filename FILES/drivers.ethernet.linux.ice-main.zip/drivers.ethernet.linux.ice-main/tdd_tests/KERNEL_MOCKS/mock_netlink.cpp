#define nla_for_each_attr(pos, head, len, rem) \
for (pos = head, rem = len; \
     nla_ok(pos, rem); \
     pos = nla_next(pos, &(rem)))
#define nla_for_each_nested(pos, nla, rem) \
nla_for_each_attr(pos, nla_data(nla), nla_len(nla), rem)

static struct nlattr *nla_data(const struct nlattr *nla)
{
	return (struct nlattr *) (((char *) nla) + NLA_HDRLEN);
}

static int nla_len(const struct nlattr *nla)
{
	return nla->nla_len - NLA_HDRLEN;
}

static struct nlattr *nla_next(const struct nlattr *nla, int *remaining)
{
	int totlen = NLA_ALIGN(nla->nla_len);

	*remaining -= totlen;
	return (struct nlattr *) ((char *) nla + totlen);
}

static int nla_ok(const struct nlattr *nla, int remaining)
{
	return remaining >= (int) sizeof(*nla) &&
	nla->nla_len >= sizeof(*nla) &&
	nla->nla_len <= remaining;
}

static int nla_type(const struct nlattr *nla)
{
	return nla->nla_type & NLA_TYPE_MASK;
}

static u16 nla_get_u16(const struct nlattr *nla)
{
	mock().actualCall(__func__);
	return (u16) mock().returnUnsignedIntValueOrDefault(0);
}

static struct nlattr *
nlmsg_find_attr(const struct nlmsghdr *nlh, int hdrlen, int attrtype)
{
	mock().actualCall(__func__);
	return (struct nlattr *) mock().returnPointerValueOrDefault(NULL);
}
