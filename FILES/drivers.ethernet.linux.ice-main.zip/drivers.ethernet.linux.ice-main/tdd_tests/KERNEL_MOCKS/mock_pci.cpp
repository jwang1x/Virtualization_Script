/* globals are always initialized to zero, this is for our register space */
u8 g_regmem[0x5000000];
static u8 * const map_table[6] = { g_regmem, 0, 0, 0, 0, 0 };

struct pci_device_id {
	int vendor, device;		/* Vendor and device ID or PCI_ANY_ID*/
	int subvendor, subdevice;	/* Subsystem ID's or PCI_ANY_ID */
	int pci_class, pci_class_mask;	/* (class,subclass,prog-if) triplet */
	long int driver_data;	/* Data private to the driver */
	__u32 override_only;
};

struct module;
struct pci_driver {
	const char *name;
	const struct pci_device_id *id_table;	/* must be non-NULL for probe to be called */
	int  (*probe)  (struct pci_dev *dev, const struct pci_device_id *id);	/* New device inserted */
	void (*remove) (struct pci_dev *dev);	/* Device removed (NULL if not a hot-plug capable driver) */
	int  (*suspend) (struct pci_dev *dev, pm_message_t state);	/* Device suspended */
	int  (*suspend_late) (struct pci_dev *dev, pm_message_t state);
	int  (*resume_early) (struct pci_dev *dev);
	int  (*resume) (struct pci_dev *dev);	                /* Device woken up */
	void (*shutdown) (struct pci_dev *dev);
	int (*sriov_configure) (struct pci_dev *dev, int num_vfs); /* PF pdev */
	const struct pci_error_handlers *err_handler;
};

enum system_states {
	SYSTEM_POWER_HALT,
	SYSTEM_POWER_OFF,
	SYSTEM_POWER_RESTART,
} system_state;

static int pcim_enable_device(struct pci_dev *pdev)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}
static int pcim_iomap_regions(struct pci_dev *pdev, int mask, const char *name)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int pci_set_power_state(struct pci_dev *pdev, pci_power_t state)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int pci_enable_device(struct pci_dev *pdev)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

static int pci_request_mem_regions(struct pci_dev *pdev, const char *name)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

u8 *ioremap(u64 address, unsigned long size)
{
	//return (u8 *)mock().returnPointerValueOrDefault(NULL);
	return map_table[0];
}


static void iounmap(u8 *offset)
{
	mock().actualCall(__func__);
}

static void pci_release_mem_regions(struct pci_dev *pdev)
{
	mock().actualCall(__func__);
}

void pci_set_drvdata(struct pci_dev *pdev, void *val)
{
	pdev->dev.driver_data = val;
}
int pci_register_driver(struct pci_driver *drv) { return 0; }
int pci_unregister_driver(struct pci_driver *drv) { return 0; }
int pci_enable_msix_range(struct pci_dev *dev, struct msix_entry *entries,
			  int minvec, int maxvec)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withParameter("entries", entries)
		.withParameter("minvec", minvec)
		.withParameter("maxvec", maxvec);

	/* maybe have caller specify some return value like 129? */
	return mock().intReturnValue();
}

/* this function returns 0 on success (i.e. num_entries were successfully enabled
 * and negative on failure (i.e. num_entries were not successfully enabled). This is different than
 * pci_enable_msix_range() because that function returns either negative for an error or the number
 * of vectors that were enabled between minvec and maxvec.
 */
int pci_enable_msix_exact(struct pci_dev *dev, struct msix_entry *entries, int num_entries)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withParameter("entries", entries)
		.withParameter("num_entries", num_entries);

	return mock().returnIntValueOrDefault(0);
}

int pci_read_config_byte(const struct pci_dev *dev, int where, u8 *val)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

u8 * const *pcim_iomap_table(struct pci_dev *pdev)
{
	/* TODO: convert this to use mock().getData() */
	return map_table;
}

/* TODO: convert to mock().actualCall() */
static void pci_disable_pcie_error_reporting(struct pci_dev *pdev) {}

/* TODO: convert to mock().actualCall() */
static void pci_enable_pcie_error_reporting(struct pci_dev *pdev) {}

static bool pci_ari_enabled(struct pci_bus *bus)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void __iomem *pci_iomap(struct pci_dev *dev, int bar, unsigned long maxlen)
{
	return map_table[0];
}

void pci_iounmap(struct pci_dev *dev, void __iomem *p)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withParameter("p", p);
}

int pci_iov_vf_id(struct pci_dev *dev)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev);
	return mock().intReturnValue();
}

