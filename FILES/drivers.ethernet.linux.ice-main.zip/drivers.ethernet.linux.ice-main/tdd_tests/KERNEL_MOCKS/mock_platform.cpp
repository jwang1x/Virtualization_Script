int platform_device_register(struct platform_device *pdev)
{
	return 0;
}

int mfd_add_devices(struct device *dev, int id,
			 const struct mfd_cell *cells, int n_devs,
			 struct resource *mem_base,
			 int irq_base, struct irq_domain *irq_domain)
{
	mock().actualCall(__func__);
	return 0;
}

void mfd_remove_devices(struct device *parent)
{
	mock().actualCall(__func__);
}

struct bus_type platform_bus_type = {
	.name		= "platform",
};
