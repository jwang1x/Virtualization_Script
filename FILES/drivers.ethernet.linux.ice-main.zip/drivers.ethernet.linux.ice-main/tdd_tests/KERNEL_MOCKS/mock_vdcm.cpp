#include "mdev_private.h"

int mdev_register_device(struct device *dev, const struct mdev_parent_ops *ops)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev)
		.withParameter("ops", ops);

	return mock().returnIntValueOrDefault(0);
}

void mdev_unregister_device(struct device *dev)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev);
}

struct device *mtype_get_parent_dev(struct mdev_type *mtype)
{
	mock().actualCall(__func__)
		.withParameter("mtype", mtype);

	return (struct device *)mock().returnPointerValueOrDefault(NULL);
}

struct device *mdev_parent_dev(struct mdev_device *mdev)
{
	mock().actualCall(__func__)
		.withParameter("mdev", mdev);

	return (struct device *)mock().returnPointerValueOrDefault(NULL);
}

int iommu_dev_enable_feature(struct device *dev, enum iommu_dev_features f)
{
	mock().actualCall(__func__)
		.withParameter("f", f)
		.withParameter("dev", dev);

	return mock().returnIntValueOrDefault(0);
}

int iommu_dev_disable_feature(struct device *dev, enum iommu_dev_features f)
{
	mock().actualCall(__func__)
		.withParameter("f", f)
		.withParameter("dev", dev);

	return mock().returnIntValueOrDefault(0);
}

void vfio_group_put_external_user(struct vfio_group *group)
{
	mock().actualCall(__func__)
		.withParameter("group", group);
}

struct vfio_group *vfio_group_get_external_user_from_dev(struct device *dev)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev);

	return (struct vfio_group *)mock().returnPointerValueOrDefault(NULL);
}

struct iommu_domain *vfio_group_iommu_domain(struct vfio_group *group)
{
	mock().actualCall(__func__)
		.withParameter("group", group);

	return (struct iommu_domain *)mock().returnPointerValueOrDefault(NULL);
}

int iommu_aux_get_pasid(struct iommu_domain *domain, struct device *dev)
{
	mock().actualCall(__func__)
		.withParameter("domain", domain)
		.withParameter("dev", dev);

	return mock().returnIntValueOrDefault(0);
}

__u64 eventfd_signal(struct eventfd_ctx *ctx, __u64 n)
{
	mock().actualCall(__func__);

	return mock().returnIntValueOrDefault(0);
}

void eventfd_ctx_put(struct eventfd_ctx *ctx)
{
	mock().actualCall(__func__);
}

struct eventfd_ctx *eventfd_ctx_fdget(int fd)
{
	mock().actualCall(__func__);

	return (struct eventfd_ctx *)mock().returnPointerValueOrDefault(NULL);
}

void *memdup_user(const void *src, size_t len)
{
	void *p;

	p = malloc(len);
	if (!p)
		return (void *)ERR_PTR(-ENOMEM);

	memcpy(p, src, len);

	return p;
}

int
vfio_set_irqs_validate_and_prepare(struct vfio_irq_set *hdr, int num_irqs,
				   int max_irq_type, size_t *data_size)
{
	mock().actualCall(__func__);

	return mock().returnIntValueOrDefault(0);
}

int
irq_bypass_register_producer(struct irq_bypass_producer *producer)
{
	mock().actualCall(__func__);

	return mock().returnIntValueOrDefault(0);
}

void
irq_bypass_unregister_producer(struct irq_bypass_producer *producer)
{
	mock().actualCall(__func__);

	return;
}

int
vfio_info_add_capability(struct vfio_info_cap *caps, struct vfio_info_cap_header *cap, unsigned long size)
{
	mock().actualCall(__func__)
		.withParameter("caps", caps)
		.withParameter("size", size);

	caps->size = size;
	caps->buf = (struct vfio_info_cap_header *)malloc(size);

	memset(caps->buf, 0, size);

	return mock().returnIntValueOrDefault(0);
}

int
remap_pfn_range(struct vm_area_struct *vm_area, unsigned long addr,
		unsigned long pfn, unsigned long size, pgprot_t)
{
	mock().actualCall(__func__);

	return mock().returnIntValueOrDefault(0);
}

void
vfio_info_cap_shift(struct vfio_info_cap *caps, unsigned long offset)
{
	mock().actualCall(__func__)
		.withParameter("caps", caps)
		.withParameter("offset", offset);

	return;
}
