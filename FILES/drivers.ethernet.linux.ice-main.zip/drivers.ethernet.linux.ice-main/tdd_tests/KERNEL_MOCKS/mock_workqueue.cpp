#define WQ_NAME_LEN 24

struct workqueue_struct {
};

static void destroy_workqueue(struct workqueue_struct *wq)
{
	mock().actualCall(__func__)
		.withParameter("wq", wq);
}

static void flush_workqueue(struct workqueue_struct *wq)
{
	mock().actualCall(__func__)
		.withParameter("wq", wq);
}

static workqueue_struct *
alloc_workqueue(const char *fmt, int flags, int max_active, ...)
{
	static workqueue_struct fake_wq = {};
	char name[WQ_NAME_LEN] = "";
	va_list args;

	va_start(args, max_active);
	vsnprintf(name, sizeof(name), fmt, args);
	va_end(args);

	mock().actualCall(__func__)
		.withParameter("fmt", fmt)
		.withParameter("flags", flags)
		.withParameter("max_active", max_active)
		.withParameter("name", name);

	return (struct workqueue_struct *)mock().returnPointerValueOrDefault(&fake_wq);
}

static workqueue_struct *
alloc_ordered_workqueue(const char *fmt, int flags, ...)
{
	static workqueue_struct fake_wq = {};
	char name[WQ_NAME_LEN] = "";
	va_list args;

	vsnprintf(name, sizeof(name), fmt, args);
	va_end(args);

	mock().actualCall(__func__)
		.withParameter("fmt", fmt)
		.withParameter("flags", flags)
		.withParameter("name", name);

	return (struct workqueue_struct *)mock().returnPointerValueOrDefault(&fake_wq);
}

static bool queue_work(struct workqueue_struct *wq, struct work_struct *work)
{
	mock().actualCall(__func__)
		.withParameter("wq", wq)
		.withParameter("work", work);

	return mock().returnBoolValueOrDefault(true);
}
