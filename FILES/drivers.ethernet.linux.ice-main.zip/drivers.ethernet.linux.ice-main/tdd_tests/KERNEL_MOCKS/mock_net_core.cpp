static
gro_result_t napi_gro_receive(struct napi_struct *napi, struct sk_buff *skb)
{
	mock().expectOneCall(__func__)
		.withParameter("napi", napi)
		.withParameter("skb", skb);

	return (gro_result_t)mock().returnIntValueOrDefault(GRO_NORMAL);
}

static void netdev_tx_reset_queue(struct netdev_queue *q) {}
static void napi_consume_skb(struct sk_buff *skb, int budget) {}

static int page_count(struct page *page)
{
	return 1;
}

static void page_frag_free(void *addr)
{
	return;
}

static inline void page_ref_add(struct page *page, int nr)
{
	return;
}

void *dmam_alloc_coherent(struct device *dev, size_t size, dma_addr_t *dma_handle, gfp_t gfp)
{
	return mock().actualCall(__func__).withParameter("size", size).returnPointerValueOrDefault(0);
}
void dmam_free_coherent(struct device *dev, size_t size, void *vaddr, dma_addr_t dma_handle)
{
	mock().actualCall(__func__).withParameter("size", size);
}
static bool napi_complete_done(struct napi_struct *napi, int num)
{
	return mock().actualCall(__func__).returnBoolValueOrDefault(false);
}
#define netif_stop_subqueue(netdev, q_index)
#define netif_start_subqueue(netdev, q_index)

#define get_page(pi)
#define prefetchw(pi)

#define skb_record_rx_queue(skb, q_index)

#define __skb_linearize(skb) 0

static void csum_replace_by_diff(__sum16 *sum, __wsum diff)
{
	mock().actualCall(__func__);
}

static void *skb_header_pointer(const struct sk_buff *skb, int offset,
				       int len, struct vlan_hdr *buffer)
{
	return buffer;
}

static int skb_cow_head(struct sk_buff *skb, unsigned int headroom)
{
	return mock().actualCall(__func__)
		.withParameter("skb", skb)
		.withParameter("headroom", headroom)
		.returnIntValueOrDefault(0);
}

int skb_checksum_help(struct sk_buff *skb)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

int ipv6_skip_exthdr(const struct sk_buff *skb, int start, u8 *nexthdrp,
		     __be16 *frag_offp)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static __be16 vlan_get_protocol(struct sk_buff *skb)
{
	mock().actualCall(__func__).withParameter("skb", skb);
	return (__be16) mock().intReturnValue();
}

static struct iphdr *ip_hdr(struct sk_buff *skb)
{
	return (iphdr *)mock().actualCall(__func__).returnPointerValueOrDefault(0);
}

static int ipv6_find_hdr(struct sk_buff *skb, unsigned int *offset,
				   int target, unsigned short *fragoff,
				   int *fragflg)
{
	mock().actualCall(__func__)
		.withParameter("skb", skb)
		.withParameter("offset", offset)
		.withParameter("target", target)
		.withParameter("fragoff", fragoff)
		.withParameter("fragflg", fragflg);
	return (int) mock().intReturnValue();
}

static u8 ipv4_get_dsfield(const struct iphdr *iph)
{
	mock().actualCall(__func__);
	return 0;
}

static u8 ipv6_get_dsfield(const struct ipv6hdr *ipv6h)
{
	mock().actualCall(__func__);
	return 0;
}

static u16 netdev_pick_tx(struct net_device *dev, struct sk_buff *skb,
			  struct net_device *sb_dev)
{
	mock().actualCall(__func__);
	return 0;
}

static void skb_mark_napi_id(struct sk_buff *skb,
			     struct napi_struct *napi)
{
	return;
}
