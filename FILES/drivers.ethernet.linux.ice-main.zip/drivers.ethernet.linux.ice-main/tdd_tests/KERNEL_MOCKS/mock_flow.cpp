#include <net/flow_offload.h>


int flow_block_cb_setup_simple(struct flow_block_offload *f,
			       struct list_head *driver_list,
			       flow_setup_cb_t *cb,
			       void *cb_ident, void *cb_priv, bool ingress_only)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
