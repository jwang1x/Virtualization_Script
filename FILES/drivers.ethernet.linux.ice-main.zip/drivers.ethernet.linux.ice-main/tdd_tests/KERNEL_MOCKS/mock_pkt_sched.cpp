struct tc_etf_qopt_offload {
	u8 enable;
	s32 queue;
};
