struct tdd_err_ptr {
	int err;
};

static const struct tdd_err_ptr tdd_err_EAGAIN = { .err = -EAGAIN };
static const struct tdd_err_ptr tdd_err_EOPNOTSUPP = { .err = -EOPNOTSUPP };
static const struct tdd_err_ptr tdd_err_ENOMEM = { .err = -ENOMEM };
static const struct tdd_err_ptr tdd_err_EEXIST = { .err = -EEXIST };
static const struct tdd_err_ptr tdd_err_EINTR = { .err = -EINTR };
static const struct tdd_err_ptr tdd_err_EINVAL = { .err = -EINVAL };
static const struct tdd_err_ptr tdd_err_EIO = { .err = -EIO };
static const struct tdd_err_ptr tdd_err_ENODEV = { .err = -ENODEV };

static bool IS_ERR(const void *ptr)
{
	if (ptr == &tdd_err_EAGAIN)
		return true;
	if (ptr == &tdd_err_EOPNOTSUPP)
		return true;
	if (ptr == &tdd_err_ENOMEM)
		return true;
	if (ptr == &tdd_err_EEXIST)
		return true;
	if (ptr == &tdd_err_EINTR)
		return true;
	if (ptr == &tdd_err_EINVAL)
		return true;
	if (ptr == &tdd_err_EIO)
		return true;
	if (ptr == &tdd_err_ENODEV)
		return true;

	return false;
}

static long PTR_ERR(const void *ptr)
{
	if (IS_ERR(ptr))
		return ((struct tdd_err_ptr *)ptr)->err;
	else
		return 0;
}

static const void *ERR_PTR(long err)
{
	switch (err) {
	case -EAGAIN:
		return (const void *)&tdd_err_EAGAIN;
	case -EOPNOTSUPP:
		return (const void *)&tdd_err_EOPNOTSUPP;
	case -ENOMEM:
		return (const void *)&tdd_err_ENOMEM;
	case -EEXIST:
		return (const void *)&tdd_err_EEXIST;
	case -EINTR:
		return (const void *)&tdd_err_EINTR;
	case -EINVAL:
		return (const void *)&tdd_err_EINVAL;
	case -EIO:
		return (const void *)&tdd_err_EIO;
	case -ENODEV:
		return (const void *)&tdd_err_ENODEV;
	default:
		FAIL(StringFromFormat("Err value %ld has not been added as a valid error pointer", err).asCharString());
		return NULL;
	}
}
