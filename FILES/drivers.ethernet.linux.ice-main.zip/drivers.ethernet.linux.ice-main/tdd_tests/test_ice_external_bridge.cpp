#ifdef BMSM_MODE
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_external_bridge {
	#include "tdd_shared_code_transform.h"
	#include "ice_osdep.h"
	#include "kernel_abstract.h"

	#include "../src/CORE/ice.h"

	#include "CORE_MOCKS/mock_ice_main.cpp"
	#include "CORE_MOCKS/mock_ice_lib.cpp"
	#include "CORE_MOCKS/mock_ice_hw_lag.cpp"
	#include "SHARED_MOCKS/mock_ice_common.cpp"
	#include "SHARED_MOCKS/mock_ice_sched.cpp"
	#include "KERNEL_MOCKS/mock_kernel.cpp"

	#include "CORE_MOCKS/stdmock_ice_external_bridge.cpp"
	#include "CORE_MOCKS/mock_ice_sriov.cpp"

	#include "../src/CORE/ice_external_bridge.c"
}

using namespace ns_external_bridge;

TEST_GROUP(ice_external_bridge)
{
	struct pci_dev *pdev;
	struct ice_pf *pf;
	struct ice_vsi *vsi;
	struct ice_vsi *pf_vsi;
	struct ice_port_info *br_pi;
	struct ice_port_info *pi;
	struct peerchnl_event *event;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		pf->pdev = pdev;
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi**)
			calloc(1, sizeof(struct ice_vsi *) * pf->num_alloc_vsi);
		pf_vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[0] = pf_vsi;
		pf->hw.port_info = (struct ice_port_info *)
			calloc(ICE_MAX_PORT_PER_PCI_DEV, sizeof(struct ice_port_info));

		br_pi = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		br_pi->lport = 20;

		pi = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));

		event = (struct peerchnl_event *)calloc(1, sizeof(struct peerchnl_event *));

		mutex_init(&pf->vfs.table_lock);
	}

	void teardown(void)
	{
		mutex_destroy(&pf->vfs.table_lock);

		mock().checkExpectations();
		mock().clear();
		free(event);
		free(pi);
		free(br_pi);
		free(pf->hw.port_info);
		free(pf_vsi);
		free(pf->vsi);
		free(pf->pdev);
		free(pf);
	}
};

#if 0

/* these tests don't seem to be setup correctly. ice_bridge_create
 * calls ice_setup_pf_sw and this flow should set up the VSI for
 * the port (br_pi) but this doesn't seem to be happening. Disabling
 * these for now until the BMSM team can correct this
 */
TEST(ice_external_bridge, ice_bridge_create_vsi_already_exists)
{
	int err;

	mock().expectOneCall("ice_find_vsi_from_pi")
		.andReturnValue(pf_vsi);

	err = ice_bridge_create(pf, br_pi);
	CHECK_EQUAL(0, err);

}

TEST(ice_external_bridge, ice_bridge_create)
{
	int err;

	mock().expectOneCall("ice_find_vsi_from_pi");
	mock().expectOneCall("ice_setup_pf_sw");
	mock().expectOneCall("ice_find_port_info_idx");

	err = ice_bridge_create(pf, br_pi);
	CHECK_EQUAL(0, err);
}
#endif

TEST(ice_external_bridge, ice_bridge_destroy_vsi_does_not_exist)
{
	int err;
	mock().expectOneCall("ice_find_vsi_from_pi");

	err = ice_bridge_destroy(pf, br_pi);
	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_bridge_destroy)
{
	int err;
	mock().expectOneCall("ice_find_vsi_from_pi")
		.andReturnValue(pf_vsi);
	mock().expectOneCall("ice_vsi_release").withParameter("vsi", pf_vsi);

	err = ice_bridge_destroy(pf, br_pi);
	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_bridge_add_port_first)
{
	int err;
	int weight_before, weight_after;

	pi->vf_allowed = true;

	mock().expectOneCall("ice_sched_copy_cgd");

	weight_before = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	err = ice_bridge_add_port(pf, pi, br_pi);
	weight_after = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(weight_before + 1, weight_after);
	CHECK_EQUAL(false, pi->vf_allowed);
}

TEST(ice_external_bridge, ice_bridge_add_port_second)
{
	int err;
	int weight_before, weight_after;

	set_bit(1, pf->br.ports);
	pi->vf_allowed = true;

	weight_before = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	err = ice_bridge_add_port(pf, pi, br_pi);
	weight_after = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(weight_before + 1, weight_after);
	CHECK_EQUAL(false, pi->vf_allowed);
}

TEST(ice_external_bridge, ice_bridge_del_first_port)
{
	int err;
	int weight_before, weight_after;

	pi->lport = 1;
	pi->is_bridge_member = true;
	pf->br.first_lport = 1;
	pf->br.ports[0] = 3;

	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(&pf->hw.port_info[0]);
	mock().expectOneCall("ice_sched_copy_cgd")
		.andReturnValue(0);

	weight_before = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	err = ice_bridge_del_port(pf, pi, br_pi);
	weight_after = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(weight_before - 1, weight_after);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(0, pf->br.first_lport);
}

TEST(ice_external_bridge, ice_bridge_del_port_other_than_first)
{
	int err;
	int weight_before, weight_after;

	pi->lport = 0;
	pi->is_bridge_member = true;
	pf->br.first_lport = 1;
	pf->br.ports[0] = 3;

	weight_before = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	err = ice_bridge_del_port(pf, pi, br_pi);
	weight_after = bitmap_weight(pf->br.ports, ICE_MAX_PORT_PER_PCI_DEV);

	CHECK_EQUAL(0, err);
	CHECK_EQUAL(weight_before - 1, weight_after);
	CHECK_EQUAL(true, pi->vf_allowed);
}


TEST(ice_external_bridge, ice_bridge_del_all_ports_no_ports)
{
	int err;

	USE_STD_MOCK(ice_bridge_del_port);

	err = ice_bridge_del_all_ports(pf, br_pi);

	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_bridge_del_all_ports_one_port)
{
	int err;
	pf->br.ports[0] = 1;

	USE_STD_MOCK(ice_bridge_del_port);

	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(pi);
	mock().expectOneCall("ice_bridge_del_port")
		.withParameter("pf", pf)
		.withParameter("pi", pi)
		.withParameter("br_pi", br_pi);

	err = ice_bridge_del_all_ports(pf, br_pi);

	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_bridge_clean)
{
	USE_STD_MOCK(ice_bridge_get_br_port);
	USE_STD_MOCK(ice_bridge_del_all_ports);
	USE_STD_MOCK(ice_bridge_destroy);

	mock().expectOneCall("ice_bridge_get_br_port")
		.andReturnValue(br_pi);
	mock().expectOneCall("ice_bridge_del_all_ports");
	mock().expectOneCall("ice_bridge_destroy");

	ice_bridge_clean(pf);
}

TEST(ice_external_bridge, ice_handle_ies_bridge_event_create_bridge)
{
	int err;
	event->event = PEERCHNL_EVENT_BRIDGE_ADD_PORT;
	event->event_data = 20;
	pf->hw.port_info[0].lport = 20;

	USE_STD_MOCK(ice_bridge_get_br_port);
	USE_STD_MOCK(ice_bridge_create);
	USE_STD_MOCK(ice_bridge_add_port);
	USE_STD_MOCK(ice_bridge_destroy);
	USE_STD_MOCK(ice_bridge_del_port);

	mock().expectOneCall("ice_bridge_get_br_port")
		.andReturnValue(br_pi);
	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(&pf->hw.port_info[0]);
	mock().expectOneCall("ice_bridge_create");

	err = ice_handle_ies_bridge_event(pf, event);
	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_handle_ies_bridge_event_add_port)
{
	int err;
	event->event = PEERCHNL_EVENT_BRIDGE_ADD_PORT;
	event->event_data = 1;

	USE_STD_MOCK(ice_bridge_get_br_port);
	USE_STD_MOCK(ice_bridge_create);
	USE_STD_MOCK(ice_bridge_add_port);
	USE_STD_MOCK(ice_bridge_destroy);
	USE_STD_MOCK(ice_bridge_del_port);

	mock().expectOneCall("ice_bridge_get_br_port")
		.andReturnValue(br_pi);
	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(&pf->hw.port_info[0]);
	mock().expectOneCall("ice_bridge_add_port")
		.withParameter("pf", pf)
		.withParameter("pi", &pf->hw.port_info[0])
		.withParameter("br_pi", br_pi);

	err = ice_handle_ies_bridge_event(pf, event);
	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_handle_ies_bridge_event_destroy_bridge)
{
	int err;
	event->event = PEERCHNL_EVENT_BRIDGE_DEL_PORT;
	event->event_data = 20;
	pf->hw.port_info[0].lport = 20;

	USE_STD_MOCK(ice_bridge_get_br_port);
	USE_STD_MOCK(ice_bridge_create);
	USE_STD_MOCK(ice_bridge_add_port);
	USE_STD_MOCK(ice_bridge_destroy);
	USE_STD_MOCK(ice_bridge_del_port);

	mock().expectOneCall("ice_bridge_get_br_port")
		.andReturnValue(br_pi);
	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(&pf->hw.port_info[0]);
	mock().expectOneCall("ice_bridge_destroy");

	err = ice_handle_ies_bridge_event(pf, event);
	CHECK_EQUAL(0, err);
}

TEST(ice_external_bridge, ice_handle_ies_bridge_event_del_port)
{
	int err;
	event->event = PEERCHNL_EVENT_BRIDGE_DEL_PORT;
	event->event_data = 1;

	USE_STD_MOCK(ice_bridge_get_br_port);
	USE_STD_MOCK(ice_bridge_create);
	USE_STD_MOCK(ice_bridge_add_port);
	USE_STD_MOCK(ice_bridge_destroy);
	USE_STD_MOCK(ice_bridge_del_port);

	mock().expectOneCall("ice_bridge_get_br_port")
		.andReturnValue(br_pi);
	mock().expectOneCall("ice_find_port_info")
		.andReturnValue(&pf->hw.port_info[0]);
	mock().expectOneCall("ice_bridge_del_port")
		.withParameter("pf", pf)
		.withParameter("pi", &pf->hw.port_info[0])
		.withParameter("br_pi", br_pi);

	err = ice_handle_ies_bridge_event(pf, event);
	CHECK_EQUAL(0, err);
}
#endif /* BMSM_MODE */
