bool ice_vc_is_opcode_allowed(struct ice_vf *vf, u32 opcode)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void ice_vc_allowlist_opcodes(struct ice_vf *vf, const u32 *opcodes,
			      size_t size)
{
	mock().actualCall(__func__);
}

void ice_vc_set_default_allowlist(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_vc_set_caps_allowlist(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_vc_set_working_allowlist(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}
