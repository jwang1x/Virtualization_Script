#ifdef DCF_SUPPORT
bool ice_dcf_aq_cmd_permitted(struct ice_aq_desc *desc)
{
	mock().actualCall(__func__)
		.withParameter("desc", desc);

	return mock().returnBoolValueOrDefault(true);
}

bool ice_check_dcf_allowed(struct ice_vf *vf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_is_dcf_enabled(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);

	return mock().returnBoolValueOrDefault(true);
}

bool ice_is_vf_dcf(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return mock().returnBoolValueOrDefault(true);
}

enum ice_dcf_state ice_dcf_get_state(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);

	return (enum ice_dcf_state)
			mock().returnIntValueOrDefault(ICE_DCF_STATE_ON);
}

void ice_dcf_set_state(struct ice_pf *pf, enum ice_dcf_state state)
{
	mock().actualCall(__func__);
}

void ice_dcf_init_sw_rule_mgmt(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_rm_all_dcf_sw_rules(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_rm_dcf_sw_vsi_rule(struct ice_pf *pf, u16 hw_vsi_id)
{
	mock().actualCall(__func__);
}

bool
ice_dcf_pre_aq_send_cmd(struct ice_vf *vf, struct ice_aq_desc *aq_desc,
			u8 *aq_buf, u16 aq_buf_size)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("aq_desc", aq_desc)
		.withParameter("aq_buf", aq_buf)
		.withParameter("aq_buf_size", aq_buf_size);

	return mock().returnBoolValueOrDefault(false);
}

enum virtchnl_status_code
ice_dcf_post_aq_send_cmd(struct ice_pf *pf, struct ice_aq_desc *aq_desc,
			 u8 *aq_buf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("aq_desc", aq_desc)
		.withParameter("aq_buf", aq_buf);

	return (enum virtchnl_status_code)mock().returnIntValueOrDefault(0);
}

bool ice_dcf_is_acl_aq_cmd(struct ice_aq_desc *desc)
{
	mock().actualCall(__func__);

	return mock().returnBoolValueOrDefault(false);
}

void ice_clear_dcf_acl_cfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

bool ice_dcf_is_acl_capable(struct ice_hw *hw)
{
	mock().actualCall(__func__);

	return mock().returnBoolValueOrDefault(false);
}

enum virtchnl_status_code
ice_dcf_update_acl_rule_info(struct ice_pf *pf, struct ice_aq_desc *desc,
			     u8 *aq_buf)
{
	mock().actualCall(__func__);

	return (enum virtchnl_status_code)mock().returnIntValueOrDefault(0);
}

void ice_clear_dcf_udp_tunnel_cfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

bool ice_dcf_is_udp_tunnel_capable(struct ice_hw *hw)
{
	mock().actualCall(__func__);

	return mock().returnBoolValueOrDefault(false);
}

bool ice_dcf_is_udp_tunnel_aq_cmd(struct ice_aq_desc *desc, u8 *aq_buf)
{
	mock().actualCall(__func__);

	return mock().returnBoolValueOrDefault(false);
}
#endif
