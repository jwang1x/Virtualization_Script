int
ice_mbx_send_msg_to_ies(struct ice_pf *pf, u16 msg_opcode, u16 seq_num,
			u8 data, void *buf, u16 buf_size,
			struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return 0;
}

int
ice_send_phy_state_change_to_ies(struct ice_pf *pf, u32 lports_map, bool state)
{
	mock().actualCall(__func__);
	return 0;
}
