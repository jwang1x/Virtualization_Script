int ice_repr_add_for_all_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_repr_rem_from_all_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_repr_test_and_add_for_vf(struct ice_pf *pf, struct ice_vf *vf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_repr_test_and_rem_from_vf(struct ice_pf *pf, struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_repr_set_traffic_vsi(struct ice_repr *repr, struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

struct ice_repr *ice_netdev_to_repr(struct net_device *netdev)
{
	mock().actualCall(__func__);
	return (struct ice_repr *)mock().returnPointerValueOrDefault(NULL);
}

bool ice_is_port_repr_netdev(struct net_device *netdev)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void ice_repr_start_tx_queues(struct ice_repr *repr)
{
	mock().actualCall(__func__);
}

void ice_repr_stop_tx_queues(struct ice_repr *repr)
{
	mock().actualCall(__func__);
}
