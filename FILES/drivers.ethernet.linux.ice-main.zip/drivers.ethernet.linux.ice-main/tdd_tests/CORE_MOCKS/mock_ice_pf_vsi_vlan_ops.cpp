void ice_pf_vsi_init_vlan_ops(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}
