void ice_vsi_init_vlan_ops(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}

struct ice_vsi_vlan_ops *ice_get_compat_vsi_vlan_ops(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return (struct ice_vsi_vlan_ops *)mock().returnPointerValueOrDefault(NULL);
}

int mock_add_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tpid", vlan->tpid)
		.withParameter("vid", vlan->vid)
		.withParameter("prio", vlan->prio)
		.withParameter("fwd_act", vlan->fwd_act);
	return mock().returnIntValueOrDefault(0);
}

int mock_del_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tpid", vlan->tpid)
		.withParameter("vid", vlan->vid)
		.withParameter("prio", vlan->prio)
		.withParameter("fwd_act", vlan->fwd_act);
	return mock().returnIntValueOrDefault(0);
}

int mock_set_port_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tpid", vlan->tpid)
		.withParameter("vid", vlan->vid)
		.withParameter("prio", vlan->prio)
		.withParameter("fwd_act", vlan->fwd_act);
	return mock().returnIntValueOrDefault(0);
}

int mock_ena_stripping(struct ice_vsi *vsi, u16 tpid)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tpid", tpid);
	return mock().returnIntValueOrDefault(0);
}

int mock_dis_stripping(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

int mock_ena_insertion(struct ice_vsi *vsi, u16 tpid)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tpid", tpid);
	return mock().returnIntValueOrDefault(0);
}

int mock_dis_insertion(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

int mock_ena_rx_vlan_filtering(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

int mock_dis_rx_vlan_filtering(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

void init_vlan_ops_mocks(struct ice_vsi_vlan_ops *vlan_ops)
{
	vlan_ops->add_vlan = &mock_add_vlan;
	vlan_ops->del_vlan = &mock_del_vlan;
	vlan_ops->ena_stripping = &mock_ena_stripping;
	vlan_ops->dis_stripping = &mock_dis_stripping;
	vlan_ops->ena_insertion = &mock_ena_insertion;
	vlan_ops->dis_insertion = &mock_dis_insertion;
	vlan_ops->ena_rx_filtering = &mock_ena_rx_vlan_filtering;
	vlan_ops->dis_rx_filtering = &mock_dis_rx_vlan_filtering;
	vlan_ops->set_port_vlan = &mock_set_port_vlan;
}
