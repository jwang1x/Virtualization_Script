/* This file contains implementations of mock functions in the TDD ice_osdep.h
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

static inline void writel_relaxed(u32 value, void *addr)
{
	mock().actualCall(__func__)
		.withParameter("value", value)
		.withParameter("addr", addr);
}


}; /* End of namespace stdmock. Function implementations go above this line */
