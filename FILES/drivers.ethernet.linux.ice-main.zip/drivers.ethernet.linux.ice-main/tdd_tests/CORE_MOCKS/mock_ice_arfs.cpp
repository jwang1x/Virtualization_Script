#include "ice_type.h"

void ice_sync_arfs_fltrs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_init_arfs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_clear_arfs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_set_cpu_rx_rmap(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_free_cpu_rx_rmap(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_remove_arfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_rebuild_arfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

#ifndef SWITCH_MODE
bool
ice_is_arfs_using_perfect_flow(struct ice_hw *hw, enum ice_fltr_ptype flow_type)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}
#endif
