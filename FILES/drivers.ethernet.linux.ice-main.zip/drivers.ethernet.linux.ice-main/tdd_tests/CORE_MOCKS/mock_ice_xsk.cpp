int ice_xsk_pool_setup(struct ice_vsi *vsi, struct xsk_buff_pool *pool, u16 qid)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
int ice_xsk_umem_query(struct ice_vsi *vsi, struct xdp_umem **umem, u16 qid)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
int ice_clean_rx_irq_zc(struct ice_ring *ring, int budget)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
void ice_zca_free(struct zero_copy_allocator *zca, unsigned long handle)
{
	mock().actualCall(__func__);
}
bool ice_clean_tx_irq_zc(struct ice_ring *xdp_ring)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_xsk_any_rx_ring_ena(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().boolReturnValue();
}

static void ice_xsk_clean_rx_ring(struct ice_ring *xdp_ring)
{
	mock().actualCall(__func__);
}

static void ice_xsk_clean_xdp_ring(struct ice_ring *xdp_ring)
{
	mock().actualCall(__func__);
}

bool ice_alloc_rx_bufs_slow_zc(struct ice_ring *rx_ring, u16 count)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

bool ice_alloc_rx_bufs_zc(struct ice_ring *rx_ring, u16 count)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}
