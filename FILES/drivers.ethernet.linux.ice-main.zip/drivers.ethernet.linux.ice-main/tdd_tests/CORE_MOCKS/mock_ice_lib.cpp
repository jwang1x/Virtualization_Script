int
ice_add_mac_to_list(struct ice_vsi *vsi, struct list_head *add_list,
		    const u8 *macaddr, enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_free_fltr_list(struct device *dev, struct list_head *h)
{
	mock().actualCall(__func__);
}

bool ice_pf_state_is_nominal(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

void ice_update_eth_stats(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_vsi_cfg_rxqs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_cfg_lan_txqs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
void ice_vsi_cfg_single_msix(struct ice_vsi *vsi, u16 vector_id)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE && ADK_SUPPORT */

void ice_vsi_cfg_msix(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

#ifdef CONFIG_PCI_IOV
int ice_vsi_cfg_mac_fltr(struct ice_vsi *vsi, const u8 *macaddr, bool set)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif /* CONFIG_PCI_IOV */

int ice_vsi_start_all_rx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_stop_all_rx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_vsi_stop_lan_tx_rings(struct ice_vsi *vsi, enum ice_disq_rst_src rst_src,
			  u16 rel_vmvf_num)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT

int ice_vsi_cfg_xdp_txqs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_stop_xdp_tx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#ifdef HAVE_AF_XDP_ZC_SUPPORT
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */

#ifndef SWITCH_MODE
void ice_cfg_sw_lldp(struct ice_vsi *vsi, bool tx, bool create)
{
	mock().actualCall(__func__);
}
#endif /* !SWITCH_MODE */

void ice_vsi_delete(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_vsi_clear(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_vsi_cfg_netdev_tc(struct ice_vsi *vsi, u8 ena_tc)
{
	mock().actualCall(__func__);
}

int ice_vsi_cfg_tc(struct ice_vsi *vsi, u8 ena_tc)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_cfg_rss_lut_key(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_get_valid_rss_size(struct ice_hw *hw, int new_size)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(new_size);
}

int ice_vsi_set_dflt_rss_lut(struct ice_vsi *vsi, int req_rss_size)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#ifdef ADK_SUPPORT
int ice_vsi_map_vlan_pcp_q_sel(struct ice_vsi *vsi, u8 *q_sel_map)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_manage_vlan_pcp_q_sel(struct ice_vsi *vsi, bool ena)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif /* ADK_SUPPORT */

#if defined(SRIOV_SUPPORT) && defined(ADQ_SUPPORT)
struct ice_vsi *
ice_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi,
	      enum ice_vsi_type type, struct ice_vf *vf,
	      struct ice_channel *ch, u8 tc)
#elif defined(ADQ_SUPPORT)
struct ice_vsi *
ice_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi,
	      enum ice_vsi_type type, struct ice_vf *vf,
	      struct ice_channel *ch)
#else
struct ice_vsi *
ice_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi,
	      enum ice_vsi_type type, struct ice_vf *vf)
#endif
{
	mock().actualCall(__func__)
#ifdef ADQ_SUPPORT
		.withParameter("ch", ch)
		.withParameter("tc", tc)
#endif /* ADQ_SUPPORT */
		.withParameter("pf", pf)
		.withParameter("pi", pi)
		.withParameter("type", type)
		.withParameter("vf", vf);

	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

void ice_napi_del(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_vsi_release(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

void ice_vsi_close(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_ena_vsi(struct ice_vsi *vsi, bool locked)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_dis_vsi(struct ice_vsi *vsi, bool locked)
{
	mock().actualCall(__func__);
}

int ice_free_res(struct ice_res_tracker *res, u16 index, u16 id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_get_res(struct ice_pf *pf, struct ice_res_tracker *res, u16 needed, u16 id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_rebuild(struct ice_vsi *vsi, bool init_vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_is_reset_in_progress(unsigned long *state)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void ice_vsi_put_qs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
void ice_vsi_dis_single_irq(struct ice_vsi *vsi, u16 vector_id)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE && !BMSM_MODE */

void ice_vsi_dis_irq(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
void ice_vsi_free_single_irq(struct ice_vsi *vsi, u16 vector_id)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE && !BMSM_MODE */

void ice_vsi_free_irq(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_vsi_free_rx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_vsi_free_tx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_vsi_manage_rss_lut(struct ice_vsi *vsi, bool ena)
{
	mock().actualCall(__func__);
}

void ice_pf_clean_rss_flow_fld(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_vsi_set_rss_flow_fld(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_vsi_set_vf_rss_flow_fld(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

irqreturn_t ice_msix_clean_rings(int __always_unused irq, void *data)
{
	mock().actualCall(__func__);
	return (irqreturn_t) 0;
}

u32 ice_intrl_usec_to_reg(u8 intrl, u8 gran)
{
	mock().actualCall(__func__);
	return (u32) mock().returnIntValueOrDefault(0);
}

void ice_set_q_vector_intrl(struct ice_q_vector *q_vector)
{
	mock().actualCall(__func__);
}

void ice_vsi_get_q_vector_q_base(struct ice_vsi *vsi, u16 vector_id, u16 *txq,
				 u16 *rxq)
{
	mock().actualCall(__func__);
}

void ice_write_intrl(struct ice_q_vector *q_vector, u8 intrl)
{
	mock().actualCall(__func__)
		.withParameter("q_vector", q_vector)
		.withParameter("intrl", intrl);
}

void __ice_write_itr(struct ice_q_vector *q_vector, struct ice_ring_container *rc, u16 itr)
{
	mock().actualCall(__func__);
}

void ice_write_itr(struct ice_ring_container *rc, u16 itr)
{
	mock().actualCall(__func__);
}

char *ice_nvm_version_str(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (char *) mock().returnPointerValueOrDefault((void*)"0.00 0x0 0.0.0");
}

void ice_update_tx_ring_stats(struct ice_ring *tx_ring, u64 pkts, u64 bytes)
{
	mock().actualCall(__func__);
}

void ice_update_rx_ring_stats(struct ice_ring *rx_ring, u64 pkts, u64 bytes)
{
	mock().actualCall(__func__);
}

void ice_vsi_cfg_frame_size(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_setup_fw_log(struct ice_pf *pf, u8 level, u32 events)
{
	mock().actualCall(__func__);
}

const char *ice_vsi_type_str(enum ice_vsi_type type)
{
	mock().actualCall(__func__);
	return (const char *)
		mock().returnPointerValueOrDefault((void*)"ICE_VSI_TDD");
}

bool ice_is_safe_mode(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

#ifdef PEER_SUPPORT
bool ice_is_peer_ena(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}
#endif

bool ice_vsi_is_vlan_pruning_ena(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_is_dflt_vsi_in_use(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_is_vsi_dflt_vsi(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

int ice_set_dflt_vsi(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_clear_dflt_vsi(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
int ice_recalc_each_link_speed_kbps(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

u32 ice_calc_link_speed_kbps(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return (u32) mock().returnIntValueOrDefault(0);
}
#endif /* BMSM_MODE */

int ice_set_min_bw_limit(struct ice_vsi *vsi, u64 min_tx_rate)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("min_tx_rate", min_tx_rate);
	return mock().returnIntValueOrDefault(0);
}

int ice_set_max_bw_limit(struct ice_vsi *vsi, u64 max_tx_rate)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("max_tx_rate", max_tx_rate);
	return mock().returnIntValueOrDefault(0);
}

void
ice_write_qrxflxp_cntxt(struct ice_hw *hw, u16 pf_q, u32 rxdid, u32 prio,
			bool ena_ts)
{
	mock().actualCall(__func__);
}

int ice_get_link_speed_mbps(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(100000);
}

#ifdef ESWITCH_SUPPORT
int ice_vsi_update_security(struct ice_vsi *vsi,
			    void (*fill)(struct ice_vsi_ctx *))
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_vsi_ctx_set_antispoof(struct ice_vsi_ctx *ctx)
{
	mock().actualCall(__func__);
}

void ice_vsi_ctx_clear_antispoof(struct ice_vsi_ctx *ctx)
{
	mock().actualCall(__func__);
}

void ice_vsi_ctx_set_allow_override(struct ice_vsi_ctx *ctx)
{
	mock().actualCall(__func__);
}

void ice_vsi_ctx_clear_allow_override(struct ice_vsi_ctx *ctx)
{
	mock().actualCall(__func__);
}
#endif /* ESWITCH_SUPPORT */

int ice_check_mtu_valid(struct net_device *netdev, int new_mtu)
{
	mock().actualCall(__func__)
		.withParameter("netdev", netdev)
		.withParameter("new_mtu", new_mtu);
	return mock().returnIntValueOrDefault(0);
}

void ice_rebuild_aggregator_node_cfg(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_vsi_cfg_single_rxq(struct ice_vsi *vsi, u16 q_idx)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("q_idx", q_idx);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_cfg_single_txq(struct ice_vsi *vsi, struct ice_ring **tx_rings, u16 q_idx)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("tx_rings", tx_rings)
		.withParameter("q_idx", q_idx);
	return mock().returnIntValueOrDefault(0);
}

int ice_set_link(struct ice_vsi *vsi, bool ena)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_add_vlan_zero(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_vsi_has_non_zero_vlans(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

u16 ice_vsi_num_non_zero_vlans(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_del_vlan_zero(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_wait_for_reset(struct ice_pf *pf, unsigned long timeout)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_is_aux_ena(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

void ice_vsi_cfg_crc_strip(struct ice_vsi *vsi, bool disable)
{
	mock().actualCall(__func__);
}

#ifdef FEATURE_BITS_SUPPORT
void ice_init_feature_support(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

bool ice_is_feature_supported(struct ice_pf *pf, enum ice_feature f)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("f", f);
	return mock().returnBoolValueOrDefault(false);
}

void ice_clear_feature_support(struct ice_pf *pf, enum ice_feature f)
{
	mock().actualCall(__func__);
}

int ice_get_link_speed_kbps(struct ice_vsi * vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(100000000);
}
#endif
