/* This file contains implementations of mock functions in the ice_hw_lag.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * ice_hw_lag.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_hw_lag.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall()
 * should remain near the test code that calls them.
 */

namespace stdmock {

#include "mock_ice_hw_lag.cpp"

static inline s8 ice_hw_lag_get_idx(u8 lag_lport)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int ice_hw_lag_move_cgd(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info * pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int ice_hw_lag_create(struct ice_pf *pf, struct ice_hw_lag *lag)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static void ice_hw_lag_destroy(struct ice_pf *pf, struct ice_hw_lag *lag, bool is_reset)
{
	mock().actualCall(__func__);
}

static int ice_hw_lag_add_port(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info *pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int ice_hw_lag_del_port(struct ice_pf *pf, struct ice_hw_lag *lag, struct ice_port_info *pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

}; /* End of namespace stdmock. Function implementations go above this line */
