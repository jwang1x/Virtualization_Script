int ice_finish_init_peer_obj(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_unroll_cdev_info(struct iidc_core_dev_info *cdev_info,
			 void __always_unused *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_init_aux_devices(struct ice_pf *pf)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

void platform_device_unregister(struct platform_device *pdev)
{
	return;
}

int ice_unreg_peer_obj(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_peer_close(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

void ice_send_vf_reset_to_peers(struct ice_pf *pf, u16 vf_id)
{
	mock().actualCall(__func__);
}

int ice_peer_vf_reset(struct device *dev, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_peer_check_for_reg(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_process_msg_from_peer_drv(struct device_driver *driver, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

void ice_send_fw_event_to_all_peer_drv(struct ice_pf *pf, struct ice_rq_event_info *event)
{
	mock().actualCall(__func__);
}

void ice_send_gen_event_to_all_peer_drv(struct ice_pf *pf, struct peerchnl_event *event)
{
	mock().actualCall(__func__);
}

#if defined SWITCH_MODE && !defined BMSM_MODE
void ice_send_mtu_event_to_all_peer_drv(struct ice_pf *pf, u8 lport, int new_mtu)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE && !BMSM_MODE */

int ice_send_link_event_to_peers(struct ice_vsi *vsi, struct ice_port_info *pi,
				 bool link_up)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int ice_peer_update_vsi(struct ice_peer_obj_int *peer_obj_int, void *data)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

int
ice_for_each_aux(struct ice_pf *pf, void *data,
		  int (*fn)(struct iidc_core_dev_info *, void *))
{
	mock().actualCall(__func__);
	return 0;
}

enum ice_status
ice_send_add_pre_veb_to_peer_drv(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	return (enum ice_status)mock().actualCall("ice_send_add_pre_veb_to_peer_drv")
		.returnIntValueOrDefault(0);
}

enum ice_status
ice_send_del_pre_veb_to_peer_drv(struct ice_pf *pf, int rule_id)
{
	return (enum ice_status)mock().actualCall("ice_send_del_pre_veb_to_peer_drv")
		.returnIntValueOrDefault(0);
}

struct iidc_auxiliary_drv
*ice_get_auxiliary_drv(struct iidc_core_dev_info *cdi)
{
	mock().actualCall(__func__);
	return NULL;
}

static void
ice_send_event_to_auxs(struct ice_pf *pf, void *data)
{
	mock().actualCall(__func__);
}

void
ice_send_event_to_aux(struct iidc_core_dev_info *cdev_info,
		      struct iidc_event *event)
{
	mock().actualCall(__func__);
}

int ice_cdev_info_update_vsi(struct iidc_core_dev_info *cdev_info,
			     struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return 0;
}

void ice_unplug_aux_devs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_unplug_aux_dev(struct iidc_core_dev_info *cdev_info)
{
	mock().actualCall(__func__);
}

int ice_plug_aux_devs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_plug_aux_dev(struct iidc_core_dev_info *cdev_info, const char *name)
{
	mock().actualCall(__func__);
	return 0;
}

struct iidc_core_dev_info
*ice_find_cdev_info_by_id(struct ice_pf *pf, int cdev_info_id)
{
	mock().actualCall(__func__);
	return NULL;
}

void ice_send_vf_reset_to_aux(struct iidc_core_dev_info *cdev_info, u16 vf_id)
{
	mock().actualCall(__func__)
		.withParameter("vf_id", vf_id);
}

bool ice_is_rdma_aux_loaded(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
int ice_get_ae_aux_and_lock(struct ice_pf *pf,
			    struct iidc_auxiliary_drv **adrv,
			    struct iidc_core_dev_info **cdev_info)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif

DEFINE_IDA(ice_peer_index_ida);
