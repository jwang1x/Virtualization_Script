int ice_vf_init_host_cfg(struct ice_vf *vf, struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("vsi", vsi);

	return mock().returnIntValueOrDefault(0);
}
