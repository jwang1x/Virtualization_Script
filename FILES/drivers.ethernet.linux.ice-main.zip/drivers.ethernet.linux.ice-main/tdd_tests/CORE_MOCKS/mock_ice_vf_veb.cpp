void ice_vf_del_pre_veb(struct ice_pf *pf, int rule_id)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("rule_id", rule_id);
}

void ice_vf_sync_pre_veb_peer(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
}

void ice_vf_free_pre_veb(struct ice_vf *vf)
{
        mock().actualCall(__func__)
		.withParameter("vf", vf);
}

void ice_vf_send_add_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
        mock().actualCall(__func__)
		.withParameter("vlan_id", vlan_id)
		.withParameter("vf", vf)
		.withParameter("mac_addr", mac_addr);
}

void ice_vf_send_del_pre_veb_peer(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
        mock().actualCall(__func__)
		.withParameter("vlan_id", vlan_id)
		.withParameter("vf", vf)
		.withParameter("mac_addr", mac_addr);
}

int ice_vf_add_pre_veb(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr)
{
	return mock().actualCall(__func__)
		.withParameter("vlan_id", vlan_id)
		.withParameter("vf", vf)
		.withParameter("mac_addr", mac_addr)
		.returnIntValueOrDefault(0);
}

int
ice_vf_update_pre_veb_status(struct ice_vf *vf, u16 vlan_id, u8 *mac_addr,
			     int rule_id, bool sent_state)
{
	return mock().actualCall(__func__)
		.withParameter("vlan_id", vlan_id)
		.withParameter("vf", vf)
		.withParameter("mac_addr", mac_addr)
		.returnIntValueOrDefault(0);
}
