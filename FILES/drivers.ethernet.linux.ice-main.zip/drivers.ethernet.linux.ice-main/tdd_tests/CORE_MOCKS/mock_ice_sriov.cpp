void ice_vc_process_vf_msg(struct ice_pf *pf, struct ice_rq_event_info *event)
{
	mock().actualCall(__func__);
}

void ice_free_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_vc_notify_reset(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_vc_notify_link_state(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_process_vflr_event(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_reset_all_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_reset_vf(struct ice_vf *vf, u32 flags)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("flags", flags);

	return mock().returnIntValueOrDefault(0);
}

struct ice_vsi *
ice_vf_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi, u16 vf_id)
{
       mock().actualCall(__func__)
               .withIntParameter("vf_id", vf_id);
       return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

int ice_vsi_set_pvid(struct ice_vsi *vsi, u16 vid)
{
       mock().actualCall(__func__);
       return mock().returnIntValueOrDefault(0);
}

int ice_vsi_kill_pvid(struct ice_vsi *vsi)
{
       mock().actualCall(__func__);
       return mock().returnIntValueOrDefault(0);
}

int ice_calc_vf_reg_idx(struct ice_vf *vf, struct ice_q_vector *q_vector, u8 tc)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_set_vf_state_qs_dis(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_wait_on_vf_reset(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

bool ice_is_any_vf_in_unicast_promisc(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void
ice_vf_lan_overflow_event(struct ice_pf *pf, struct ice_rq_event_info *event)
{
	mock().actualCall(__func__);
}

void ice_print_vfs_mdd_events(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_print_vf_rx_mdd_event(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

struct ice_sw *
ice_find_sw_from_id(struct ice_sw *sw, u16 sw_id, u8 num_total_sw)
{
	mock().actualCall(__func__);
	return (struct ice_sw *)mock().returnPointerValueOrDefault(NULL);
}

int
ice_vc_send_msg_to_vf(struct ice_vf *vf, u32 v_opcode,
		      enum virtchnl_status_code v_retval, u8 *msg, u16 msglen)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("v_opcode", v_opcode)
		.withParameter("v_retval", v_retval)
		.withParameter("msg", msg, msglen)
		.withParameter("msglen", msglen);

	return mock().returnIntValueOrDefault(0);
}

void ice_restore_all_vfs_msi_state(struct pci_dev *pdev)
{
	mock().actualCall(__func__);
}

int
ice_determine_res(struct ice_pf *pf, u16 avail_res, u16 max_res, u16 min_res)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("avail_res", avail_res)
		.withParameter("max_res", max_res)
		.withParameter("min_res", min_res);
	return mock().returnIntValueOrDefault(0);
}

int ice_get_max_valid_res_idx(struct ice_res_tracker *res)
{
	mock().actualCall(__func__)
		.withParameter("res", res);
	return mock().returnIntValueOrDefault(0);
}

int ice_sriov_set_msix_res(struct ice_pf *pf, u16 num_msix_needed)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("num_msix_needed", num_msix_needed);
	return mock().returnIntValueOrDefault(0);
}

#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
void ice_vc_notify_vf_link_state(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_virtchnl_set_repr_ops(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}
#endif

void ice_virtchnl_set_dflt_ops(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

}

int ice_calc_all_vfs_min_tx_rate(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
	return mock().returnIntValueOrDefault(0);
}

bool ice_min_tx_rate_oversubscribed(struct ice_vf *vf, int min_tx_rate)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", min_tx_rate);
	return mock().returnBoolValueOrDefault(false);
}

bool
ice_is_legacy_umac_expired(struct ice_time_mac *last_added_umac)
{
	mock().actualCall(__func__)
		.withParameter("last_added_umac", last_added_umac);
	return mock().returnBoolValueOrDefault(false);
}

bool
ice_is_malicious_vf(struct ice_pf *pf, struct ice_rq_event_info *event,
                    u16 num_msg_proc, u16 num_msg_pending)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

struct ice_vsi *ice_get_vf_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

void ice_flush_fdir_ctx(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_check_vf_ready_for_cfg(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnIntValueOrDefault(0);
}

bool ice_is_vf_disabled(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnBoolValueOrDefault(0);
}

int ice_get_vf_port_info(struct ice_pf *pf, u16 vf_id,
			 struct iidc_vf_port_info *vf_port_info)
{
	mock().actualCall(__func__)
		.withParameter("vf_id", vf_id);
	return mock().returnIntValueOrDefault(0);
}

static void ice_release_vf(struct kref *ref)
{
	struct ice_vf *vf = container_of(ref, struct ice_vf, refcnt);

	vf->vf_ops->free(vf);
}

struct ice_vf *ice_get_vf_by_id(struct ice_pf *pf, u32 vf_id)
{
	struct ice_vf *vf;

	/* All valid VF IDs are 16 bits */
	if (vf_id > U16_MAX) {
		dev_err(ice_pf_to_dev(pf), "Out of range VF ID: %u\n",
			vf_id);
		return NULL;
	}

	hash_for_each_possible(pf->vfs.table, vf, entry, vf_id) {
		if (vf->vf_id == vf_id) {
			if (kref_get_unless_zero(&vf->refcnt))
				return vf;
			else
				return NULL;
		}
	}

	return NULL;
}

void ice_put_vf(struct ice_vf *vf)
{
	kref_put(&vf->refcnt, ice_release_vf);
}

bool ice_is_valid_vf_id(struct ice_pf *pf, u32 vf_id)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("vf_id", vf_id);

	return mock().returnBoolValueOrDefault(true);
}

bool ice_has_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);

	return mock().returnBoolValueOrDefault(false);
}

u16 ice_get_num_vfs(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);

	return mock().returnIntValueOrDefault(0);
}

int ice_initialize_vf_entry(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return mock().returnIntValueOrDefault(0);
}

void ice_vf_invalidate_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

void ice_vf_set_initialized(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

#ifdef VLAN2PDU_SUPPORT
void ice_vlan2pdu_sysfs_init(struct ice_pf *pf)
{
}

void ice_vlan2pdu_release(struct ice_pf *pf)
{
}
#endif
