int ice_ipsec_handle_idc_msg(struct ice_vf *vf, u8 *msg, u16 len)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ipsec_handle_vc_msg(struct ice_vf *vf, u8 *msg, u16 len)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_ipsec_request_status(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

bool ice_is_vf_ipsec_capable(struct ice_vf *vf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

int ice_ipsec_send_vc_msg(struct ice_pf *pf, u8 *msg, u16 len, u32 vf_id)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("msg", msg, len)
		.withParameter("len", len)
		.withParameter("vf_id", vf_id);

	return mock().returnIntValueOrDefault(0);
}
