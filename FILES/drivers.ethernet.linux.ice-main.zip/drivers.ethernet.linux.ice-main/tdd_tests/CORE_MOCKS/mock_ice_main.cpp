/* from ice_main.c */

#ifndef STDMOCK_SKIP_GLOBALS
#ifndef DRV_VERSION
#define DRV_VERSION "1.0.0.0"
#endif
const char ice_drv_ver[] = DRV_VERSION;

#ifndef DRV_SUMMARY
#define DRV_SUMMARY "Intel(R) TDD Test Driver"
#endif
const char ice_driver_string[] = DRV_SUMMARY;
int lan_vf_qps_rsvd = 0;
#endif /* !STDMOCK_SKIP_GLOBALS */

struct device *ice_hw_to_dev(struct ice_hw *hw)
{
	struct ice_pf *pf = container_of(hw, struct ice_pf, hw);

	return &pf->pdev->dev;
}

void ice_do_reset_safe(struct ice_pf *pf, u32 reset_flags)
{
	mock().actualCall(__func__);
}

const char *ice_aq_str(enum ice_aq_err aq_err)
{
	mock().actualCall(__func__);
	return (char *)mock().returnStringValueOrDefault(NULL);
}

void ice_print_link_msg(struct ice_vsi *vsi, bool isup)
{
	mock().actualCall(__func__);
}

// for ice_reset_req
#include "ice_type.h"

int ice_schedule_reset(struct ice_pf *pf, enum ice_reset_req reset)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_update_vsi_stats(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_update_pf_stats(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_vsi_stop_tx_rx_rings(struct ice_vsi *vsi, enum ice_disq_rst_src rst_src,
			     u16 vmvf_num)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_up(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_down(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

u16 ice_get_avail_rxq_count(struct ice_pf *pf)
{
       mock().actualCall(__func__);
       return (u16)mock().returnIntValueOrDefault(0);
}

u16 ice_get_avail_txq_count(struct ice_pf *pf)
{
       mock().actualCall(__func__);
       return (u16)mock().returnIntValueOrDefault(0);
}

int ice_get_rss_lut(struct ice_vsi *vsi, u8 *lut, u16 lut_size)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_set_rss_lut(struct ice_vsi *vsi, u8 *lut, u16 lut_size)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_get_rss_key(struct ice_vsi *vsi, u8 *seed)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_set_rss_key(struct ice_vsi *vsi, u8 *seed)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}


void ice_fill_rss_lut(u8 *lut, u16 rss_table_size, u16 rss_size)
{
	mock().actualCall(__func__);
}

int ice_vsi_recfg_qs(struct ice_vsi *vsi, int new_rx, int new_tx)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_link_speed_to_mbps(int ice_link_speed)
{
	mock().actualCall(__func__)
		.withParameter("ice_link_speed", ice_link_speed);
	return mock().returnIntValueOrDefault(-1);
}

int ice_vsi_ena_irq(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_setup_tx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#if defined(ADK_SUPPORT) && defined(SWITCH_MODE)
int ice_vsi_req_single_irq_msix(struct ice_vsi *vsi, char *basename,
				u16 vector_id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif /* ADK_SUPPORT && SWITCH_MODE */

int ice_vsi_req_irq_msix(struct ice_vsi *vsi, char *basename)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_setup_rx_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_open_ctrl(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vsi_open(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_napi_disable_all(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_napi_enable_all(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
void ice_napi_enable(struct ice_q_vector *q_vector)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE && ADK_SUPPORT */

bool ice_is_wol_supported(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

int ice_vsi_cfg(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_stop(struct net_device *netdev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_open(struct net_device *netdev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_open_internal(struct net_device *netdev)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_service_task_schedule(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_trig_sw_itr(struct ice_vsi *vsi, int v_idx)
{
	mock().actualCall(__func__);
}

struct ice_vsi *
ice_lb_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

int ice_destroy_xdp_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_prepare_xdp_rings(struct ice_vsi *vsi, struct bpf_prog *prog)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_add_tc_flower_adv_fltr(struct ice_vsi *vsi,
			       struct ice_tc_flower_fltr *tc_fltr)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_deinit_adv_features(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

#ifdef DCF_SUPPORT
int ice_init_acl(struct ice_pf *pf)
{
	mock().actualCall("__func__");
	return mock().returnIntValueOrDefault(0);
}
#endif

bool ice_is_nd_vis(void)
{
	/* Default to true, if the mock() data is not set */
	if (mock().hasData("module_param_ND_VIS"))
		return mock().getData("module_param_ND_VIS").getBoolValue();
	else
		return true;
}

#ifdef LOOPBACK_MODE
bool ice_is_loopback_mode(void)
{
	/* Default to true, if the mock() data is not set */
	if (mock().hasData("module_param_LOOPBACK"))
		return mock().getData("module_param_LOOPBACK").getBoolValue();
	else
		return true;
}
#endif /* LOOPBACK_MODE */

int ice_set_bw_limit(struct ice_vsi *vsi, u64 max_tx_rate, u64 min_tx_rate)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_set_safe_mode_vlan_cfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_napi_add(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

struct ice_vsi *
ice_find_vsi_from_pi_and_type(struct ice_pf *pf, struct ice_port_info *pi, enum ice_vsi_type vsi_type)
{
	mock().actualCall(__func__);
	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

struct ice_vsi *
ice_find_vsi_from_pi(struct ice_pf *pf, struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

#ifdef SWITCH_MODE
int ice_setup_pf_sw(struct ice_pf *pf, u8 port)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_deinit_lag_sw(struct ice_pf *pf, struct ice_port_info *lag_port)
{
	mock().actualCall(__func__);
}
#endif /* SWITCH_MODE */

int ice_aq_wait_for_event(struct ice_pf *pf, u16 opcode, unsigned long timeout,
			  struct ice_rq_event_info *event)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("opcode", opcode)
		.withParameter("timeout", timeout)
		.withOutputParameter("event->desc.retval", &event->desc.retval)
		.withOutputParameter("event->desc.params", &event->desc.params);

	return mock().returnIntValueOrDefault(0);
}

bool netif_is_ice(struct net_device *dev)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

int ice_vsi_cfg_netdev_tc0(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#if defined(ESWITCH_SUPPORT)
int
ice_del_cls_flower(struct ice_vsi *vsi, struct flow_cls_offload *cls_flower)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("cls_flower", cls_flower);
	return mock().returnIntValueOrDefault(0);
}

int
ice_add_cls_flower(struct net_device *netdev, struct ice_vsi *vsi,
		   struct flow_cls_offload *cls_flower)
{
	mock().actualCall(__func__)
		.withParameter("netdev", netdev)
		.withParameter("vsi", vsi)
		.withParameter("cls_flower", cls_flower);
	return mock().returnIntValueOrDefault(0);
}

void ice_replay_tc_fltrs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}
#endif /* ESWITCH_SUPPORT */

void ice_ch_vsi_update_ring_vecs(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}
