#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT
void ice_finalize_xdp_rx_mock(struct ice_ring *rx_ring, unsigned int xdp_res)
{
	mock().actualCall("ice_finalize_xdp_rx");
}
int ice_xmit_xdp_buff_mock(struct xdp_buff *xdp, struct ice_ring *xdp_ring)
{
	mock().actualCall("ice_xmit_xdp_buff");
	return mock().intReturnValue();
}
int ice_xmit_xdp_ring_mock(void *data, u16 size, struct ice_ring *xdp_ring)
{
	mock().actualCall("ice_xmit_xdp_ring");
	return mock().intReturnValue();
}
void ice_xdp_ring_update_tail_mock(struct ice_ring *xdp_ring)
{
	mock().actualCall("ice_xdp_ring_update_tail");
}
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */
void ice_release_rx_desc_mock(struct ice_ring *rx_ring, u32 val)
{
	mock().actualCall("ice_release_rx_desc");
}
bool
ice_test_staterr_mock(union ice_32b_rx_flex_desc *rx_desc, const u16 stat_err_bits)
{
	mock().actualCall("ice_test_staterr");
	return mock().boolReturnValue();
}
void
ice_process_skb_fields_mock(struct ice_ring *rx_ring,
			    union ice_32b_rx_flex_desc *rx_desc,
			    struct sk_buff *skb, u16 ptype)
{
	mock().actualCall("ice_process_skb_fields");
}
void
ice_receive_skb_mock(struct ice_ring *rx_ring, struct sk_buff *skb, u16 vlan_tag)
{
	mock().actualCall(__func__);
}
