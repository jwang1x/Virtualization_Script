/* This file contains implementations of mock functions in the
 * ice_sriov.c implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_sriov.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_sriov.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_sriov.cpp"

static bool
ice_unicast_mac_exists(struct ice_pf *pf, u8 *mac)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("mac", mac, ETH_ALEN);
	return mock().returnBoolValueOrDefault(true);
}

static int
ice_check_sriov_allowed(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
	return mock().returnIntValueOrDefault(0);
}

static int
ice_pci_sriov_ena(struct ice_pf *pf, int num_vfs)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("num_vfs", num_vfs);
	return mock().returnIntValueOrDefault(0);
}

static void
ice_create_port_assoc_sysfs(struct pci_dev *pdev)
{
	mock().actualCall(__func__)
		.withParameter("pdev", pdev);
}

static int
ice_init_vf_vsi_res(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnIntValueOrDefault(0);
}

static void
ice_ena_vf_mappings(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static void
ice_dis_vf_mappings(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static void
ice_sriov_clear_reset_trigger(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static int
ice_vsi_manage_pvid(struct ice_vsi *vsi, u16 pvid_info, bool enable)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("pvid_info", pvid_info)
		.withParameter("enable", enable);
	return mock().returnIntValueOrDefault(0);
}

static void
ice_rm_all_dcf_sw_rules(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
}

static void
ice_trigger_vf_reset(struct ice_vf *vf, bool is_vflr, bool is_pfr)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("is_vflr", is_vflr)
		.withParameter("is_pfr", is_pfr);
}

static void
ice_vf_pre_vsi_rebuild(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static int
ice_vf_rebuild_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnIntValueOrDefault(0);
}

static void
ice_sriov_post_vsi_rebuild(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static void
ice_vf_vsi_release(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static u32
ice_globalq_to_pfq(struct ice_pf *pf, u32 globalq)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("globalq", globalq);

	return (u32)mock().returnIntValueOrDefault(0);
}

static bool ice_is_vf_link_up(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return mock().returnBoolValueOrDefault(true);
}

static int ice_vf_clear_vsi_promisc(struct ice_vf *vf, struct ice_vsi *vsi, u8 promisc_m)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("vsi", vsi)
		.withParameter("promisc_m", promisc_m);

	return mock().returnIntValueOrDefault(0);
}

static int ice_vf_set_vsi_promisc(struct ice_vf *vf, struct ice_vsi *vsi, u8 promisc_m)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("vsi", vsi)
		.withParameter("promisc_m", promisc_m);

	return mock().returnIntValueOrDefault(0);
}

static void ice_vf_ena_rxq_interrupt(struct ice_vsi *vsi, u32 q_idx)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("q_idx", q_idx);
}

static void ice_vf_ena_txq_interrupt(struct ice_vsi *vsi, u32 q_idx)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("q_idx", q_idx);
}

static int ice_vc_ena_txq_chunk(struct ice_vf *vf, struct virtchnl_queue_chunk *chunk)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("chunk", chunk);
	return mock().returnIntValueOrDefault(0);
}

static int ice_vc_ena_rxq_chunk(struct ice_vf *vf, struct virtchnl_queue_chunk *chunk)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("chunk", chunk);
	return mock().returnIntValueOrDefault(0);
}

static int ice_vc_dis_txq_chunk(struct ice_vf *vf, struct virtchnl_queue_chunk *chunk)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("chunk", chunk);
	return mock().returnIntValueOrDefault(0);
}

static int ice_vc_dis_rxq_chunk(struct ice_vf *vf, struct virtchnl_queue_chunk *chunk)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("chunk", chunk);
	return mock().returnIntValueOrDefault(0);
}

static void ice_vf_vsi_ena_single_txq(struct ice_vf *vf, struct ice_vsi *vsi, u16 q_id, u16 vf_q_id)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("vsi", vsi)
		.withParameter("q_id", q_id)
		.withParameter("vf_q_id", vf_q_id);
}

static int ice_vf_vsi_ena_single_rxq(struct ice_vf *vf, struct ice_vsi *vsi, u16 q_id, u16 vf_q_id)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("vsi", vsi)
		.withParameter("q_id", q_id)
		.withParameter("vf_q_id", vf_q_id);
	return mock().returnIntValueOrDefault(0);
}
static void ice_vc_set_svm_caps(struct ice_vf *vf, struct virtchnl_vlan_caps *caps)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static void ice_vc_set_dvm_caps(struct ice_vf *vf, struct virtchnl_vlan_caps *caps)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

static struct ice_vsi *ice_vf_get_vf_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
}

static int ice_vsi_ena_spoofchk(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

static int ice_vsi_dis_spoofchk(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
	return mock().returnIntValueOrDefault(0);
}

static void ice_sriov_clear_rdma_irq_map(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

static void ice_sriov_clear_ceq_irq_map(struct ice_vf *vf, u16 ceq_idx)
{
	mock().actualCall(__func__);
}

static void ice_sriov_clear_aeq_irq_map(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

static void ice_sriov_cfg_rdma_ceq_irq_map(struct ice_vf *vf,
					   struct virtchnl_rdma_qv_info *qv_info)
{
	mock().actualCall(__func__);
}

static void ice_sriov_cfg_rdma_aeq_irq_map(struct ice_vf *vf,
					   struct virtchnl_rdma_qv_info *qv_info)
{
	mock().actualCall(__func__);
}
}; /* End of namespace stdmock. Function implementations go above this line */
