#ifndef MOCK_ICE_ACL_MAIN
#define MOCK_ICE_ACL_MAIN

#ifndef NO_ACL_SUPPORT
int
ice_acl_add_rule_ethtool(struct ice_vsi *vsi, struct ethtool_rxnfc *cmd)
{
	int retval;

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	return retval;
}
#endif /* !NO_ACL_SUPPORT */
#endif /*  MOCK_ICE_ACL_MAIN */
