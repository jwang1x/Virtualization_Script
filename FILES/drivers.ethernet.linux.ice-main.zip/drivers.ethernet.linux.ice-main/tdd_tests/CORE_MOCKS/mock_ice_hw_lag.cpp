int ice_hw_lag_init(struct ice_pf *pf)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

void ice_hw_lag_deinit(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_hw_lag_clean(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_hw_lag_disable_sw_bonding(struct net_device *netdev)
{
	mock().actualCall(__func__);
}
