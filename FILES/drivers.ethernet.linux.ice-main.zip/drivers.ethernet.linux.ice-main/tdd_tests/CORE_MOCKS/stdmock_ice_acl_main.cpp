/* This file contains implementations of mock functions in the ice_acl_main.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_acl_main.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_acl_main.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actuaclall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actuaclall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_acl_main.cpp"

static int
ice_acl_check_input_set(struct ice_pf *pf, struct ethtool_rx_flow_spec *fsp)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		/* TODO: Perhaps this should be a memory buffer or we should
		 * provide parameters for structure members.
		 */
		.withParameter("fsp", fsp);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_acl_set_input_set(struct ice_vsi *vsi, struct ethtool_rx_flow_spec *fsp,
		      struct ice_fdir_fltr *input)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		/* TODO: Perhaps these should be a memory buffer or we should
		 * provide parameters for structure members.
		 */
		.withParameter("fsp", fsp)
		.withParameter("input", input);

	return mock().returnIntValueOrDefault(0);
}

}; /* End of namespace stdmock. Function implementations go above this line */
