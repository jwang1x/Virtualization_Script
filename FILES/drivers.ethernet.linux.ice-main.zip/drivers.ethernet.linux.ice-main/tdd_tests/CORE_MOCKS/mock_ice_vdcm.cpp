int ice_vdcm_init(struct pci_dev *pdev)
{
	mock().actualCall(__func__)
		.withParameter("pdev", pdev);

	return mock().returnIntValueOrDefault(0);
}

void ice_vdcm_deinit(struct pci_dev *pdev)
{
	mock().actualCall(__func__)
		.withParameter("pdev", pdev);
}

void ice_vdcm_pre_rebuild_irqctx(void *token)
{
	mock().actualCall(__func__)
		.withParameter("token", token);
}

int ice_vdcm_rebuild_irqctx(void *token)
{
	mock().actualCall(__func__)
		.withParameter("token", token);

	return mock().returnIntValueOrDefault(0);
}

int ice_vdcm_zap(void *token)
{
	mock().actualCall(__func__)
		.withParameter("token", token);

	return mock().returnIntValueOrDefault(0);
}
