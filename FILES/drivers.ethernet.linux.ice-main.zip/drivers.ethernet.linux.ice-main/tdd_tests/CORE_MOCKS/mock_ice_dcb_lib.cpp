u8 ice_dcb_get_ena_tc(struct ice_dcbx_cfg *dcbcfg)
{
	mock().actualCall(__func__);
	return (u8)mock().returnIntValueOrDefault(1);
}

u8 ice_dcb_get_num_tc(struct ice_dcbx_cfg *dcbcfg)
{
	mock().actualCall(__func__);
	return (u8)mock().returnIntValueOrDefault(1);
}

u8 ice_dcb_get_tc(struct ice_vsi *vsi, int queue_index)
{
	mock().actualCall(__func__);
	return (u8)mock().returnIntValueOrDefault(1);
}

void ice_vsi_cfg_dcb_rings(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_pf_dcb_recfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_update_dcb_stats(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_tx_prepare_vlan_flags_dcb(struct ice_ring *tx_ring,
				   struct ice_tx_buf *first)
{
	mock().actualCall(__func__);
}

void ice_dcb_rebuild(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_vsi_set_dcb_tc_cfg(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

bool ice_fw_supports_lldp_fltr_ctrl(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

enum ice_status
ice_lldp_fltr_add_remove(struct ice_hw *hw, u16 vsi_num, bool add)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_dcb_process_lldp_set_mib_change(struct ice_pf *pf,
					 struct ice_rq_event_info *event)
{
	mock().actualCall(__func__);
}

int
ice_pf_dcb_cfg(struct ice_pf *pf, struct ice_dcbx_cfg *new_cfg, bool locked)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_init_pf_dcb(struct ice_pf *pf, bool locked)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_setup_dcb_qos_info(struct ice_pf *pf, struct iidc_qos_params *qos_info)
{
	mock().actualCall(__func__);
}

int ice_dcb_bwchk(struct ice_pf *pf, struct ice_dcbx_cfg *dcbcfg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_dcb_sw_dflt_cfg(struct ice_pf *pf, bool ets_willing, bool locked)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
