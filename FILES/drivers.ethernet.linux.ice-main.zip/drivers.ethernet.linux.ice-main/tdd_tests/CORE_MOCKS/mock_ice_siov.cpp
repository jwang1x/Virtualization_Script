struct ice_adi *ice_vdcm_alloc_adi(struct device *dev, void *token)
{
	mock().actualCall(__func__)
		.withParameter("dev", dev);

	return (struct ice_adi *)malloc(sizeof(struct ice_adi));
}

void ice_vdcm_free_adi(struct ice_adi *adi)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	free(adi);
}

u32 ice_adi_read_reg32(struct ice_adi *adi, size_t offs)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	return mock().returnIntValueOrDefault(0);
}

void ice_adi_write_reg32(struct ice_adi *adi, size_t offs, u32 data)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);
}

void ice_initialize_siov_res(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
}

void ice_restore_pasid_config(struct ice_pf *pf, enum ice_reset_req reset_type)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
}

int ice_adi_get_vector_num(struct ice_adi *adi)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	return mock().returnIntValueOrDefault(0);
}

int ice_adi_get_sparse_mmap_num(struct ice_adi *adi)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	return mock().returnIntValueOrDefault(14);
}

int ice_adi_get_sparse_mmap_area(struct ice_adi *adi, int index, u64 *offset, u64 *size)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	return mock().returnIntValueOrDefault(0);
}

int ice_adi_get_sparse_mmap_hpa(struct ice_adi *adi, u32 index, u64 vm_pgoff, u64 *addr)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	return mock().returnIntValueOrDefault(0);
}
