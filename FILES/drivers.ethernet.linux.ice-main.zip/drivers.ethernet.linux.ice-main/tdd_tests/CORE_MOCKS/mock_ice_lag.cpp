#include "../include/linux/netdevice.h"

static rx_handler_result_t ice_lag_nop_handler(struct sk_buff **pskb)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

static int ice_init_lag(struct ice_pf *pf)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}

static int ice_deinit_lag(struct ice_pf *pf)
{
	return mock().actualCall(__func__)
		.returnIntValueOrDefault(0);
}
