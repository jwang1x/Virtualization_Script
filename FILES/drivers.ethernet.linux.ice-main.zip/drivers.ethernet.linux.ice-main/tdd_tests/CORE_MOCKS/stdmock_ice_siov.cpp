/* This file contains implementations of mock functions in the
 * ice_sriov.c implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_sriov.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_sriov.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_siov.cpp"

static struct ice_vsi *ice_adi_vsi_setup(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return (struct ice_vsi*)mock().returnPointerValueOrDefault(NULL);
}

static struct ice_adi_priv *ice_create_adi(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
	return (struct ice_adi_priv *)mock().returnPointerValueOrDefault(NULL);
}

static void ice_free_adi(struct ice_adi_priv *priv)
{
	mock().actualCall(__func__)
		.withParameter("priv", priv);
}

static int ice_vsi_configure_pasid(struct ice_vf *vf, u32 pasid, bool ena)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf)
		.withParameter("pasid", pasid)
		.withParameter("ena", ena);
	return mock().returnIntValueOrDefault(0);
}

static int ice_ena_siov_vf_mapping(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnIntValueOrDefault(0);
}

static int ice_dis_siov_vf_mapping(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnIntValueOrDefault(0);
}
}; /* End of namespace stdmock. Function implementations go above this line */
