/* This file contains implementations of mock functions in the ice_base.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_vdcm.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_vdcm.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_vdcm.cpp"

static long
ice_vdcm_vfio_device_get_info(struct ice_vdcm *ivdm, unsigned long arg)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_sparse_mmap_cap(struct vfio_info_cap *caps, struct ice_adi *adi)
{
	mock().actualCall(__func__)
		.withParameter("adi", adi);

	caps->size = 0xf0;
	caps->buf = (struct vfio_info_cap_header *)malloc(sizeof(caps->size));

	return mock().returnIntValueOrDefault(0);
}

static long
ice_vdcm_vfio_device_get_region_info(struct ice_vdcm *ivdm, unsigned long arg)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static long
ice_vdcm_vfio_device_get_irq_info(struct ice_vdcm *ivdm, unsigned long arg)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static long ice_vdcm_vfio_device_reset(struct ice_vdcm *ivdm)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static ssize_t
ice_vdcm_rw(struct mdev_device *mdev, char *buf,
	    size_t count, const loff_t *ppos, bool is_write)
{
	mock().actualCall(__func__)
		.withParameter("mdev", mdev)
		.withParameter("is_write", is_write);

	return mock().returnIntValueOrDefault(count);
}

static int
ice_vdcm_cfg_read(struct ice_vdcm *ivdm, unsigned int pos,
		  char *buf, unsigned int count)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_cfg_write(struct ice_vdcm *ivdm, unsigned int pos,
		  char *buf, unsigned int count)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_cfg_write_bar(struct ice_vdcm *ivdm, unsigned int offset,
		       char *buf, unsigned int bytes)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_cfg_write_mask(struct ice_vdcm *ivdm, unsigned int off,
			u8 *buf, unsigned int bytes)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_bar0_read(struct ice_vdcm *ivdm, unsigned int pos,
		  char *buf, unsigned int count)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_bar0_write(struct ice_vdcm *ivdm, unsigned int pos,
		  char *buf, unsigned int count)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static long
ice_vdcm_set_msix_trigger(struct ice_vdcm *ivdm, struct vfio_irq_set *hdr,
			  void *data)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static void ice_vdcm_msix_disable(struct ice_vdcm *ivdm)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);
}

static int ice_vdcm_msix_enable(struct ice_vdcm *ivdm, int nvec)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_vdcm_set_vector_signals(struct ice_vdcm *ivdm, u32 start,
			    u32 count, int *fds)
{
	mock().actualCall(__func__)
		.withParameter("ivdm", ivdm);

	return mock().returnIntValueOrDefault(0);
}
}; /* End of namespace stdmock. Function implementations go above this line */

