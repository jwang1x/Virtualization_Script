
void *ice_migration_get_vf(struct pci_dev *vf_pdev)
{
	mock().actualCall(__func__)
		.withParameter("dev", vf_pdev);
	return (void *)mock().returnPointerValueOrDefault(0);
}
