/* This file contains implementations of mock functions in the ice_idc_int.h
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

static inline bool ice_validate_peer_obj(struct ice_peer_obj *peer_obj)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj);

	return mock().returnBoolValueOrDefault(true);
}

static void ice_cdev_info_sw_clean_cfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

}; /* End of namespace stdmock. Function implementations go above this line */
