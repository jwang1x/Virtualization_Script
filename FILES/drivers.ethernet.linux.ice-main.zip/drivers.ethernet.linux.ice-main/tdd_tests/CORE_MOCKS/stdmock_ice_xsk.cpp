/* This file contains implementations of mock functions in the ice_xsk.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_xsk.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_xsk.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_xsk.cpp"

static int ice_xsk_alloc_umems(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);

	return mock().returnIntValueOrDefault(0);
}

static int ice_xsk_umem_dma_map(struct ice_vsi *vsi, struct xdp_umem *umem)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("umem", umem);

	return mock().returnIntValueOrDefault(0);
}

}; /* End of namespace stdmock. Function implementations go above this line */
