int ice_flash_pldm_image(struct devlink *devlink,
			 struct devlink_flash_update_params *params,
			 struct netlink_ext_ack *extack)
{
	mock().actualCall(__func__)
		.withParameter("devlink", devlink)
		.withParameter("params", params)
		.withParameter("extack", extack);

	return mock().returnIntValueOrDefault(0);
}

int ice_get_pending_updates(struct ice_pf *pf, u8 *pending,
			    struct netlink_ext_ack *extack)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withOutputParameter("pending", pending)
		.withParameter("extack", extack);

	return mock().returnIntValueOrDefault(0);
}

int ice_write_one_nvm_block(struct ice_pf *pf, u16 module, u32 offset,
			    u16 block_size, u8 *block, bool last_cmd,
			    u8 *reset_level, struct netlink_ext_ack *extack)
{
		mock().actualCall(__func__)
			.withParameter("pf", pf)
			.withParameter("module", module)
			.withParameter("offset", offset)
			.withParameter("block_size", block_size)
			.withParameter("block", block)
			.withParameter("last_cmd", last_cmd)
			.withOutputParameter("reset_level", reset_level)
			.withParameter("extack", extack);

			return mock().returnIntValueOrDefault(0);
}
