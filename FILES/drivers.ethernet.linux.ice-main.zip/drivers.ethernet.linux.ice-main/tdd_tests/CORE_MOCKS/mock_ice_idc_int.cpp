#ifdef BMSM_MODE
void ice_cdev_info_sw_clean_cfg(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}
#endif /* BMSM_MODE */
