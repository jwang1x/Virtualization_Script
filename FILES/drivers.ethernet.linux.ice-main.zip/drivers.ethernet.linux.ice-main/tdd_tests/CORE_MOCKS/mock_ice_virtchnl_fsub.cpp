
void ice_vf_fsub_init(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

int ice_vc_flow_sub_fltr(struct ice_vf *vf, u8 *msg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vc_flow_unsub_fltr(struct ice_vf *vf, u8 *msg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_vf_fsub_exit(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}
