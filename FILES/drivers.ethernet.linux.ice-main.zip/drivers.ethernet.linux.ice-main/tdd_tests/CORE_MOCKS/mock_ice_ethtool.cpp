/* from ice_ethtool.c */
#ifdef ADK_SUPPORT
void ice_set_adk_ethtool_ops(struct net_device *netdev)
{
	mock().actualCall(__func__);
}
#endif

#ifndef NO_RECOVERY_MODE_SUPPORT
void ice_set_ethtool_recovery_ops(struct net_device *netdev)
{
	mock().actualCall(__func__);
}
#endif

#ifndef SWITCH_MODE
void ice_set_ethtool_safe_mode_ops(struct net_device *netdev)
{
	mock().actualCall(__func__);
}
#endif

void ice_set_ethtool_ops(struct net_device *netdev)
{
	mock().actualCall(__func__);
}

#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
void ice_set_ethtool_repr_ops(struct net_device *netdev)
{
	mock().actualCall(__func__);
}
#endif /* ESWITCH_SUPPORT || BMSM_MODE */
