void ice_vf_vsi_init_vlan_ops(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}

void ice_vf_vsi_cfg_dvm_legacy_vlan_mode(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}

void ice_vf_vsi_cfg_svm_legacy_vlan_mode(struct ice_vsi *vsi)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);
}

#if defined(VF_QINQ_SUPPORT) && defined(DCF_SUPPORT)
int ice_vf_vsi_dcf_set_outer_port_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);

	return mock().returnBoolValueOrDefault(0);
}

int ice_vf_vsi_dcf_ena_outer_vlan_stripping(struct ice_vsi *vsi, u16 tpid)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi);

	return mock().returnBoolValueOrDefault(0);
}
#endif /* VF_QINQ_SUPPORT && DCF_SUPPORT */
