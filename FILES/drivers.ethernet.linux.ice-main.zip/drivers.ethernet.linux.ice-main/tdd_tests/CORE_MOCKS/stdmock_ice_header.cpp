/* This file contains implementations of mock functions in the ice.h
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice.h file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice.h is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

static void ice_set_ring_xdp(struct ice_ring *ring)
{
	mock().actualCall(__func__);
}

bool ice_is_xdp_ena_vsi(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

static inline bool ice_ring_is_xdp(struct ice_ring *ring)
{
		mock().actualCall(__func__);
	return mock().boolReturnValue();
}

static struct xsk_buff_pool *ice_xsk_pool(struct ice_ring *ring)
{
	mock().actualCall(__func__);
	return (struct xsk_buff_pool *)mock().returnPointerValueOrDefault(NULL);
}

}; /* End of namespace stdmock. Function implementations go above this line */
