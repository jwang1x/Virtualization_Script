void ice_ptp_init(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_ptp_release(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_ptp_reset(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

void ice_ptp_prepare_for_reset(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

#ifndef BMSM_MODE
void ice_ptp_link_change(struct ice_pf *pf, u8 port, bool linkup)
{
	mock().actualCall(__func__);
}
#else
void ice_ptp_link_change(struct ice_pf *pf, u8 port, bool linkup, bool ies_call)
{
	mock().actualCall(__func__);
}
#endif

void ice_ptp_rx_hwtstamp(struct ice_ring *rx_ring, union ice_32b_rx_flex_desc *rx_desc,
			 struct sk_buff *skb)
{
	return;
}

s8 ice_ptp_request_ts(struct ice_ptp_tx *tx, struct sk_buff *skb)
{
	mock().actualCall(__func__)
		.withParameter("tx", tx)
		.withParameter("skb", skb);

	return mock().returnIntValueOrDefault(-1);
}

bool ice_ptp_process_ts(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
	return mock().returnBoolValueOrDefault(1);
}

void ice_ptp_set_timestamp_offsets(struct ice_pf *pf)
{
	return;
}

int ice_ptp_set_ts_config(struct ice_pf *pf, struct ifreq *ifr)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_ptp_cfg_timestamp(struct ice_pf *pf, bool ena)
{
	return;
}
#ifdef SWITCH_MODE

void ice_ptp_cfg_ts_rebuild(struct ice_pf *pt)
{
	return;
}
#endif /* SWITCH_MODE */

u64 ice_ptp_read_src_clk_reg(struct ice_pf *pf, struct ptp_system_timestamp *sts)
{
	return 0;
}

#ifdef SWITCH_MODE
int ice_ptp_update_incval(struct ice_pf *pf, enum ice_time_ref_freq time_ref_freq,
			  enum ice_src_tmr_mode src_tmr_mode)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ptp_get_incval(struct ice_pf *pf, enum ice_time_ref_freq *time_ref_freq,
		       enum ice_src_tmr_mode *src_tmr_mode)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ptp_cfg_clkout(struct ice_pf *pf, unsigned int chan,
				struct ice_perout_channel *config, bool store)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ptp_match_and_adj(struct ice_pf *pf, u64 at_time, s64 offset)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ptp_get_src_phy_time(struct ice_pf *pf, struct iidc_ptp_timer_info *ts)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ptp_check_rx_fifo(struct ice_pf *pf, u8 port)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ptp_ts_enable(struct ice_pf *pf, u8 port, bool enable)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#else /* !SWITCH_MODE */
int ice_get_ptp_clock_index(struct ice_pf *pf)
{
	return 0;
}
#endif /* SWITCH_MODE */
