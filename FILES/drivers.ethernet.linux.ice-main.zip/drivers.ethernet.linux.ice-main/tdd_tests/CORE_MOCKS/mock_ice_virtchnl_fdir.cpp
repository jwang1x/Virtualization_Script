int ice_vc_add_fdir_fltr(struct ice_vf *vf, u8 *msg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_vc_del_fdir_fltr(struct ice_vf *vf, u8 *msg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_vc_fdir_free_prof_all(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_vc_fdir_rem_prof_all(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_vf_fdir_init(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_vf_fdir_exit(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void
ice_vc_fdir_irq_handler(struct ice_vsi *ctrl_vsi,
			union ice_32b_rx_flex_desc *rx_desc)
{
	mock().actualCall(__func__);
}

void ice_flush_fdir_ctx(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

