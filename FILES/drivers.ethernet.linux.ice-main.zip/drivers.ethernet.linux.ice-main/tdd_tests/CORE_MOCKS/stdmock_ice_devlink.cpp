/* This file contains implementations of mock functions in the ice_fw_update.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_fw_update.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_fw_update.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_devlink.cpp"

static int ice_get_tx_topo_user_sel(struct ice_pf *pf, bool *txbalance_ena)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withOutputParameter("txbalance_ena", txbalance_ena);

	return mock().returnIntValueOrDefault(0);
}

static int ice_update_tx_topo_user_sel(struct ice_pf *pf, bool txbalance_ena)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("txbalance_ena", txbalance_ena);

	return mock().returnIntValueOrDefault(0);
}
}; /* End of namespace stdmock. Function implementations go above this line */
