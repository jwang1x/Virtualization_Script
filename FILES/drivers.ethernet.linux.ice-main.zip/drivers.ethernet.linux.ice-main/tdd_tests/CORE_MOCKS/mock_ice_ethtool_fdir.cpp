/* from ice_ethtool_fdir.c */
int ice_fdir_create_dflt_rules(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}	

void ice_vsi_manage_fdir(struct ice_vsi *vsi, bool ena)
{
	mock().actualCall(__func__);
}

int ice_get_ethtool_fdir_entry(struct ice_hw *hw, struct ethtool_rxnfc *cmd)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

u32 ice_ntuple_get_max_fltr_cnt(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

#ifdef SWITCH_MODE
int
ice_get_fdir_fltr_ids_per_port(struct ice_hw *hw, struct ethtool_rxnfc *cmd,
			       u32 *rule_locs, struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#else
int ice_get_fdir_fltr_ids(struct ice_hw *hw, struct ethtool_rxnfc *cmd, u32 *rule_locs)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif /* SWITCH_MODE */

int ice_add_ntuple_ethtool(struct ice_vsi *vsi, struct ethtool_rxnfc *cmd)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_del_ntuple_ethtool(struct ice_vsi *vsi, struct ethtool_rxnfc *cmd)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ntuple_check_ip4_seg(struct ethtool_tcpip4_spec *tcp_ip4_spec)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ntuple_check_ip4_usr_seg(struct ethtool_usrip4_spec *usr_ip4_spec)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ntuple_check_ip6_seg(struct ethtool_tcpip6_spec *tcp_ip6_spec)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_ntuple_check_ip6_usr_seg(struct ethtool_usrip6_spec *usr_ip6_spec)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fdir_write_fltr(struct ice_pf *pf, struct ice_fdir_fltr *input, bool add,
		    bool is_tun)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_fdir_release_flows(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_fdir_replay_flows(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_fdir_replay_fltrs(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

#ifndef SWITCH_MODE
int ice_create_init_fdir_rule(struct ice_pf *pf, enum ice_fltr_ptype flow)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
#endif /* !SWITCH_MODE */

void
ice_update_ring_dest_vsi(struct ice_vsi *vsi, u16 *dest_vsi, u32 *ring)
{
	mock().actualCall(__func__);
}

int
ice_ntuple_update_list_entry(struct ice_pf *pf, struct ice_fdir_fltr *input,
			   int fltr_idx)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}


enum ice_fltr_ptype ice_ethtool_flow_to_fltr(int eth)
{
        mock().actualCall(__func__);
        return (enum ice_fltr_ptype)mock().intReturnValue();
}

int
ice_ntuple_set_input_set(struct ice_vsi *vsi, enum ice_block blk,
			 struct ethtool_rx_flow_spec *fsp,
			 struct ice_fdir_fltr *input)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_ntuple_l4_proto_to_port(enum ice_flow_seg_hdr l4_proto,
			    enum ice_flow_field *src_port,
			    enum ice_flow_field *dst_port)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
