int ice_vf_rebuild_adq_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return mock().returnIntValueOrDefault(0);
}

void ice_del_all_adv_switch_fltr(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

bool ice_is_vf_adq_ena(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnBoolValueOrDefault(false);
}

bool ice_vf_adq_vsi_valid(struct ice_vf *vf, u8 tc)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
	return mock().returnBoolValueOrDefault(false);
}

void ice_vf_adq_release(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}

int ice_vf_recreate_adq_vsi(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);

	return mock().returnIntValueOrDefault(0);
}

struct ice_vsi *ice_get_vf_adq_vsi(struct ice_vf *vf, u8 tc)
{
	mock().actualCall(__func__);
	return NULL;
}
