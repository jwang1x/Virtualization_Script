/* This file contains implementations of mock functions in the ice_base.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_vfio_pci.cpp file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_vfio_pci.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */

static int ice_vfio_migration_init(struct ice_vfio_pci_core_device *ice_vdev)
{
	mock().actualCall(__func__)
		.withParameter("ice_vdev", ice_vdev);

	return mock().returnIntValueOrDefault(0);
}

static void ice_vfio_migration_uninit(struct ice_vfio_pci_core_device *ice_vdev)
{
	mock().actualCall(__func__)
		.withParameter("ice_vdev", ice_vdev);
}

static int ice_vfio_pci_save_state(struct ice_vfio_pci_core_device *ice_vdev)
{
	mock().actualCall(__func__)
		.withParameter("ice_vdev", ice_vdev);

	return mock().returnIntValueOrDefault(0);
}

static int ice_vfio_pci_load_state(struct ice_vfio_pci_core_device *ice_vdev)
{
	mock().actualCall(__func__)
		.withParameter("ice_vdev", ice_vdev);

	return mock().returnIntValueOrDefault(0);
}

static void ice_vfio_pci_reset_mig(struct ice_vfio_pci_core_device *ice_vdev)
{
	mock().actualCall(__func__)
		.withParameter("ice_vdev", ice_vdev);
}
}; /* End of namespace stdmock. Function implementations go above this line */

