struct ice_pf *ice_allocate_pf(struct device *dev)
{
	mock().actualCall(__func__).withParameter("dev", dev);

	return (struct ice_pf *)mock().returnPointerValueOrDefault(NULL);
}

void ice_devlink_register(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}

void ice_devlink_unregister(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}

int ice_devlink_register_params(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);

	return mock().returnIntValueOrDefault(0);
}

void ice_devlink_unregister_params(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}

#ifndef SWITCH_MODE
int ice_devlink_create_pf_port(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);

	return mock().returnIntValueOrDefault(0);
}

void ice_devlink_destroy_pf_port(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}
#endif /* !SWITCH_MODE */

#ifdef ESWITCH_SUPPORT
#ifdef HAVE_DEVLINK_PORT_ATTR_PCI_VF
int ice_devlink_create_vf_port(struct ice_vf *vf)
{
	mock().actualCall(__func__).withParameter("vf", vf);

	return mock().returnIntValueOrDefault(0);
}

void ice_devlink_destroy_vf_port(struct ice_vf *vf)
{
	mock().actualCall(__func__).withParameter("vf", vf);
}
#endif /* HAVE_DEVLINK_PORT_ATTR_PCI_VF */
#endif /* ESWITCH_SUPPORT */

void ice_devlink_init_regions(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}

void ice_devlink_destroy_regions(struct ice_pf *pf)
{
	mock().actualCall(__func__).withParameter("pf", pf);
}
