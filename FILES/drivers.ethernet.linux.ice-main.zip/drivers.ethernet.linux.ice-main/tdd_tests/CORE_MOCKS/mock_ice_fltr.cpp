void ice_fltr_free_list(struct device *dev, struct list_head *h)
{
	mock().actualCall(__func__);
}

int
ice_fltr_set_vlan_vsi_promisc(struct ice_hw *hw, struct ice_vsi *vsi,
			      u8 promisc_mask)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_clear_vlan_vsi_promisc(struct ice_hw *hw, struct ice_vsi *vsi,
				u8 promisc_mask)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_clear_vsi_promisc(struct ice_hw *hw, u16 vsi_handle, u8 promisc_mask,
			   u16 vid, u8 lport)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_set_vsi_promisc(struct ice_hw *hw, u16 vsi_handle, u8 promisc_mask,
			 u16 vid, u8 lport)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_add_mac_to_list(struct ice_vsi *vsi, struct list_head *list,
			 const u8 *mac, enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_add_mac(struct ice_vsi *vsi, const u8 *mac,
		 enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__)
		.withParameter("vsi", vsi)
		.withParameter("mac", mac, ETH_ALEN)
		.withParameter("action", action);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_add_mac_and_broadcast(struct ice_vsi *vsi, const u8 *mac,
			       enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_fltr_add_mac_list(struct ice_vsi *vsi, struct list_head *list)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_remove_mac(struct ice_vsi *vsi, const u8 *mac,
		    enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_fltr_remove_all(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_fltr_remove_mac_list(struct ice_vsi *vsi, struct list_head *list)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_fltr_add_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_fltr_remove_vlan(struct ice_vsi *vsi, struct ice_vlan *vlan)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_add_eth(struct ice_vsi *vsi, u16 ethertype, u16 flag,
		 enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_remove_eth(struct ice_vsi *vsi, u16 ethertype, u16 flag,
		    enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_add_mac_vlan(struct ice_vsi *vsi, const u8 *macaddr, u16 vlan_id,
		      enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int
ice_fltr_remove_mac_vlan(struct ice_vsi *vsi, const u8 *macaddr, u16 vlan_id,
			 enum ice_sw_fwd_act_type action)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_fltr_add_mac_to_q(struct ice_vsi *vsi, const u8 *mac, u16 q_id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_fltr_remove_mac_to_q(struct ice_vsi *vsi, const u8 *mac, u16 q_id)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
