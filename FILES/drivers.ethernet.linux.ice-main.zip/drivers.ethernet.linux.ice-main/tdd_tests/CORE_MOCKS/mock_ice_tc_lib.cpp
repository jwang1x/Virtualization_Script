
int
ice_add_tc_flower_adv_fltr(struct ice_vsi *vsi,
			   struct ice_tc_flower_fltr *tc_fltr)
{
	mock().actualCall(__func__);

	return mock().returnIntValueOrDefault(0);
}
