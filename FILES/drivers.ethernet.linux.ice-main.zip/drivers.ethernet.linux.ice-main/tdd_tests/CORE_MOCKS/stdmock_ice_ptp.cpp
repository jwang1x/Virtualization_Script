/* This file contains implementations of mock functions in the ice_ptp.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_ptp.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_ptp.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#define STDMOCK_SKIP_GLOBALS
#include "mock_ice_ptp.cpp"
#undef STDMOCK_SKIP_GLOBALS

static int ice_ptp_check_tx_fifo(struct ice_ptp_port *port)
{
	mock().actualCall(__func__)
		.withParameter("port", port);

	return mock().returnIntValueOrDefault(0);
}

static void ice_ptp_reset_phy_timestamping(struct ice_pf *pf)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf);
}

}; /* End of namespace stdmock. Function implementations go above this line */
