/* This file contains implementations of mock functions in the ice_ethtool_fdir.c
 * implemented under the stdmock namespace.
 *
 * This enables use of the USE_STD_MOCK macro to detour to the mock
 * implementation easily.
 *
 * For convenience all of the regular function mocks defined in the
 * mock_ice_ethtool_fdir.c file are included.
 *
 * Additional functions may be defined within this file, for example if a mock
 * for a static function only found within ice_ethtool_fdir.c is needed.
 *
 * Implementations for functions in this file should generally follow the
 * pattern of mock().actualCall() with all of the parameters, and use
 * mock().return<Type>ValueOrDefault() to return a value.
 *
 * Implementations that are test-specific and not based on mock().actualCall
 * should remain near the test code that calls them.
 */

namespace stdmock {

/* include the mock definitions for exported functions */
#include "mock_ice_ethtool_fdir.cpp"

static void
ice_fdir_do_rem_flow(struct ice_pf *pf, enum ice_fltr_ptype flow_type)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("flow_type", flow_type);
}

static int
ice_cfg_fdir_xtrct_seq(struct ice_pf *pf, struct ethtool_rx_flow_spec *fsp,
		       struct ice_rx_flow_userdef *user)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("fsp->flow_type", fsp->flow_type)
		.withParameter("user", user);

	return mock().returnIntValueOrDefault(0);
}

static int
ice_fdir_write_all_fltr(struct ice_pf *pf, struct ice_fdir_fltr *input,
			bool add)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("input", input)
		.withParameter("add", add);

	return mock().returnIntValueOrDefault(0);
}

}; /* End of namespace stdmock. Function implementations go above this line */
