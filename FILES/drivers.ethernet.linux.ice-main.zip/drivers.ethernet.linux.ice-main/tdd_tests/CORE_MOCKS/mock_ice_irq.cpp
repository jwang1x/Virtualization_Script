int ice_init_interrupt_scheme(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_clear_interrupt_scheme(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_get_irq_num(struct ice_pf *pf, int idx)
{
	mock().actualCall(__func__)
		.withParameter("idx", idx);
	return mock().returnIntValueOrDefault(0);
}
