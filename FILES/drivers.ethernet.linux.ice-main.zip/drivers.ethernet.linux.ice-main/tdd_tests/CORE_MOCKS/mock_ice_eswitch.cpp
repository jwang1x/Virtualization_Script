
int ice_eswitch_mode_get(struct devlink *devlink, u16 *p_mode)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_eswitch_mode_set(struct devlink *devlink, u16 mode,
			 struct netlink_ext_ack *extack)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_is_eswitch_mode_switchdev(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

void ice_eswitch_release(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

int ice_eswitch_configure(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_eswitch_set_target_vsi(struct sk_buff *skb,
				struct ice_tx_offload_params *off)
{
	mock().actualCall(__func__);
}

void ice_eswitch_update_repr(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

int ice_eswitch_rebuild(struct ice_pf *pf)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_eswitch_stop_all_tx_queues(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}

u16 ice_eswitch_get_unique_q_index(struct ice_ring *ring)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_eswitch_add_vf_mac_rule(struct ice_pf *pf, struct ice_vf *vf, const u8 *mac)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

void ice_eswitch_replay_vf_mac_rule(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}

void ice_eswitch_del_vf_mac_rule(struct ice_vf *vf)
{
	mock().actualCall(__func__);
}
