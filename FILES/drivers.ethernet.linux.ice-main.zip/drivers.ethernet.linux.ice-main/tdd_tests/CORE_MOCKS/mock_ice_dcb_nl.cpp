void ice_dcbnl_setup(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}

void ice_dcbnl_set_all(struct ice_vsi *vsi)
{
	mock().actualCall(__func__);
}
