/* from ice_txrx.c */
#include "../include/linux/netdevice.h"

int ice_prgm_fdir_fltr(struct ice_vsi *vsi, struct ice_fltr_desc *fdir_desc,
		       u8 *raw_packet)
{
	/* on a 'real' driver this function will queue up a packet and the
	 * packet will be deleted after tranmit. this is a debug environment so
	 * delete the packet when seen.
	 */
	struct ice_pf *pf = NULL;
	struct ice_hw *hw = NULL;
	if (vsi) {
		pf = vsi->back;
		if (pf)
			hw = &pf->hw;
	}
	mock().actualCall(__func__);
	if (hw && fdir_desc) {
		ice_free(hw, raw_packet);
	}
	return mock().intReturnValue();
}

#ifdef TXPP_SUPPORT
int ice_setup_tstamp_ring(struct ice_ring *tstamp_ring)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

void ice_clean_tx_ring(struct ice_ring *tx_ring,
		       struct ice_ring *tstamp_ring)
#else
void ice_clean_tx_ring(struct ice_ring *tx_ring)
#endif /* TXPP_SUPPORT */
{
	mock().actualCall(__func__);
}

void ice_clean_rx_ring(struct ice_ring *tx_ring)
{
	mock().actualCall(__func__);
}

#ifdef TXPP_SUPPORT
void ice_free_tx_ring(struct ice_ring *tx_ring,
		      struct ice_ring *tstamp_ring)
#else
void ice_free_tx_ring(struct ice_ring *tx_ring)
#endif /* TXPP_SUPPORT */
{
       mock().actualCall(__func__);
}

void ice_free_rx_ring(struct ice_ring *tx_ring)
{
       mock().actualCall(__func__);
}

int ice_napi_poll(struct napi_struct *napi, int budget)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

int ice_setup_tx_ring(struct ice_ring *tx_ring)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

int ice_setup_rx_ring(struct ice_ring *tx_ring)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

bool ice_alloc_rx_bufs(struct ice_ring *rx_ring, u16 cleaned_count)
{
	mock().actualCall(__func__);
	return mock().boolReturnValue();
}

netdev_tx_t ice_start_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	mock().actualCall(__func__);
	return NETDEV_TX_OK; 
}

void ice_vsi_drain_rxq(struct ice_vsi *vsi, int idx)
{
	mock().actualCall(__func__);
}

void ice_clean_ctrl_tx_irq(struct ice_ring *tx_ring)
{
	mock().actualCall(__func__);
}

int ice_clean_rx_irq(struct ice_ring *rx_ring, int budget){
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

int ice_run_xdp(struct ice_ring *rx_ring, struct xdp_buff *xdp,
		struct bpf_prog *xdp_prog)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}
