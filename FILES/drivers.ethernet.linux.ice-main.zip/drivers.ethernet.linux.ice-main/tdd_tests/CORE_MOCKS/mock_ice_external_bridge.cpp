
static struct ice_port_info *ice_bridge_get_br_port(struct ice_pf *pf)
{
	return (struct ice_port_info *)mock().actualCall(__func__).returnPointerValueOrDefault(NULL);
}

static int ice_remap_cgd(struct ice_port_info *src, struct ice_port_info *dst, u8 num_cgd)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int ice_bridge_create(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int ice_bridge_destroy(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static int
ice_bridge_add_port(struct ice_pf *pf, struct ice_port_info *pi, struct ice_port_info *br_pi)
{
	return mock().actualCall(__func__)
			.withParameter("pf", pf)
			.withParameter("pi", pi)
			.withParameter("br_pi", br_pi)
			.returnIntValueOrDefault(0);
}

static int
ice_bridge_del_port(struct ice_pf *pf, struct ice_port_info *pi, struct ice_port_info *br_pi)
{
	return mock().actualCall(__func__)
			.withParameter("pf", pf)
			.withParameter("pi", pi)
			.withParameter("br_pi", br_pi)
			.returnIntValueOrDefault(0);
}

static int ice_bridge_del_all_ports(struct ice_pf *pf, struct ice_port_info *br_pi)
{
	return mock().actualCall(__func__).returnIntValueOrDefault(0);
}

static void ice_bridge_clean(struct ice_pf *pf)
{
	mock().actualCall(__func__);
}
