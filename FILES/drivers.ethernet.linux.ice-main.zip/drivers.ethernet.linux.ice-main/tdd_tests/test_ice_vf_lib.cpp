#if !defined(SWITCH_MODE) || defined(BMSM_MODE)
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_vf_lib {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/skbuff.h>
#include <linux/compiler.h>
#include <linux/if_link.h>
#include <linux/pci_regs.h>

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_acl.cpp"
#include "SHARED_MOCKS/mock_ice_vf_mbx.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_mbx.cpp"
#include "CORE_MOCKS/mock_ice_dcf.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_allowlist.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fdir.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fsub.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_vf_adq.cpp"
#include "CORE_MOCKS/mock_ice_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_vf_vsi_vlan_ops.cpp"

#ifdef BMSM_MODE
#include "CORE_MOCKS/mock_ice_vf_veb.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"
#endif /* BMSM_MODE */

#include "CORE_MOCKS/stdmock_ice_sriov.cpp"
#include "../src/CORE/ice_vf_lib.c"


void ice_virtchnl_set_dflt_ops(struct ice_vf *vf)
{
	mock().actualCall(__func__)
		.withParameter("vf", vf);
}
}

using namespace ns_vf_lib;

TEST_GROUP(ice_test_vf_lib)
{
	struct net_device *netdev;
	struct ice_vfs *vfs;
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct ice_vsi *vf_vsi;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		vf = (struct ice_vf *)calloc(1, sizeof(struct ice_vf));
        	vf_vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
        	vf->pf = pf;
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(pf->pdev);
		free(pf);
		free(vf);
		free_netdev(netdev);
		free(vf_vsi);
		netdev = NULL;
	}
};

TEST(ice_test_vf_lib, ice_test_clear_all_promisc_modes_true_promisc_off)
{
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	mock().expectOneCall("ice_vsi_has_non_zero_vlans")
		.ignoreOtherParameters()
		.andReturnValue(true);

    	mock().expectOneCall("ice_clear_dflt_vsi")
	    	.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.ignoreOtherParameters()
		.andReturnValue(0);

	set_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states);
	set_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states);
	clear_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, vf->pf->flags);

	ice_vf_clear_all_promisc_modes(vf, vf_vsi);

	CHECK(!test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
	CHECK(!test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
}

TEST(ice_test_vf_lib, ice_test_clear_all_promisc_modes_true_promisc_on)
{
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	mock().expectOneCall("ice_vsi_has_non_zero_vlans")
		.ignoreOtherParameters()
		.andReturnValue(true);


	mock().expectNCalls(2, "ice_vf_clear_vsi_promisc")
		.ignoreOtherParameters()
		.andReturnValue(0);

	set_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states);
	set_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, vf->pf->flags);

	ice_vf_clear_all_promisc_modes(vf, vf_vsi);

	CHECK(!test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
	CHECK(!test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
}
#endif

#ifdef VLAN2PDU_SUPPORT
TEST_GROUP(ice_vlan2pdu)
{
	struct ice_boost_tcam_entry boost_entry;
	struct dev_uldl_attribute attr;
	const char *buf = "100";
	struct kobject *kobj;
	struct pci_dev *pdev;
	struct ice_pf *pf;
	int count = 10;
	size_t size;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(*pdev));
		kobj = (struct kobject *)calloc(1, sizeof(*kobj));

		/* set data */
		kobj->parent = &pdev->dev.kobj;
		pf->hw.vlan2pdu.count = count;
		attr.index = 1;
		size = sizeof(buf);
		boost_entry.key.key.vlan.hv_vlan_id_key = 100;
		pf->hw.vlan2pdu.tbl[1].vlan_id = 100;

		/* Link pieces up, in order */
		pf->hw.vlan2pdu.tbl[1].boost_entry = &boost_entry;
		pdev->dev.driver_data = pf;
		pf->pdev = pdev;
	}

	void teardown(void)
	{
		free(kobj);
		free(pf);
		free(pdev);
	}
};

TEST(ice_vlan2pdu, ice_vlan2pdu_sysfs_init_success)
{
	mock().expectOneCall("kobject_create_and_add")
		.withParameter("name", "vlan2pdu")
		.withParameter("parent", &pdev->dev.kobj)
		.andReturnValue(kobj);

	mock().expectOneCall("sysfs_create_group")
		.withParameter("kobj", kobj)
		.withConstPointerParameter("grp", &uldl_group)
		.andReturnValue(0);

	ice_vlan2pdu_sysfs_init(pf);

	/* The address should match the one created if successful,
	 * all our other code is handling errors from the kernel
	 */
	POINTERS_EQUAL(kobj, pf->vlan2pdu.kobj);
}

TEST(ice_vlan2pdu, ice_vlan2pdu_release_success)
{
	pf->vlan2pdu.kobj = kobj;

	mock().expectOneCall("sysfs_remove_group")
		.withParameter("kobj", kobj)
		.withConstPointerParameter("grp", &uldl_group);

	mock().expectOneCall("kobject_put")
		.withParameter("kobj", kobj);

	ice_vlan2pdu_release(pf);
	POINTERS_EQUAL(NULL, pf->vlan2pdu.kobj);
}

TEST(ice_vlan2pdu, vlan2pdu_link_attr_store_success)
{
	struct dev_uldl_attribute kobj_attr;
	ssize_t result;

	kobj_attr.index = 1;

	mock().expectOneCall("ice_vlan2pdu_create");

	result = vlan2pdu_link_attr_store(kobj, &kobj_attr.attr, buf, size);
	CHECK_EQUAL((ssize_t)size, (ssize_t)result);
}

TEST(ice_vlan2pdu, vlan2pdu_link_attr_show_success)
{
	struct dev_uldl_attribute kobj_attr;
	char buffer[PAGE_SIZE] = "";
	ssize_t result;

	kobj_attr.index = 1;

	result = vlan2pdu_link_attr_show(kobj, &kobj_attr.attr, buffer);

	STRCMP_EQUAL("100\n", buffer);
	CHECK_EQUAL(4, result);
}
#endif /* VLAN2PDU_SUPPORT */
