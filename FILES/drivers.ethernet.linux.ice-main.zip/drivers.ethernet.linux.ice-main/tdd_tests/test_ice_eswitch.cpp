#ifdef ESWITCH_SUPPORT
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_eswitch {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include <net/dst_metadata.h>
#include "../src/CORE/ice.h"
#include "KERNEL_MOCKS/mock_dst.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/stdmock_ice_eswitch.cpp"
#include "../src/CORE/ice_eswitch.c"
};
/////////////////////////////////////////////////
using namespace ns_eswitch;

TEST_GROUP(eswitch_grp)
{
	static const size_t devlink_alloc_size = sizeof(struct devlink) + \
						 sizeof(struct ice_pf);
	u8 __aligned(__alignof__(struct devlink)) alloc_data[devlink_alloc_size];
	struct netlink_ext_ack *extack;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct devlink *devlink;
	struct ice_vsi **vsi_list;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct pci_dev *pdev;

	void setup(void)
	{
		memset(alloc_data, 0, sizeof(alloc_data));
		devlink = (struct devlink *)alloc_data;
		pf = (struct ice_pf *)&devlink->priv;

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi_list = (struct ice_vsi **)calloc(1, sizeof(ice_vsi *));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pdev = (__typeof__(pdev))calloc(1, sizeof(*pdev));
		np->vsi = vsi;
		vsi->back = pf;
		vsi_list[0] = vsi;
		pf->vsi = vsi_list;
		pf->pdev = pdev;
	}

	void teardown(void)
	{
		free(vsi);
		free(vsi_list);
		free_netdev(netdev);
		free(pdev);
	}
};

TEST(eswitch_grp, mode_get_expected_to_be_legacy)
{
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_LEGACY;

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_LEGACY);
}

TEST(eswitch_grp, mode_get_expected_to_be_switchdev)
{
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_SWITCHDEV);
}

TEST(eswitch_grp, mode_set_legacy_when_legacy)
{
	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_LEGACY;
	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_LEGACY, extack);
}

TEST(eswitch_grp, mode_set_eswitch_when_switchdev)
{
	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;
	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_SWITCHDEV, extack);
}

TEST(eswitch_grp, mode_set_legacy)
{
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;
	set_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);

	mock().expectOneCall("ice_has_vfs")
		.withParameter("pf", pf);

	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_LEGACY, extack);

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_LEGACY);
}

TEST(eswitch_grp, mode_set_legacy_with_vfs)
{
	struct ice_vf vf;
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;
	hash_add(pf->vfs.table, &vf.entry, 0);

	mock().expectOneCall("ice_has_vfs")
		.withParameter("pf", pf)
		.andReturnValue(true);

	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_LEGACY, extack);

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_SWITCHDEV);
}

TEST(eswitch_grp, mode_set_switchdev)
{
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_LEGACY;
	set_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);

	mock().expectOneCall("ice_has_vfs")
		.withParameter("pf", pf);

	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_SWITCHDEV, extack);

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_SWITCHDEV);
}

TEST(eswitch_grp, mode_set_switchdev_with_vfs)
{
	struct ice_vf vf;
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_LEGACY;
	set_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);
	hash_add(pf->vfs.table, &vf.entry, 0);

	mock().expectOneCall("ice_has_vfs")
		.withParameter("pf", pf)
		.andReturnValue(true);

	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_SWITCHDEV, extack);

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_LEGACY);
}

TEST(eswitch_grp, mode_set_switchdev_without_eswitch_capable_flag)
{
	u16 mode;

	pf->eswitch_mode = DEVLINK_ESWITCH_MODE_LEGACY;
	clear_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);

	mock().expectOneCall("ice_has_vfs")
		.withParameter("pf", pf);

	ice_eswitch_mode_set(devlink, DEVLINK_ESWITCH_MODE_SWITCHDEV, extack);

	ice_eswitch_mode_get(devlink, &mode);
	CHECK_EQUAL(mode, DEVLINK_ESWITCH_MODE_LEGACY);
}

TEST(eswitch_grp, start_xmit_success)
{
	struct ice_repr repr;
	struct sk_buff skb;
	struct ice_vf vf;

	repr.vf = &vf;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_netdev_to_repr")
		.andReturnValue(&repr);
	mock().expectOneCall("ice_start_xmit");

	CHECK_EQUAL(0, ice_eswitch_port_start_xmit(&skb, netdev));
}

TEST(eswitch_grp, set_ctx_for_uplink_switch)
{
	struct ice_tx_offload_params off = { };
	struct sk_buff skb = { };

	ice_eswitch_set_target_vsi(&skb, &off);

	LONGS_EQUAL((ICE_TX_CTX_DESC_SWTCH_UPLINK << ICE_TXD_CTX_QW1_CMD_S)
		    | ICE_TX_DESC_DTYPE_CTX, off.cd_qw1);
}

TEST(eswitch_grp, set_ctx_for_vsi_switch)
{
	struct ice_tx_offload_params off = { };
	struct metadata_dst mocked_dst;
	const int mocked_vsi_num = 9;
	struct sk_buff skb = { };

	USE_STD_MOCK(skb_metadata_dst);
	mock().expectOneCall("skb_metadata_dst")
		.ignoreOtherParameters()
		.andReturnValue(&mocked_dst);
	mocked_dst.u.port_info.port_id = mocked_vsi_num;
	ice_eswitch_set_target_vsi(&skb, &off);

	u64 cd_cmd = ICE_TX_CTX_DESC_SWTCH_VSI << ICE_TXD_CTX_QW1_CMD_S;
	u64 dst = ((u64)mocked_vsi_num << ICE_TXD_CTX_QW1_VSI_S) &
		  ICE_TXD_CTX_QW1_VSI_M;
	LONGS_EQUAL(cd_cmd | dst | ICE_TX_DESC_DTYPE_CTX, off.cd_qw1);
}

TEST_GROUP_BASE(receive_cp, TGN(eswitch_grp))
{
	struct ice_32b_rx_flex_desc_nic_2 *flex_desc;
	struct ice_switchdev_info switchdev = { };
	union ice_32b_rx_flex_desc rx_desc = { };
	struct ice_vsi mocked_vsi = { };
	struct ice_ring rx_ring = { };
	const int mocked_vsi_num = 5;
	struct net_device netdev;

	TEST_SETUP()
	{
		TGN(eswitch_grp)::setup();

		mocked_vsi.back = pf;
		rx_ring.vsi = &mocked_vsi;
		rx_ring.netdev = &netdev;
		pf->switchdev = switchdev;
		flex_desc = (struct ice_32b_rx_flex_desc_nic_2 *)&rx_desc;
		flex_desc->src_vsi = mocked_vsi_num;
	}

};
#endif
