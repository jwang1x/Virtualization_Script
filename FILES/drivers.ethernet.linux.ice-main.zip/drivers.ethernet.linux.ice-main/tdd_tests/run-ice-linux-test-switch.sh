#!/bin/bash
# Intel ice-linux TDD test launch script
# Copyright(c) 2018 Intel Corporation.
#
# This file is NEVER to be distributed outside of Intel.

DIR="$(dirname "$0")"
export UBSAN_OPTIONS="print_stacktrace=1"
LD_LIBRARY_PATH=$DIR/../src/SHARED/tdd_tests/tdd_shared/detour_function \
$DIR/ice-linux-test-switch "$@"
