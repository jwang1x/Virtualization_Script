#ifdef FDIR_SUPPORT
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_acl {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/compiler.h>

#include "../src/CORE/ice.h"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"

#include "CORE_MOCKS/stdmock_ice_acl_main.cpp"
#include "CORE_MOCKS/stdmock_ice_ethtool_fdir.cpp"

static inline ice_fltr_ptype& operator++(ice_fltr_ptype& val, int)
{
	return val = ice_fltr_ptype(val + 1);
}

#include "../src/CORE/ice_ethtool_fdir.c"
#include "../src/CORE/ice_acl_main.c"
}
/////////////////////////////////////////////////
using namespace ns_acl;

#if !defined(NO_ACL_SUPPORT) && defined(FDIR_SUPPORT)

struct test_hw {
	/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

/* tests begin */
TEST_BASE(ice_acl_base)
{
	struct test_hw *tdd_hw;
	struct ice_pf *pf;
	struct ice_hw *hw;
	struct ice_vsi *vsi;

	void setup() {
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		tdd_hw = (struct test_hw *)calloc(1, sizeof(*tdd_hw));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		vsi->back = pf;
		vsi->num_rxq = 256; /* random number */
		hw = &pf->hw;

		INIT_LIST_HEAD(&hw->fdir_list_head);

#ifdef ADQ_SUPPORT
		INIT_LIST_HEAD(&vsi->ch_list);
#endif /* ADQ_SUPPORT */

		/* used by rd32/wr32 */
		hw->hw_addr = (u8 *)tdd_hw;
		hw->back = pf;
		hw->vendor_id = 0x8086;
		hw->device_id = 0xF0B5; /* ICE_DEV_ID_I200_FPGA */
		hw->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		hw->port_info->hw = hw;
		hw->port_info->lport = 0;
		ice_init_lock(&hw->fdir_fltr_lock);
		set_bit(ICE_FLAG_ADV_FEATURES, pf->flags);
		/* ADQ wants a vsi set up so that it can find it */
		pf->vsi = (struct ice_vsi **)calloc(10, sizeof(struct ice_vsi *));
		pf->vsi[0] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[0]->type = ICE_VSI_PF;
		pf->vsi[1] = vsi;
		pf->ctrl_vsi_idx = 1;
		pf->num_alloc_vsi = 1;
		pf->hw.acl_tbl = (struct ice_acl_tbl *)calloc(1, sizeof(*pf->hw.acl_tbl));
	}
	void teardown() {
		ice_destroy_lock(&hw->fdir_fltr_lock);
		free(hw->port_info);
		if (hw->acl_prof) {
			int i;

			for (i = 0; i < ICE_FLTR_PTYPE_MAX; i++) {
				if (hw->acl_prof[i]) {
					if (hw->acl_prof[i]->fdir_seg[0])
						devm_kfree(ice_hw_to_dev(hw),
						  hw->acl_prof[i]->fdir_seg[0]);
					devm_kfree(ice_hw_to_dev(hw),
						   hw->acl_prof[i]);
				}
			}
			devm_kfree(ice_hw_to_dev(hw), hw->acl_prof);
		}
		if (hw->acl_tbl)
			free(hw->acl_tbl);
		memset(hw, 0, sizeof (*hw));
		free(pf->vsi[0]);
		free(pf->vsi);
		free(pf->pdev);
		free(pf);
		free(vsi);
		free(tdd_hw);
	}
};

TEST_GROUP_BASE(ice_acl_calls, ice_acl_base)
{
	void setup() {
		ice_acl_base::setup();
	}
	void teardown() {
		struct ice_fdir_fltr *rule, *tmp;

		LIST_FOR_EACH_ENTRY_SAFE(rule, tmp, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
			LIST_DEL(&rule->fltr_node);
			ice_free(hw, rule);
		}
		ice_acl_base::teardown();
	}

	void expect_ice_acl_check_input_set_tcp4() {
		mock().expectNCalls(4, "ice_flow_set_fld")
			.ignoreOtherParameters();
		mock().expectOneCall("ice_flow_add_prof")
			.ignoreOtherParameters()
			.andReturnValue(0);
	}
};

TEST_GROUP(ice_acl_plain)
{
	void setup() {
	}
	void teardown() {
	}
};

static void test_set_fsp_tcp4(struct ethtool_rx_flow_spec *fsp, u64 toq,
			      u16 port)
{
	fsp->flow_type = TCP_V4_FLOW;
	fsp->ring_cookie = toq;
	fsp->location = 111;
	fsp->h_u.tcp_ip4_spec.psrc = cpu_to_be16(port);
	fsp->h_u.tcp_ip4_spec.pdst = cpu_to_be16(port);
	fsp->h_u.tcp_ip4_spec.ip4src = cpu_to_be32(0x01020304);
	fsp->h_u.tcp_ip4_spec.ip4dst = cpu_to_be32(0x05060708);
	fsp->m_u.tcp_ip4_spec.psrc = cpu_to_be16(0xffff);
	fsp->m_u.tcp_ip4_spec.pdst = cpu_to_be16(0xffff);
	fsp->m_u.tcp_ip4_spec.ip4src = cpu_to_be32(0xffffffff);
	fsp->m_u.tcp_ip4_spec.ip4dst = cpu_to_be32(0xffffffff);
}

static void test_set_fsp_udp4(struct ethtool_rx_flow_spec *fsp, u64 toq,
			      u16 port)
{
	fsp->flow_type = UDP_V4_FLOW;
	fsp->ring_cookie = toq;
	fsp->location = 111;
	fsp->h_u.udp_ip4_spec.psrc = cpu_to_be16(port);
	fsp->h_u.udp_ip4_spec.pdst = cpu_to_be16(port);
	fsp->h_u.udp_ip4_spec.ip4src = cpu_to_be32(0x01020304);
	fsp->h_u.udp_ip4_spec.ip4dst = cpu_to_be32(0x05060708);
	fsp->m_u.udp_ip4_spec.psrc = cpu_to_be16(0xffff);
	fsp->m_u.udp_ip4_spec.pdst = cpu_to_be16(0xffff);
	fsp->m_u.udp_ip4_spec.ip4src = cpu_to_be32(0xffffffff);
	fsp->m_u.udp_ip4_spec.ip4dst = cpu_to_be32(0xffffffff);
}

static void test_set_fsp_sctp4(struct ethtool_rx_flow_spec *fsp, u64 toq,
			       u16 port)
{
	fsp->flow_type = SCTP_V4_FLOW;
	fsp->ring_cookie = toq;
	fsp->location = 111;
	fsp->h_u.sctp_ip4_spec.psrc = cpu_to_be16(port);
	fsp->h_u.sctp_ip4_spec.pdst = cpu_to_be16(port);
	fsp->h_u.sctp_ip4_spec.ip4src = cpu_to_be32(0x01020304);
	fsp->h_u.sctp_ip4_spec.ip4dst = cpu_to_be32(0x05060708);
	fsp->m_u.sctp_ip4_spec.psrc = cpu_to_be16(0xffff);
	fsp->m_u.sctp_ip4_spec.pdst = cpu_to_be16(0xffff);
	fsp->m_u.sctp_ip4_spec.ip4src = cpu_to_be32(0xffffffff);
	fsp->m_u.sctp_ip4_spec.ip4dst = cpu_to_be32(0xffffffff);
}

static void test_set_fsp_ip4_user(struct ethtool_rx_flow_spec *fsp, u64 toq,
				  u16 port)
{
	fsp->flow_type = IPV4_USER_FLOW;
	fsp->ring_cookie = toq;
	fsp->location = 111;
	fsp->h_u.usr_ip4_spec.ip4src = cpu_to_be32(0x01020304);
	fsp->h_u.usr_ip4_spec.ip4dst = cpu_to_be32(0x05060708);
	fsp->m_u.usr_ip4_spec.ip4src = cpu_to_be32(0xffffffff);
	fsp->m_u.usr_ip4_spec.ip4dst = cpu_to_be32(0xffffffff);
}

static int
ice_ntuple_update_list_entry_mock(struct ice_pf *pf, struct ice_fdir_fltr *input,
				int fltr_idx)
{
	ice_fdir_list_add_fltr(&pf->hw, input);
	return 0;
}

static void *devm_kcalloc_mock(struct device *dev, size_t n, size_t size,
			       gfp_t gfp)
{
	return NULL;
}

static void *devm_kzalloc_mock(struct device *dev __attribute((__unused__)),
			       size_t size, gfp_t gfp)
{
	return NULL;
}

static enum ice_fltr_ptype ice_ethtool_flow_to_fltr_mock(int eth)
{
	switch (eth) {
	case TCP_V4_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV4_TCP;
	case UDP_V4_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	case SCTP_V4_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV4_SCTP;
	case IPV4_USER_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV4_OTHER;
#ifndef EXTERNAL_RELEASE
	case ESP_V4_FLOW:
		/* FIXME: ESP IPv4 not available yet */
		return ICE_FLTR_PTYPE_NONF_NONE;
#endif
	case TCP_V6_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV6_TCP;
	case UDP_V6_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV6_UDP;
	case SCTP_V6_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV6_SCTP;
#ifdef HAVE_ETHTOOL_FLOW_UNION_IP6_SPEC
	case IPV6_USER_FLOW:
		return ICE_FLTR_PTYPE_NONF_IPV6_OTHER;
#endif
#ifndef EXTERNAL_RELEASE
	case ESP_V6_FLOW:
		/* FIXME: ESP IPv6 not available yet */
		return ICE_FLTR_PTYPE_NONF_NONE;
#endif
	default:
		return ICE_FLTR_PTYPE_NONF_NONE;
	}
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_invalid_flow_type)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Invalide flow type */
	fsp->flow_type = 0;
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-EOPNOTSUPP, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_devm_kcalloc_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Invalid kcalloc */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);
	USE_MOCK(devm_kcalloc, devm_kcalloc_mock);

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-ENOMEM, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_devm_kzalloc_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Invalid kzalloc */
	USE_MOCK(devm_kzalloc, devm_kzalloc_mock);
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-ENOMEM, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_ice_flow_add_prof_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Invalide flow type */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_flow_add_prof")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(ICE_ERR_PARAM, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_tcp4)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Invalid flow type */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_flow_add_prof")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_udp4)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_udp4(fsp, to_queue, port);

	/* Invalide flow type */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_flow_add_prof")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_sctp4)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_sctp4(fsp, to_queue, port);

	/* Invalide flow type */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_flow_add_prof")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_ip4_user)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_ip4_user(fsp, to_queue, port);

	/* Invalide flow type */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	mock().expectNCalls(2, "ice_flow_set_fld")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_flow_add_prof")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(ice_acl_calls, test_ice_acl_check_input_set_ipv6_not_supported)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 10;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* IPv6 not supported yet by ACL */
	/* TODO: ACL IPv6 code is being stripped from TDD to ensure we are
	 * returning -EOPNOTSUPP. When this is implemented, remove the
	 * NO_ACL_IPV6_SUPPORT from the TDD Makefile and update as needed
	 */
	fsp->flow_type = TCP_V6_FLOW;
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-EOPNOTSUPP, ret);

	fsp->flow_type = UDP_V6_FLOW;
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-EOPNOTSUPP, ret);

	fsp->flow_type = SCTP_V6_FLOW;
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-EOPNOTSUPP, ret);

	fsp->flow_type = IPV6_USER_FLOW;
	ret = ice_acl_check_input_set(pf, fsp);
	CHECK_EQUAL(-EOPNOTSUPP, ret);
}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_invalid_input)
{
	struct ethtool_rxnfc cmd;
	int ret;

	memset(&cmd, 0, sizeof(cmd));

	/* Validate NULL pointers */
	ret = ice_acl_add_rule_ethtool(NULL/*vsi*/, &cmd);
	CHECK_EQUAL(-EINVAL, ret);

	/* Validate NULL pointers */
	ret = ice_acl_add_rule_ethtool(vsi, NULL/*&cmd*/);
	CHECK_EQUAL(-EINVAL, ret);

}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_check_input_set_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 80;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Validate error returned by ice_acl_check_input_set */
	USE_STD_MOCK(ice_acl_check_input_set);

	mock().expectOneCall("ice_acl_check_input_set")
		.ignoreOtherParameters()
		.andReturnValue(-EOPNOTSUPP);

	ret = ice_acl_add_rule_ethtool(vsi, &cmd);
	CHECK_EQUAL(-EOPNOTSUPP, ret);
}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_set_input_set_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 80;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Validate error returned by ice_acl_set_input_set */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);
	USE_STD_MOCK(ice_ntuple_set_input_set);

	expect_ice_acl_check_input_set_tcp4();

	mock().expectOneCall("ice_ntuple_set_input_set")
		.andReturnValue(-EINVAL);

	ret = ice_acl_add_rule_ethtool(vsi, &cmd);
	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_flow_add_entry_error)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 80;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Validate error returned by ice_flow_add_entry */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);

	expect_ice_acl_check_input_set_tcp4();

	mock().expectOneCall("ice_fdir_is_dup_fltr")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_flow_add_entry")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);

	ret = ice_acl_add_rule_ethtool(vsi, &cmd);
	CHECK_EQUAL(ICE_ERR_PARAM, ret);
}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_valid)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 80;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Validate successful case */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);
	USE_MOCK(ice_ntuple_update_list_entry, ice_ntuple_update_list_entry_mock);

	expect_ice_acl_check_input_set_tcp4();

	mock().expectOneCall("ice_fdir_is_dup_fltr")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_flow_add_entry")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_fdir_list_add_fltr")
		.ignoreOtherParameters();

	ret = ice_acl_add_rule_ethtool(vsi, &cmd);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(ice_acl_calls, test_ice_acl_add_rule_ethtool_duplicate)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	u32 port = 80;
	int to_queue;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Forward to queue 3 */
	to_queue = 3;
	test_set_fsp_tcp4(fsp, to_queue, port);

	/* Validate successful case */
	USE_MOCK(ice_ethtool_flow_to_fltr, ice_ethtool_flow_to_fltr_mock);
	USE_MOCK(ice_ntuple_update_list_entry, ice_ntuple_update_list_entry_mock);
	
	expect_ice_acl_check_input_set_tcp4();

	mock().expectOneCall("ice_fdir_is_dup_fltr")
		.ignoreOtherParameters()
		.andReturnValue(true);
	ret = ice_acl_add_rule_ethtool(vsi, &cmd);
	CHECK_EQUAL(-EINVAL, ret);
}
#endif /* !NO_ACL_SUPPORT && FDIR_SUPPORT */
#endif /* FDIR_SUPPORT */
