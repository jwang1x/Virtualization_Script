#ifdef BMSM_MODE
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_hw_lag {
	#include "tdd_shared_code_transform.h"
        #include "ice_osdep.h"
        #include "kernel_abstract.h"

        #include "../src/CORE/ice.h"

        #include "CORE_MOCKS/mock_ice_main.cpp"
        #include "CORE_MOCKS/mock_ice_lib.cpp"
	#include "CORE_MOCKS/mock_ice_sriov.cpp"
        #include "SHARED_MOCKS/mock_ice_common.cpp"
        #include "SHARED_MOCKS/mock_ice_sched.cpp"
        #include "KERNEL_MOCKS/mock_kernel.cpp"

        #include "CORE_MOCKS/stdmock_ice_hw_lag.cpp"

        #include "../src/CORE/ice_hw_lag.c"
}

using namespace ns_hw_lag;

TEST_GROUP(ice_hw_lag)
{
	struct pci_dev *pdev;
	struct ice_vfs *vfs;
        struct ice_pf *pf;
        struct ice_vsi *vsi;
        struct ice_port_info *pi, *next_pi;
        struct peerchnl_event *event;
	struct ice_hw_lag *lag;

	void setup(void)
        {
                pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		vfs = &pf->vfs;
		pf->pdev = pdev;
		pf->hw_lag = (struct ice_hw_lag *)
                        calloc(ICE_HW_LAG_PORT_NUM, sizeof(struct ice_hw_lag));
		lag = &pf->hw_lag[0];

		for (int i = 0; i < ICE_HW_LAG_PORT_NUM; i++) {
			pf->hw_lag[i].lag_port =
				(struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
			pf->hw_lag[i].lag_port->lport = ICE_HW_LAG_PORT_MIN + i;
		}

		pf->hw.port_info = (struct ice_port_info *)calloc
			(ICE_MAX_PORT_PER_PCI_DEV, sizeof(struct ice_port_info));
		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);
		for (int i = 0; i < 2; i ++) {
			struct ice_vf *vf = (struct ice_vf *)calloc(1, sizeof(*vf));

			vf->pf = pf;
			vf->vf_id = i;

			hash_add(vfs->table, &vf->entry, i);
		}
		pi = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		pi->vf_allowed = true;

		next_pi = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		event = (struct peerchnl_event *)calloc(1, sizeof(struct peerchnl_event));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->netdev = (struct net_device *)calloc(1, sizeof(struct net_device));
	}

	struct ice_vf *test_get_vf(int i) {
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each(pf->vfs.table, bkt, vf, entry) {
			if (vf->vf_id == i)
				return vf;
		}

		return NULL;
	}


	void empty_vfs_table()
	{
		struct hlist_node *tmp;
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each_safe(vfs->table, bkt, tmp, vf, entry) {
			hash_del(&vf->entry);
			free(vf);
		}
	}


	void teardown(void)
        {
                mock().checkExpectations();
		mock().clear();
		free(vsi->netdev);
		free(vsi);
		free(event);
		free(next_pi);
		free(pi);
		empty_vfs_table();
		mutex_destroy(&vfs->table_lock);
		free(pf->hw.port_info);

		for (int i = 0; i < ICE_HW_LAG_PORT_NUM; i++)
			free(pf->hw_lag[i].lag_port);

		free(pf->hw_lag);
		free(pf->pdev);
		free(pf);
	}
};

TEST(ice_hw_lag, ice_hw_lag_get_idx)
{
	int idx;

	idx = ice_hw_lag_get_idx(ICE_HW_LAG_PORT_MIN);
        CHECK_EQUAL(0, idx);

        idx = ice_hw_lag_get_idx(ICE_HW_LAG_PORT_MAX);
        CHECK_EQUAL(3, idx);

        idx = ice_hw_lag_get_idx(ICE_HW_LAG_PORT_MIN-1);
        CHECK_EQUAL(-1, idx);

        idx = ice_hw_lag_get_idx(ICE_HW_LAG_PORT_MAX+1);
        CHECK_EQUAL(-1, idx);
}

TEST(ice_hw_lag, ice_hw_lag_move_cgd)
{
	int err;

	mock().expectOneCall("ice_sched_copy_cgd");
        mock().expectOneCall("ice_sched_clear_l2_nodes");

	err = ice_hw_lag_move_cgd(pf, lag, pi);
	CHECK_EQUAL(0, err);
}

TEST(ice_hw_lag, ice_hw_lag_move_cgd_copy_fail)
{
	int err;

	mock().expectOneCall("ice_sched_copy_cgd").andReturnValue(-1);

	err = ice_hw_lag_move_cgd(pf, lag, pi);
	CHECK_EQUAL(-1, err);
}

TEST(ice_hw_lag, ice_hw_lag_move_cgd_clear_fail)
{
	int err;

	mock().expectOneCall("ice_sched_copy_cgd");
        mock().expectOneCall("ice_sched_clear_l2_nodes").andReturnValue(-1);

	err = ice_hw_lag_move_cgd(pf, lag, pi);
	CHECK_EQUAL(-1, err);
}

TEST(ice_hw_lag, ice_hw_lag_create)
{
	int err;

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
        mock().expectOneCall("ice_find_port_info_idx");
        mock().expectOneCall("ice_setup_pf_sw");
        mock().expectOneCall("ice_find_vsi_from_pi_and_type").andReturnValue(vsi);
        mock().expectOneCall("register_netdev");

	err = ice_hw_lag_create(pf, lag);
	CHECK_EQUAL(0, err);
        CHECK_EQUAL(true, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_create_add_nodes_fail)
{
	int err;

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes").andReturnValue(-1);

	err = ice_hw_lag_create(pf, lag);
	CHECK_EQUAL(-1, err);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_create_setup_sw_fail)
{
	int err;

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
        mock().expectOneCall("ice_find_port_info_idx");
        mock().expectOneCall("ice_setup_pf_sw").andReturnValue(-1);

        mock().expectOneCall("ice_sched_clear_l2_nodes");

	err = ice_hw_lag_create(pf, lag);
	CHECK_EQUAL(-1, err);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_create_vsi_is_null)
{
	int err;

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
        mock().expectOneCall("ice_find_port_info_idx");
	mock().expectOneCall("ice_setup_pf_sw");
	mock().expectOneCall("ice_find_vsi_from_pi_and_type");

        mock().expectOneCall("ice_sched_clear_l2_nodes");

	err = ice_hw_lag_create(pf, lag);
	CHECK_EQUAL(-EIO, err);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_create_register_netdev_fail)
{
	int err;

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
        mock().expectOneCall("ice_find_port_info_idx");
	mock().expectOneCall("ice_setup_pf_sw");
	mock().expectOneCall("ice_find_vsi_from_pi_and_type").andReturnValue(vsi);
        mock().expectOneCall("register_netdev").andReturnValue(-1);

        mock().expectOneCall("ice_vsi_release").withParameter("vsi", vsi);
        mock().expectOneCall("ice_sched_clear_l2_nodes");

	err = ice_hw_lag_create(pf, lag);
	CHECK_EQUAL(-1, err);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_destroy_no_vfs)
{
	mock().expectOneCall("ice_sched_clear_l2_nodes");
	mock().expectOneCall("ice_deinit_lag_sw");
	mock().expectOneCall("ice_find_vsi_from_pi_and_type").andReturnValue(vsi);
	mock().expectOneCall("ice_vsi_release").withParameter("vsi", vsi);

	ice_hw_lag_destroy(pf, lag, false);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_destroy_2_vfs)
{
	test_get_vf(0)->port_assoc = lag->lag_port->lport;
	test_get_vf(1)->port_assoc = lag->lag_port->lport;

	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_LOCK);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(1))
		.withParameter("flags", ICE_VF_RESET_LOCK);
	mock().expectOneCall("ice_sched_clear_l2_nodes");
	mock().expectOneCall("ice_deinit_lag_sw");
	mock().expectOneCall("ice_find_vsi_from_pi_and_type").andReturnValue(vsi);
	mock().expectOneCall("ice_vsi_release").withParameter("vsi", vsi);

	ice_hw_lag_destroy(pf, lag, false);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_destroy_reset)
{
	test_get_vf(0)->port_assoc = lag->lag_port->lport;
	test_get_vf(1)->port_assoc = lag->lag_port->lport;

	mock().expectNoCall("ice_reset_vf");
	mock().expectNoCall("ice_sched_clear_l2_nodes");

	mock().expectOneCall("ice_find_vsi_from_pi_and_type").andReturnValue(vsi);
	mock().expectOneCall("ice_vsi_release").withParameter("vsi", vsi);

	ice_hw_lag_destroy(pf, lag, true);
        CHECK_EQUAL(false, lag->lag_port->vf_allowed);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_2_vfs)
{
	int err;

	pi->lport = 1;
	test_get_vf(0)->port_assoc = pi->lport;
	test_get_vf(1)->port_assoc = pi->lport;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_hw_lag_create");
	mock().expectOneCall("ice_hw_lag_move_cgd");
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_LOCK);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(1))
		.withParameter("flags", ICE_VF_RESET_LOCK);

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(false, pi->vf_allowed);
	CHECK_EQUAL(true, pi->is_lag_member);
	CHECK_EQUAL(1, test_bit(pi->lport, lag->ports));
	CHECK_EQUAL(pi->lport, lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_no_vfs)
{
	int err;

	pi->lport = 1;
	test_get_vf(0)->port_assoc = 2;
	test_get_vf(1)->port_assoc = 3;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_hw_lag_create");
	mock().expectOneCall("ice_hw_lag_move_cgd");

	mock().expectNoCall("ice_reset_vf");

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(false, pi->vf_allowed);
	CHECK_EQUAL(true, pi->is_lag_member);
	CHECK_EQUAL(1, test_bit(pi->lport, lag->ports));
	CHECK_EQUAL(pi->lport, lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_1_vf_second_port)
{
	int err;

	test_get_vf(0)->port_assoc = 1;
	set_bit(0, lag->ports);
	pi->lport = 1;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_LOCK);

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(false, pi->vf_allowed);
	CHECK_EQUAL(true, pi->is_lag_member);
	CHECK_EQUAL(1, test_bit(pi->lport, lag->ports));
	CHECK_FALSE(pi->lport == lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_in_other_lag)
{
	int err;

	set_bit(0, lag->ports);
	pi->lport = 1;
	pi->is_lag_member = true;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(-EEXIST, err);
	CHECK_FALSE(pi->lport == lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_bridge_member)
{
	int err;

	pi->lport = 1;
	pi->is_bridge_member = true;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(-EEXIST, err);
	CHECK_FALSE(pi->lport == lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_create_fail)
{
	int err;

	pi->lport = 1;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_hw_lag_create").andReturnValue(-1);

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(-1, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(0, test_bit(pi->lport, lag->ports));
	CHECK_FALSE(pi->lport == lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_add_port_move_cgd_fail)
{
	int err;

	pi->lport = 1;

	USE_STD_MOCK(ice_hw_lag_create);
	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_hw_lag_create");
	mock().expectOneCall("ice_hw_lag_move_cgd").andReturnValue(-1);

	mock().expectOneCall("ice_hw_lag_destroy");

	err = ice_hw_lag_add_port(pf, lag, pi);
	CHECK_EQUAL(-1, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(0, test_bit(pi->lport, lag->ports));
	CHECK_FALSE(pi->lport == lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_del_port_primary_and_the_only)
{
	int err;

	pi->lport = 1;
	pi->is_lag_member = true;
	set_bit(pi->lport, lag->ports);
	lag->primary_lport = pi->lport;

	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
	mock().expectOneCall("ice_sched_set_dflt_cgd_to_tc_map");
	mock().expectOneCall("ice_hw_lag_destroy");

	err = ice_hw_lag_del_port(pf, lag, pi);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(0, bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS));
}

TEST(ice_hw_lag, ice_hw_lag_del_port_primary_and_the_only_add_nodes_fail)
{
	int err;

	pi->lport = 1;
	pi->is_lag_member = true;
	set_bit(pi->lport, lag->ports);
	lag->primary_lport = pi->lport;

	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_sched_add_dflt_l2_nodes").andReturnValue(-1);

	mock().expectNoCall("ice_sched_set_dflt_cgd_to_tc_map");

	mock().expectOneCall("ice_hw_lag_destroy");

	err = ice_hw_lag_del_port(pf, lag, pi);
	CHECK_EQUAL(-1, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(0, bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS));
}

TEST(ice_hw_lag, ice_hw_lag_del_port_primary_and_not_the_only)
{
	int err;

	pi->lport = 1;
	pi->is_lag_member = true;
	next_pi->lport = 2;
	set_bit(next_pi->lport, lag->ports);
	set_bit(pi->lport, lag->ports);
	lag->primary_lport = pi->lport;

	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_find_port_info").andReturnValue(next_pi);
	mock().expectOneCall("ice_hw_lag_move_cgd");
	mock().expectOneCall("ice_sched_add_dflt_l2_nodes");
	mock().expectOneCall("ice_sched_set_dflt_cgd_to_tc_map");

	err = ice_hw_lag_del_port(pf, lag, pi);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(1, bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS));
	CHECK_FALSE(test_bit(pi->lport, lag->ports));
	CHECK_EQUAL(next_pi->lport, lag->primary_lport);
}

TEST(ice_hw_lag, ice_hw_lag_del_port_primary_and_not_the_only_move_cgd_failed)
{
	int err;

	pi->lport = 1;
	pi->is_lag_member = true;
	set_bit(0, lag->ports);
	set_bit(pi->lport, lag->ports);
	lag->primary_lport = pi->lport;

	USE_STD_MOCK(ice_hw_lag_move_cgd);
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectOneCall("ice_find_port_info").andReturnValue(next_pi);
	mock().expectOneCall("ice_hw_lag_move_cgd").andReturnValue(-1);
	mock().expectOneCall("ice_hw_lag_destroy");

	err = ice_hw_lag_del_port(pf, lag, pi);
	CHECK_EQUAL(-1, err);
	CHECK_EQUAL(true, pi->vf_allowed);
	CHECK_EQUAL(false, pi->is_lag_member);
	CHECK_EQUAL(1, bitmap_weight(lag->ports, ICE_NUM_EXTERNAL_PORTS));
	CHECK_FALSE(test_bit(pi->lport, lag->ports));
}

TEST(ice_hw_lag, ice_handle_ies_hw_lag_event_add_port)
{
	int err;

	event->event = PEERCHNL_EVENT_LAG_ADD_PORT;

	USE_STD_MOCK(ice_hw_lag_get_idx);
	USE_STD_MOCK(ice_hw_lag_add_port);
	USE_STD_MOCK(ice_hw_lag_del_port);

	mock().expectOneCall("ice_find_port_info").andReturnValue(pi);
	mock().expectOneCall("ice_hw_lag_get_idx");
	mock().expectOneCall("ice_hw_lag_add_port");

	err = ice_handle_ies_hw_lag_event(pf, event);
	CHECK_EQUAL(0, err);
}

TEST(ice_hw_lag, ice_handle_ies_hw_lag_event_add_port_fail)
{
	int err;

	event->event = PEERCHNL_EVENT_LAG_ADD_PORT;

	USE_STD_MOCK(ice_hw_lag_get_idx);
	USE_STD_MOCK(ice_hw_lag_add_port);
	USE_STD_MOCK(ice_hw_lag_del_port);

	mock().expectOneCall("ice_find_port_info").andReturnValue(pi);
	mock().expectOneCall("ice_hw_lag_get_idx");
	mock().expectOneCall("ice_hw_lag_add_port").andReturnValue(-1);

	err = ice_handle_ies_hw_lag_event(pf, event);
	CHECK_EQUAL(-1, err);
}

TEST(ice_hw_lag, ice_handle_ies_hw_lag_event_del_port)
{
	int err;

	event->event = PEERCHNL_EVENT_LAG_DEL_PORT;

	USE_STD_MOCK(ice_hw_lag_get_idx);
	USE_STD_MOCK(ice_hw_lag_add_port);
	USE_STD_MOCK(ice_hw_lag_del_port);

	mock().expectOneCall("ice_find_port_info").andReturnValue(pi);
	mock().expectOneCall("ice_hw_lag_get_idx");
	mock().expectOneCall("ice_hw_lag_del_port");

	err = ice_handle_ies_hw_lag_event(pf, event);
	CHECK_EQUAL(0, err);
}

TEST(ice_hw_lag, ice_handle_ies_hw_lag_event_add_port_invalid_port)
{
	int err;

	event->event = PEERCHNL_EVENT_LAG_ADD_PORT;

	USE_STD_MOCK(ice_hw_lag_get_idx);
	USE_STD_MOCK(ice_hw_lag_add_port);
	USE_STD_MOCK(ice_hw_lag_del_port);

	mock().expectOneCall("ice_find_port_info");
	mock().expectOneCall("ice_hw_lag_get_idx");

	err = ice_handle_ies_hw_lag_event(pf, event);
	CHECK_EQUAL(-EINVAL, err);
}

TEST(ice_hw_lag, ice_handle_ies_hw_lag_event_add_port_invalid_event)
{
	int err;

	event->event = PEERCHNL_EVENT_BRIDGE_ADD_PORT;

	USE_STD_MOCK(ice_hw_lag_get_idx);
	USE_STD_MOCK(ice_hw_lag_add_port);
	USE_STD_MOCK(ice_hw_lag_del_port);

	mock().expectOneCall("ice_find_port_info");
	mock().expectOneCall("ice_hw_lag_get_idx");

	err = ice_handle_ies_hw_lag_event(pf, event);
	CHECK_EQUAL(-EINVAL, err);
}

TEST(ice_hw_lag, ice_hw_lag_clean_no_ports)
{
	USE_STD_MOCK(ice_hw_lag_destroy);

	mock().expectNCalls(ICE_HW_LAG_PORT_NUM, "ice_hw_lag_destroy");

	ice_hw_lag_clean(pf);
}

TEST(ice_hw_lag, ice_hw_lag_clean_all_ports)
{
	USE_STD_MOCK(ice_hw_lag_destroy);

	for (int i = 0; i < ICE_NUM_EXTERNAL_PORTS; i++)
		set_bit(i, pf->hw_lag[0].ports);

	mock().expectNCalls(ICE_NUM_EXTERNAL_PORTS, "ice_find_port_info");
	mock().expectNCalls(ICE_HW_LAG_PORT_NUM, "ice_hw_lag_destroy");

	ice_hw_lag_clean(pf);
}
#endif /* BMSM_MODE */
