#include <CppUTest/UtestMacros.h>       // for RUN_ALL_TESTS
#include "CppUTest/CommandLineTestRunner.h"
#include "CppUTest/TestRegistry.h"
#include "CppUTestExt/MockSupport.h"
#include "CppUTestExt/MockSupportPlugin.h"

int main(int argc, char **argv)
{
	MockSupportPlugin mockPlugin;
	//MyDummyComparator dummyComparator;
	//mockPlugin.installComparator("myType", dummyComparator);
	TestRegistry::getCurrentRegistry()->installPlugin(&mockPlugin);

	//std::cout << "Unit Test for ice linux CORE code" << std::endl;

	//MemoryLeakWarningPlugin::turnOffNewDeleteOverloads();
	int ret_val = RUN_ALL_TESTS(argc, argv);
	return ret_val;
}
