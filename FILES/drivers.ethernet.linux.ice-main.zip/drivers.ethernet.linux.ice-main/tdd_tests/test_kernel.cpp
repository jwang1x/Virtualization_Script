#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_kernel {
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/atomic.h>
}
/////////////////////////////////////////////////
using namespace ns_kernel;

/* the idea behind this file is to test some of the kernel emulation
 * we have in TDD, so add if you doubt something is working
 */

TEST_GROUP(kernel)
{
	atomic_t v;

	void setup() {
		memset(&v, 0, sizeof(v));
	};

	void teardown() {
	};
};

TEST(kernel, atomic_inc)
{

	atomic_set(&v, 0);

	for (int i = 1; i < 10; i++) {
		atomic_inc(&v);

		CHECK_EQUAL(i, atomic_read(&v));
	}
}

TEST(kernel, atomic_dec_if_positive_one)
{
	atomic_t v;

	atomic_set(&v, 11);

	for (int i = 10; i > 0; i--) {
		atomic_dec_if_positive(&v);

		CHECK_EQUAL(i, atomic_read(&v));
	}
}

TEST(kernel, atomic_dec_if_positive_zero)
{
	atomic_t v;

	atomic_set(&v, 0);

	atomic_dec_if_positive(&v);

	CHECK_EQUAL(0, atomic_read(&v));
}

