#include "ice_utest.h"

#define WQ_MEM_RECLAIM 0
#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_idc {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/bitmap.h>
#include <linux/bitops.h>
#include <linux/kernel.h>

#include "ice_type.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_workqueue.cpp"
#include "KERNEL_MOCKS/mock_platform.cpp"
#include "KERNEL_MOCKS/mock_pci.cpp"

#include "../src/CORE/ice.h"

#include <linux/compiler.h>
#include <linux/device.h>
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_vf_mbx.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_ipsec.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_vf_veb.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#ifdef BMSM_MODE
#include "CORE_MOCKS/mock_ice_external_bridge.cpp"
#include "CORE_MOCKS/mock_ice_hw_lag.cpp"
#include "CORE_MOCKS/stdmock_ice_idc_int.cpp"
#endif /* BMSM_MODE */

#include "tdd_mock_peer_impl.h"

#include "../src/CORE/ice_idc.c"
}
/////////////////////////////////////////////////
using namespace ns_idc;

struct test_hw {
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_idc)
{
	struct device *dev;
	struct iidc_core_dev_info *cdi;
	struct pci_dev *pdev;
	struct device_driver *drv;
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct ice_vsi *vsi;
	struct ice_port_info *pi;
	struct ice_sched_node *node;
	struct devreg devlist;

	void setup(void)
	{
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));

		cdi = (struct iidc_core_dev_info *)
			calloc(1, sizeof(struct iidc_core_dev_info));

		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pi = (struct ice_port_info *)
			calloc(1, sizeof(struct ice_port_info));
		node = (struct ice_sched_node *)
			calloc(1,sizeof(struct ice_sched_node));

		netdev = alloc_etherdev_mqs(sizeof(*np), 1, 1);

		cdi->pdev = pdev;
		pdev->dev.driver_data = pf;
		pf->pdev = pdev;

		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->back = pf;
		vsi->port_info = pi;
		pf->hw.port_info = pi;
		pf->vsi = &vsi;
#ifdef SWITCH_MODE
		hash_init(pf->vfs.table);
		vf = (struct ice_vf *)calloc(1, sizeof(struct ice_vf));
		vf->pf = pf;
		vf->vf_id = 0;
		hash_add(pf->vfs.table, &vf->entry, 0);
#ifndef BMSM_MODE
		kref_init(&vf->refcnt);
#endif /* !BMSM_MODE */
#ifdef MULTI_PEER_SUPPORT
		pf->cdev_infos = (struct iidc_core_dev_info **)
				  calloc(1,sizeof(struct iidc_core_dev_info **));
#endif /* MULTI_PEER_SUPPORT */
#endif /* SWITCH_MODE */
#ifdef SWITCH_MODE
		pf->max_pf_txqs = ICE_MAX_TXQS;
		pf->max_pf_rxqs = ICE_MAX_RXQS;
#else
		pf->max_pf_txqs = 64;
		pf->max_pf_rxqs = 64;
#endif
		pf->avail_txqs = bitmap_zalloc(pf->max_pf_txqs, GFP_KERNEL);
		pf->avail_rxqs = bitmap_zalloc(pf->max_pf_rxqs, GFP_KERNEL);
		mutex_init(&pf->sw_mutex);
		mutex_init(&pf->avail_q_mutex);

		/* init our dev tracking list */
		INIT_LIST_HEAD(&devlist.devreg_list);
		global_devreg_list = &devlist;
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		mutex_destroy(&pf->avail_q_mutex);
		mutex_destroy(&pf->sw_mutex);
		free(pf->hw.hw_addr);
		bitmap_free(pf->avail_txqs);
		bitmap_free(pf->avail_rxqs);
		free(pdev);
		free(cdi);
		free(pi);
		free(vsi);
#ifdef SWITCH_MODE
		hash_del(&vf->entry);
		free(vf);
#ifdef MULTI_PEER_SUPPORT
		free(pf->cdev_infos);
#endif /* MULTI_PEER_SUPPORT */
#endif /* SWITCH_MODE */
		free(pf);
		free(node);
		free_netdev(netdev);
	}
};

#ifdef SWITCH_MODE
#ifndef BMSM_MODE

TEST(ice_idc, ice_setup_ae_data_q_info)
{
	ice_setup_ae_data_q_info(pf, cdi);
}
#endif /* !BMSM_MODE */
#else

#ifdef RDMA_SUPPORT
TEST(ice_idc, ice_find_vsi)
{
	ice_vsi *ret_vsi;
	u16 vsi_num;

	vsi_num = 1;
	ret_vsi = ice_find_vsi(pf, vsi_num);
	CHECK_EQUAL(0, ret_vsi);
}
#endif /* RDMA_SUPPORT */
#endif /* SWITCH_MODE */

TEST(ice_idc, ice_peer_request_reset)
{
	enum iidc_reset_type rt;

	mock().expectOneCall("ice_schedule_reset");

	rt = IIDC_CORER;
	ice_cdev_info_request_reset(cdi, rt);

	mock().checkExpectations();
	mock().clear();

#ifdef SWITCH_MODE
#ifndef BMSM_MODE
	mock().expectOneCall("ice_schedule_reset");
	rt = IIDC_CORER_SW_CORE;
	ice_cdev_info_request_reset(cdi, rt);
#endif /* !BMSM_MODE */
#endif /* SWITCH_MODE */

	mock().checkExpectations();
	mock().clear();
}

TEST(ice_idc, ice_cdev_info_vc_send_bogus)
{
	u8 msg[] = "MESSAGE";
	int ret;

	mock().expectNCalls(1, "ice_is_reset_in_progress");

	ret = ice_cdev_info_vc_send(cdi, 27, msg, sizeof(msg));
	CHECK_EQUAL(-ENODEV, ret);
}

#ifdef RDMA_SUPPORT
TEST(ice_idc, ice_cdev_info_vc_send_rdma_invalid_id)
{
	u8 msg[] = "MESSAGE";
	int ret;

	pf->hw.func_caps.vf_base_id = 7;
	cdi->cdev_info_id = IIDC_RDMA_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 20)
		.andReturnValue(false);

	ret = ice_cdev_info_vc_send(cdi, 27, msg, sizeof(msg));
	CHECK_EQUAL(-ENODEV, ret);
}

TEST(ice_idc, ice_cdev_info_vc_send_rdma_valid)
{
	u8 msg[] = "MESSAGE";
	int ret;

	pf->hw.func_caps.vf_base_id = 7;
	cdi->cdev_info_id = IIDC_RDMA_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 20);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.withParameter("hw", &pf->hw)
		.withParameter("vfid", 20)
		.withParameter("v_opcode", VIRTCHNL_OP_RDMA)
		.withParameter("v_retval", 0)
		.withParameter("msg", msg, sizeof(msg))
		.withParameter("msglen", sizeof(msg));

	ret = ice_cdev_info_vc_send(cdi, 27, msg, sizeof(msg));
	CHECK_EQUAL(0, ret);
}

TEST(ice_idc, ice_cdev_info_vc_send_rdma_fails)
{
	u8 msg[] = "MESSAGE";
	int ret;

	pf->hw.func_caps.vf_base_id = 7;
	cdi->cdev_info_id = IIDC_RDMA_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 20);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.withParameter("hw", &pf->hw)
		.withParameter("vfid", 20)
		.withParameter("v_opcode", VIRTCHNL_OP_RDMA)
		.withParameter("v_retval", 0)
		.withParameter("msg", msg, sizeof(msg))
		.withParameter("msglen", sizeof(msg))
		.andReturnValue(-EINVAL);

	ret = ice_cdev_info_vc_send(cdi, 27, msg, sizeof(msg));
	CHECK_EQUAL(-EINVAL, ret);
}
#endif /* RDMA_SUPPORT */

#ifdef VIRTCHNL_IPSEC
TEST(ice_idc, ice_cdev_info_vc_send_ipsec_invalid_id)
{
	u8 msg[] = "IPSEC";
	int ret;

	/* This is set to help verify that ice_rel_vf_id is *not* used */
	pf->hw.func_caps.vf_base_id = 10;
	cdi->cdev_info_id = IIDC_IPSEC_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 37)
		.andReturnValue(false);
#endif /* SWITCH_MODE */

	ret = ice_cdev_info_vc_send(cdi, 37, msg, sizeof(msg));
	CHECK_EQUAL(-ENODEV, ret);
}

TEST(ice_idc, ice_cdev_info_vc_send_ipsec_valid)
{
	u8 msg[] = "IPSEC";
	int ret;

	/* This is set to help verify that ice_rel_vf_id is *not* used */
	pf->hw.func_caps.vf_base_id = 15;
	cdi->cdev_info_id = IIDC_IPSEC_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 0);
#endif /* SWITCH_MODE */

	mock().expectOneCall("ice_ipsec_send_vc_msg")
		.withParameter("pf", pf)
		.withParameter("msg", msg, sizeof(msg))
		.withParameter("len", sizeof(msg))
		.withParameter("vf_id", 0);

	ret = ice_cdev_info_vc_send(cdi, 0, msg, sizeof(msg));
	CHECK_EQUAL(0, ret);
}

TEST(ice_idc, ice_cdev_info_vc_send_ipsec_fails)
{
	u8 msg[] = "IPSEC";
	int ret;

	/* This is set to help verify that ice_rel_vf_id is *not* used */
	pf->hw.func_caps.vf_base_id = 4;
	cdi->cdev_info_id = IIDC_IPSEC_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_is_valid_vf_id")
		.withParameter("pf", pf)
		.withParameter("vf_id", 0);
#endif /* SWITCH_MODE */

	mock().expectOneCall("ice_ipsec_send_vc_msg")
		.withParameter("pf", pf)
		.withParameter("msg", msg, sizeof(msg))
		.withParameter("len", sizeof(msg))
		.withParameter("vf_id", 0)
		.andReturnValue(-EINVAL);

	ret = ice_cdev_info_vc_send(cdi, 0, msg, sizeof(msg));
	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_idc, ice_cdev_info_vc_send_ipsec_broadcast)
{
	u8 msg[] = "IPSEC";
	int ret;

	/* This is set to help verify that ice_rel_vf_id is *not* used */
	pf->hw.func_caps.vf_base_id = 37;
	cdi->cdev_info_id = IIDC_IPSEC_ID;

	mock().expectOneCall("ice_is_reset_in_progress");

	mock().expectNoCall("ice_is_valid_vf_id");

	mock().expectOneCall("ice_ipsec_send_vc_msg")
		.withParameter("pf", pf)
		.withParameter("msg", msg, sizeof(msg))
		.withParameter("len", sizeof(msg))
		.withParameter("vf_id", VIRTCHNL_IPSEC_BROADCAST_VFID);

	ret = ice_cdev_info_vc_send(cdi, VIRTCHNL_IPSEC_BROADCAST_VFID, msg,
				    sizeof(msg));
	CHECK_EQUAL(0, ret);
}
#endif /* VIRTCHNL_IPSEC */

#ifdef SWITCH_MODE
#ifdef ADK_SUPPORT
TEST(ice_idc, ice_vsi_from_port_info)
{
	int ret;

	pf->num_alloc_vsi = 1;
	pf->vsi[0]->type = ICE_VSI_PF;
	pf->vsi[0]->port_info = pi;

	ret = ice_vsi_from_port_info(pf, pi);
	CHECK_EQUAL(0, ret);
}

TEST(ice_idc, ice_peer_adk_setup)
{
	pf->hw.num_lports = 1;
	pf->hw.num_total_ports = pf->hw.num_lports + 1;
	pf->num_alloc_vsi = 1;
	pf->vsi[0]->type = ICE_VSI_PF;
	pf->vsi[0]->port_info = pi;

	ice_peer_adk_setup(cdi);
}

TEST(ice_idc, ice_adk_vsi_q_cfg)
{
	bool enable;
	u8 type;
	int ret;

	vsi->port_info->lport = 0;

	set_bit(ICE_VSI_DOWN, vsi->state);

	clear_bit(IIDC_TX, cdi->port_info[0].ena);
	clear_bit(IIDC_RX, cdi->port_info[0].ena);
	enable = true;
	type = IIDC_TXRX;

	mock().expectNCalls(1, "ice_is_reset_in_progress");
	mock().expectOneCall("ice_vsi_setup_tx_rings");
	mock().expectOneCall("ice_vsi_cfg_lan_txqs");
	mock().expectOneCall("ice_vsi_setup_rx_rings");
	mock().expectOneCall("ice_vsi_cfg_rxqs");
	mock().expectOneCall("ice_vsi_req_irq_msix");
	mock().expectOneCall("ice_vsi_cfg_msix");
	mock().expectOneCall("ice_vsi_ena_irq");
	mock().expectOneCall("ice_napi_enable_all");
	mock().expectOneCall("ice_vsi_start_all_rx_rings");

	ret = ice_adk_vsi_q_cfg(cdi, netdev, type, enable);
	CHECK_EQUAL(0, ret);
	CHECK_EQUAL(1, test_bit(IIDC_TX, cdi->port_info[0].ena));
	CHECK_EQUAL(1, test_bit(IIDC_RX, cdi->port_info[0].ena));

	set_bit(IIDC_TX, cdi->port_info[0].ena);
	set_bit(IIDC_RX, cdi->port_info[0].ena);
	clear_bit(ICE_VSI_DOWN, vsi->state);
	enable = false;
	type = IIDC_TXRX;

	mock().expectNCalls(1, "ice_is_reset_in_progress");
	mock().expectOneCall("ice_vsi_stop_lan_tx_rings");
	mock().expectOneCall("ice_vsi_free_tx_rings");
	mock().expectOneCall("ice_vsi_stop_all_rx_rings");
	mock().expectOneCall("ice_vsi_free_rx_rings");
	mock().expectOneCall("ice_vsi_dis_irq");
	mock().expectOneCall("ice_vsi_free_irq");
	mock().expectOneCall("ice_napi_disable_all");

	ret = ice_adk_vsi_q_cfg(cdi, netdev, type, enable);
        CHECK_EQUAL(0, ret);
	CHECK_EQUAL(0, test_bit(IIDC_TX, cdi->port_info[0].ena));
	CHECK_EQUAL(0, test_bit(IIDC_RX, cdi->port_info[0].ena));
}

TEST(ice_idc, ice_adk_strt_xmit_internal)
{
	int ret;
	struct iidc_nd_tx_md *txmd;
	struct sk_buff *skb;

	skb = (struct sk_buff *)calloc(1, sizeof(struct sk_buff));

	txmd = (struct iidc_nd_tx_md *)calloc(1, sizeof(struct iidc_nd_tx_md));
	txmd->ts_ena = false;

	vsi->adk_cdev_info = cdi;

	vsi->port_info->lport = 0;
	clear_bit(IIDC_TX, cdi->port_info[0].ena);
	mock().expectOneCall("ice_is_reset_in_progress");

	ret = ice_adk_strt_xmit_internal(cdi, skb, txmd, netdev);
	CHECK_EQUAL(-EIO, ret);

	free(txmd);
	free(skb);
}

TEST(ice_idc, ice_adk_get_port_id)
{
        int ret;

	vsi->port_info->lport = 13;
	ret = ice_adk_get_port_id(netdev);
	CHECK_EQUAL(13, ret);
}
#endif /* ADK_SUPPORT */
#endif /* SWITCH_MODE */
