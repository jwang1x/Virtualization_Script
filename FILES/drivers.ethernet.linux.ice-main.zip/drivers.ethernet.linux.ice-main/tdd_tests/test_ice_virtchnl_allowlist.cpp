#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_virtchnl_allowlist {
#include "tdd_shared_code_transform.h"
#include "include/asm-generic/bitops/const_hweight.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "../src/CORE/ice_virtchnl_allowlist.c"
};
/////////////////////////////////////////////////
using namespace ns_virtchnl_allowlist;

TEST_GROUP(virtchnl_allowlist_grp)
{
	struct ice_vf *vf;

	void setup(void)
	{
		vf = (struct ice_vf *)calloc(1, sizeof(*vf));
	}

	void teardown(void)
	{
		free(vf);
	}
};

TEST(virtchnl_allowlist_grp, test_not_defined_opcode)
{
	CHECK_FALSE(ice_vc_is_opcode_allowed(vf, VIRTCHNL_OP_MAX));
}

TEST(virtchnl_allowlist_grp, test_get_vf_res_opcode_should_be_clear)
{
	bitmap_clear(vf->opcodes_allowlist, 0, VIRTCHNL_OP_MAX);

	CHECK_FALSE(ice_vc_is_opcode_allowed(vf,
						 VIRTCHNL_OP_GET_VF_RESOURCES));
}

TEST(virtchnl_allowlist_grp, test_get_vf_res_opcode_should_be_set)
{
	set_bit(VIRTCHNL_OP_GET_VF_RESOURCES, vf->opcodes_allowlist);

	CHECK_TRUE(ice_vc_is_opcode_allowed(vf,
						VIRTCHNL_OP_GET_VF_RESOURCES));
}

TEST(virtchnl_allowlist_grp, test_allowlisting_default_opcodes)
{
	ice_vc_allowlist_opcodes(vf, default_allowlist_opcodes,
				 ARRAY_SIZE(default_allowlist_opcodes));

	CHECK_FALSE(test_bit(VIRTCHNL_OP_UNKNOWN,
			    vf->opcodes_allowlist));
	CHECK_TRUE(test_bit(VIRTCHNL_OP_GET_VF_RESOURCES,
			    vf->opcodes_allowlist));
	CHECK_TRUE(test_bit(VIRTCHNL_OP_VERSION,
			    vf->opcodes_allowlist));
	CHECK_TRUE(test_bit(VIRTCHNL_OP_RESET_VF,
			    vf->opcodes_allowlist));
}

TEST(virtchnl_allowlist_grp, test_calculating_index_from_caps)
{
	CHECK_EQUAL(0, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_L2));
	CHECK_EQUAL(1, BIT_INDEX(VIRTCHNL_VF_CAP_RDMA));
	CHECK_EQUAL(6, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_REQ_QUEUES));
#ifdef VIRTCHNL_IPSEC
	CHECK_EQUAL(8, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_INLINE_IPSEC_CRYPTO));
#endif /* VIRTCHNL_IPSEC */
	CHECK_EQUAL(16, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_VLAN));
	CHECK_EQUAL(19, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_RSS_PF));
	CHECK_EQUAL(23, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_ADQ));
#ifdef DCF_SUPPORT
	CHECK_EQUAL(30, BIT_INDEX(VIRTCHNL_VF_CAP_DCF));
#endif /* DCF_SUPPORT */
#ifdef ADV_AVF_SUPPORT
	CHECK_EQUAL(26, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_RX_FLEX_DESC));
	CHECK_EQUAL(27, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_ADV_RSS_PF));
	CHECK_EQUAL(28, BIT_INDEX(VIRTCHNL_VF_OFFLOAD_FDIR_PF));
#endif /* ADV_AVF_SUPPORT */
}
