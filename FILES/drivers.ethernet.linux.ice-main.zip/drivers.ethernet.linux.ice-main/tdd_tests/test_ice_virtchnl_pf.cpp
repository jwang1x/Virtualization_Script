#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_virtchnl {
#include "tdd_shared_code_transform.h"
#include "include/asm-generic/bitops/const_hweight.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/skbuff.h>
#include <linux/compiler.h>
#include <linux/if_link.h>
#include <linux/pci_regs.h>
#include <linux/jiffies.h>

#include "../src/CORE/ice.h"

#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_acl.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_vf_mbx.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "SHARED_MOCKS/mock_ice_bitops.cpp"
#include "SHARED_MOCKS/mock_ice_parser.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"
#include "CORE_MOCKS/mock_ice_ipsec.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_allowlist.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_dcf.cpp"
#include "CORE_MOCKS/mock_ice_vf_veb.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_vf_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fdir.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fsub.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"

#include "CORE_MOCKS/stdmock_ice_vf_lib.cpp"
#include "CORE_MOCKS/stdmock_ice_sriov.cpp"

#include "../src/CORE/ice_vf_lib.c"
#ifdef ADQ_SUPPORT
#include "../src/CORE/ice_vf_adq.c"
#endif /* ADQ_SUPPORT */
#include "../src/CORE/ice_virtchnl.c"
#include "../src/CORE/ice_sriov.c"
}
////////////////////////////////////////
using namespace ns_virtchnl;

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

#define FLAG_VF_UNICAST_PROMISC	0x00000001
#define FLAG_VF_MULTICAST_PROMISC	0x00000002

/* basic setup for the PF structure and common pointers */
TEST_GROUP(ice_virtchnl)
{
	struct device *dev = NULL;
	struct pci_dev *pdev;
	struct ice_vfs *vfs;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void test_del_vfs() {
		struct hlist_node *tmp;
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each_safe(pf->vfs.table, bkt, tmp, vf, entry) {
			hash_del(&vf->entry);
			mutex_destroy(&vf->cfg_lock);
			kfree(vf);
		}
	}

	struct ice_vf *test_add_one_vf(int i) {
		struct ice_vf *vf;

		vf = (struct ice_vf *)kzalloc(sizeof(*vf), GFP_KERNEL);

		vf->pf = pf;
		vf->vf_id = i;
		vf->vf_ops = &ice_sriov_vf_ops;
		mutex_init(&vf->cfg_lock);
		kref_init(&vf->refcnt);

		hash_add(vfs->table, &vf->entry, i);
		return vf;
	}

	struct ice_vf *test_get_vf(int i) {
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each(pf->vfs.table, bkt, vf, entry) {
			if (vf->vf_id == i)
				return vf;
		}

		FAIL(StringFromFormat("Unable to locate VF with ID %d", i).asCharString());
		return NULL;
	}

	void test_add_vfs(int num_vfs) {
		for (int i = 0; i < num_vfs; i++)
			test_add_one_vf(i);
	}

	void test_set_vfs(int num_vfs) {
		test_del_vfs();
		test_add_vfs(num_vfs);
	}

	TEST_SETUP()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		hw = &pf->hw;
		vfs = &pf->vfs;

		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);

		hw->back = pf;
		hw->hw_addr = (unsigned char *) calloc(1, sizeof(unsigned char) * 0x1000000);

		pdev = (struct pci_dev*) calloc(1, sizeof(*pdev));
		pdev->dev.driver_data = pf;
		pf->pdev = pdev;
	}

	TEST_TEARDOWN()
	{
		test_del_vfs();
		mutex_destroy(&vfs->table_lock);
		free(hw->hw_addr);
		free(pdev);
		free(pf);
	}
};

TEST(ice_virtchnl, ice_free_vfs_expect_hash_empty)
{
	/* make sure VF table is empty */
	test_del_vfs();

	/* expect no other calls since there are no VFs to clean */
	ice_free_vfs(pf);
}

TEST_GROUP_BASE(ice_vc_set_rss_hena, TGN(ice_virtchnl))
{
	struct ice_vf *vf;
	struct ice_vsi *vsi;
	struct virtchnl_rss_hena *set_rss_hena;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(0);
		vf->pf = pf;

		set_rss_hena = (struct virtchnl_rss_hena *)calloc(1, sizeof(*set_rss_hena));

		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->back = pf;

		set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
		set_bit(ICE_FLAG_RSS_ENA, vf->pf->flags);
	}

	void teardown()
	{
		free(vsi);
		free(set_rss_hena);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_set_rss_hena, attempt_to_clear_vf_config_success_expect_report_success_to_vf)
{
	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	set_rss_hena->hena = 0;

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vsi);

	mock().expectOneCall("ice_rem_vsi_rss_cfg")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_vc_set_rss_hena(vf, (u8 *)set_rss_hena);
}

TEST(ice_vc_set_rss_hena, attempt_to_clear_vf_config_fails_expect_report_error_to_vf)
{
	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	set_rss_hena->hena = 0;

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vsi);

	mock().expectOneCall("ice_rem_vsi_rss_cfg")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_AQ_ERROR);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_retval", ice_err_to_virt_err(ICE_ERR_AQ_ERROR))
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_vc_set_rss_hena(vf, (u8 *)set_rss_hena);
}

TEST(ice_vc_set_rss_hena, attempt_to_set_vf_config_clear_old_config_fails_expect_report_success_to_vf)
{
	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	set_rss_hena->hena = ICE_AVF_FLOW_FIELD_IPV4_UDP;

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vsi);

	mock().expectOneCall("ice_rem_vsi_rss_cfg")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_AQ_ERROR);

	mock().expectOneCall("ice_add_avf_rss_cfg")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_vc_set_rss_hena(vf, (u8 *)set_rss_hena);
}

TEST(ice_vc_set_rss_hena, vf_tries_to_set_new_rss_hena_expect_call_to_rem_vsi_rss_cfg)
{
	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	set_rss_hena->hena = ICE_AVF_FLOW_FIELD_IPV4_UDP;


	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vsi);

	mock().expectOneCall("ice_rem_vsi_rss_cfg")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_add_avf_rss_cfg")
		.withParameter("avf_hash", set_rss_hena->hena)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_vc_set_rss_hena(vf, (u8 *)set_rss_hena);
}

TEST_GROUP_BASE(ice_cpk_virt, TGN(ice_virtchnl))
{
	struct ice_vsi *vsi;
	const int num_vfs = 5;

	void setup(void)
	{
		TGN(ice_virtchnl)::setup();

		vfs->num_supported = 10;
		mutex_init(&pf->sw_mutex);
		mutex_init(&pf->avail_q_mutex);
		pf->first_sw = (struct ice_sw*) calloc(1, sizeof(struct ice_sw));
		pf->first_sw->sw_id = 2;
		pf->first_sw->pf = pf;
		hw->func_caps.common_cap.num_msix_vectors = 256;
#ifdef SWITCH_MODE
		hw->func_caps.guar_num_vsi = ICE_NUM_EXTERNAL_PORTS;
		hw->num_lports = ICE_NUM_EXTERNAL_PORTS;
		hw->num_total_ports = hw->num_lports + 1;
		hw->ena_lports = BIT(hw->num_total_ports) - 1;
#ifdef BMSM_MODE
		pf->sw = (struct ice_sw *)calloc(ICE_MAX_PORT_PER_PCI_DEV, sizeof(struct ice_sw));
		for (int i = 0; i < ICE_MAX_PORT_PER_PCI_DEV; i++) {
			pf->sw[i].pf = pf;
			pf->sw[i].sw_id = 3 + i;
		}
#endif
		hw->port_info = (struct ice_port_info *)calloc(hw->num_total_ports, sizeof(struct ice_port_info));
#ifdef BMSM_MODE
		/* Make sure all of the ports mark VF as allowed */
		for (int i = 0; i < hw->num_total_ports; i++) {
			hw->port_info[i].vf_allowed = true;
			hw->port_info[i].sw_id = 3 + i;
		}
#endif
#else
		hw->port_info = (struct ice_port_info *) calloc(1, sizeof(struct ice_port_info));
		hw->func_caps.guar_num_vsi = ICE_MAX_VSI / 8;
#endif
		pf->num_alloc_vsi = hw->func_caps.guar_num_vsi;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi, sizeof(struct ice_vsi *));
		for (int i = 0; i < VPGEN_VFRSTAT_MAX_INDEX; i++)
			wr32(&pf->hw, VPGEN_VFRSTAT(i), 1);
		/* allocate PF VSI */
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = pf;
		vsi->port_info = pf->hw.port_info;
		pf->vsi[0] = vsi;
		/* irq_tracker has 160 entries */
		int vectors = 160;
		pf->irq_tracker = (struct ice_res_tracker *)
			calloc(1, sizeof(*pf->irq_tracker) +
			       sizeof(u16) * vectors);
		pf->irq_tracker->end = vectors - 1;
		pf->irq_tracker->num_entries = vectors;
		test_add_vfs(num_vfs);
	}

	void teardown(void)
	{
		/* Some of the fields being freed here are actually allocated in
		 * the ice_pci_sriov_configure flow but unless these are
		 * deallocated some where, cpputest will complain about memory
		 * leaks. This is a bit of a workaround.
		 */
		free(vsi);
		vsi = NULL;
		free(pf->vsi);
		free(pf->hw.port_info);
		free(pf->first_sw);
#if defined(SWITCH_MODE) && defined(BMSM_MODE)
		free(pf->sw);
#endif
		mutex_destroy(&pf->sw_mutex);
		mutex_destroy(&pf->avail_q_mutex);

		free(pf->irq_tracker);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_cpk_virt, do_vf_stats)
{
	struct ifla_vf_stats vf_stats = { };
	struct net_device *netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
	struct ice_netdev_priv *np = netdev_priv(netdev);
	int vf_id = 0;
	USE_STD_MOCK(ice_check_vf_ready_for_cfg);

	np->vsi = vsi;

	pf->num_avail_sw_msix = 256;

	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_update_eth_stats")
		.ignoreOtherParameters();
	ice_get_vf_stats(netdev, vf_id, &vf_stats);

	CHECK_EQUAL(0, vf_stats.tx_packets);

	free_netdev(netdev);
}

TEST(ice_cpk_virt, calc_vf_reg_idx_4_vfs_4_num_vf_msix)
{
	struct ice_vf *vf = test_add_one_vf(0);
	struct ice_q_vector *q_vector;
	u16 reg_idx;

	vf->pf = pf;
	q_vector = (struct ice_q_vector *)calloc(1, sizeof(*q_vector));
	pf->vfs.num_msix_per = 5;
	pf->sriov_base_vector = 100;

	vf->vf_id = 0;
	/* start at 1 because index 0 is always OICR */
	for (int i = 1; i < pf->vfs.num_msix_per; ++i) {
		q_vector->v_idx = i - 1;
		reg_idx = ice_calc_vf_reg_idx(vf, q_vector, 0);
		CHECK_EQUAL(100 + i, reg_idx);
	}

	vf->vf_id = 1;
	for (int i = 1; i < pf->vfs.num_msix_per; ++i) {
		q_vector->v_idx = i - 1;
		reg_idx = ice_calc_vf_reg_idx(vf, q_vector, 0);
		/* +1 is to account for the first vector being the OICR index */
		CHECK_EQUAL(105 + i, reg_idx);
	}

	vf->vf_id = 2;
	for (int i = 1; i < pf->vfs.num_msix_per; ++i) {
		q_vector->v_idx = i - 1;
		reg_idx = ice_calc_vf_reg_idx(vf, q_vector, 0);
		/* +1 is to account for the first vector being the OICR index */
		CHECK_EQUAL(110 + i, reg_idx);
	}

	vf->vf_id = 3;
	for (int i = 1; i < pf->vfs.num_msix_per; ++i) {
		q_vector->v_idx = i - 1;
		reg_idx = ice_calc_vf_reg_idx(vf, q_vector, 0);
		/* +1 is to account for the first vector being the OICR index */
		CHECK_EQUAL(115 + i, reg_idx);
	}

	free(q_vector);
	q_vector = NULL;
}

TEST(ice_cpk_virt, calc_vf_reg_idx_fail_cases)
{
	struct ice_vf *vf = test_add_one_vf(0);
	struct ice_q_vector *q_vector =
		(struct ice_q_vector *)calloc(1, sizeof(*q_vector));
	int reg_idx;

	vf->pf = pf;
	reg_idx = ice_calc_vf_reg_idx(NULL, q_vector, 0);
	CHECK_EQUAL(-EINVAL, reg_idx);

	reg_idx = ice_calc_vf_reg_idx(vf, NULL, 0);
	CHECK_EQUAL(-EINVAL, reg_idx);

	free(q_vector);
	q_vector = NULL;
}

TEST(ice_cpk_virt, check_avail_res_fail_no_vfs)
{
	mutex_lock(&pf->vfs.table_lock);
	CHECK_EQUAL(-EINVAL, ice_set_per_vf_res(pf, 0));
	mutex_unlock(&pf->vfs.table_lock);
}

TEST(ice_cpk_virt, check_avail_res_fail_no_space)
{
	u16 max_valid_res_idx;

	/* We have 124 available MSIX vectors in hardware for SRIOV
	 * (hw->func_caps.common_cap.num_msix_vectors - 1) -
	 * (max_valid_res_idx + 1)
	 */
	max_valid_res_idx = 130;
	pf->irq_tracker->list[max_valid_res_idx] = ICE_RES_VALID_BIT;

	mutex_lock(&pf->vfs.table_lock);
	CHECK_EQUAL(-ENOSPC, ice_set_per_vf_res(pf, 63));
	mutex_unlock(&pf->vfs.table_lock);
}

TEST(ice_cpk_virt, check_avail_res_only_non_os_reserved_res_needed_success)
{
	u16 max_valid_res_idx = 130;
	u16 num_avail_sw_msix = pf->irq_tracker->num_entries -
		max_valid_res_idx - 1;
	int result;

	pf->num_avail_sw_msix = num_avail_sw_msix;
	pf->irq_tracker->list[max_valid_res_idx] = ICE_RES_VALID_BIT;
	pf->hw.func_caps.common_cap.num_msix_vectors = pf->irq_tracker->num_entries + 5;

	mock().expectOneCall("ice_get_avail_txq_count")
		.andReturnValue(4);
	mock().expectOneCall("ice_get_avail_rxq_count")
		.andReturnValue(4);

	mutex_lock(&pf->vfs.table_lock);
	result = ice_set_per_vf_res(pf, 1);
	mutex_unlock(&pf->vfs.table_lock);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(4, pf->vfs.num_qps_per);
	CHECK_EQUAL(pf->hw.func_caps.common_cap.num_msix_vectors -
		    5, pf->sriov_base_vector);
	CHECK_EQUAL(5, pf->vfs.num_msix_per);
	/* pf->num_avail_sw_msix should not have changed here as we are only
	 * getting non OS reserved MSIX vectors.
	 */
	CHECK_EQUAL(num_avail_sw_msix, pf->num_avail_sw_msix);
}

TEST(ice_cpk_virt, 3_msix_avail_per_vf_expect_each_vf_to_get_2_queue_pairs)
{
	int result;

	USE_STD_MOCK(ice_get_max_valid_res_idx);
	USE_STD_MOCK(ice_sriov_set_msix_res);

#define TOTAL_MSIX		512
#define MSIX_USED		295
#define AVAILABLE_QUEUES	(TOTAL_MSIX - MSIX_USED)
#define EXPECTED_MSIX_PER_VF	3

	pf->hw.func_caps.common_cap.num_msix_vectors = TOTAL_MSIX;
	/* PF LAN MSI-X: 112
	 * PF OICR MSI-X: 1
	 * PF FDIR MSI-X: 1
	 * VF FDIR MSI-X: 1
	 * RDMA MSI-X: 116
	 * MACVLAN MSI-X: 64
	 *
	 * Total: 295 reserved/used MSI-X
	 */
	pf->irq_tracker->num_entries = MSIX_USED;

	mock().expectOneCall("ice_get_max_valid_res_idx")
		.withParameter("res", pf->irq_tracker)
		.andReturnValue(pf->irq_tracker->num_entries - 1);

	mock().expectOneCall("ice_get_avail_txq_count")
		.andReturnValue(AVAILABLE_QUEUES);

	mock().expectOneCall("ice_get_avail_rxq_count")
		.andReturnValue(AVAILABLE_QUEUES);


	mock().expectOneCall("ice_sriov_set_msix_res")
		.withParameter("pf", pf)
		.withParameter("num_msix_needed", EXPECTED_MSIX_PER_VF * 64)
		.andReturnValue(0);

	mutex_lock(&pf->vfs.table_lock);
	result = ice_set_per_vf_res(pf, 64);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(0, result);
	CHECK_EQUAL(EXPECTED_MSIX_PER_VF, pf->vfs.num_msix_per);
	CHECK_EQUAL(EXPECTED_MSIX_PER_VF - 1, pf->vfs.num_qps_per);
}

TEST(ice_cpk_virt, sriov_set_res_dont_need_irq_tracker_entries)
{
	int result;
	/* set it up so we use every interrupt possible without touching
	 * the sw_irq_entries
	 */
	u16 num_msix_needed = 96;

	result = ice_sriov_set_msix_res(pf, num_msix_needed);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(pf->irq_tracker->num_entries - 1,
		    pf->irq_tracker->end);
}

TEST(ice_cpk_virt, sriov_set_res_max_valid_res_idx_using_space_needed_for_sriov)
{
	u16 max_valid_res_idx;
	int result;
	/* set it up so we use every interrupt possible without touching
	 * the sw_irq_entries
	 */
	u16 num_msix_needed = 98;

	/* this is the first entry we need for SRIOV but it is already taken so
	 * fail the request for MSIX resources
	 */
	max_valid_res_idx = 158;
	pf->irq_tracker->list[max_valid_res_idx] = ICE_RES_VALID_BIT;

	result = ice_sriov_set_msix_res(pf, num_msix_needed);
	CHECK_EQUAL(-EINVAL, result);
}

TEST(ice_cpk_virt, ice_sriov_free_msix_res_no_irq_tracker_entries_used)
{
	int result;

	/* only 1 VF with 2 vectors, not realistic but still a useful simple
	 * test
	 */
	pf->sriov_base_vector = 254;

	result = ice_sriov_free_msix_res(pf);

	CHECK_EQUAL(0, result);
	CHECK_EQUAL(0, pf->sriov_base_vector);
}

TEST(ice_cpk_virt, ice_sriov_free_msix_res_2_irq_tracker_entries_used)
{
	int resource_start;
	int result;
	/* set it up so we use every interrupt possible without touching
	 * the sw_irq_entries
	 */
	pf->hw.func_caps.common_cap.num_msix_vectors = pf->irq_tracker->num_entries + 98;
	u16 num_msix_needed = 98;

	pf->irq_tracker->list[130] = ICE_RES_VALID_BIT;

	resource_start = pf->irq_tracker->num_entries - 2;
	result = ice_sriov_set_msix_res(pf, num_msix_needed);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(resource_start, pf->sriov_base_vector - 2);
	CHECK_EQUAL(resource_start, pf->irq_tracker->end - 1);

	result = ice_sriov_free_msix_res(pf);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(0, pf->sriov_base_vector);
	CHECK_EQUAL(pf->irq_tracker->num_entries - 1,
		    pf->irq_tracker->end);
}

TEST(ice_cpk_virt, calc_vf_first_vector_idx_for_2_vfs_with_2_msix_each)
{
	struct ice_vf *vf = test_add_one_vf(0);
	int first_vector_index;
	pf->sriov_base_vector = 252;

	vf->vf_id = 0;
	pf->vfs.num_msix_per = 2;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(252, first_vector_index);

	vf->vf_id = 1;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(254, first_vector_index);
}

TEST(ice_cpk_virt, calc_vf_first_vector_idx_for_4_vfs_with_4_msix_each)
{
	struct ice_vf *vf = test_add_one_vf(0);
	int first_vector_index;
	pf->sriov_base_vector = 240;

	vf->vf_id = 0;
	pf->vfs.num_msix_per = 4;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(240, first_vector_index);

	vf->vf_id = 1;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(244, first_vector_index);

	vf->vf_id = 2;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(248, first_vector_index);

	vf->vf_id = 3;
	first_vector_index = ice_calc_vf_first_vector_idx(pf, vf);
	CHECK_EQUAL(252, first_vector_index);
}

TEST(ice_cpk_virt, get_pf_max_valid_res_idx_is_at_max)
{
	int last_entry = pf->irq_tracker->num_entries - 1;
	int max_valid_res_idx;

	pf->irq_tracker->list[last_entry] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(last_entry, max_valid_res_idx);

	pf->irq_tracker->list[0] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(last_entry, max_valid_res_idx);
}

TEST(ice_cpk_virt, get_pf_max_valid_res_idx_is_in_middle)
{
	int entry = DIV_ROUND_UP(pf->irq_tracker->num_entries, 2);
	int max_valid_res_idx;

	pf->irq_tracker->list[entry] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(entry, max_valid_res_idx);

	pf->irq_tracker->list[0] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(entry, max_valid_res_idx);
}

TEST(ice_cpk_virt, get_pf_max_valid_res_idx_is_in_beginning_then_middle)
{
	int entry = DIV_ROUND_UP(pf->irq_tracker->num_entries, 2);
	int max_valid_res_idx;

	pf->irq_tracker->list[0] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(0, max_valid_res_idx);

	pf->irq_tracker->list[entry] = ICE_RES_VALID_BIT;
	max_valid_res_idx = ice_get_max_valid_res_idx(pf->irq_tracker);
	CHECK_EQUAL(entry, max_valid_res_idx);
}

TEST(ice_cpk_virt, get_pf_max_valid_res_idx_res_is_null)
{
	CHECK_EQUAL(-EINVAL, ice_get_max_valid_res_idx(NULL));
}

TEST(ice_cpk_virt, check_sriov_configure_fail)
{
	int ret;

	USE_STD_MOCK(ice_check_sriov_allowed);
	USE_STD_MOCK(ice_pci_sriov_ena);

	mock().expectOneCall("ice_check_sriov_allowed")
		.withParameter("pf", pf)
		.andReturnValue(0);
	mock().expectOneCall("ice_mbx_init_snapshot")
		.withParameter("vf_count", num_vfs)
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_pci_sriov_ena")
		.withParameter("pf", pf)
		.withParameter("num_vfs", num_vfs)
		.andReturnValue(-EIO);
	mock().expectOneCall("ice_mbx_deinit_snapshot");

	ret = ice_sriov_configure(pf->pdev, num_vfs);
	CHECK_EQUAL(-EIO, ret);
}

TEST(ice_cpk_virt, check_sriov_configure_disable_vfs)
{
	int ret;

	USE_STD_MOCK(ice_check_sriov_allowed);
	USE_STD_MOCK(ice_pci_sriov_ena);
	USE_STD_MOCK(ice_free_vfs);

	mock().expectOneCall("ice_check_sriov_allowed")
		.withParameter("pf", pf)
		.andReturnValue(0);
	mock().expectOneCall("ice_free_vfs");
	mock().expectOneCall("ice_mbx_deinit_snapshot");

	ret = ice_sriov_configure(pf->pdev, 0);
	CHECK_EQUAL(0, ret);
}

TEST(ice_cpk_virt, ice_reset_all_vfs_fails_when_no_vfs)
{
	/* Remove all VF entries now */
	test_del_vfs();

	ice_reset_all_vfs(pf);
}

TEST(ice_cpk_virt, ice_reset_all_vfs_fails_when_all_vfs_are_already_disabled)
{
	set_bit(ICE_VF_DIS, pf->state);

	for (int i = 0; i < num_vfs; ++i)
		mock().expectOneCall("ice_mbx_clear_malvf")
			.andReturnValue(0);

	ice_reset_all_vfs(pf);
}

TEST(ice_cpk_virt, ice_reset_all_vfs_success)
{
	struct ice_vf *vf;
	unsigned int bkt;

	clear_bit(ICE_VF_DIS, pf->state);

	USE_STD_MOCK(ice_trigger_vf_reset);
	USE_STD_MOCK(ice_vf_pre_vsi_rebuild);
	USE_STD_MOCK(ice_vf_rebuild_vsi);
	USE_STD_MOCK(ice_sriov_post_vsi_rebuild);
	USE_STD_MOCK(ice_vf_post_vsi_rebuild);

#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_clear_dcf_acl_cfg")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_clear_dcf_udp_tunnel_cfg")
		.ignoreOtherParameters();
#endif

	ice_for_each_vf(pf, bkt, vf) {
		mock().expectOneCall("ice_trigger_vf_reset")
			.withParameter("vf", vf)
			.withParameter("is_vflr", true)
			.withParameter("is_pfr", true);
		mock().expectOneCall("ice_vc_set_default_allowlist");
#ifdef ADV_AVF_SUPPORT
		mock().expectOneCall("ice_vf_fdir_exit");
		mock().expectOneCall("ice_vf_fdir_init");
		mock().expectOneCall("ice_vf_fsub_exit");
		mock().expectOneCall("ice_vf_fsub_init");
#endif /* ADV_AVF_SUPPORT */
		mock().expectOneCall("ice_vf_pre_vsi_rebuild")
			.withParameter("vf", vf);
		mock().expectOneCall("ice_vf_rebuild_vsi")
			.withParameter("vf", vf)
			.andReturnValue(0);
		mock().expectOneCall("ice_vf_post_vsi_rebuild")
			.withParameter("vf", vf);
		mock().expectOneCall("ice_mbx_clear_malvf")
			.andReturnValue(0);
	}

#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);

#endif
	ice_reset_all_vfs(pf);
	CHECK_FALSE(test_bit(ICE_VF_DIS, pf->state));
}

TEST(ice_cpk_virt, check_sriov_configure_works)
{
	USE_STD_MOCK(ice_check_sriov_allowed);
	USE_STD_MOCK(ice_pci_sriov_ena);

	mock().expectOneCall("ice_check_sriov_allowed")
		.withParameter("pf", pf)
		.andReturnValue(0);
	mock().expectOneCall("ice_mbx_init_snapshot")
		.withParameter("vf_count", num_vfs)
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_pci_sriov_ena")
		.withParameter("pf", pf)
		.withParameter("num_vfs", num_vfs)
		.andReturnValue(0);

#if defined(SWITCH_MODE)
	USE_STD_MOCK(ice_create_port_assoc_sysfs);
	mock().expectOneCall("ice_create_port_assoc_sysfs")
		.withParameter("pdev", pf->pdev);
#endif /* SWITCH_MODE */

	CHECK_EQUAL(ice_sriov_configure(pf->pdev, num_vfs), num_vfs);
}

TEST(ice_cpk_virt, ice_sriov_configure_but_sriov_not_allowed)
{
	USE_STD_MOCK(ice_check_sriov_allowed);
	mock().expectOneCall("ice_check_sriov_allowed")
		.withParameter("pf", pf)
		.andReturnValue(-EOPNOTSUPP);
	CHECK_EQUAL(-EOPNOTSUPP, ice_sriov_configure(pf->pdev, num_vfs));
}

#ifdef BMSM_MODE
TEST(ice_cpk_virt, vfs_round_robin_ports_all_enabled)
{
	test_del_vfs();

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, all ports are enabled and allow VFs
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(0, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(2, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(3, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(4, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_skip_disabled_ports)
{
	test_del_vfs();
	hw->ena_lports &= ~BIT(3);

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, port 3 is disabled, so it should be skipped
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(0, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(2, test_get_vf(2)->port_assoc);
	/* Skip port 3 */
	CHECK_EQUAL(4, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(5, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_skip_if_vfs_not_allowed)
{
	test_del_vfs();
	hw->port_info[1].vf_allowed = false;

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, port 1 does not allow VFs, so it should be skipped.
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(0, test_get_vf(0)->port_assoc);
	/* skip 1 */
	CHECK_EQUAL(2, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(3, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(4, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(5, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_once_out_of_ports)
{
	test_del_vfs();

	/* Only enable the first two ports */
	hw->ena_lports = BIT(2) - 1;

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, only port 0 and port 1 are enabled, so VFs should round
	 * robin between these two.
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(0, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(0, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(0, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_skip_over_ports)
{
	test_del_vfs();

	/* Enable port 1 and port 5 only */
	hw->ena_lports = BIT(1) | BIT(5);

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, only port 1 and port 5 are enabled, so VFs should round
	 * robin between these two.
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(1, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(5, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(5, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(1, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_skip_over_vf_disallowed)
{
	test_del_vfs();

	/* Enable 6, 7, 8 */
	hw->ena_lports = BIT(6) | BIT(7) | BIT(8);
	/* But 8 is not allowing VFs */
	hw->port_info[8].vf_allowed = false;

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, ports 6, 7, and 8 are enabled, but 8 does not allow
	 * VFs, so it should be skipped
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(6, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(6, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(6, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_round_robin_only_one_port_available)
{
	test_del_vfs();

	/* Enable only port 7 */
	hw->ena_lports = BIT(7);

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * case only port 7 is available.
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	CHECK_EQUAL(7, test_get_vf(0)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(1)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(2)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(3)->port_assoc);
	CHECK_EQUAL(7, test_get_vf(4)->port_assoc);
}

TEST(ice_cpk_virt, vfs_sw_id_assignment)
{
	test_del_vfs();

	/* Enable 6, 7, 8 */
	hw->ena_lports = BIT(6) | BIT(7) | BIT(8);
	/* But 8 is not allowing VFs */
	hw->port_info[8].vf_allowed = false;

	/* This test does not care about function expectations */
	mock().ignoreOtherCalls();

	/* Verify that VFs will round robin among the available ports. In this
	 * test case, ports 6, 7, and 8 are enabled, but 8 does not allow
	 * VFs, so it should be skipped
	 */
	mutex_lock(&pf->vfs.table_lock);
	ice_create_vf_entries(pf, 5);
	mutex_unlock(&pf->vfs.table_lock);

	POINTERS_EQUAL(&pf->sw[6], test_get_vf(0)->vf_sw_id);
	POINTERS_EQUAL(&pf->sw[7], test_get_vf(1)->vf_sw_id);
	POINTERS_EQUAL(&pf->sw[6], test_get_vf(2)->vf_sw_id);
	POINTERS_EQUAL(&pf->sw[7], test_get_vf(3)->vf_sw_id);
	POINTERS_EQUAL(&pf->sw[6], test_get_vf(4)->vf_sw_id);
}
#endif /* BMSM_MODE */

TEST_GROUP_BASE(ice_start_vfs, TGN(ice_virtchnl))
{
	int num_vfs = 10;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vfs = &pf->vfs;

		test_add_vfs(num_vfs);
		pf->vsi = (struct ice_vsi **)calloc(num_vfs, sizeof(struct ice_vsi *));
		for (int i = 0; i < num_vfs; i++)
			pf->vsi[i] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
	}

	void teardown()
	{
		for (int i = 0; i < num_vfs; i++)
			free(pf->vsi[i]);
		free(pf->vsi);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_start_vfs, ice_start_vfs_failed_to_init_vf_vsi_res_for_vf_2)
{
	unsigned int bkt, it_cnt;
	struct ice_vf *vf;
	int err;

	USE_STD_MOCK(ice_init_vf_vsi_res);
	USE_STD_MOCK(ice_ena_vf_mappings);
	USE_STD_MOCK(ice_dis_vf_mappings);
	USE_STD_MOCK(ice_sriov_clear_reset_trigger);
	USE_STD_MOCK(ice_vf_vsi_release);

	it_cnt = 0;
	ice_for_each_vf(pf, bkt, vf) {
		if (it_cnt == 2) {
			mock().expectOneCall("ice_sriov_clear_reset_trigger")
				.withParameter("vf", vf);
			mock().expectOneCall("ice_init_vf_vsi_res")
				.withParameter("vf", vf)
				.andReturnValue(-EIO);
			break;
		}

		mock().expectOneCall("ice_sriov_clear_reset_trigger")
			.withParameter("vf", vf);
		mock().expectOneCall("ice_init_vf_vsi_res")
			.withParameter("vf", vf)
			.andReturnValue(0);
		mock().expectOneCall("ice_ena_vf_mappings")
			.withParameter("vf", vf);
		it_cnt++;
	}

	ice_for_each_vf(pf, bkt, vf) {
		if (it_cnt == 0)
			break;

		mock().expectOneCall("ice_dis_vf_mappings")
			.withParameter("vf", vf);

		vf->lan_vsi_idx = vf->vf_id;
		mock().expectOneCall("ice_vf_vsi_release")
			.withParameter("vf", vf)
			.andReturnValue(0);
		it_cnt--;
	}

	mutex_lock(&pf->vfs.table_lock);
	err = ice_start_vfs(pf);
	mutex_unlock(&pf->vfs.table_lock);
	CHECK_EQUAL(-EIO, err);
}

TEST(ice_start_vfs, ice_start_vfs_success)
{
	struct ice_vf *vf;
	unsigned int bkt;
	int err;

	USE_STD_MOCK(ice_init_vf_vsi_res);
	USE_STD_MOCK(ice_ena_vf_mappings);
	USE_STD_MOCK(ice_dis_vf_mappings);
	USE_STD_MOCK(ice_sriov_clear_reset_trigger);

	ice_for_each_vf(pf, bkt, vf) {
		mock().expectOneCall("ice_sriov_clear_reset_trigger")
			.withParameter("vf", vf);
		mock().expectOneCall("ice_init_vf_vsi_res")
			.withParameter("vf", vf)
			.andReturnValue(0);
		mock().expectOneCall("ice_ena_vf_mappings")
			.withParameter("vf", vf);
	}

	mutex_lock(&pf->vfs.table_lock);
	err = ice_start_vfs(pf);
	mutex_unlock(&pf->vfs.table_lock);
	CHECK_EQUAL(0, err);
}

TEST_GROUP_BASE(check_virtchnl_ops, TGN(ice_virtchnl))
{
	struct virtchnl_ether_addr *vc_ether_addr;
	struct ice_rq_event_info *rq_event;
	struct virtchnl_promisc_info *msg;
	struct ice_vsi_vlan_ops vlan_ops;
	struct ice_vsi_ctx *vf_vsi_ctx;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *pf_vsi;
	struct ice_vsi *vf_vsi;
	struct ice_vf *vf;
	u8 *vfres;

	void setup(void)
	{
		TGN(ice_virtchnl)::setup();

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		pf->num_alloc_vsi = 128;
		pf->vsi = (struct ice_vsi**)calloc(128, sizeof(struct ice_vsi *) * pf->num_alloc_vsi);
		rq_event = (struct ice_rq_event_info *)calloc(1, sizeof(struct ice_rq_event_info));
		vfres = (u8 *)calloc(1, sizeof(struct virtchnl_vf_res_request));
		rq_event->msg_buf = vfres;
		hw->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));

		vf = test_add_one_vf(0);

		pf_vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf_vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		pf_vsi->idx = 0;
		pf_vsi->vsi_num = 0;
		np->vsi = pf_vsi;
		np->vsi->back = pf;
		pf_vsi->netdev = netdev;

		vf_vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vf_vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		vf_vsi->type = ICE_VSI_VF;
		vf_vsi->vsi_num = 10;
		vf_vsi->idx = 1;
		vf_vsi->back = pf;
		vf_vsi->vf =vf;
		vlan_ops.ena_rx_filtering = &mock_ena_rx_vlan_filtering;
		vlan_ops.dis_rx_filtering = &mock_dis_rx_vlan_filtering;
		vf->lan_vsi_idx = 1;
		vf->lan_vsi_num = 10;

		vf_vsi_ctx = (struct ice_vsi_ctx *)calloc(1, sizeof(struct ice_vsi_ctx));

		pf->vsi[0] = pf_vsi;
		pf->vsi[1] = vf_vsi;

		pf->vsi[0]->port_info->lport = 0;
		pf->vsi[1]->port_info->lport = 1;

		clear_bit(ICE_VF_STATE_INIT, vf->vf_states);

		vc_ether_addr = (struct virtchnl_ether_addr *)
			calloc(1, sizeof(struct virtchnl_ether_addr));
		msg = (struct virtchnl_promisc_info*) calloc(1, sizeof(struct virtchnl_promisc_info));
	}
	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(pf_vsi->port_info);
		free(vf_vsi->port_info);
		free(pf->vsi);
		free(pf_vsi);
		free(vf_vsi);
		free(hw->port_info);
		free(rq_event);
		free(vfres);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
		free(vc_ether_addr);
		free(msg);
		free(vf_vsi_ctx);

		TGN(ice_virtchnl)::teardown();
	}

};

#ifdef ESWITCH_SUPPORT
TEST(check_virtchnl_ops, get_vlan_caps_in_switchdev_mode)
{
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(true);

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, 0);
}
#endif /* ESWITCH_SUPPORT */

#ifdef VF_QINQ_SUPPORT
TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_v2)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN_V2);

	CHECK_EQUAL(res, VIRTCHNL_VF_OFFLOAD_VLAN_V2);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_v2_no_dvm_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	mock().expectNCalls(3, "ice_is_dvm_ena")
		.andReturnValue(false);
	vf->port_vlan_info.vid = 1;

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, 0);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_v2_dvm_no_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	mock().expectNCalls(3, "ice_is_dvm_ena")
		.andReturnValue(true);
	mock().expectOneCall("ice_vf_vsi_cfg_dvm_legacy_vlan_mode")
		.withParameter("vsi", vf_vsi);

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, 0);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_v2_no_dvm_no_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	mock().expectNCalls(2, "ice_is_dvm_ena")
		.andReturnValue(false);
	mock().expectOneCall("ice_vf_vsi_cfg_svm_legacy_vlan_mode")
		.withParameter("vsi", vf_vsi);

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, VIRTCHNL_VF_OFFLOAD_VLAN);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_v2_dvm_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	mock().expectNCalls(1, "ice_is_dvm_ena")
		.andReturnValue(true);
	vf->port_vlan_info.vid = 1;

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, VIRTCHNL_VF_OFFLOAD_VLAN);
}
#else
TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_no_vlan_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	vf->port_vlan_info.vid = 1;

	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, 0);

	CHECK_EQUAL(res, 0);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_no_vlan_no_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */


	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, 0);

	CHECK_EQUAL(res, 0);
}

TEST(check_virtchnl_ops, get_vlan_caps_no_switchdev_vlan_port_vlan)
{
#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);
#endif /* ESWITCH_SUPPORT */
	u32 res = ice_vc_get_vlan_caps(hw, vf, vf_vsi, VIRTCHNL_VF_OFFLOAD_VLAN);

	CHECK_EQUAL(res, VIRTCHNL_VF_OFFLOAD_VLAN);
}
#endif /* VF_QINQ_SUPPORT */

TEST(check_virtchnl_ops, request_queue_msg)
{
	int aq_ret;
	u8 *msg;

	msg = rq_event->msg_buf;
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	aq_ret = ice_vc_request_qs_msg(vf, msg);
	CHECK_EQUAL(aq_ret, ICE_SUCCESS);
}

TEST(check_virtchnl_ops, set_vf_port_vlan_10_qos_3_success)
{
	u16 proto = ETH_P_8021Q;
	u16 vlan_id = 13;
	u8 qos = 3;
	int actual;

	USE_STD_MOCK(ice_check_vf_ready_for_cfg);
	USE_STD_MOCK(ice_reset_vf);

	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.withParameter("vf", test_get_vf(0))
		.andReturnValue(0);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_NOTIFY);

	vf->port_vlan_info = {};
	actual = ice_set_vf_port_vlan(netdev, 0, vlan_id, qos, htons(proto));
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(vlan_id, ice_vf_get_port_vlan_id(vf));
	CHECK_EQUAL(qos, ice_vf_get_port_vlan_prio(vf));
	CHECK_EQUAL(proto, ice_vf_get_port_vlan_tpid(vf));
}

TEST(check_virtchnl_ops, set_vf_port_vlan_clear_port_vlan)
{
	u16 proto = ETH_P_8021Q;
	u16 vlan_id = 13;
	u8 qos = 3;
	int actual;

	USE_STD_MOCK(ice_check_vf_ready_for_cfg);
	USE_STD_MOCK(ice_reset_vf);

	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.withParameter("vf", test_get_vf(0))
		.andReturnValue(0);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_NOTIFY);

	vf->port_vlan_info = ICE_VLAN(proto, vlan_id, qos, ICE_FWD_TO_VSI);
	actual = ice_set_vf_port_vlan(netdev, 0, 0, 0, htons(ETH_P_8021Q));
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(0, ice_vf_get_port_vlan_id(vf));
	CHECK_EQUAL(0, ice_vf_get_port_vlan_prio(vf));
}

TEST(check_virtchnl_ops, set_vf_port_vlan_failed_with_invalid_vlan_id_4096)
{
	u16 vlan_id = 4096;
	int actual;

	actual = ice_set_vf_port_vlan(netdev, 0, vlan_id, 0, htons(ETH_P_8021Q));
	CHECK_EQUAL(-EINVAL, actual);
}

TEST(check_virtchnl_ops, set_vf_port_failed_invalid_qos_8)
{
	u16 vlan_id = 0;
	u8 qos = 8;
	int actual;

	actual = ice_set_vf_port_vlan(netdev, 0, vlan_id, qos, htons(ETH_P_8021Q));
	CHECK_EQUAL(-EINVAL, actual);
}

TEST(check_virtchnl_ops, set_vf_port_failed_invalid_vlan_proto_ETH_P_8021AD)
{
	u16 vlan_id = 13;
	u8 qos = 3;
	int actual;

	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);

	actual = ice_set_vf_port_vlan(netdev, 0, vlan_id, qos, htons(ETH_P_8021AD));
	CHECK_EQUAL(-EPROTONOSUPPORT, actual);
}

TEST(check_virtchnl_ops, vc_notify_reset)
{
        ice_vc_notify_reset(pf);
}

TEST(check_virtchnl_ops, set_vf_spoofchk_invalid_vf_id)
{
	/* Enable value doesn't affect this test */
	bool enable = false;
	int vf_id = 1;
	int result;

	result = ice_set_vf_spoofchk(netdev, vf_id, enable);
	CHECK_EQUAL(-EINVAL, result);
}

TEST(check_virtchnl_ops, set_vf_spoofchk_vf_in_reset)
{
	/* Enable values doesn't affect this test */
	bool enable = false;
	int vf_id = 0;
	int result;

	clear_bit(ICE_VF_STATE_INIT, vf[vf_id].vf_states);

	result = ice_set_vf_spoofchk(netdev, vf_id, enable);
	CHECK_EQUAL(-EBUSY, result);
}

TEST(check_virtchnl_ops, vf_spoofchk_and_enable_are_equal)
{
	int vf_id = 0;
	int result;

	set_bit(ICE_VF_STATE_INIT, vf[vf_id].vf_states);

	vf[vf_id].spoofchk = false;
	result = ice_set_vf_spoofchk(netdev, vf_id, false);
	CHECK_EQUAL(0, result);

	vf[vf_id].spoofchk = true;
	result = ice_set_vf_spoofchk(netdev, vf_id, true);
	CHECK_EQUAL(0, result);
}

TEST(check_virtchnl_ops, set_vf_spoofchk_expect_ena_spoofchk_failed)
{
	bool enable = true;
	int vf_id = 0;
	int result;

	USE_STD_MOCK(ice_vsi_ena_spoofchk);
	set_bit(ICE_VF_STATE_INIT, vf[vf_id].vf_states);

	mock().expectOneCall("ice_vsi_ena_spoofchk")
		.ignoreOtherParameters()
		.andReturnValue(-1);
	/* Needs to be different from enable to get past initial conditions */
	vf[vf_id].spoofchk = false;
	result = ice_set_vf_spoofchk(netdev, vf_id, enable);
	CHECK_EQUAL(-1, result);
}

TEST(check_virtchnl_ops, set_vf_spoofchk_expect_ena_spoofchk_success)
{
	bool enable = true;
	int vf_id = 0;
	int result;

	USE_STD_MOCK(ice_vsi_ena_spoofchk);
	set_bit(ICE_VF_STATE_INIT, vf[vf_id].vf_states);

	mock().expectOneCall("ice_vsi_ena_spoofchk")
		.ignoreOtherParameters()
		.andReturnValue(0);

	/* Needs to be different from enable to get past initial conditions */
	vf[vf_id].spoofchk = false;
	result = ice_set_vf_spoofchk(netdev, vf_id, enable);
	CHECK_EQUAL(0, result);
}

TEST(check_virtchnl_ops, set_promisc_untrusted_vf)
{
	int vf_id = 0;
	int result;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	msg->vsi_id = vf_vsi->vsi_num;
	vf[vf_id].vf_caps = 0;
	vf_vsi->port_info->lport = 0;
	result = ice_vc_cfg_promiscuous_mode_msg(vf, (u8 *)msg);
	CHECK_EQUAL(0, result);
}

TEST(check_virtchnl_ops, set_multicast_and_clear_unicast_no_vlans_configured_trusted_vf)
{
	int result;

	USE_STD_MOCK(ice_vf_set_vsi_promisc);
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_vsi_has_non_zero_vlans")
		.andReturnValue(false);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_VF_UCAST_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_vf_set_vsi_promisc")
		.withParameter("promisc_m", ICE_MCAST_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_dis_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	set_bit(ICE_VIRTCHNL_VF_CAP_PRIVILEGE, &vf->vf_caps);
	msg->flags = FLAG_VF_MULTICAST_PROMISC;
	msg->vsi_id = vf_vsi->vsi_num;

	result = ice_vc_cfg_promiscuous_mode_msg(vf,(u8 *)msg);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(1, test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
}

TEST(check_virtchnl_ops, set_unicast_promisc_and_clear_multicast_promisc_trusted_vf_with_port_vlan)
{
	int result;

	USE_STD_MOCK(ice_vf_set_vsi_promisc);
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_vf_set_vsi_promisc")
		.withParameter("promisc_m", ICE_VF_UCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_MCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_dis_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	set_bit(ICE_VIRTCHNL_VF_CAP_PRIVILEGE, &vf->vf_caps);
	msg->flags = FLAG_VF_UNICAST_PROMISC;
	msg->vsi_id = vf_vsi->vsi_num;

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, 10, 0, ICE_FWD_TO_VSI);
	result = ice_vc_cfg_promiscuous_mode_msg(vf,(u8 *)msg);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
	CHECK_EQUAL(1, test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
}

TEST(check_virtchnl_ops, set_multicast_clear_unicast_promisc_trusted_vf_in_port_vlan)
{
	int result;

	USE_STD_MOCK(ice_vf_set_vsi_promisc);
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_vf_set_vsi_promisc")
		.withParameter("promisc_m", ICE_MCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_VF_UCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_dis_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, 10, 0, ICE_FWD_TO_VSI);
	set_bit(ICE_VIRTCHNL_VF_CAP_PRIVILEGE, &vf->vf_caps);
	msg->flags = FLAG_VF_MULTICAST_PROMISC;
	msg->vsi_id = vf_vsi->vsi_num;

	result = ice_vc_cfg_promiscuous_mode_msg(vf,(u8 *)msg);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(1, test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
}

TEST(check_virtchnl_ops, clear_multicast_and_unicast_promisc_trusted_vf_with_guest_vlans)
{
	int result;

	USE_STD_MOCK(ice_vf_set_vsi_promisc);
	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_vsi_has_non_zero_vlans")
		.andReturnValue(true);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_VF_UCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_MCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	set_bit(ICE_VIRTCHNL_VF_CAP_PRIVILEGE, &vf->vf_caps);
	msg->flags = ~(FLAG_VF_UNICAST_PROMISC | FLAG_VF_MULTICAST_PROMISC);
	msg->vsi_id = vf_vsi->vsi_num;

	result = ice_vc_cfg_promiscuous_mode_msg(vf,(u8 *)msg);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
}

TEST(check_virtchnl_ops, clear_unicast_and_multicast_promisc_trusted_vf_in_port_vlan)
{
	int result;

	USE_STD_MOCK(ice_vf_clear_vsi_promisc);

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	set_bit(ICE_FLAG_VF_TRUE_PROMISC_ENA, pf->flags);

	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_VF_UCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_vf_clear_vsi_promisc")
		.withParameter("promisc_m", ICE_MCAST_VLAN_PROMISC_BITS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, 13, 0, ICE_FWD_TO_VSI);
	set_bit(ICE_VIRTCHNL_VF_CAP_PRIVILEGE, &vf->vf_caps);
	msg->flags &= ~(FLAG_VF_UNICAST_PROMISC | FLAG_VF_MULTICAST_PROMISC);
	msg->vsi_id = vf_vsi->vsi_num;

	result = ice_vc_cfg_promiscuous_mode_msg(vf,(u8 *)msg);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_MC_PROMISC, vf->vf_states));
	CHECK_EQUAL(0, test_bit(ICE_VF_STATE_UC_PROMISC, vf->vf_states));
}

#ifdef HAVE_NDO_SET_VF_LINK_STATE
TEST(check_virtchnl_ops, set_vf_link_state_no_link)
{
	int link_state = -1;
	int ret;

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	ret = ice_set_vf_link_state(netdev, vf->vf_id, link_state);
	CHECK_EQUAL(-EINVAL, ret);
}

TEST(check_virtchnl_ops, set_vf_link_state_successful)
{
	int link_state = 1;
	int ret = 0;

	/* at least set one of the link states successfully */
	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	ice_set_vf_link_state(netdev, vf->vf_id, link_state);
	CHECK_EQUAL(0, ret);
}
#endif /* HAVE_NDO_SET_VF_LINK_STATE */

TEST(check_virtchnl_ops, ice_set_pfe_link_up_virtchnl_vf_cap_adv_link_speed_not_supported)
{
	struct virtchnl_pf_event pfe = { };
	bool adv_link_support;

	vf->driver_caps &= ~VIRTCHNL_VF_CAP_ADV_LINK_SPEED;
	adv_link_support = vf->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", adv_link_support)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_100GB)
		.andReturnValue(VIRTCHNL_LINK_SPEED_40GB);

	ice_set_pfe_link(vf, &pfe, ICE_AQ_LINK_SPEED_100GB, true);

	CHECK_EQUAL(true, pfe.event_data.link_event.link_status);
	CHECK_EQUAL(VIRTCHNL_LINK_SPEED_40GB, pfe.event_data.link_event.link_speed);
}

TEST(check_virtchnl_ops, ice_set_pfe_link_down_virtchnl_vf_cap_adv_link_speed_not_supported)
{
	struct virtchnl_pf_event pfe = { };
	bool adv_link_support;

	vf->driver_caps &= ~VIRTCHNL_VF_CAP_ADV_LINK_SPEED;
	adv_link_support = vf->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", adv_link_support)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_100GB)
		.andReturnValue(VIRTCHNL_LINK_SPEED_40GB);

	ice_set_pfe_link(vf, &pfe, ICE_AQ_LINK_SPEED_100GB, false);

	CHECK_EQUAL(false, pfe.event_data.link_event.link_status);
	CHECK_EQUAL(VIRTCHNL_LINK_SPEED_40GB, pfe.event_data.link_event.link_speed);
}

TEST(check_virtchnl_ops, ice_set_pfe_link_up_virtchnl_vf_cap_adv_link_speed_supported)
{
	struct virtchnl_pf_event pfe = { };
	bool adv_link_support;

	vf->driver_caps |= VIRTCHNL_VF_CAP_ADV_LINK_SPEED;
	adv_link_support = vf->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", adv_link_support)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_100GB)
		.andReturnValue(SPEED_100000);

	ice_set_pfe_link(vf, &pfe, ICE_AQ_LINK_SPEED_100GB, true);

	CHECK_EQUAL(true, pfe.event_data.link_event_adv.link_status);
	CHECK_EQUAL(SPEED_100000, pfe.event_data.link_event_adv.link_speed);
}

TEST(check_virtchnl_ops, ice_set_pfe_link_down_virtchnl_vf_cap_adv_link_speed_supported)
{
	struct virtchnl_pf_event pfe = { };
	bool adv_link_support;

	vf->driver_caps |= VIRTCHNL_VF_CAP_ADV_LINK_SPEED;
	adv_link_support = vf->driver_caps & VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", adv_link_support)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_100GB)
		.andReturnValue(SPEED_100000);

	ice_set_pfe_link(vf, &pfe, ICE_AQ_LINK_SPEED_100GB, false);

	CHECK_EQUAL(false, pfe.event_data.link_event_adv.link_status);
	CHECK_EQUAL(SPEED_100000, pfe.event_data.link_event_adv.link_speed);
}

TEST(check_virtchnl_ops, ice_vc_notify_vf_link_state_vf_link_up_100G)
{
	struct virtchnl_pf_event expected_pfe = { };

	hw->port_info->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_100GB;

	expected_pfe.event = VIRTCHNL_EVENT_LINK_CHANGE;
	expected_pfe.severity = PF_EVENT_SEVERITY_INFO;
	expected_pfe.event_data.link_event.link_status = true;
	expected_pfe.event_data.link_event.link_speed = VIRTCHNL_LINK_SPEED_40GB;

	USE_STD_MOCK(ice_is_vf_link_up);

	mock().expectOneCall("ice_is_vf_link_up")
		.withParameter("vf", vf)
		.andReturnValue(true);

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", false)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_100GB)
		.andReturnValue(VIRTCHNL_LINK_SPEED_40GB);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.withParameter("msglen", sizeof(expected_pfe))
		.withParameter("msg", (u8 *)&expected_pfe, sizeof(expected_pfe))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	ice_vc_notify_vf_link_state(vf);
}

TEST(check_virtchnl_ops, ice_vc_notify_vf_link_state_vf_link_up_40G)
{
	struct ice_link_status *ls = &pf->hw.port_info->phy.link_info;
	struct virtchnl_pf_event expected_pfe = { };

	ls->link_speed = ICE_AQ_LINK_SPEED_40GB;

	USE_STD_MOCK(ice_is_vf_link_up);

	expected_pfe.event = VIRTCHNL_EVENT_LINK_CHANGE;
	expected_pfe.severity = PF_EVENT_SEVERITY_INFO;
	expected_pfe.event_data.link_event.link_status = true;
	expected_pfe.event_data.link_event.link_speed = VIRTCHNL_LINK_SPEED_40GB;

	mock().expectOneCall("ice_is_vf_link_up")
		.withParameter("vf", vf)
		.andReturnValue(true);

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", false)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_40GB)
		.andReturnValue(VIRTCHNL_LINK_SPEED_40GB);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.withParameter("msglen", sizeof(expected_pfe))
		.withParameter("msg", (u8 *)&expected_pfe, sizeof(expected_pfe))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	ice_vc_notify_vf_link_state(vf);
}

TEST(check_virtchnl_ops, ice_vc_notify_vf_link_state_vf_link_down)
{
	struct ice_link_status *ls = &pf->hw.port_info->phy.link_info;

	ls->link_speed = ICE_AQ_LINK_SPEED_UNKNOWN;

	USE_STD_MOCK(ice_is_vf_link_up);

	mock().expectOneCall("ice_is_vf_link_up")
		.withParameter("vf", vf)
		.andReturnValue(false);

	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
		.withParameter("adv_link_support", false)
		.withParameter("link_speed", ICE_AQ_LINK_SPEED_UNKNOWN)
		.andReturnValue(VIRTCHNL_LINK_SPEED_UNKNOWN);

	mock().expectOneCall("ice_aq_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	ice_vc_notify_vf_link_state(vf);
}

TEST(check_virtchnl_ops, set_vf_bw_no_change_to_min_or_max)
{
	int ret;

	USE_STD_MOCK(ice_min_tx_rate_oversubscribed);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	vf->min_tx_rate = 1000;
	vf->max_tx_rate = 2000;

	mock().expectOneCall("ice_min_tx_rate_oversubscribed")
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", vf->min_tx_rate)
		.andReturnValue(false);

	ret = ice_set_vf_bw(netdev, vf->vf_id, vf->min_tx_rate, vf->max_tx_rate);

	CHECK_EQUAL(0, ret);
}

void expect_call_to_set_max_bw(struct ice_vf *vf, int max_tx_rate, int result)
{

	struct ice_vsi *vsi = vf->pf->vsi[vf->lan_vsi_idx];

	mock().expectOneCall("ice_set_max_bw_limit")
		.withParameter("vsi", vsi)
		.withParameter("max_tx_rate", max_tx_rate * 1000)
		.andReturnValue(result);
}

void expect_call_to_set_min_bw(struct ice_vf *vf, int min_tx_rate, int result)
{

	struct ice_vsi *vsi = vf->pf->vsi[vf->lan_vsi_idx];

	mock().expectOneCall("ice_set_min_bw_limit")
		.withParameter("vsi", vsi)
		.withParameter("min_tx_rate", min_tx_rate * 1000)
		.andReturnValue(result);
}

TEST(check_virtchnl_ops, set_vf_bw_invalid_max_rate)
{
	u64 max_tx_rate = 200000, min_tx_rate = 0;
	int ret, expected_result = -EINVAL;

	USE_STD_MOCK(ice_min_tx_rate_oversubscribed);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	expect_call_to_set_max_bw(vf, max_tx_rate, expected_result);
	mock().expectOneCall("ice_min_tx_rate_oversubscribed")
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", min_tx_rate)
		.andReturnValue(false);

	ret = ice_set_vf_bw(netdev, vf->vf_id, min_tx_rate, max_tx_rate);

	CHECK_EQUAL(expected_result, ret);
}


TEST(check_virtchnl_ops, set_vf_min_bw_to_5000mbps_returns_success)
{
	u64 min_tx_rate = 5000, max_tx_rate = 0;
	int ret, expected_result = 0;

	USE_STD_MOCK(ice_min_tx_rate_oversubscribed);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	expect_call_to_set_min_bw(vf, min_tx_rate, expected_result);
	mock().expectOneCall("ice_min_tx_rate_oversubscribed")
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", min_tx_rate)
		.andReturnValue(false);

	ret = ice_set_vf_bw(netdev, vf->vf_id, min_tx_rate, max_tx_rate);

	CHECK_EQUAL(min_tx_rate, vf->min_tx_rate);
	CHECK_EQUAL(expected_result, ret);
}

TEST(check_virtchnl_ops, set_vf_max_bw_to_10000mbps_returns_success)
{
	u64 min_tx_rate = 0, max_tx_rate = 10000;
	int ret, expected_result = 0;

	USE_STD_MOCK(ice_min_tx_rate_oversubscribed);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	expect_call_to_set_max_bw(vf, max_tx_rate, expected_result);
	mock().expectOneCall("ice_min_tx_rate_oversubscribed")
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", min_tx_rate)
		.andReturnValue(false);

	ret = ice_set_vf_bw(netdev, vf->vf_id, min_tx_rate, max_tx_rate);

	CHECK_EQUAL(max_tx_rate, vf->max_tx_rate);
	CHECK_EQUAL(expected_result, ret);
}

TEST(check_virtchnl_ops, set_vf_max_bw_to_50000mbps_min_bw_to_25000mbps_returns_success)
{
	u64 min_tx_rate = 25000, max_tx_rate = 50000;
	int ret, expected_result = 0;

	USE_STD_MOCK(ice_min_tx_rate_oversubscribed);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	expect_call_to_set_min_bw(vf, min_tx_rate, expected_result);
	expect_call_to_set_max_bw(vf, max_tx_rate, expected_result);
	mock().expectOneCall("ice_min_tx_rate_oversubscribed")
		.withParameter("vf", vf)
		.withParameter("min_tx_rate", min_tx_rate)
		.andReturnValue(false);

	ret = ice_set_vf_bw(netdev, vf->vf_id, min_tx_rate, max_tx_rate);

	CHECK_EQUAL(min_tx_rate, vf->min_tx_rate);
	CHECK_EQUAL(max_tx_rate, vf->max_tx_rate);
	CHECK_EQUAL(expected_result, ret);
}

TEST(check_virtchnl_ops, set_vf_min_bw_to_greater_than_max_bw_fails)
{
	u64 min_tx_rate = 5000, max_tx_rate = 1000;
	int ret, expected_result = -EINVAL;

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	ret = ice_set_vf_bw(netdev, vf->vf_id, min_tx_rate, max_tx_rate);

	CHECK_EQUAL(expected_result, ret);
}

TEST(check_virtchnl_ops, min_tx_rate_oversubscribed_by_1Mbps_past_link_speed)
{
	int min_tx_rate = 1;

	USE_STD_MOCK(ice_calc_all_vfs_min_tx_rate);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_calc_all_vfs_min_tx_rate")
		.withParameter("pf", pf)
		.andReturnValue(100000);
	mock().expectOneCall("ice_get_link_speed_mbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(SPEED_100000);

	CHECK_TRUE(ice_min_tx_rate_oversubscribed(vf, min_tx_rate));
}

TEST(check_virtchnl_ops, min_tx_rate_not_oversubscribed_past_link_speed)
{
	int min_tx_rate = 4000;

	USE_STD_MOCK(ice_calc_all_vfs_min_tx_rate);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_calc_all_vfs_min_tx_rate")
		.withParameter("pf", pf)
		.andReturnValue(21000);
	mock().expectOneCall("ice_get_link_speed_mbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(SPEED_25000);

	CHECK_FALSE(ice_min_tx_rate_oversubscribed(vf, min_tx_rate));
}

TEST(check_virtchnl_ops, min_tx_rate_0_when_all_vfs_min_tx_rate_at_10Gbps_on_10Gbps_link_speed)
{
	int min_tx_rate = 0;

	USE_STD_MOCK(ice_calc_all_vfs_min_tx_rate);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_calc_all_vfs_min_tx_rate")
		.withParameter("pf", pf)
		.andReturnValue(10000);
	mock().expectOneCall("ice_get_link_speed_mbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(SPEED_10000);

	CHECK_FALSE(ice_min_tx_rate_oversubscribed(vf, min_tx_rate));
}

TEST(check_virtchnl_ops, new_min_tx_rate_smaller_than_previous_doesnt_cause_oversubscription)
{
	int min_tx_rate = 9999;

	/* VF's previous min_tx_rate */
	vf->min_tx_rate = 10000;

	USE_STD_MOCK(ice_calc_all_vfs_min_tx_rate);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_calc_all_vfs_min_tx_rate")
		.withParameter("pf", pf)
		.andReturnValue(100000);
	mock().expectOneCall("ice_get_link_speed_mbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(SPEED_100000);

	CHECK_FALSE(ice_min_tx_rate_oversubscribed(vf, min_tx_rate));
}

TEST(check_virtchnl_ops, new_min_tx_rate_larger_than_previous_causes_oversubscription)
{
	int min_tx_rate = 10001;

	/* VF's previous min_tx_rate */
	vf->min_tx_rate = 10000;

	USE_STD_MOCK(ice_calc_all_vfs_min_tx_rate);

	set_bit(ICE_VF_STATE_INIT, vf->vf_states);

	mock().expectOneCall("ice_calc_all_vfs_min_tx_rate")
		.withParameter("pf", pf)
		.andReturnValue(100000);
	mock().expectOneCall("ice_get_link_speed_mbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(SPEED_100000);

	CHECK_TRUE(ice_min_tx_rate_oversubscribed(vf, min_tx_rate));
}

TEST_GROUP_BASE(ice_calc_all_vfs_min_tx_rate, TGN(ice_virtchnl))
{
	static const int num_vfs = 10;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		test_add_vfs(num_vfs);
	}

	void teardown()
	{
		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_calc_all_vfs_min_tx_rate, all_vfs_rate_equals_100Gbps)
{
	struct ice_vf *vf;
	unsigned int bkt;

	ice_for_each_vf(pf, bkt, vf)
		vf->min_tx_rate = 10000;

	CHECK_EQUAL(100000, ice_calc_all_vfs_min_tx_rate(pf));
}

TEST(ice_calc_all_vfs_min_tx_rate, all_vfs_rate_equals_1Gbps)
{
	struct ice_vf *vf;
	unsigned int bkt;

	ice_for_each_vf(pf, bkt, vf)
		vf->min_tx_rate = 100;

	CHECK_EQUAL(1000, ice_calc_all_vfs_min_tx_rate(pf));
}

#ifdef ADQ_SUPPORT
TEST(check_virtchnl_ops, ice_vc_add_qch_msg_spoofchk_on_fail_adq)
{
	struct virtchnl_tc_info *msg = (struct virtchnl_tc_info *)
		calloc(1, sizeof(struct virtchnl_tc_info));
	int ret;

	vf->spoofchk = 1;
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	/* Vf active */
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	/* No VF active */
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	ret = ice_vc_add_qch_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);

	CHECK_EQUAL(1, vf->spoofchk);
	free(msg);
}

TEST(check_virtchnl_ops, ice_vc_add_qch_msg_adq_success)
{
	struct virtchnl_tc_info *msg = (struct virtchnl_tc_info *)
		       calloc(4, sizeof(struct virtchnl_tc_info));
	unsigned int i;
	int ret;

	/* maximum number of TC allowed for VF is 4 so max it out */
	msg->num_tc = 4;

	/* configuring ADQ on VF needs spoofcheck to be turned off */
	vf->spoofchk = 0;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	USE_STD_MOCK(ice_reset_vf);

	/* VF active */
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	vf->driver_caps |= VIRTCHNL_VF_OFFLOAD_ADQ;

	for (i = 0; i < msg->num_tc; i++) {
		msg->list[i].count = 4;
		msg->list[i].max_tx_rate = 5000;
	}

	vf->driver_caps |= VIRTCHNL_VF_CAP_ADV_LINK_SPEED;

#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_is_dcf_enabled")
			.withParameter("pf", pf)
			.andReturnValue(false);
#endif
	mock().expectOneCall("ice_conv_link_speed_to_virtchnl")
			.ignoreOtherParameters()
			.andReturnValue(25000);
	mock().expectOneCall("ice_get_avail_txq_count")
			.ignoreOtherParameters()
			.andReturnValue(100);
	mock().expectOneCall("ice_reset_vf")
			.ignoreOtherParameters();
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	ret = ice_vc_add_qch_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);

	free(msg);
}

TEST(check_virtchnl_ops, ice_vc_del_qch_msg_adq_fail)
{
	struct virtchnl_tc_info *msg = (struct virtchnl_tc_info *)
		calloc(1, sizeof(struct virtchnl_tc_info));
	int ret;

	/* VF active */
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	/* disable ADQ */
	vf->adq_enabled = 0;

	/* clear TCs */
	vf->num_tc = 0;

#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_is_dcf_enabled")
		.withParameter("pf", pf)
		.andReturnValue(false);
#endif
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	ret = ice_vc_del_qch_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
	free(msg);
}

TEST(check_virtchnl_ops, ice_vc_del_qch_msg_adq_success)
{
	struct virtchnl_tc_info *msg = (struct virtchnl_tc_info *)
		calloc(1, sizeof(struct virtchnl_tc_info));
	int ret;

	/* VF active */
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	USE_STD_MOCK(ice_reset_vf);

	/* set ADQ enable flag */
	vf->adq_enabled = 1;

	/* to make sure, it goes thru correct code path and tries
	 * to do something meaningful
	 */
	vf->num_tc = 2;

#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_is_dcf_enabled")
			.withParameter("pf", pf)
			.andReturnValue(false);
#endif
	mock().expectOneCall("ice_reset_vf")
			.ignoreOtherParameters();
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	ret = ice_vc_del_qch_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	free(msg);
}
#endif /* ADQ_SUPPORT */

TEST(check_virtchnl_ops, ice_vc_cfg_irq_map_msg_validation)
{
	struct virtchnl_irq_map_info *msg = (struct virtchnl_irq_map_info *)
		calloc(1, sizeof(*msg));
	const int num_rings = 16;
	int ret;

	vf_vsi->num_q_vectors = 2;
	pf->vfs.num_msix_per = 3;
	vf_vsi->q_vectors = (struct ice_q_vector **)
		calloc(vf_vsi->num_q_vectors, sizeof(struct ice_q_vector *));
	for (int i = 0; i < vf_vsi->num_q_vectors; i++)
		vf_vsi->q_vectors[i] = (struct ice_q_vector *)
			calloc(1, sizeof(struct ice_q_vector));

	vf_vsi->rx_rings = (struct ice_ring **)
		calloc(num_rings, sizeof(struct ice_ring *));
	vf_vsi->alloc_rxq = num_rings;
	vf_vsi->tx_rings = (struct ice_ring **)
		calloc(num_rings, sizeof(struct ice_ring *));
	vf_vsi->alloc_txq = num_rings;
	for (int i = 0; i < num_rings; i++) {
		vf_vsi->rx_rings[i] = (struct ice_ring *)
			calloc(1, sizeof(struct ice_ring));
		vf_vsi->tx_rings[i] = (struct ice_ring *)
			calloc(1, sizeof(struct ice_ring));
	}
	vf->lan_vsi_idx = 1;
	vf->vf_id = 1;
	pf->vsi[vf->lan_vsi_idx]->vf = vf;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	/* No vf active */
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);

	/* Vf active, num_vectors == 0 */
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);

	/* test OICR vector_id = 0 and no queues mapped */
	msg->num_vectors = 1;
	msg->vecmap[0].vsi_id = 10;
	msg->vecmap[0].vector_id = 0;
	msg->vecmap[0].rxq_map = 0;
	msg->vecmap[0].txq_map = 0;

	pf->hw.func_caps.common_cap.num_msix_vectors = 2;
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(0, ret);

	/* test vector_id = 1 and no queues mapped */
	msg->num_vectors = 1;
	msg->vecmap[0].vsi_id = 10;
	msg->vecmap[0].vector_id = 1;
	msg->vecmap[0].rxq_map = 0;
	msg->vecmap[0].txq_map = 0;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(0, ret);

	/* num_vectors > pf->vfs.num_msix_per */
	msg->num_vectors = pf->vfs.num_msix_per + 1;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);

	/* test amount of rings in q_vector after second call of function */
	msg->num_vectors = 1;
	const u16 used_rings = 4;
	msg->vecmap[0].vector_id = 1;
	const u16 bitmap_rings = (1 << used_rings) - 1;
	msg->vecmap[0].rxq_map = bitmap_rings;
	msg->vecmap[0].txq_map = bitmap_rings;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectNCalls(used_rings, "ice_cfg_txq_interrupt")
		.ignoreOtherParameters();
	mock().expectNCalls(used_rings, "ice_cfg_rxq_interrupt")
		.ignoreOtherParameters();
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(0, ret);

	CHECK_EQUAL(used_rings, vf_vsi->q_vectors[0]->num_ring_rx);
	CHECK_EQUAL(used_rings, vf_vsi->q_vectors[0]->num_ring_tx);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectNCalls(used_rings, "ice_cfg_txq_interrupt")
		.ignoreOtherParameters();
	mock().expectNCalls(used_rings, "ice_cfg_rxq_interrupt")
		.ignoreOtherParameters();
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(0, ret);
	CHECK_EQUAL(used_rings, vf_vsi->q_vectors[0]->num_ring_rx);
	CHECK_EQUAL(used_rings, vf_vsi->q_vectors[0]->num_ring_tx);

	/* try to set more rings then is available */
	vf_vsi->alloc_txq = 2;
	vf_vsi->alloc_rxq = 2;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);
	mock().expectNCalls(vf_vsi->alloc_rxq, "ice_cfg_rxq_interrupt")
		.ignoreOtherParameters();
	ret = ice_vc_cfg_irq_map_msg(vf, (u8 *)msg);
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);

	for (int i = 0; i < num_rings; i++) {
		free(vf_vsi->rx_rings[i]);
		free(vf_vsi->tx_rings[i]);
	}
	free(vf_vsi->rx_rings);
	free(vf_vsi->tx_rings);
	for (int i = 0; i < vf_vsi->num_q_vectors; i++)
		free(vf_vsi->q_vectors[i]);
	free(vf_vsi->q_vectors);
	free(msg);
}

TEST(check_virtchnl_ops, ice_vc_add_mac_addr_mac_addr_same_as_dev_lan_addr_return_0)
{
	u8 mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vc_ether_addr->addr, mac_addr);
	ether_addr_copy(vf->dev_lan_addr.addr, mac_addr);
	ether_addr_copy(vf->hw_lan_addr.addr, mac_addr);

#ifdef VIRTCHNL_IPSEC
	mock().expectOneCall("ice_is_vf_ipsec_capable")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* VIRTCHNL_IPSEC */

	vf->num_mac = 3;
	CHECK_EQUAL(0, ice_vc_add_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(3, vf->num_mac);
}

TEST(check_virtchnl_ops, ice_vc_add_mac_addr_mac_switch_filter_already_exists)
{
	u8 dev_mac_addr[ETH_ALEN] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55 };
	u8 already_exists_mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vf->dev_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vf->hw_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vc_ether_addr->addr, already_exists_mac_addr);

	vf->num_mac = 3;
	mock().expectOneCall("ice_fltr_add_mac")
		.ignoreOtherParameters()
		.andReturnValue(-EEXIST);
	CHECK_EQUAL(-EEXIST, ice_vc_add_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(3, vf->num_mac);
	CHECK_TRUE(ether_addr_equal(dev_mac_addr, vf->dev_lan_addr.addr));
}

TEST(check_virtchnl_ops, ice_vc_add_mac_addr_mac_switch_filter_already_exists_vc_mac_type_primary)
{
	u8 dev_mac_addr[ETH_ALEN] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55 };
	u8 already_exists_mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vf->dev_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vf->hw_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vc_ether_addr->addr, already_exists_mac_addr);

	vc_ether_addr->type = VIRTCHNL_ETHER_ADDR_PRIMARY;

	vf->num_mac = 3;
	mock().expectOneCall("ice_fltr_add_mac")
		.ignoreOtherParameters()
		.andReturnValue(-EEXIST);
	CHECK_EQUAL(-EEXIST, ice_vc_add_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(3, vf->num_mac);
	CHECK_TRUE(ether_addr_equal(already_exists_mac_addr, vf->dev_lan_addr.addr));
	CHECK_TRUE(ether_addr_equal(already_exists_mac_addr, vf->hw_lan_addr.addr));
}

TEST(check_virtchnl_ops, ice_vc_add_mac_addr_add_mac_switch_filter_fails)
{
	u8 mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vc_ether_addr->addr, mac_addr);

	vf->num_mac = 3;
	mock().expectOneCall("ice_fltr_add_mac")
		.ignoreOtherParameters()
		.andReturnValue(-EIO);
	CHECK_EQUAL(-EIO, ice_vc_add_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(3, vf->num_mac);
}

TEST(check_virtchnl_ops, ice_vc_add_mac_addr_make_sure_dev_and_hw_lan_addr_gets_set_when_zero)
{
	u8 mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vc_ether_addr->addr, mac_addr);

	vf->pf_set_mac = false;
	vf->num_mac = 0;
#ifdef VIRTCHNL_IPSEC
	mock().expectOneCall("ice_is_vf_ipsec_capable")
			     .ignoreOtherParameters()
			     .andReturnValue(false);
#endif /* VIRTCHNL_IPSEC */
	mock().expectOneCall("ice_fltr_add_mac")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	CHECK_EQUAL(0, ice_vc_add_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(1, vf->num_mac);
	CHECK_TRUE(ether_addr_equal(mac_addr, vf->dev_lan_addr.addr));
	CHECK_TRUE(ether_addr_equal(mac_addr, vf->hw_lan_addr.addr));
}

TEST(check_virtchnl_ops, ice_vc_del_mac_addr_mac_switch_filter_does_not_exist)
{
	u8 dev_mac_addr[ETH_ALEN] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55 };
	u8 does_not_exist_mac_addr[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };

	ether_addr_copy(vf->dev_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vf->hw_lan_addr.addr, dev_mac_addr);
	ether_addr_copy(vc_ether_addr->addr, does_not_exist_mac_addr);
	vf->num_mac = 1;
	mock().expectOneCall("ice_fltr_remove_mac")
		.andReturnValue(-ENOENT);
	CHECK_EQUAL(-ENOENT, ice_vc_del_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_EQUAL(1, vf->num_mac);
	CHECK_TRUE(ether_addr_equal(dev_mac_addr, vf->dev_lan_addr.addr));
}

TEST(check_virtchnl_ops, ice_vc_del_mac_addr_legacy_mac_dev_and_hw_lan_addr_replaced_with_last_legacy_set)
{
	USE_STD_MOCK(ice_is_legacy_umac_expired);

	u8 last_added_umac[ETH_ALEN] = { 0x00, 0xAA, 0xBB, 0xFF, 0xEE, 0x00 };
	u8 del_mac_addr[ETH_ALEN] = { 0x00, 0xFF, 0x33, 0x44, 0xCC, 0x00 };

	vf->pf_set_mac = false;
	vf->num_mac = 2;
	ether_addr_copy(vf->legacy_last_added_umac.addr, last_added_umac);
	ether_addr_copy(vc_ether_addr->addr, del_mac_addr);
	ether_addr_copy(vf->dev_lan_addr.addr, del_mac_addr);
	ether_addr_copy(vf->hw_lan_addr.addr, del_mac_addr);

	mock().expectOneCall("ice_fltr_remove_mac")
		.andReturnValue(ICE_SUCCESS);

#ifdef VIRTCHNL_IPSEC
	mock().expectOneCall("ice_is_vf_ipsec_capable")
			     .ignoreOtherParameters()
			     .andReturnValue(false);
#endif /* VIRTCHNL_IPSEC */

	mock().expectOneCall("ice_is_legacy_umac_expired")
		.withParameter("last_added_umac", &vf->legacy_last_added_umac)
		.andReturnValue(false);

	CHECK_EQUAL(0, ice_vc_del_mac_addr(vf, vf_vsi, vc_ether_addr));
	CHECK_TRUE(ether_addr_equal(vf->dev_lan_addr.addr, last_added_umac));
	CHECK_TRUE(ether_addr_equal(vf->hw_lan_addr.addr, last_added_umac));
	CHECK_EQUAL(1, vf->num_mac);
}

#if defined(DCF_SUPPORT) || defined(ADV_AVF_SUPPORT)
TEST_GROUP_BASE(ice_vc_cfg_qos, TGN(check_virtchnl_ops))
{
#ifdef DCF_SUPPORT
	struct virtchnl_dcf_bw_cfg_list *bwcfg_list;
	u16 num_elem = 8;
#endif /* DCF_SUPPORT */
#ifdef ADV_AVF_SUPPORT
	struct virtchnl_queue_tc_mapping *qtc;
	struct virtchnl_queues_bw_cfg *qbw;
	struct virtchnl_quanta_cfg *qquanta;
	u16 num_tc = 8;
	u16 num_queues = 8;
#endif /* ADV_AVF_SUPPORT */

	TEST_SETUP()
	{
		TGN(check_virtchnl_ops)::setup();
#ifdef DCF_SUPPORT
		bwcfg_list = (struct virtchnl_dcf_bw_cfg_list *)calloc(1, sizeof(*bwcfg_list)
			+ sizeof(bwcfg_list->cfg[0]) * (num_elem - 1));
#endif /* DCF_SUPPORT */
#ifdef ADV_AVF_SUPPORT
		qtc = (struct virtchnl_queue_tc_mapping *)calloc(1, sizeof(*qtc) +
			sizeof(qtc->tc[0]) * (num_tc - 1));
		qbw = (struct virtchnl_queues_bw_cfg *)calloc(1, sizeof(*qbw) +
			sizeof(qbw->cfg[0]) * (num_queues - 1));
		qquanta = (struct virtchnl_quanta_cfg *)calloc(1, sizeof(*qquanta));
#endif /* ADV_AVF_SUPPORT */
	}

	TEST_TEARDOWN()
	{
		TGN(check_virtchnl_ops)::teardown();
#ifdef DCF_SUPPORT
		free(bwcfg_list);
#endif /* DCF_SUPPORT */
#ifdef ADV_AVF_SUPPORT
		free(qquanta);
		free(qbw);
		free(qtc);
#endif /* ADV_AVF_SUPPORT */
	}
};
#endif /* DCF_SUPPORT || ADV_AVF_SUPPORT */

#ifdef DCF_SUPPORT
TEST(ice_vc_cfg_qos, ice_vc_dcf_config_vf_tc_success)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_VF_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 100000;
	bwcfg_list->cfg[0].shaper.peak = 10000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	vf_vsi->tc_cfg.ena_tc = 1;

	USE_STD_MOCK(ice_check_vf_ready_for_cfg);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.withParameter("vf", vf)
		.andReturnValue(0);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(100000000);
	mock().expectNCalls(2, "ice_cfg_vsi_bw_lmt_per_tc")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_vf_tc_adminq_failed)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_VF_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 100000;
	bwcfg_list->cfg[0].shaper.peak = 10000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	vf_vsi->tc_cfg.ena_tc = 1;

	USE_STD_MOCK(ice_check_vf_ready_for_cfg);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.withParameter("vf", vf)
		.andReturnValue(0);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_cfg_vsi_bw_lmt_per_tc")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_AQ_ERROR);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR);

	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_ADMIN_QUEUE_ERROR, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_vf_tc_default_success)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_VF_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 0;
	bwcfg_list->cfg[0].shaper.peak = 0;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	vf_vsi->tc_cfg.ena_tc = 1;

	USE_STD_MOCK(ice_check_vf_ready_for_cfg);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_check_vf_ready_for_cfg")
		.withParameter("vf", vf)
		.andReturnValue(0);
	mock().expectNCalls(2, "ice_cfg_vsi_bw_dflt_lmt_per_tc")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_vf_tc_peak_too_large_failed)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_VF_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 100000;
	bwcfg_list->cfg[0].shaper.peak = 200000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	vf_vsi->tc_cfg.ena_tc = 1;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_vsi_type_str")
		.ignoreOtherParameters()
		.andReturnValue((void*)0);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	mutex_lock(&vfs->table_lock);
	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);
	mutex_unlock(&vfs->table_lock);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_vf_tc_committed_too_large_failed)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_VF_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 1000000000;
	bwcfg_list->cfg[0].shaper.peak = 10000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	vf_vsi->tc_cfg.ena_tc = 1;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_vsi_type_str")
		.ignoreOtherParameters()
		.andReturnValue((void*)0);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	mutex_lock(&vfs->table_lock);
	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);
	mutex_unlock(&vfs->table_lock);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_tc_node_success)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0xffff;
	bwcfg_list->num_elem = 1;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_TC_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 100000;
	bwcfg_list->cfg[0].shaper.peak = 10000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	pf_vsi->tc_cfg.ena_tc = 1;
	hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.tsatable[0] = 0;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[0])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_cfg_tc_node_bw_lmt")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	mutex_lock(&vfs->table_lock);
	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);
	mutex_unlock(&vfs->table_lock);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_dcf_config_tc_node_committed_failed)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	bwcfg_list->vf_id = 0xffff;
	bwcfg_list->num_elem = 2;
	bwcfg_list->node_type = VIRTCHNL_DCF_TARGET_TC_BW;

	bwcfg_list->cfg[0].tc_num = 0;
	bwcfg_list->cfg[0].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[0].shaper.committed = 20000000;
	bwcfg_list->cfg[0].shaper.peak = 10000000;

	bwcfg_list->cfg[1].tc_num = 1;
	bwcfg_list->cfg[1].type = VIRTCHNL_BW_SHAPER;
	bwcfg_list->cfg[1].shaper.committed = 100000;
	bwcfg_list->cfg[1].shaper.peak = 90000000;
	bwcfg_list->cfg[0].bw_type |=
		VIRTCHNL_DCF_BW_PIR | VIRTCHNL_DCF_BW_CIR;

	pf_vsi->tc_cfg.ena_tc = 0x3;
	hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.tsatable[0] = 0;
	hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.tsatable[1] = 0;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_get_link_speed_kbps")
		.withParameter("vsi", pf->vsi[0])
		.andReturnValue(100000000);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	mutex_lock(&vfs->table_lock);
	ret = ice_vc_dcf_config_tc(vf, (u8 *)bwcfg_list);
	mutex_unlock(&vfs->table_lock);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_aq_send_cmd_not_permitted)
{
	struct ice_aq_desc desc;
	int ret;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_q_shutdown);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_dcf_aq_cmd_permitted")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_dcf_cmd_desc_msg(vf, (u8 *)&desc, sizeof(desc));
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_aq_send_cmd_no_desc_fail)
{
	u8 buff[32];
	int ret;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_dcf_cmd_buff_msg(vf, buff, sizeof(buff));
	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_aq_send_cmd_success)
{
	struct ice_aq_desc desc;
	int ret;

	vf->pf->hw.dcf_caps |= DCF_ACL_CAP;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_dcf_aq_cmd_permitted")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_acl_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_acl_capable")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_udp_tunnel_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_dcf_pre_aq_send_cmd")
		.withParameter("vf", vf)
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_send_cmd")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_dcf_post_aq_send_cmd")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_dcf_update_acl_rule_info")
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_get_ver);
	ret = ice_vc_dcf_cmd_desc_msg(vf, (u8 *)&desc, sizeof(desc));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_aq_send_cmd_with_buff_success)
{
	struct ice_aqc_get_phy_caps_data pcaps;
	struct ice_aqc_get_phy_caps *cmd;
	struct ice_aq_desc desc;
	int ret;

	vf->pf->hw.dcf_caps |= DCF_ACL_CAP;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_dcf_aq_cmd_permitted")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	cmd = &desc.params.get_phy;
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_get_phy_caps);
	desc.flags |= cpu_to_le16(ICE_AQ_FLAG_BUF);
	cmd->param0 |= cpu_to_le16(ICE_AQC_REPORT_TOPO_CAP_MEDIA);
	ret = ice_vc_dcf_cmd_desc_msg(vf, (u8 *)&desc, sizeof(desc));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(cpu_to_le16(ice_aqc_opc_get_phy_caps),
		    vf->pf->dcf.aq_desc.opcode);
	CHECK_EQUAL(true, vf->pf->dcf.aq_desc_received);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("time_is_before_jiffies")
		.withParameter("time", 0)
		.andReturnValue(false);
	mock().expectOneCall("ice_dcf_is_acl_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_acl_capable")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_udp_tunnel_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_dcf_pre_aq_send_cmd")
		.withParameter("vf", vf)
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_send_cmd")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_dcf_post_aq_send_cmd")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_dcf_update_acl_rule_info")
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	vf->pf->dcf.aq_desc_expires = 0;
	ret = ice_vc_dcf_cmd_buff_msg(vf, (u8 *)&pcaps, sizeof(pcaps));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(false, vf->pf->dcf.aq_desc_received);
}

TEST(check_virtchnl_ops, ice_vc_dcf_query_pkg_info_success)
{
#define ICE_COMMS_PKG "ICE COMMS Package"
	char pkg_name[ICE_PKG_NAME_SIZE] = ICE_COMMS_PKG;
	int ret;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf->driver_caps |= VIRTCHNL_VF_CAP_DCF;

	hw->active_track_id = 0xc0000002;
	memcpy(hw->active_pkg_name, pkg_name,
		sizeof(hw->active_pkg_name));
	memset(pf->dcf.dsn, 0, sizeof(pf->dcf.dsn));
	hw->active_pkg_ver.major = ICE_PKG_SUPP_VER_MAJ;
	hw->active_pkg_ver.minor = ICE_PKG_SUPP_VER_MNR;
	hw->active_pkg_ver.update = 0;
	hw->active_pkg_ver.draft = 0;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_dcf_query_pkg_info(vf);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_query_pkg_info_not_dcf_fail)
{
	int ret;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(false);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_dcf_query_pkg_info(vf);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(check_virtchnl_ops, ice_vc_dcf_acl_clear_success)
{
	using namespace ns_virtchnl;
	struct ice_aq_desc desc;
	int ret;

	vf->pf->dcf.vf = vf;
	vf->pf->dcf.state = ICE_DCF_STATE_ON;
	vf->pf->hw.dcf_caps |= DCF_ACL_CAP;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("ice_dcf_aq_cmd_permitted")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_alloc_acl_tbl);
	desc.flags |= cpu_to_le16(ICE_AQ_FLAG_BUF);
	ret = ice_vc_dcf_cmd_desc_msg(vf, (u8 *)&desc, sizeof(desc));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(true, vf->pf->dcf.aq_desc_received);

	mock().expectOneCall("ice_is_vf_dcf")
		.withParameter("vf", vf)
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_get_state")
		.withParameter("pf", pf)
		.andReturnValue(ICE_DCF_STATE_ON);
	mock().expectOneCall("time_is_before_jiffies")
		.withParameter("time", 0)
		.andReturnValue(false);
	mock().expectOneCall("ice_dcf_is_acl_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_acl_capable")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_dcf_is_udp_tunnel_aq_cmd")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_dcf_pre_aq_send_cmd")
		.withParameter("vf", vf)
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_send_cmd")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_dcf_post_aq_send_cmd")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_dcf_update_acl_rule_info")
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	vf->pf->dcf.aq_desc_expires = 0;
	ret = ice_vc_dcf_cmd_buff_msg(vf, (u8 *)&desc, sizeof(desc));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}
#endif

#ifdef ADV_AVF_SUPPORT
TEST(check_virtchnl_ops, ice_vc_query_rxdid_success)
{
	int ret;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf->driver_caps |= VIRTCHNL_VF_OFFLOAD_RX_FLEX_DESC;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);
	ret = ice_vc_query_rxdid(vf);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(check_virtchnl_ops, ice_vc_query_rxdid_no_flag_fail)
{
	int ret;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf->driver_caps &= ~VIRTCHNL_VF_OFFLOAD_RX_FLEX_DESC;

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_query_rxdid(vf);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_get_qos_caps_success)
{
	int i, ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->tc_cfg.numtc = 8;
	vf_vsi->tc_cfg.ena_tc = 0xffff;

	for (i = 0; i < 8; i++) {
		hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.prio_table[i] = i;
		hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.tsatable[i] = VIRTCHNL_ABITER_STRICT;
		vf_vsi_ctx->sched.bw_t_info[i].cir_bw.bw = 0;
		vf_vsi_ctx->sched.bw_t_info[i].eir_bw.bw = 0;
	}

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_get_vsi_ctx")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi_ctx);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_get_qos_caps(vf);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_cfg_q_tc_map_success)
{
	int i, ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->vsi_num = 10;
	vf_vsi->alloc_txq = 16;
	vf_vsi->alloc_rxq = 16;
	vf_vsi->tc_cfg.numtc = 8;

	qtc->vsi_id = 10;
	qtc->num_tc = 8;
	qtc->num_queue_pairs = 16;

	for (i = 0; i < 8; i++) {
		hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.prio_table[i] = i;
		qtc->tc[i].req.queue_count = 2;
	}

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectNCalls(2, "ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_vsi_cfg_dcb_rings")
		.ignoreOtherParameters()
		.andReturnValue((void *)0);
	mock().expectOneCall("ice_update_vsi")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_cfg_q_tc_map(vf, (u8 *)qtc);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_cfg_q_tc_map_queue_num_failed)
{
	int i, ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->vsi_num = 10;
	vf_vsi->alloc_txq = 16;
	vf_vsi->alloc_rxq = 16;
	vf_vsi->tc_cfg.numtc = 8;

	qtc->vsi_id = 10;
	qtc->num_tc = 8;
	qtc->num_queue_pairs = 14;

	for (i = 0; i < 8; i++) {
		hw->port_info->qos_cfg.local_dcbx_cfg.etscfg.prio_table[i] = i;
		qtc->tc[i].req.queue_count = 2;
	}

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectNCalls(2, "ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_cfg_q_tc_map(vf, (u8 *)qtc);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}
TEST(ice_vc_cfg_qos, ice_vc_cfg_q_bw_success)
{
	int i, ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->vsi_num = 10;
	vf_vsi->alloc_txq = 8;
	vf_vsi->alloc_rxq = 8;

	qbw->vsi_id = 10;
	qbw->num_queues = 8;

	for (i = 0; i < 8; i++) {
		qbw->cfg[i].queue_id = i;
		qbw->cfg[i].shaper.committed = 100000;
		qbw->cfg[i].shaper.peak = 90000000;
	}

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_cfg_q_bw(vf, (u8 *)qbw);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
}

TEST(ice_vc_cfg_qos, ice_vc_cfg_q_quanta_success)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->vsi_num = 10;
	vf_vsi->alloc_txq = 8;
	vf_vsi->alloc_rxq = 8;
	vf_vsi->tx_rings = (struct ice_ring **)
		calloc(vf_vsi->alloc_txq, sizeof(struct ice_ring *));
	for (int i = 0; i < vf_vsi->alloc_txq; i++)
		vf_vsi->tx_rings[i] = (struct ice_ring *)
			calloc(1, sizeof(struct ice_ring));

	hw->dev_caps.num_funcs = 4;
	hw->logical_pf_id = 0;
	pf->n_quanta_prof_used = 0;

	qquanta->quanta_size = 1024;
	qquanta->queue_select.type = 1;
	qquanta->queue_select.start_queue_id = 0;
	qquanta->queue_select.num_queues = 8;

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_SUCCESS);

	ret = ice_vc_cfg_q_quanta(vf, (u8 *)qquanta);

	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);

	for (int i = 0; i < vf_vsi->alloc_txq; i++)
		free(vf_vsi->tx_rings[i]);
	free(vf_vsi->tx_rings);
}

TEST(ice_vc_cfg_qos, ice_vc_cfg_q_quanta_failed)
{
	int ret;
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	vf_vsi->vsi_num = 10;
	vf_vsi->alloc_txq = 8;
	vf_vsi->alloc_rxq = 8;

	hw->dev_caps.num_funcs = 4;
	hw->logical_pf_id = 0;
	pf->n_quanta_prof_used = 0;

	qquanta->quanta_size = 1000;
	qquanta->queue_select.type = 1;
	qquanta->queue_select.start_queue_id = 0;
	qquanta->queue_select.num_queues = 8;

	USE_STD_MOCK(ice_get_vf_vsi);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_get_vf_vsi")
		.ignoreOtherParameters()
		.andReturnValue(vf_vsi);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters()
		.andReturnValue(VIRTCHNL_STATUS_ERR_PARAM);

	ret = ice_vc_cfg_q_quanta(vf, (u8 *)qquanta);

	CHECK_EQUAL(VIRTCHNL_STATUS_ERR_PARAM, ret);
}
#endif /* ADV_AVF_SUPPORT */

TEST_GROUP_BASE(ice_vf_lan_overflow_event, TGN(ice_virtchnl))
{
	struct ice_rq_event_info *event;
	static const int num_vfs = 2;

	void init_vsi(u16 vsi_idx, enum ice_vsi_type type, u16 num_rxq,
		      u16 pfq_start)
	{
		struct ice_vsi *vsi;
		int i;

		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->rxq_map = (u16*)calloc(num_rxq, sizeof(u16));
		vsi->type = type;
		vsi->num_rxq = num_rxq;
		vsi->alloc_rxq = num_rxq;
		ice_for_each_rxq(vsi, i)
			vsi->rxq_map[i] = pfq_start++;
		pf->vsi[vsi_idx] = vsi;
	}

	void setup()
	{
		u16 pfq_start = 0, num_rxq = 4;
		u16 vsi_idx;
		int i;

		TGN(ice_virtchnl)::setup();

		event = (struct ice_rq_event_info *)calloc(1, sizeof(*event));
		vfs = &pf->vfs;

		test_add_vfs(num_vfs);
		pf->num_alloc_vsi = 3;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi,
						    sizeof(struct ice_vsi *));
		ice_for_each_vsi(pf, i)
			pf->vsi[i] = NULL;

		vsi_idx = 0;
		pfq_start = 0;
		init_vsi(vsi_idx, ICE_VSI_PF, num_rxq, pfq_start);
		pfq_start += num_rxq;

		vsi_idx = 1;
		test_get_vf(0)->lan_vsi_idx = vsi_idx;
		pfq_start = 4;
		init_vsi(vsi_idx, ICE_VSI_VF, num_rxq, pfq_start);
		pfq_start += num_rxq;

		vsi_idx = 2;
		test_get_vf(1)->lan_vsi_idx = vsi_idx;
		pfq_start = 8;
		init_vsi(vsi_idx, ICE_VSI_VF, num_rxq, pfq_start);
	}

	void teardown()
	{
		int i;

		ice_for_each_vsi(pf, i) {
			struct ice_vsi *vsi = pf->vsi[i];

			free(vsi->rxq_map);
			vsi->rxq_map = NULL;
			free(vsi);
			vsi = NULL;
		}
		free(pf->vsi);
		pf->vsi = NULL;
		free(event);
		event = NULL;

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vf_lan_overflow_event, ice_queue_belongs_to_pf)
{
	USE_STD_MOCK(ice_globalq_to_pfq);

	event->desc.params.lan_overflow.prtdcb_ruptq = cpu_to_le32(0x00010001);
	mock().expectOneCall("ice_globalq_to_pfq")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(1);
	ice_vf_lan_overflow_event(pf, event);
}

TEST(ice_vf_lan_overflow_event, ice_queue_belongs_to_vf0)
{
	USE_STD_MOCK(ice_globalq_to_pfq);
	USE_STD_MOCK(ice_reset_vf);

	event->desc.params.lan_overflow.prtdcb_ruptq = cpu_to_le32(0x00000004);
	mock().expectOneCall("ice_globalq_to_pfq")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(4);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(0))
		.withParameter("flags", ICE_VF_RESET_NOTIFY | ICE_VF_RESET_LOCK);
	ice_vf_lan_overflow_event(pf, event);
}

TEST(ice_vf_lan_overflow_event, ice_queue_belongs_to_vf1)
{
	USE_STD_MOCK(ice_globalq_to_pfq);
	USE_STD_MOCK(ice_reset_vf);

	event->desc.params.lan_overflow.prtdcb_ruptq = cpu_to_le32(0x0000000B);
	mock().expectOneCall("ice_globalq_to_pfq")
		.withParameter("pf", pf)
		.ignoreOtherParameters()
		.andReturnValue(0xB);
	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", test_get_vf(1))
		.withParameter("flags", ICE_VF_RESET_NOTIFY | ICE_VF_RESET_LOCK);
	ice_vf_lan_overflow_event(pf, event);
}

TEST_GROUP_BASE(ice_vc_validate_vqs_bitmaps, TGN(ice_virtchnl))
{
	struct virtchnl_queue_select *vqs;
	bool result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vqs = (struct virtchnl_queue_select *)calloc(1, sizeof(*vqs));
	}

	void teardown()
	{
		free(vqs);
		vqs = NULL;

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_validate_vqs_bitmaps, both_rx_and_tx_bitmaps_empty)
{
	CHECK_FALSE(ice_vc_validate_vqs_bitmaps(vqs));
}

TEST(ice_vc_validate_vqs_bitmaps, rx_bitmap_with_out_of_range_bit_set)
{
	unsigned long queue_bitmap = vqs->rx_queues;

	set_bit(ICE_MAX_DFLT_QS_PER_VF, &queue_bitmap);
	CHECK_FALSE(ice_vc_validate_vqs_bitmaps(vqs));
}

TEST(ice_vc_validate_vqs_bitmaps, tx_bitmap_with_out_of_range_bit_set)
{
	unsigned long queue_bitmap = vqs->tx_queues;

	set_bit(ICE_MAX_DFLT_QS_PER_VF, &queue_bitmap);
	CHECK_FALSE(ice_vc_validate_vqs_bitmaps(vqs));
}

TEST(ice_vc_validate_vqs_bitmaps, valid_rx_and_tx_queue_bitmaps)
{
	vqs->rx_queues = BIT(ICE_MAX_DFLT_QS_PER_VF) - 1;
	vqs->tx_queues = BIT(ICE_MAX_DFLT_QS_PER_VF) - 1;
	CHECK_TRUE(ice_vc_validate_vqs_bitmaps(vqs));
}


TEST_GROUP_BASE(ice_set_vf_mac, TGN(ice_virtchnl))
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(struct ice_vsi *));
		pf->vsi[0] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));

		test_add_vfs(1);

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = pf->vsi[0];
		np->vsi->back = pf;
	}

	void teardown()
	{
		free(pf->vsi[0]);
		free(pf->vsi);
		free_netdev(netdev);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_set_vf_mac, same_mac_as_previously_set)
{
	u8 mac[ETH_ALEN] = { 0x00, 0xaa, 0xbb, 0xcc, 0x11, 0x22 };
	struct ice_vf *vf = test_get_vf(0);
	int err;

	ether_addr_copy(vf->dev_lan_addr.addr, mac);
	ether_addr_copy(vf->hw_lan_addr.addr, mac);

	err = ice_set_vf_mac(netdev, 0, mac);
	CHECK_EQUAL(0, err);
}

TEST_GROUP_BASE(ice_ena_vf_mappings, TGN(ice_virtchnl))
{
	struct ice_vf *vf;
	struct ice_vsi *vsi;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(10);
		vf->lan_vsi_idx = 1;
		vf->first_vector_idx = 122;

		pf->vfs.num_msix_per = 5;
		/* This would be PF1's first vector id in a 2 port NIC */
		hw->func_caps.common_cap.msix_vector_first_id = 1024;
		/* This would be PF1's first VF ID */
		hw->func_caps.vf_base_id = 0;
		pf->vsi = (struct ice_vsi **)calloc(2, sizeof(struct ice_vsi *));
		pf->vsi[vf->lan_vsi_idx] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi = pf->vsi[vf->lan_vsi_idx];

		vsi->alloc_txq = 4;
		vsi->alloc_rxq = 4;
		vsi->tx_mapping_mode = ICE_VSI_MAP_CONTIG;
		vsi->rx_mapping_mode = ICE_VSI_MAP_CONTIG;
		vsi->txq_map = (u16 *)calloc(vsi->alloc_txq, sizeof(u16));
		vsi->txq_map[0] = 16;
		vsi->rxq_map = (u16 *)calloc(vsi->alloc_rxq, sizeof(u16));
		vsi->rxq_map[0] = 20;

		vf->pf = pf;
		hw->pf_id = 1;
	}

	void teardown()
	{
		free(vsi->txq_map);
		free(vsi->rxq_map);
		free(vsi);
		free(pf->vsi);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_ena_vf_mappings, valid_vector_queue_mapping)
{
	u32 device_based_vf_id = vf->vf_id + hw->func_caps.vf_base_id;
	u32 device_based_first_msix, device_based_last_msix, expected;
	u32 pf_based_first_msix, pf_based_last_msix;

	ice_ena_vf_mappings(vf);

	device_based_first_msix = vf->first_vector_idx +
		pf->hw.func_caps.common_cap.msix_vector_first_id;
	device_based_last_msix = (device_based_first_msix + pf->vfs.num_msix_per) - 1;
	expected =
		(((device_based_first_msix << VPINT_ALLOC_FIRST_S) & VPINT_ALLOC_FIRST_M) |
		 ((device_based_last_msix << VPINT_ALLOC_LAST_S) & VPINT_ALLOC_LAST_M) |
		 VPINT_ALLOC_VALID_M);
	CHECK_EQUAL(rd32(hw, VPINT_ALLOC(vf->vf_id)), expected);

	expected = (((device_based_first_msix << VPINT_ALLOC_PCI_FIRST_S) & VPINT_ALLOC_PCI_FIRST_M) |
		    ((device_based_last_msix << VPINT_ALLOC_PCI_LAST_S) & VPINT_ALLOC_PCI_LAST_M) |
		    VPINT_ALLOC_PCI_VALID_M);
	CHECK_EQUAL(rd32(hw, VPINT_ALLOC_PCI(vf->vf_id)),
		    expected);

	pf_based_first_msix = vf->first_vector_idx;
	pf_based_last_msix = (pf_based_first_msix + pf->vfs.num_msix_per) - 1;
	for (u32 v = pf_based_first_msix; v < pf_based_last_msix; v++) {
		expected = (((device_based_vf_id << GLINT_VECT2FUNC_VF_NUM_S) & GLINT_VECT2FUNC_VF_NUM_M) |
			    ((hw->pf_id << GLINT_VECT2FUNC_PF_NUM_S) & GLINT_VECT2FUNC_PF_NUM_M));
		CHECK_EQUAL(rd32(hw, GLINT_VECT2FUNC(v)), expected);
	}

	expected = VPINT_MBX_CTL_CAUSE_ENA_M;
	CHECK_EQUAL(rd32(hw, VPINT_MBX_CTL(device_based_vf_id)), expected);

	expected = VPLAN_TXQ_MAPENA_TX_ENA_M;
	CHECK_EQUAL(rd32(hw, VPLAN_TXQ_MAPENA(vf->vf_id)), expected);

	expected = VPLAN_RXQ_MAPENA_RX_ENA_M;
	CHECK_EQUAL(rd32(hw, VPLAN_RXQ_MAPENA(vf->vf_id)), expected);
}

TEST_GROUP_BASE(ice_vf_rebuild_host_cfg, TGN(ice_virtchnl))
{
	struct ice_vf *vf;
	struct ice_vsi_vlan_ops vlan_ops{};

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(0);
		vf->lan_vsi_idx = 1;
		pf->vsi = (struct ice_vsi **)calloc(2, sizeof(struct ice_vsi *));
		pf->vsi[vf->lan_vsi_idx] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vf->pf = pf;

		vlan_ops.add_vlan = &mock_add_vlan;
		vlan_ops.set_port_vlan = &mock_set_port_vlan;
		vlan_ops.ena_rx_filtering = &mock_ena_rx_vlan_filtering;
		vlan_ops.dis_rx_filtering = &mock_dis_rx_vlan_filtering;
	}

	void teardown()
	{
		free(pf->vsi[vf->lan_vsi_idx]);
		free(pf->vsi);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vf_rebuild_host_cfg, port_vlan_13_active_add_vlan_13_success)
{
	u16 vid = 13;
	u8 prio = 0;
	int actual;

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, vid, prio, ICE_FWD_TO_VSI);

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("mock_set_port_vlan")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.withParameter("tpid", ETH_P_8021Q)
		.withParameter("vid", vid)
		.withParameter("prio", prio)
		.withParameter("fwd_act", ICE_FWD_TO_VSI);
	mock().expectOneCall("mock_add_vlan")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.withParameter("tpid", ETH_P_8021Q)
		.withParameter("vid", vid)
		.withParameter("prio", prio)
		.withParameter("fwd_act", ICE_FWD_TO_VSI);
	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	actual = ice_vf_rebuild_host_vlan_cfg(vf, pf->vsi[vf->lan_vsi_idx]);
	CHECK_EQUAL(0, actual);
}

TEST(ice_vf_rebuild_host_cfg, no_port_vlan_active_expect_call_to_add_vlan_0)
{
	int actual;

	vf->port_vlan_info = {};

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);
	mock().expectOneCall("ice_vsi_add_vlan_zero")
		.andReturnValue(0);
	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);
	actual = ice_vf_rebuild_host_vlan_cfg(vf, pf->vsi[vf->lan_vsi_idx]);
	CHECK_EQUAL(0, actual);
}

TEST(ice_vf_rebuild_host_cfg, hw_lan_addr_zero_success_1_active_mac_fitler)
{
	u8 broadcast[ETH_ALEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
	int actual;

	eth_zero_addr(vf->hw_lan_addr.addr);

#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);

#endif
	mock().expectOneCall("ice_fltr_add_mac")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.withParameter("mac", broadcast, ETH_ALEN)
		.withParameter("action", ICE_FWD_TO_VSI)
		.andReturnValue(0);

	actual = ice_vf_rebuild_host_mac_cfg(vf);
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(1, vf->num_mac);

}

TEST(ice_vf_rebuild_host_cfg, hw_lan_addr_valid_success_2_active_mac_filters)
{
	u8 broadcast[ETH_ALEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
	u8 mac_addr[ETH_ALEN] = { 0x00, 0x1a, 0x2a, 0x3a, 0x4a, 0x5a };
	int actual;

	ether_addr_copy(vf->hw_lan_addr.addr, mac_addr);

#ifdef ESWITCH_SUPPORT
	mock().expectOneCall("ice_is_eswitch_mode_switchdev")
		.andReturnValue(false);

#endif
	mock().expectOneCall("ice_fltr_add_mac")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.withParameter("mac", broadcast, ETH_ALEN)
		.withParameter("action", ICE_FWD_TO_VSI)
		.andReturnValue(0);

	mock().expectOneCall("ice_fltr_add_mac")
		.withParameter("vsi", pf->vsi[vf->lan_vsi_idx])
		.withParameter("mac", vf->hw_lan_addr.addr, ETH_ALEN)
		.withParameter("action", ICE_FWD_TO_VSI)
		.andReturnValue(0);

	actual = ice_vf_rebuild_host_mac_cfg(vf);
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(2, vf->num_mac);
}

TEST(ice_vf_rebuild_host_cfg, tx_rate_cfg_min_and_max_are_default_success)
{
	int actual;

	actual = ice_vf_rebuild_host_tx_rate_cfg(vf);

	CHECK_EQUAL(0, actual);
}

TEST(ice_vf_rebuild_host_cfg, tx_rate_cfg_set_min_and_max_success)
{
	int actual, expected_result = 0;

	vf->min_tx_rate = 10000;
	vf->max_tx_rate = 20000;
	expect_call_to_set_min_bw(vf, vf->min_tx_rate, expected_result);
	expect_call_to_set_max_bw(vf, vf->max_tx_rate, expected_result);

	actual = ice_vf_rebuild_host_tx_rate_cfg(vf);

	CHECK_EQUAL(0, actual);
}

#ifdef VF_LARGE_NUM_QPAIRS_SUPPORT
TEST_GROUP_BASE(ice_vc_get_max_rss_qregion, TGN(ice_virtchnl))
{
	struct ice_vsi *vsi;
	struct ice_vf *vf;
	int result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		pf->vsi = (struct ice_vsi **)calloc(3, sizeof(struct ice_vsi *));
		pf->vsi[2] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[2]->vsi_num = 2;
		vf = test_add_one_vf(0);
		vf->pf = pf;
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
		vsi = pf->vsi[vf->lan_vsi_idx];
		set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	}

	void teardown()
	{
		free(pf->vsi[vf->lan_vsi_idx]);
		free(pf->vsi);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_get_max_rss_qregion, max_rss_qregion_is_16_since_no_global_lut_id_allocated)
{
	struct virtchnl_max_rss_qregion expected_msg = { .vport_id = 2, .qregion_width = 4 };

	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_GET_MAX_RSS_QREGION)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)&expected_msg, sizeof(expected_msg))
		.withParameter("msglen", sizeof(expected_msg))
		.andReturnValue(0);

	result = ice_vc_get_max_rss_qregion(vf);
	CHECK_EQUAL(0, result);
}

#ifdef RSS_GLOBAL_LUT_SUPPORT
TEST(ice_vc_get_max_rss_qregion, max_rss_qregion_is_64_since_global_lut_id_allocated)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	struct virtchnl_max_rss_qregion expected_msg = { .vport_id = 2, .qregion_width = 6 };
	u16 global_lut_id = 0;

	vsi->global_lut_id = &global_lut_id;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_GET_MAX_RSS_QREGION)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)&expected_msg, sizeof(expected_msg))
		.withParameter("msglen", sizeof(expected_msg))
		.andReturnValue(0);

	result = ice_vc_get_max_rss_qregion(vf);
	CHECK_EQUAL(0, result);
}
#endif /* RSS_GLOBAL_LUT_SUPPORT */

TEST_GROUP_BASE(ice_vc_validate_qs_v2_msg, TGN(ice_virtchnl))
{
	struct virtchnl_del_ena_dis_queues *qs_msg;
	struct ice_vf *vf;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(0);
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
		qs_msg = (struct virtchnl_del_ena_dis_queues *)calloc(1, sizeof(*qs_msg) +
								      (sizeof(virtchnl_queue_chunk)));
	}

	void teardown()
	{
		free(qs_msg);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_validate_qs_v2_msg, invalid_vport_id)
{
	qs_msg->vport_id = 0;
	CHECK_FALSE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST(ice_vc_validate_qs_v2_msg, num_chunks_set_to_0_invalid)
{
	qs_msg->vport_id = vf->lan_vsi_num;
	qs_msg->chunks.num_chunks = 0;
	CHECK_FALSE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST(ice_vc_validate_qs_v2_msg, invalid_num_queues_0_for_one_of_the_queue_chunks_entries)
{
	vf->num_vf_qs = 256;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	CHECK_FALSE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST(ice_vc_validate_qs_v2_msg, number_of_tx_queues_greater_than_vf_allocated)
{
	vf->num_vf_qs = 256;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = vf->num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 0;
	qs_msg->chunks.chunks[1].num_queues = vf->num_vf_qs + 1;
	CHECK_FALSE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST(ice_vc_validate_qs_v2_msg, number_of_tx_queues_greater_than_vf_allocated_with_nonzero_start_id)
{
	vf->num_vf_qs = 256;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = vf->num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 10;
	qs_msg->chunks.chunks[1].num_queues = vf->num_vf_qs - (10 - 1);
	CHECK_FALSE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST(ice_vc_validate_qs_v2_msg, valid_message)
{
	vf->num_vf_qs = 256;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = vf->num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 0;
	qs_msg->chunks.chunks[1].num_queues = vf->num_vf_qs;
	CHECK_TRUE(ice_vc_validate_qs_v2_msg(vf, qs_msg));
}

TEST_GROUP_BASE(ice_vc_ena_dis_chunk, TGN(ice_virtchnl))
{
	int num_vf_qs = 16;
	struct virtchnl_queue_chunk *chunk;
	struct ice_vsi *vsi;
	struct ice_vf *vf;
	int result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		pf->num_alloc_vsi = 3;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi, sizeof(struct ice_vsi *));
		pf->vsi[2] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[2]->vsi_num = 2;
		vf = test_add_one_vf(0);
		vf->pf = pf;
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
		vsi = pf->vsi[vf->lan_vsi_idx];
		chunk = (struct virtchnl_queue_chunk *)calloc(1, sizeof(*chunk));
	}

	void teardown()
	{
		free(vsi);
		free(pf->vsi);
		free(chunk);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_ena_dis_chunk, enable_single_txq_15_success)
{
	u16 queue_id = 15;
	USE_STD_MOCK(ice_vf_vsi_ena_single_txq);

	chunk->start_queue_id = queue_id;
	chunk->num_queues = 1;

	mock().expectOneCall("ice_vf_vsi_ena_single_txq")
		.withParameter("q_id", queue_id)
		.withParameter("vf_q_id", queue_id)
		.ignoreOtherParameters();

	CHECK_EQUAL(0, ice_vc_ena_txq_chunk(vf, chunk));
}

TEST(ice_vc_ena_dis_chunk, enable_16_txqs_success)
{
	u16 num_queues = 16;
	USE_STD_MOCK(ice_vf_vsi_ena_single_txq);

	chunk->start_queue_id = 0;
	chunk->num_queues = num_queues;

	for (int queue_id = 0; queue_id < num_queues; queue_id++) {
		mock().expectOneCall("ice_vf_vsi_ena_single_txq")
			.withParameter("q_id", queue_id)
			.withParameter("vf_q_id", queue_id)
			.ignoreOtherParameters();
	}

	CHECK_EQUAL(0, ice_vc_ena_txq_chunk(vf, chunk));
}

TEST(ice_vc_ena_dis_chunk, enable_single_rxq_13_success)
{
	u16 queue_id = 13;
	USE_STD_MOCK(ice_vf_vsi_ena_single_rxq);

	chunk->start_queue_id = queue_id;
	chunk->num_queues = 1;

	mock().expectOneCall("ice_vf_vsi_ena_single_rxq")
		.withParameter("q_id", queue_id)
		.withParameter("vf_q_id", queue_id)
		.ignoreOtherParameters()
		.andReturnValue(0);

	CHECK_EQUAL(0, ice_vc_ena_rxq_chunk(vf, chunk));
}

TEST(ice_vc_ena_dis_chunk, enable_4_rxqs_success)
{
	u16 num_queues = 4;
	USE_STD_MOCK(ice_vf_vsi_ena_single_rxq);

	chunk->start_queue_id = 0;
	chunk->num_queues = num_queues;

	for (int queue_id = 0; queue_id < num_queues; queue_id++) {
		mock().expectOneCall("ice_vf_vsi_ena_single_rxq")
			.withParameter("q_id", queue_id)
			.withParameter("vf_q_id", queue_id)
			.ignoreOtherParameters()
			.andReturnValue(0);
	}

	CHECK_EQUAL(0, ice_vc_ena_rxq_chunk(vf, chunk));
}

TEST_GROUP_BASE(ice_vc_ena_dis_qs_msg_v2, TGN(ice_virtchnl))
{
	int num_vf_qs = 16;
	struct virtchnl_del_ena_dis_queues *qs_msg;
	struct ice_vsi *vsi;
	struct ice_vf *vf;
	int result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		pf->num_alloc_vsi = 3;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi, sizeof(struct ice_vsi *));
		pf->vsi[2] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[2]->vsi_num = 2;
		vf = test_add_one_vf(0);
		vf->pf = pf;
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
		pf->vsi[2]->vf = vf;
		vsi = pf->vsi[vf->lan_vsi_idx];
		set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
		qs_msg = (struct virtchnl_del_ena_dis_queues *)calloc(1, sizeof(*qs_msg) +
								      (sizeof(virtchnl_queue_chunk)));
	}

	void teardown()
	{
		free(vsi);
		free(pf->vsi);
		free(qs_msg);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_ena_dis_qs_msg_v2, vf_attempting_to_enable_16_queue_pairs_success)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	USE_STD_MOCK(ice_vc_ena_rxq_chunk);
	USE_STD_MOCK(ice_vc_ena_txq_chunk);

	vf->num_vf_qs = num_vf_qs;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 0;
	qs_msg->chunks.chunks[1].num_queues = num_vf_qs;

	mock().expectOneCall("ice_vc_ena_rxq_chunk")
		.withParameter("vf", vf)
		.withParameter("chunk", &qs_msg->chunks.chunks[0])
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_ena_txq_chunk")
		.withParameter("vf", vf)
		.withParameter("chunk", &qs_msg->chunks.chunks[1])
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_ENABLE_QUEUES_V2)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)NULL, 0)
		.withParameter("msglen", 0)
		.andReturnValue(0);

	result = ice_vc_ena_qs_v2_msg(vf, (u8 *)qs_msg);
	CHECK_EQUAL(0, result);
}

TEST(ice_vc_ena_dis_qs_msg_v2, vf_attempting_to_enable_16_queue_pairs_failed_to_enable_rx_queue)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	USE_STD_MOCK(ice_vc_ena_rxq_chunk);

	vf->num_vf_qs = num_vf_qs;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 0;
	qs_msg->chunks.chunks[1].num_queues = num_vf_qs;

	mock().expectOneCall("ice_vc_ena_rxq_chunk")
		.withParameter("vf", vf)
		.withParameter("chunk", &qs_msg->chunks.chunks[0])
		.andReturnValue(-ETIMEDOUT);

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_ENABLE_QUEUES_V2)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.withParameter("msg", (u8 *)NULL, 0)
		.withParameter("msglen", 0)
		.andReturnValue(0);

	result = ice_vc_ena_qs_v2_msg(vf, (u8 *)qs_msg);
	CHECK_EQUAL(0, result);
}

TEST(ice_vc_ena_dis_qs_msg_v2, vf_attempting_to_disable_16_queue_pairs_success)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	USE_STD_MOCK(ice_vc_dis_rxq_chunk);
	USE_STD_MOCK(ice_vc_dis_txq_chunk);

	vf->num_vf_qs = num_vf_qs;
	qs_msg->vport_id = 2;
	qs_msg->chunks.num_chunks = 2;
	qs_msg->chunks.chunks[0].type = VIRTCHNL_QUEUE_TYPE_RX;
	qs_msg->chunks.chunks[0].start_queue_id = 0;
	qs_msg->chunks.chunks[0].num_queues = num_vf_qs;
	qs_msg->chunks.chunks[1].type = VIRTCHNL_QUEUE_TYPE_TX;
	qs_msg->chunks.chunks[1].start_queue_id = 0;
	qs_msg->chunks.chunks[1].num_queues = num_vf_qs;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_DISABLE_QUEUES_V2)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)NULL, 0)
		.withParameter("msglen", 0)
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_dis_rxq_chunk")
		.withParameter("vf", vf)
		.withParameter("chunk", &qs_msg->chunks.chunks[0])
		.andReturnValue(0);

	mock().expectOneCall("ice_vc_dis_txq_chunk")
		.withParameter("vf", vf)
		.withParameter("chunk", &qs_msg->chunks.chunks[1])
		.andReturnValue(0);

	result = ice_vc_dis_qs_v2_msg(vf, (u8 *)qs_msg);
	CHECK_EQUAL(0, result);
}

TEST_GROUP_BASE(ice_vc_map_q_vector_msg, TGN(ice_virtchnl))
{
	struct virtchnl_queue_vector_maps *qv_maps;
	struct ice_q_vector **q_vectors;

	struct ice_vsi *vsi;
	struct ice_vf *vf;
	int result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		qv_maps = (struct virtchnl_queue_vector_maps *)
			calloc(1, sizeof(*qv_maps) + sizeof(struct virtchnl_queue_vector) * 63);
		pf->num_alloc_vsi = 3;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi, sizeof(struct ice_vsi *));
		pf->vsi[2] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[2]->vsi_num = 2;
		vsi = pf->vsi[2];
		vf = test_add_one_vf(0);
		vf->pf = pf;
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
		pf->vsi[2]->vf = vf;

		vsi->num_q_vectors = 32;

		q_vectors = (struct ice_q_vector **)calloc(vsi->num_q_vectors,
							   sizeof(*q_vectors));
		for (int i = 0; i < vsi->num_q_vectors; i++) {
			struct ice_q_vector *q_vector;

			q_vector = (struct ice_q_vector *)calloc(1, sizeof(*q_vector));
			q_vector->v_idx = i;

			q_vectors[i] = q_vector;
		}
		vsi->q_vectors = q_vectors;

		vsi->base_vector = ICE_NONQ_VECS_VF;

		set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
	}

	void teardown()
	{
		for (int i = 0; i < vsi->num_q_vectors; i++)
			free(q_vectors[i]);
		free(q_vectors);
		free(pf->vsi[2]);
		free(pf->vsi);
		free(qv_maps);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_map_q_vector_msg, map_q_vector_msg_success)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	vf->num_vf_qs = 32;
	qv_maps->num_qv_maps = 64;
	for (int i = 0; i < vf->num_vf_qs; ++i) {
		qv_maps->qv_maps[i].queue_type = VIRTCHNL_QUEUE_TYPE_RX;
		qv_maps->qv_maps[i].queue_id = i;
		qv_maps->qv_maps[i].vector_id = i + 1;
		qv_maps->qv_maps[i].itr_idx = VIRTCHNL_ITR_IDX_0;
		mock().expectOneCall("ice_cfg_rxq_interrupt")
			.withParameter("vsi", vsi)
			.withParameter("rxq", i)
			.withParameter("msix_idx", i + 1)
			.withParameter("itr_idx", VIRTCHNL_ITR_IDX_0);

		qv_maps->qv_maps[i + vf->num_vf_qs].queue_type = VIRTCHNL_QUEUE_TYPE_TX;
		qv_maps->qv_maps[i + vf->num_vf_qs].queue_id = i;
		qv_maps->qv_maps[i + vf->num_vf_qs].vector_id = i + 1;
		qv_maps->qv_maps[i + vf->num_vf_qs].itr_idx = VIRTCHNL_ITR_IDX_1;
		mock().expectOneCall("ice_cfg_txq_interrupt")
			.withParameter("vsi", vsi)
			.withParameter("txq", i)
			.withParameter("msix_idx", i + 1)
			.withParameter("itr_idx", VIRTCHNL_ITR_IDX_1);
	}

	qv_maps->vport_id = vf->lan_vsi_num;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_MAP_QUEUE_VECTOR)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)NULL, 0)
		.withParameter("msglen", 0)
		.andReturnValue(0);

	result = ice_vc_map_q_vector_msg(vf, (u8 *)qv_maps);
	CHECK_EQUAL(0, result);
}

TEST_GROUP_BASE(ice_vc_validate_qv_maps, TGN(ice_virtchnl))
{
	struct virtchnl_queue_vector_maps *qv_maps;
	struct ice_vsi *vsi;
	struct ice_vf *vf;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		qv_maps = (struct virtchnl_queue_vector_maps *)calloc(1, sizeof(*qv_maps) +
								      sizeof(struct virtchnl_queue_vector));
		pf->vsi = (struct ice_vsi **)calloc(3, sizeof(struct ice_vsi *));
		pf->vsi[2] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[2]->vsi_num = 2;
		vsi = pf->vsi[2];
		vf = test_add_one_vf(0);
		vf->pf = pf;
		vf->lan_vsi_idx = 2;
		vf->lan_vsi_num = 2;
	}

	void teardown()
	{
		free(pf->vsi[2]);
		free(pf->vsi);
		free(qv_maps);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_validate_qv_maps, invalid_vport_id)
{
	qv_maps->vport_id = 0;
	CHECK_FALSE(ice_vc_validate_qv_maps(vf, qv_maps));
}

TEST(ice_vc_validate_qv_maps, invalid_num_qv_maps)
{
	qv_maps->vport_id = vf->lan_vsi_num;
	qv_maps->num_qv_maps = 0;
	CHECK_FALSE(ice_vc_validate_qv_maps(vf, qv_maps));
}

TEST(ice_vc_validate_qv_maps, invalid_queue_id)
{
	vf->num_vf_qs = 256;
	qv_maps->vport_id = vf->lan_vsi_num;
	qv_maps->num_qv_maps = 2;
	qv_maps->qv_maps[1].queue_id = vf->num_vf_qs;
	CHECK_FALSE(ice_vc_validate_qv_maps(vf, qv_maps));
}

TEST(ice_vc_validate_qv_maps, invalid_vector_id)
{
	vsi->num_q_vectors = 64;
	vf->num_vf_qs = 256;
	qv_maps->vport_id = vf->lan_vsi_num;
	qv_maps->num_qv_maps = 2;
	qv_maps->qv_maps[1].queue_id = vf->num_vf_qs - 1;
	qv_maps->qv_maps[1].vector_id = vsi->num_q_vectors + ICE_NONQ_VECS_VF;
	CHECK_FALSE(ice_vc_validate_qv_maps(vf, qv_maps));
}

TEST(ice_vc_validate_qv_maps, success)
{
	vsi->num_q_vectors = 64;
	vf->num_vf_qs = 256;
	qv_maps->vport_id = vf->lan_vsi_num;
	qv_maps->num_qv_maps = 2;
	qv_maps->qv_maps[1].queue_id = vf->num_vf_qs - 1;
	qv_maps->qv_maps[1].vector_id = 64;
	CHECK_TRUE(ice_vc_validate_qv_maps(vf, qv_maps));

}
#endif /* VF_LARGE_NUM_QPAIRS_SUPPORT */

#ifdef ADV_AVF_SUPPORT
TEST_GROUP_BASE(ice_vc_rss_hash_update, TGN(ice_virtchnl))
{
	u8 expected_q_opt_rss;
	struct ice_vsi *vsi;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
	}

	void teardown()
	{
		free(vsi);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_rss_hash_update, q_opt_rss_hash_type_changed_expect_no_change_from_other_q_opt_rss)
{
	u8 previous_q_opt_rss, expected_q_opt_rss;
	u8 global_lut_id = 13;

	/* pre RSS hash function type update */
	previous_q_opt_rss = ICE_AQ_VSI_Q_OPT_RSS_LUT_GBL;
	previous_q_opt_rss |= (global_lut_id << ICE_AQ_VSI_Q_OPT_RSS_GBL_LUT_S) &
		ICE_AQ_VSI_Q_OPT_RSS_GBL_LUT_M;
	previous_q_opt_rss |= ICE_AQ_VSI_Q_OPT_RSS_TPLZ;
	vsi->info.q_opt_rss = previous_q_opt_rss;

	mock().expectOneCall("ice_update_vsi")
		.ignoreOtherParameters()
		.andReturnValue(0);

	/* update RSS hash function type */
	ice_vc_rss_hash_update(hw, vsi, ICE_AQ_VSI_Q_OPT_RSS_XOR);

	/* post RSS hash function update, expected values */
	expected_q_opt_rss = previous_q_opt_rss & ~ICE_AQ_VSI_Q_OPT_RSS_HASH_M;
	expected_q_opt_rss |= ICE_AQ_VSI_Q_OPT_RSS_XOR;

	CHECK_EQUAL(expected_q_opt_rss, vsi->info.q_opt_rss);
}
#endif /* ADV_AVF_SUPPORT */

#ifdef VF_QINQ_SUPPORT
TEST_GROUP_BASE(ice_vc_get_offload_vlan_v2_caps, TGN(ice_virtchnl))
{
	struct ice_vf *vf;
	int result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(0);
		set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);
		vf->pf = pf;
	}

	void teardown()
	{
		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_get_offload_vlan_v2_caps, dvm_is_configured_expect_set_dvm_caps_called)
{
	USE_STD_MOCK(ice_vc_set_dvm_caps);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(true);
	mock().expectOneCall("ice_vc_set_dvm_caps")
		.withParameter("vf", vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_vc_get_offload_vlan_v2_caps(vf);
}

TEST(ice_vc_get_offload_vlan_v2_caps, dvm_is_not_configured_expect_svm_caps_called)
{
	USE_STD_MOCK(ice_vc_set_svm_caps);
	USE_STD_MOCK(ice_vc_send_msg_to_vf);

	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(false);
	mock().expectOneCall("ice_vc_set_svm_caps")
		.withParameter("vf", vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_vc_get_offload_vlan_v2_caps(vf);
}

TEST(ice_vc_get_offload_vlan_v2_caps, ice_vc_set_dvm_caps_with_port_vlan_configured)
{
	struct virtchnl_vlan_supported_caps *supported_caps;
	struct virtchnl_vlan_caps caps = { };

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, 10, 0, ICE_FWD_TO_VSI);
	ice_vc_set_dvm_caps(vf, &caps);

	supported_caps = &caps.filtering.filtering_support;
	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, supported_caps->inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, supported_caps->outer);

	supported_caps = &caps.offloads.stripping_support;
	CHECK_EQUAL(VIRTCHNL_VLAN_TOGGLE | VIRTCHNL_VLAN_ETHERTYPE_8100 |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1,
		    supported_caps->inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, supported_caps->outer);

	supported_caps = &caps.offloads.insertion_support;
	CHECK_EQUAL(VIRTCHNL_VLAN_TOGGLE | VIRTCHNL_VLAN_ETHERTYPE_8100 |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1,
		    supported_caps->inner);

	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, supported_caps->outer);

	CHECK_EQUAL(VIRTCHNL_VLAN_ETHERTYPE_8100, caps.offloads.ethertype_init);
	CHECK_EQUAL(VIRTCHNL_ETHERTYPE_STRIPPING_MATCHES_INSERTION, caps.offloads.ethertype_match);
}

TEST(ice_vc_get_offload_vlan_v2_caps, ice_vc_set_dvm_caps_without_port_vlan_configured)
{

	struct virtchnl_vlan_caps caps = { };

	ice_vc_set_dvm_caps(vf, &caps);

	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, caps.filtering.filtering_support.inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_TOGGLE |
		    VIRTCHNL_VLAN_ETHERTYPE_8100 |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1, caps.offloads.stripping_support.inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_TOGGLE |
		    VIRTCHNL_VLAN_ETHERTYPE_8100 |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1, caps.offloads.insertion_support.inner);

	CHECK_EQUAL((VIRTCHNL_VLAN_ETHERTYPE_8100 |
		     VIRTCHNL_VLAN_ETHERTYPE_88A8 |
		     VIRTCHNL_VLAN_ETHERTYPE_9100 |
		     VIRTCHNL_VLAN_ETHERTYPE_AND), caps.filtering.filtering_support.outer);
	CHECK_EQUAL((VIRTCHNL_VLAN_TOGGLE |
		     VIRTCHNL_VLAN_ETHERTYPE_8100 |
		     VIRTCHNL_VLAN_ETHERTYPE_88A8 |
		     VIRTCHNL_VLAN_ETHERTYPE_9100 |
		     VIRTCHNL_VLAN_ETHERTYPE_XOR |
		     VIRTCHNL_VLAN_TAG_LOCATION_L2TAG2_2), caps.offloads.stripping_support.outer);
	CHECK_EQUAL((VIRTCHNL_VLAN_TOGGLE |
		     VIRTCHNL_VLAN_ETHERTYPE_8100 |
		     VIRTCHNL_VLAN_ETHERTYPE_88A8 |
		     VIRTCHNL_VLAN_ETHERTYPE_9100 |
		     VIRTCHNL_VLAN_ETHERTYPE_XOR |
		     VIRTCHNL_VLAN_TAG_LOCATION_L2TAG2), caps.offloads.insertion_support.outer);
}

TEST(ice_vc_get_offload_vlan_v2_caps, ice_vc_set_svm_caps_with_port_vlan_configured)
{
	struct virtchnl_vlan_caps caps = { };
	struct virtchnl_vlan_caps expected_caps = { };

	vf->port_vlan_info = ICE_VLAN(ETH_P_8021Q, 10, 0, ICE_FWD_TO_VSI);
	ice_vc_set_svm_caps(vf, &caps);

	MEMCMP_EQUAL(&expected_caps, &caps, sizeof(caps));

}

TEST(ice_vc_get_offload_vlan_v2_caps, ice_vc_set_svm_caps_without_port_vlan_configured)
{
	struct virtchnl_vlan_caps caps = { };

	ice_vc_set_svm_caps(vf, &caps);

	CHECK_EQUAL(VIRTCHNL_VLAN_ETHERTYPE_8100, caps.filtering.filtering_support.inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_ETHERTYPE_8100 | VIRTCHNL_VLAN_TOGGLE |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1, caps.offloads.stripping_support.inner);
	CHECK_EQUAL(VIRTCHNL_VLAN_ETHERTYPE_8100 | VIRTCHNL_VLAN_TOGGLE |
		    VIRTCHNL_VLAN_TAG_LOCATION_L2TAG1, caps.offloads.insertion_support.inner);

	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, caps.filtering.filtering_support.outer);
	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, caps.offloads.stripping_support.outer);
	CHECK_EQUAL(VIRTCHNL_VLAN_UNSUPPORTED, caps.offloads.insertion_support.outer);

	CHECK_EQUAL(VIRTCHNL_VLAN_ETHERTYPE_8100, caps.offloads.ethertype_init);
	CHECK_EQUAL(VIRTCHNL_ETHERTYPE_STRIPPING_MATCHES_INSERTION, caps.offloads.ethertype_match);
}

TEST_GROUP_BASE(ice_vc_valid_strip_msg, TGN(ice_virtchnl))
{
	struct virtchnl_vlan_supported_caps *stripping_support;
	struct virtchnl_vlan_setting *strip_request;
	bool result;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		stripping_support = (struct virtchnl_vlan_supported_caps *)calloc(1, sizeof(*stripping_support));
		strip_request = (struct virtchnl_vlan_setting *)calloc(1, sizeof(*strip_request));
	}

	void teardown()
	{
		free(stripping_support);
		free(strip_request);

		TGN(ice_virtchnl)::teardown();
	}
};

TEST(ice_vc_valid_strip_msg, valid_strip_msg)
{
	stripping_support->outer = VIRTCHNL_VLAN_ETHERTYPE_88A8 |
				   VIRTCHNL_VLAN_TOGGLE;
	strip_request->outer_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_88A8;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_TRUE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_inner_and_outer_stripping_fields_cleared)
{

	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, strip_msg_not_allowed_with_no_negotiated_stripping_support)
{
	strip_request->outer_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_88A8;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_outer_stripping_not_supported_but_vf_requested_it)
{
	stripping_support->inner = VIRTCHNL_VLAN_ETHERTYPE_8100 |
				   VIRTCHNL_VLAN_TOGGLE;
	strip_request->outer_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_8100;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_inner_stripping_not_supported_but_vf_requested_it)
{
	stripping_support->outer = VIRTCHNL_VLAN_ETHERTYPE_8100;
	strip_request->inner_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_8100;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_outer_stripping_negotiated_xor_but_vf_request_multiple_ethertypes)
{
	stripping_support->outer = VIRTCHNL_VLAN_ETHERTYPE_8100 |
				   VIRTCHNL_VLAN_ETHERTYPE_88A8 |
				   VIRTCHNL_VLAN_ETHERTYPE_9100 |
				   VIRTCHNL_VLAN_TOGGLE |
				   VIRTCHNL_VLAN_ETHERTYPE_XOR;
	strip_request->outer_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_8100 |
						 VIRTCHNL_VLAN_ETHERTYPE_9100;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_inner_stripping_negotiated_only_8100_but_vf_request_multiple_ethertypes)
{
	stripping_support->inner = VIRTCHNL_VLAN_ETHERTYPE_8100 |
				   VIRTCHNL_VLAN_TOGGLE;
	strip_request->inner_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_8100 |
						 VIRTCHNL_VLAN_ETHERTYPE_9100;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_outer_stripping_negotiated_but_vf_request_doesnt_match)
{
	stripping_support->outer = VIRTCHNL_VLAN_ETHERTYPE_8100 |
				   VIRTCHNL_VLAN_ETHERTYPE_9100 |
				   VIRTCHNL_VLAN_TOGGLE	|
				   VIRTCHNL_VLAN_ETHERTYPE_XOR;
	strip_request->outer_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_88A8;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}

TEST(ice_vc_valid_strip_msg, invalid_strip_msg_inner_stripping_negotiated_but_vf_request_doesnt_match)
{
	stripping_support->inner = VIRTCHNL_VLAN_ETHERTYPE_8100 |
				   VIRTCHNL_VLAN_TOGGLE;
	strip_request->inner_ethertype_setting = VIRTCHNL_VLAN_ETHERTYPE_88A8;
	result = ice_vc_valid_vlan_setting_msg(stripping_support, strip_request);
	CHECK_FALSE(result);
}
#endif /* VF_QINQ_SUPPORT */

#ifdef VF_RDMA_SUPPORT
TEST_GROUP_BASE(ice_vf_rdma, TGN(ice_virtchnl))
{
	struct ice_vf *vf;

	void setup()
	{
		TGN(ice_virtchnl)::setup();

		vf = test_add_one_vf(0);
		vf->pf = pf;
	}

	void teardown()
	{
		TGN(ice_virtchnl)::teardown();
	}
};

TEST_GROUP_BASE(ice_vc_clear_rdma_irq_map, TGN(ice_vf_rdma))
{
	TEST_SETUP()
	{
		TGN(ice_vf_rdma)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_vf_rdma)::teardown();
	}
};

TEST(ice_vc_clear_rdma_irq_map, vf_not_active_expect_err_param)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_RELEASE_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_clear_rdma_irq_map(vf);
}

TEST(ice_vc_clear_rdma_irq_map, expect_rdma_irq_map_cleared)
{
	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_RELEASE_RDMA_IRQ_MAP)
		.ignoreOtherParameters();

	USE_STD_MOCK(ice_sriov_clear_rdma_irq_map);
	mock().expectOneCall("ice_sriov_clear_rdma_irq_map")
		.ignoreOtherParameters();

	ice_vc_clear_rdma_irq_map(vf);
}

TEST_GROUP_BASE(ice_sriov_clear_rdma_irq_map, TGN(ice_vf_rdma))
{
	TEST_SETUP()
	{
		TGN(ice_vf_rdma)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_vf_rdma)::teardown();
	}
};

TEST(ice_sriov_clear_rdma_irq_map, expect_calls_to_clear_ceq_and_aeq_mappings)
{
	vf->pf->vfs.num_msix_per = 5;

	USE_STD_MOCK(ice_sriov_clear_ceq_irq_map);
	mock().expectNCalls(5, "ice_sriov_clear_ceq_irq_map");

	USE_STD_MOCK(ice_sriov_clear_aeq_irq_map);
	mock().expectOneCall("ice_sriov_clear_aeq_irq_map");

	ice_sriov_clear_rdma_irq_map(vf);
}

TEST_GROUP_BASE(ice_vc_cfg_rdma_irq_map_msg, TGN(ice_vf_rdma))
{
	struct virtchnl_rdma_qvlist_info *rdma_qvlist;
	u32 num_qvlist_entries = 5;

	TEST_SETUP()
	{
		TGN(ice_vf_rdma)::setup();

		rdma_qvlist = (struct virtchnl_rdma_qvlist_info *)
			calloc(1, sizeof(*rdma_qvlist) +
			       sizeof(struct virtchnl_rdma_qv_info) *
			       (num_qvlist_entries - 1));
	}

	TEST_TEARDOWN()
	{
		free(rdma_qvlist);

		TGN(ice_vf_rdma)::teardown();
	}
};

TEST(ice_vc_cfg_rdma_irq_map_msg, vf_not_active_expect_err_param)
{
	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, num_vectors_greater_than_allowed_expect_send_err_param_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 17;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);

}

TEST(ice_vc_cfg_rdma_irq_map_msg, qvlist_v_idx_greater_than_allowed_expect_send_err_param_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 5;
	rdma_qvlist->qv_info[0].ceq_idx = 0;
	rdma_qvlist->qv_info[0].aeq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].v_idx = vf->pf->vfs.num_msix_per;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, qvlist_ceq_idx_greater_than_allowed_expect_send_err_param_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 5;
	rdma_qvlist->qv_info[0].ceq_idx = vf->pf->vfs.num_msix_per + 1;
	rdma_qvlist->qv_info[0].aeq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].v_idx = vf->pf->vfs.num_msix_per - 1;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, qvlist_aeq_idx_greater_than_allowed_expect_send_err_param_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 5;
	rdma_qvlist->qv_info[0].ceq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].aeq_idx = vf->pf->vfs.num_msix_per;
	rdma_qvlist->qv_info[0].v_idx = 0;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, qvlist_aeq_and_ceq_idx_invalid_expect_send_err_param_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 5;
	rdma_qvlist->qv_info[0].ceq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].aeq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].v_idx = 0;

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_ERR_PARAM)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, expect_rdma_ceq_and_aeq_irq_map_configuration_send_succes_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 5;
	rdma_qvlist->qv_info[0].ceq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
	rdma_qvlist->qv_info[0].aeq_idx = 0;
	rdma_qvlist->qv_info[0].v_idx = 0;

	for (u32 i = 1; i < rdma_qvlist->num_vectors; ++i) {
		rdma_qvlist->qv_info[i].ceq_idx = i;
		rdma_qvlist->qv_info[i].aeq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
		rdma_qvlist->qv_info[i].v_idx = i;
	}

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_sriov_cfg_rdma_ceq_irq_map);
	mock().expectNCalls(4, "ice_sriov_cfg_rdma_ceq_irq_map")
		.ignoreOtherParameters();

	USE_STD_MOCK(ice_sriov_cfg_rdma_aeq_irq_map);
	mock().expectOneCall("ice_sriov_cfg_rdma_aeq_irq_map")
		.ignoreOtherParameters();

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

TEST(ice_vc_cfg_rdma_irq_map_msg, expect_shared_rdma_ceq_and_aeq_irq_map_configuration_send_succes_to_vf)
{
	vf->pf->vfs.num_msix_per = 5;
	rdma_qvlist->num_vectors = 2;
	rdma_qvlist->qv_info[0].ceq_idx = 0;
	rdma_qvlist->qv_info[0].aeq_idx = 0;
	rdma_qvlist->qv_info[0].v_idx = 0;

	for (u32 i = 1; i < rdma_qvlist->num_vectors; ++i) {
		rdma_qvlist->qv_info[i].ceq_idx = i;
		rdma_qvlist->qv_info[i].aeq_idx = VIRTCHNL_RDMA_INVALID_QUEUE_IDX;
		rdma_qvlist->qv_info[i].v_idx = i;
	}

	set_bit(ICE_VF_STATE_ACTIVE, vf->vf_states);

	USE_STD_MOCK(ice_sriov_cfg_rdma_ceq_irq_map);
	mock().expectNCalls(2, "ice_sriov_cfg_rdma_ceq_irq_map")
		.ignoreOtherParameters();

	USE_STD_MOCK(ice_sriov_cfg_rdma_aeq_irq_map);
	mock().expectOneCall("ice_sriov_cfg_rdma_aeq_irq_map")
		.ignoreOtherParameters();

	USE_STD_MOCK(ice_vc_send_msg_to_vf);
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_CONFIG_RDMA_IRQ_MAP)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters();

	ice_vc_cfg_rdma_irq_map_msg(vf, (u8 *)rdma_qvlist);
}

#endif /* VF_RDMA_SUPPORT */
