#ifndef _TDD_SHARED_CODE_TRANSFORM_H
#define _TDD_SHARED_CODE_TRANSFORM_H

#include "sparse/bitmap.h"
#include "kernel_abstract.h"
#include <linux/ioport.h>
#include <linux/pci_regs.h>
#include "linux/math64.h"
#include "linux/preempt.h"

#ifdef ice_bitmap_t
#undef ice_bitmap_t
#endif /* ice_bitmap_t */
#define ice_bitmap_t unsigned long

#ifdef ice_declare_bitmap
#undef ice_declare_bitmap
#endif /* ice_declare_bitmap */
#define ice_declare_bitmap DECLARE_BITMAP

#ifdef ice_is_bit_set
#undef ice_is_bit_set
#endif /* ice_is_bit_set */
static inline bool ice_is_bit_set(ice_bitmap_t *bitmap, unsigned char nr)
{
	return test_bit(nr, bitmap);
}

#endif /* _TDD_SHARED_CODE_TRANSFORM_H */
