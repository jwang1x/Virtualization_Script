#ifndef MOCK_ICE_BITOPS
#define MOCK_ICE_BITOPS

enum ice_status
ice_find_first_bit(const ice_bitmap_t *bitmap, u16 size)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* MOCK_ICE_BITOPS */
