enum ice_status ice_init_dcb(struct ice_hw *hw, bool enable_mib_change)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("enable_mib_change", enable_mib_change);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_set_dcb_cfg(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_get_dcb_cfg(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_query_port_ets(struct ice_port_info *pi,
		   struct ice_aqc_port_ets_elem *buf, u16 buf_size,
		   struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

u8 ice_get_dcbx_status(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (u8)mock().intReturnValue();
}

enum ice_status ice_lldp_to_dcb_cfg(u8 *lldpmib, struct ice_dcbx_cfg *dcbcfg)
{
	mock().actualCall(__func__);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_stop_lldp(struct ice_hw *hw, bool shutdown_lldp_agent,
		 bool persist, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_start_lldp(struct ice_hw *hw, bool persist, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_start_stop_dcbx(struct ice_hw *hw, bool start_dcbx_agent,
		       bool *dcbx_agent_status, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	/* TODO: fix this to use an output parameter */
	*dcbx_agent_status = true;
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status ice_cfg_lldp_mib_change(struct ice_hw *hw, bool ena_mib)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("ena_mib", ena_mib);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_get_dcb_cfg(struct ice_hw *hw, u8 mib_type, u8 bridgetype,
		   struct ice_dcbx_cfg *dcbcfg)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("mib_type", mib_type)
		.withParameter("bridgetype", bridgetype)
		.withParameter("dcbcfg", dcbcfg);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_pfc_mode(struct ice_hw *hw, u8 pfc_mode, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}
