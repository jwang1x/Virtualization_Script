#ifndef MOCK_ICE_DDP
#define MOCK_ICE_DDP


enum ice_status ice_cfg_tx_topo(struct ice_hw *hw, u8 *buf, u32 len)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif
