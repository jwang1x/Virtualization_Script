bool ice_fwlog_supported(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

enum ice_status ice_fwlog_init(struct ice_hw *hw, struct ice_fwlog_cfg *cfg)
{
	mock().actualCall(__func__)
		.withParameter("options", cfg->options);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_fwlog_set(struct ice_hw *hw, struct ice_fwlog_cfg *cfg)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_fwlog_update_modules(struct ice_hw *hw,
			 struct ice_fwlog_module_entry *entries,
			 u16 num_entries)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_fwlog_register(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_fwlog_unregister(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void
ice_fwlog_event_dump(struct ice_hw *hw, struct ice_aq_desc *desc, void *buf)
{
	mock().actualCall(__func__);
}

