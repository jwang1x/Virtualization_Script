enum ice_status
ice_cfg_vsi_bw_lmt_per_tc(struct ice_port_info *pi, u16 vsi_handle, u8 tc,
			  enum ice_rl_type rl_type, u32 bw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_cfg_vsi_bw_dflt_lmt_per_tc(struct ice_port_info *pi, u16 vsi_handle, u8 tc,
			       enum ice_rl_type rl_type)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_cfg_tc_node_bw_lmt(struct ice_port_info *pi, u8 tc,
		       enum ice_rl_type rl_type, u32 bw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_cfg_tc_node_bw_dflt_lmt(struct ice_port_info *pi, u8 tc,
			    enum ice_rl_type rl_type)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_cfg_root_node_bw_lmt(struct ice_port_info *pi, u32 bw,
			 enum ice_rl_type rl_type)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_sched_init_port(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_cfg_pkt_len_adj_profiles(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status ice_sched_add_dflt_l2_nodes(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_sched_set_dflt_cgd_to_tc_map(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_sched_copy_cgd(struct ice_port_info *src, struct ice_port_info *dst, u8 num_cgd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_sched_clear_l2_nodes(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_sched_clear_port(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
}

void ice_sched_cleanup_all(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status ice_rm_vsi_lan_cfg(struct ice_port_info *pi, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_rm_vsi_rdma_cfg(struct ice_port_info *pi, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

struct ice_sched_node *ice_sched_get_node(struct ice_port_info *pi,
						 u32 teid)
{
	mock().actualCall(__func__);
	return (ice_sched_node *)mock().pointerReturnValue();
}

enum ice_status
ice_move_vsi_to_agg(struct ice_port_info *pi, u32 agg_id, u16 vsi_handle,
                    u8 tc_bitmap)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_cfg_agg(struct ice_port_info *pi, u32 agg_id, enum ice_agg_type agg_type,
            u8 tc_bitmap)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_cfg_l2_node_cgd(struct ice_hw *hw, u16 num_l2_nodes,
		       struct ice_aqc_cfg_l2_node_cgd_elem *buf,
		       u16 buf_size, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_cfg_q_bw_lmt(struct ice_port_info *pi, u16 vsi_handle, u8 tc,
		 u16 q_handle, enum ice_rl_type rl_type, u32 bw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
enum ice_status
ice_cfg_q_bw_dflt_lmt(struct ice_port_info *pi, u16 vsi_handle, u8 tc,
		      u16 q_handle, enum ice_rl_type rl_type)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}