enum ice_status ice_init_nvm(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_acquire_nvm(struct ice_hw *hw,
                                     enum ice_aq_res_access_type access)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

void ice_release_nvm(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_read_sr_word(struct ice_hw *hw, u16 offset, u16 *data)
{
	mock().actualCall(__func__)
		.withOutputParameter("data", data);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_read_sr_buf(struct ice_hw *hw, u16 offset, u16 *words, u16 *data)
{
	mock().actualCall(__func__)
		.withParameter("offset", offset)
		.withOutputParameter("words", words)
		.withOutputParameter("data", data);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_calc_sr_checksum(struct ice_hw *hw, u16 *checksum)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_update_sr_checksum(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_validate_sr_checksum(struct ice_hw *hw, u16 *checksum)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_nvm_validate_checksum(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status ice_handle_nvm_access(struct ice_hw *hw,
				      struct ice_nvm_access_cmd *cmd,
				      union ice_nvm_access_data *data)
{
	mock().actualCall(__func__)
		.withParameter("cmd", cmd)
		.withParameter("data", data)
		.withOutputParameter("data", data);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_aq_read_nvm(struct ice_hw *hw, u16 module_typeid,
		u32 offset, u16 length, void *data, bool last_command,
		bool read_shadow_ram, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("offset", offset)
		.withParameter("length", length)
		.withOutputParameter("data", data);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_read_flat_nvm(struct ice_hw *hw, u32 offset, u32 *length, u8 *data,
		  bool read_shadow_ram)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("offset", offset)
		.withParameter("length", *length)
		.withOutputParameter("length", length)
		.withOutputParameter("data", data)
		.withParameter("read_shadow_ram", read_shadow_ram);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_nvm_set_pkg_data(struct ice_hw *hw, bool del_pkg_data_flag, u8 *data,
		     u16 length, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", del_pkg_data_flag)
		.withParameter("data", data, length)
		.withParameter("length", length)
		.withParameter("cd", cd);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_nvm_pass_component_tbl(struct ice_hw *hw, u8 *data, u16 length,
			   u8 transfer_flag, u8 *comp_response,
			   u8 *comp_response_code, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("data", data, length)
		.withParameter("length", length)
		.withParameter("transfer_flag", transfer_flag)
		.withOutputParameter("comp_response", comp_response)
		.withOutputParameter("comp_response_code", comp_response_code)
		.withParameter("cd", cd);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_update_nvm(struct ice_hw *hw, u16 module_typeid, u32 offset,
		  u16 length, void *data, bool last_command, u8 command_flags,
		  struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("module_typeid", module_typeid)
		.withParameter("offset", offset)
		.withParameter("length", length)
		.withParameter("data", (u8 *)data, length)
		.withParameter("last_command", last_command)
		.withParameter("command_flags", command_flags)
		.withParameter("cd", cd);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_erase_nvm(struct ice_hw *hw, u16 module_typeid, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("module_typeid", module_typeid)
		.withParameter("cd", cd);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_nvm_write_activate(struct ice_hw *hw, u16 cmd_flags, u8 *response_flags)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameter("response_flags", response_flags);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_aq_nvm_update_empr(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_get_nvm_minsrevs(struct ice_hw *hw, struct ice_minsrev_info *minsrevs)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("minsrevs", minsrevs);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_update_nvm_minsrevs(struct ice_hw *hw, struct ice_minsrev_info *minsrevs)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("minsrevs", (u8 *)minsrevs, sizeof(*minsrevs));

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_get_inactive_orom_ver(struct ice_hw *hw, struct ice_orom_info *orom)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("orom", orom);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_get_inactive_nvm_ver(struct ice_hw *hw, struct ice_nvm_info *nvm)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("nvm", nvm);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_get_inactive_netlist_ver(struct ice_hw *hw, struct ice_netlist_info *netlist)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("netlist", netlist);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
