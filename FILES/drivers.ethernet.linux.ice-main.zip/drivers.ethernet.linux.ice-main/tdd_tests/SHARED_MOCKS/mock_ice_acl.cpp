#ifndef MOCK_ICE_ACL
#define MOCK_ICE_ACL

#ifndef NO_ACL_SUPPORT
enum ice_status
ice_acl_create_tbl(struct ice_hw *hw, struct ice_acl_tbl_params *params)
{
	int retval;

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	return (enum ice_status)retval;
}

enum ice_status ice_acl_destroy_tbl(struct ice_hw *hw)
{
	int retval;

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	return (enum ice_status)retval;
}

enum ice_status
ice_acl_create_scen(struct ice_hw *hw, u16 match_width, u16 num_entries,
		    u16 *scen_id)
{
	int retval;

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	return (enum ice_status)retval;
}

#ifdef DCF_SUPPORT
bool ice_is_acl_empty(struct ice_hw *hw)
{
	return true;
}
#endif
#endif /* !NO_ACL_SUPPORT */
#endif /*  MOCK_ICE_ACL */
