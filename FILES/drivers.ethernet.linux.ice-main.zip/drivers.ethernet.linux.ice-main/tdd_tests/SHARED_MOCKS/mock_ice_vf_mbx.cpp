#include "ice_vf_mbx.h"
#include "../src/CORE/ice_sriov.h"

#ifdef CONFIG_PCI_IOV
enum ice_status
ice_aq_send_msg_to_pf(struct ice_hw *hw, enum virtchnl_ops v_opcode,
		      enum ice_status v_retval, u8 *msg, u16 msglen,
		      struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_send_msg_to_vf(struct ice_hw *hw, u16 vfid, u32 v_opcode,
		      u32 v_retval, u8 *msg, u16 msglen,
		      struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("vfid", vfid)
		.withParameter("v_opcode", v_opcode)
		.withParameter("v_retval", v_retval)
		.withParameter("msg", msg, msglen)
		.withParameter("msglen", msglen);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_mbx_vf_state_handler(struct ice_hw *hw, struct ice_mbx_data *mbx_data,
			 u16 vf_id, bool *is_malvf)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

/* the type of all_malvfs is different from what is in ice_vf_mbx.c because
 * ice_bitmap_t is different between the core and shared code. The difference
 * doesn't manifest when building the driver because the code in shared code
 * gets transformed to be the same as in the driver. When we build the TDD code
 * the difference shows up with an error if all_malvfs is declared as an
 * ice_bitmap_t that looks like:
 *
 * In file included from test_ice_sriov.cpp:43:
 * ../src/CORE/ice_sriov.c: In function ‘bool ns_virtchnl::ice_is_malicious_vf(ns_virtchnl::ice_pf*, ns_virtchnl::ice_rq_event_info*, ns_virtchnl::u16, ns_virtchnl::u16)’:
 * ../src/CORE/ice_sriov.c:9115:46: error: cannot convert ‘long unsigned int*’ to ‘ns_virtchnl::ice_bitmap_t*’ {aka ‘unsigned int*’}
 * 9115 |   status = ice_mbx_report_malvf(&pf->hw, pf->malvfs,
 *     |                                          ~~~~^~~~~~
 *     |                                              |
 *     |                                              long unsigned int*
 *
 * Solve this by using long unsigned int instead of ice_bitmap_t
 */
enum ice_status
ice_mbx_report_malvf(struct ice_hw *hw, long unsigned int *all_malvfs,
                     u16 bitmap_len, u16 vf_id, bool *report_malvf)
{
        mock().actualCall(__func__);
        return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_mbx_clear_malvf(struct ice_mbx_snapshot *mbx_snapshot, long unsigned int *all_malvfs,
		    u16 bitmap_len, u16 vf_id)
{
	mock().actualCall(__func__);
        return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_mbx_init_snapshot(struct ice_hw *hw, u16 vf_count)
{
        mock().actualCall(__func__)
		.withParameter("vf_count", vf_count);
        return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_mbx_deinit_snapshot(struct ice_hw *hw)
{
        mock().actualCall(__func__);
}
#endif /* CONFIG_PCI_IOV */
