enum ice_status ice_create_tunnel(struct ice_hw *hw, enum ice_tunnel_type type,
				  u16 port)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

static bool
ice_get_open_tunnel_port(struct ice_hw *hw, enum ice_tunnel_type type,
			 u16 *port)
{
	*port = 999;
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_tunnel_port_in_use(struct ice_hw *hw, u16 port, u16 *index)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status ice_is_create_tunnel_possible(struct ice_hw *hw, enum ice_tunnel_type type,
					      u16 port)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_destroy_tunnel(struct ice_hw *hw, u16 port, bool all)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_vsig_update_xlt2(struct ice_hw *hw, enum ice_block blk)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_vsig_find_vsi(struct ice_hw *hw, enum ice_block blk, u16 vsi, u16 *vsig)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_vsig_add_mv_vsi(struct ice_hw *hw, enum ice_block blk, u16 vsi, u16 vsig)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_fill_blk_tbls(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_ddp_state
ice_copy_and_init_pkg(struct ice_hw *hw, const u8 *buf, u32 len)
{
	mock().actualCall(__func__);
	return (enum ice_ddp_state)mock().returnIntValueOrDefault(0);
}

enum ice_ddp_state
ice_init_pkg(struct ice_hw *hw, u8 *buf, u32 len)
{
	mock().actualCall(__func__);
	return (enum ice_ddp_state)mock().returnIntValueOrDefault(0);
}

bool ice_is_init_pkg_successful(enum ice_ddp_state state)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status ice_init_hw_tbls(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
void ice_free_hw_tbls(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}
void ice_clear_hw_tbls(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}
enum ice_status
ice_rem_prof_id_flow(struct ice_hw *hw, enum ice_block blk, u16 vsi, u64 hdl)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#ifdef DCF_SUPPORT
bool ice_is_tunnel_empty(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}
#endif
#if defined(DPDK_SUPPORT) || defined(ADV_AVF_SUPPORT)
bool ice_hw_ptype_ena(struct ice_hw *hw, u16 ptype)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}
#endif /* DPDK_SUPPORT || ADV_AVF_SUPPORT */

#if defined(DPDK_SUPPORT) || defined(ADV_AVF_SUPPORT) || defined(SWITCH_MODE) && !defined(BMSM_MODE)
void ice_init_all_prof_masks(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}
#endif

#ifdef VLAN2PDU_SUPPORT
void ice_vlan2pdu_create(struct ice_hw *hw, enum ice_vlan2pdu_type type,
			 u16 vlan_id, int index)
{
	mock().actualCall(__func__);
}
#endif

enum ice_status
ice_rem_prof(struct ice_hw *hw, enum ice_block blk, u64 id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
