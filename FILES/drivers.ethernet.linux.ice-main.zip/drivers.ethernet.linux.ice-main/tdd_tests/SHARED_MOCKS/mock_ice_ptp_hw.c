/* Include PTP constants */
#include "../src/SHARED/ice_ptp_consts.h"
#include "ice_ptp_hw.h"

/* Device agnostic functions */
u8 ice_get_ptp_src_clock_index(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnIntValueOrDefault(0);
}

u64 ice_ptp_read_src_incval(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnLongIntValueOrDefault(0);
}

bool ice_ptp_lock(struct ice_hw *hw)
{
	if (mock().hasData("ptp_lock_canary") &&
	    mock().getData("ptp_lock_canary").getPointerValue()) {
		FAIL("ptp lock was previously acquired");
		return false;
	}

	/* Allocate some memory on lock that must be freed by calling
	 * ice_ptp_unlock. This enables use of the memory leak detection to
	 * verify that the lock is released by all tests.
	 */
	mock().setData("ptp_lock_canary", (void *)(new char()));

	return true;
}

void ice_ptp_unlock(struct ice_hw *hw)
{
	if (!mock().hasData("ptp_lock_canary") ||
	    !mock().getData("ptp_lock_canary").getPointerValue()) {
		FAIL("ptp lock was not previously acquired");
	}

	/* Release the previously allocated memory. This lets us use the
	 * memory leak detector to verify that the lock was properly released
	 */
	delete (char *)mock().getData("ptp_lock_canary").getPointerValue();
}

void ice_ptp_src_cmd(struct ice_hw *hw, enum ice_ptp_tmr_cmd cmd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("cmd", cmd);
}

enum ice_status ice_ptp_init_time(struct ice_hw *hw, u64 time)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("time", time);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_ptp_write_incval(struct ice_hw *hw, u64 incval)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("incval", incval);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_ptp_write_incval_locked(struct ice_hw *hw, u64 incval)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("incval", incval);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_ptp_adj_clock(struct ice_hw *hw, s32 adj, bool lock_sbq)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("adj", adj)
		.withParameter("lock_sbq", lock_sbq);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ptp_adj_clock_at_time(struct ice_hw *hw, u64 at_time, s32 adj)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("at_time", at_time)
		.withParameter("adj", adj);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_read_phy_tstamp(struct ice_hw *hw, u8 block, u8 idx, u64 *tstamp)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("block", block)
		.withParameter("idx", idx)
		.withOutputParameter("tstamp", tstamp);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_clear_phy_tstamp(struct ice_hw *hw, u8 block, u8 idx)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("block", block)
		.withParameter("idx", idx);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}


/* E822 family functions */
enum ice_status
ice_read_phy_reg_e822(struct ice_hw *hw, u8 port, u16 offset, u32 *val)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withParameter("offset", offset)
		.withOutputParameter("val", val);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_write_phy_reg_e822(struct ice_hw *hw, u8 port, u16 offset, u32 val)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withParameter("offset", offset)
		.withParameter("val", val);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_read_quad_reg_e822(struct ice_hw *hw, u8 quad, u16 offset, u32 *val)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("quad", quad)
		.withParameter("offset", offset)
		.withOutputParameter("val", val);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_write_quad_reg_e822(struct ice_hw *hw, u8 quad, u16 offset, u32 val)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("quad", quad)
		.withParameter("offset", offset)
		.withParameter("val", val);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ptp_prep_port_adj_e822(struct ice_hw *hw, u8 port, s64 time,
			   bool lock_sbq)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withParameter("time", time)
		.withParameter("lock_sbq", lock_sbq);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ptp_read_phy_incval_e822(struct ice_hw *hw, u8 port, u64 *incval)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withOutputParameter("incval", incval);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ptp_read_port_capture_e822(struct ice_hw *hw, u8 port, u64 *tx_ts,
			       u64 *rx_ts)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withOutputParameter("tx_ts", tx_ts)
		.withOutputParameter("rx_ts", rx_ts);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ptp_one_port_cmd_e822(struct ice_hw *hw, u8 port, enum ice_ptp_tmr_cmd cmd,
			  bool lock_sbq)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withParameter("cmd", cmd)
		.withParameter("lock_sbq", lock_sbq);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

/* E822 Vernier calibration functions */
enum ice_status ice_ptp_set_vernier_wl(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_phy_get_speed_and_fec_e822(struct ice_hw *hw, u8 port,
			       enum ice_ptp_link_spd *link_out,
			       enum ice_ptp_fec_mode *fec_out)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("link_out", link_out)
		.withOutputParameter("fec_out", fec_out);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_phy_cfg_lane_e822(struct ice_hw *hw, u8 port)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port);
}

#if defined(E810C_SUPPORT) || defined(E810_XXV_SUPPORT)
/* E810 family functions */
enum ice_status ice_ptp_init_phy_e810(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* E810C_SUPPORT || E810_XXV_SUPPORT */

enum ice_status ice_ptp_init_phc(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_stop_phy_timer_e822(struct ice_hw *hw, u8 port, bool soft_reset)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port)
		.withParameter("soft_reset", soft_reset);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_start_phy_timer_e822(struct ice_hw *hw, u8 port)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_phy_cfg_tx_offset_e822(struct ice_hw *hw, u8 port)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_phy_cfg_rx_offset_e822(struct ice_hw *hw, u8 port)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_phy_calc_vernier_e822(struct ice_hw *hw, u8 port)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("port", port);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_ptp_cgu_err_reporting_e810t(struct ice_hw *hw, bool enable)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("enable", enable);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

#ifdef SYNCE_SUPPORT
const char *ice_zl_pin_idx_to_name_e810t(u8 pin)
{
	mock().actualCall(__func__)
		.withParameter("pin", pin);

	return "invalid";
}

const char *ice_pin_idx_to_name_e823(struct ice_hw *hw, u8 pin)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("pin", pin);

	return "invalid";
}

const char *ice_cgu_state_to_name(int state)
{
	mock().actualCall(__func__)
		.withParameter("state", state);

	return "invalid";
}

enum ice_cgu_state
ice_get_cgu_state(struct ice_hw *hw, u8 dpll_idx, u8 *pin, s64 *phase_offset,
		  enum ice_cgu_state last_dpll_state)
{
	return ICE_CGU_STATE_FREERUN;
}
#endif /* SYNCE_SUPPORT */

bool ice_is_pca9575_present(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return (enum ice_status)mock().returnBoolValueOrDefault(false);
}

enum ice_status ice_write_sma_ctrl_e810t(struct ice_hw *hw, u8 data)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("data", data);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status ice_read_sma_ctrl_e810t(struct ice_hw *hw, u8 *data)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("data", data);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

#ifdef CGU_SUPPORT
bool ice_is_gps_present_e810t(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnBoolValueOrDefault(false);
}

bool ice_is_cgu_present(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnBoolValueOrDefault(false);
}
bool ice_is_phy_rclk_present(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnBoolValueOrDefault(false);
}
bool ice_is_clock_mux_present_e810t(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return mock().returnBoolValueOrDefault(false);
}
#endif /* CGU_SUPPORT */

enum ice_status
ice_ptp_init_phy_cfg(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_get_pf_c827_idx(struct ice_hw *hw, u8 *phy)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("phy", phy);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

void
ice_ptp_process_cgu_err(struct ice_hw *hw, struct ice_rq_event_info *event)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("event", event);
}
void ice_ptp_reset_ts_memory_quad_e822(struct ice_hw *hw, u8 quad)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("quad", quad);
}

void ice_ptp_reset_ts_memory(struct ice_hw *hw)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw);
}

enum ice_status
ice_get_phy_tx_tstamp_ready(struct ice_hw *hw, u8 block, u64 *tstamp_ready)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("block", block)
		.withOutputParameter("tstamp_ready", tstamp_ready);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}
