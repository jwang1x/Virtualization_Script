#ifndef MOCK_ICE_PARSER
#define MOCK_ICE_PARSER

enum ice_status
ice_parser_create(struct ice_hw *hw, struct ice_parser **psr)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_parser_vxlan_tunnel_set(struct ice_parser *psr,
			    u16 udp_port, bool on)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_parser_run(struct ice_parser *psr, const u8 *pkt_buf,
	       int pkt_len, struct ice_parser_result *rslt)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_parser_profile_init(struct ice_parser_result *rslt,
			const u8 *pkt_buf, const u8 *msk_buf,
			int buf_len, enum ice_block blk,
			bool prefix_match,
			struct ice_parser_profile *prof)
{
    mock().actualCall(__func__);
    return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_parser_destroy(struct ice_parser *psr)
{
    mock().actualCall(__func__);
}
#endif /* MOCK_ICE_PARSER */
