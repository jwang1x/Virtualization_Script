#ifndef MOCK_ICE_FDIR
#define MOCK_ICE_FDIR

#ifdef FDIR_SUPPORT
enum ice_status ice_alloc_fd_res_cntr(struct ice_hw *hw, u16 *cntr_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_free_fd_res_cntr(struct ice_hw *hw, u16 cntr_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_alloc_fd_guar_item(struct ice_hw *hw, u16 *cntr_id, u16 num_fltrs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_free_fd_guar_item(struct ice_hw *hw, u16 cntr_id, u16 num_fltrs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_alloc_fd_shrd_item(struct ice_hw *hw, u16 *cntr_id, u16 num_fltrs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_free_fd_shrd_item(struct ice_hw *hw, u16 cntr_id, u16 num_fltrs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void
ice_set_fd_desc_val(struct ice_fd_fltr_desc_ctx *fd_fltr_ctx,
		    struct ice_fltr_desc *fdir_desc)
{
	mock().actualCall(__func__);
}

int
ice_get_fdir_cnt_all(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

int
ice_add_del_fdir(struct ice_hw *hw, struct ice_fdir_fltr *input, bool add)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}

void
ice_fdir_get_prgm_desc(struct ice_hw *hw, struct ice_fdir_fltr *input,
		       struct ice_fltr_desc *fdesc, bool add)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_fdir_get_gen_prgm_pkt(struct ice_hw *hw, struct ice_fdir_fltr *input,
			  u8 *pkt, bool frag, bool tun)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_fdir_get_prgm_pkt(struct ice_fdir_fltr *input, u8 *pkt, bool frag)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

bool ice_fdir_has_frag(enum ice_fltr_ptype flow)
{
	mock().actualCall(__func__);
	return mock().boolReturnValue();
}

struct ice_fdir_fltr *
ice_fdir_find_fltr_by_idx(struct ice_hw *hw, u32 fltr_idx)
{
	mock().actualCall(__func__);
	return (struct ice_fdir_fltr *)mock().returnPointerValueOrDefault(NULL);
}

void ice_fdir_list_add_fltr(struct ice_hw *hw, struct ice_fdir_fltr *fltr)
{
	if (hw && fltr)
		LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	mock().actualCall(__func__);
}

void ice_fdir_list_rem_fltr(struct ice_hw *hw, struct ice_fdir_fltr *fltr)
{
	if (hw && fltr) {
		struct ice_fdir_fltr *rule = NULL;
		struct ice_fdir_fltr *tmp = NULL;

		LIST_FOR_EACH_ENTRY_SAFE(rule, tmp, &hw->fdir_list_head,
					 ice_fdir_fltr, fltr_node)
			if (rule->fltr_id == fltr->fltr_id) {
				LIST_DEL(&rule->fltr_node);
				free(rule);
			}
	}

	mock().actualCall(__func__);
}

void ice_fdir_update_cntrs(struct ice_hw *hw, enum ice_fltr_ptype flow,
			   bool acl_fltr, bool add)
{
	mock().actualCall(__func__);
}

bool ice_fdir_is_dup_fltr(struct ice_hw *hw, struct ice_fdir_fltr *input)
{
	mock().actualCall(__func__);
	return mock().boolReturnValue();
}

void ice_set_dflt_val_fd_desc(struct ice_fd_fltr_desc_ctx *fd_fltr_ctx)
{
	mock().actualCall(__func__);
}

enum ice_status ice_clear_vsi_fd_table(struct ice_hw *hw, u16 vsi_num)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* FDIR_SUPPORT */
#endif /*  MOCK_ICE_FDIR */
