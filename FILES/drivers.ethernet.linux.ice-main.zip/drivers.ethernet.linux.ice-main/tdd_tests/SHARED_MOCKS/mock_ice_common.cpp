#include "ice_type.h"
#include "../src/SHARED/virtchnl/virtchnl.h"

/* this is one value to control the total number of
 * MSI-X vectors being returned and used in multiple
 * places.  Can be changed by tests.
 */
int global_vector_count = 0;
static ice_hw *global_hw;

void ice_set_umac_shared(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status ice_init_hw(struct ice_hw *hw)
{
	int retval, num_port_infos;
	u8 mac[ETH_ALEN] = { 0x01, 0x00, 0xa, 0xb, 0xc, 0x0 };

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	/* this is so we can do something with the hw struct from
	 * the tests, using a global reference.

	 */
	global_hw = hw;

	/* if error case, don't leave memory allocated */
	if (retval == 0) {
		hw->func_caps.common_cap.num_msix_vectors = global_vector_count;
#ifndef NO_DCB_SUPPORT
		hw->func_caps.common_cap.dcb = true;
#endif /* !NO_DCB_SUPPORT */
		hw->func_caps.guar_num_vsi = 384;

#ifdef SWITCH_MODE
#ifdef BMSM_MODE
		hw->ena_lports = GENMASK(7, 0);
		hw->num_lports = 8;
#else /* !BMSM_MODE */
		/* Not sure why, but num_lports is one less than the number of
		 * ports set in the ena_lports. Changing this results in
		 * a crash..
		 */
		hw->ena_lports = GENMASK(20, 0);
		hw->num_lports = 20;
#endif
		hw->num_total_ports = hw->num_lports + 1;
		num_port_infos = 21;
#else /* !SWITCH_MODE */
		num_port_infos = 1;
#endif

		hw->port_info = new struct ice_port_info[num_port_infos]();

		for (int i = 0; i < num_port_infos; i++) {
#ifdef SWITCH_MODE
			if (!(hw->ena_lports & BIT(i)))
				continue;
#endif /* SWITCH_MODE */

			hw->port_info[i].hw = hw;

			memcpy(hw->port_info[i].mac.lan_addr, mac, ETH_ALEN);
			memcpy(hw->port_info[i].mac.perm_addr, mac, ETH_ALEN);
		}

#ifdef FDIR_SUPPORT
		hw->func_caps.fd_fltr_guar = 1;
		hw->func_caps.fd_fltr_best_effort = 1;
#endif
#ifdef SWITCH_MODE
		hw->func_caps.common_cap.num_txq = 256;
		hw->func_caps.common_cap.num_rxq = 256;
#ifdef BMSM_MODE
		/* hide internal port so vsi is not created */
		hw->port_info[8].is_internal_port = true;
#endif
#else
		hw->func_caps.common_cap.num_txq = 256;
		hw->func_caps.common_cap.num_rxq = 256;
#endif
		/* set gran values to non-zero to avoid divide by zero */
		hw->itr_gran = ICE_ITR_GRAN_ABOVE_25;
		hw->intrl_gran = ICE_INTRL_GRAN_ABOVE_25;
		/* printf("made port info %p\n", hw->port_info); */
	}

	return (enum ice_status)retval;
}

void ice_deinit_hw(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	if (hw->port_info)
		delete [] hw->port_info;
}

#ifndef SWITCH_MODE
enum ice_status ice_pf_reset(struct ice_hw *hw)
{
         mock().actualCall(__func__);
         return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

enum ice_status ice_check_reset(struct ice_hw *hw)
{
         mock().actualCall(__func__);
         return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_reset(struct ice_hw *hw, enum ice_reset_req req)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_clear_pf_cfg(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_read_pba_string(struct ice_hw *hw, u8 *pba_num,
					 u32 pba_num_size)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("pba_num", pba_num)
		.withParameter("pba_num_size", pba_num_size);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_copy_rxq_ctx_to_hw(struct ice_hw *hw, u8 *ice_rxq_ctx, u32 rxq_index){
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_write_rxq_ctx(struct ice_hw *hw, struct ice_rlan_ctx *rlan_ctx,
		      u32 rxq_index)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_clear_rxq_ctx(struct ice_hw *hw, u32 rxq_index)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_copy_tx_cmpltnq_ctx_to_hw(struct ice_hw *hw, u8 *ice_tx_cmpltnq_ctx,
				  u32 tx_cmpltnq_index)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_write_tx_cmpltnq_ctx(struct ice_hw *hw,
			     struct ice_tx_cmpltnq_ctx *tx_cmpltnq_ctx,
			     u32 tx_cmpltnq_index)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_clear_tx_cmpltnq_ctx(struct ice_hw *hw,
						  u32 tx_cmpltnq_index)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_req_res(struct ice_hw *hw, enum ice_aq_res_ids res,
	       enum ice_aq_res_access_type access, u8 sdp_number,
	       u32 *timeout, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_release_res(struct ice_hw *hw, enum ice_aq_res_ids res,
			u8 sdp_number, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_acquire_res(struct ice_hw *hw, enum ice_aq_res_ids res,
		     enum ice_aq_res_access_type access)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_release_res(struct ice_hw *hw, enum ice_aq_res_ids res)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_aq_manage_mac_read(struct ice_hw *hw, void *buff, u16 buf_size,
		       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
#ifdef SWITCH_MODE
ice_aq_manage_mac_write(struct ice_hw *hw, u8 *mac_addr, u8 port_num, u8 flags,
			struct ice_sq_cd *cd)
#else
ice_aq_manage_mac_write(struct ice_hw *hw, u8 *mac_addr, u8 flags,
			struct ice_sq_cd *cd)
#endif
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_clear_pxe_mode(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_get_link_status(struct ice_port_info *pi, bool *link_up)
{
	mock().actualCall(__func__)
		.withOutputParameterOfType("bool *", "link_up", link_up);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_update_link_info(struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_aq_get_rss_lut(struct ice_hw *hw, struct ice_aq_get_set_rss_lut_params *params)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_aq_set_rss_lut(struct ice_hw *hw, struct ice_aq_get_set_rss_lut_params *params)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_get_rss_key(struct ice_hw *hw, u16 vsi_id,
		   struct ice_aqc_get_set_rss_keys *key)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_set_rss_key(struct ice_hw *hw, u16 vsi_id,
		   struct ice_aqc_get_set_rss_keys *key)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_add_lan_txq(struct ice_hw *hw, u8 num_q_groups,
		   struct ice_aqc_add_tx_qgrp_data *qg_list,
		   u16 buf_size, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifndef SIMICS_SUPPORT
enum ice_status
ice_aq_dis_lan_txq(struct ice_hw *hw, u8 num_q_groups,
		       struct ice_aqc_dis_txq_item *qg_list,
		       u16 buf_size,
#if defined(FPGA_F7_SUPPORT) || defined(FPGA_F8_SUPPORT)
		       u16 tag,
#endif
		       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#else
enum ice_status
ice_aq_dis_lan_txq(struct ice_hw *hw,
		       struct ice_aqc_dis_txq_data *data,
		       u16 count, u16 tag,
		       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* !SIMICS_SUPPORT */

enum ice_status
ice_aq_add_rdma_qsets(struct ice_hw *hw, u8 num_qset_groups,
		      struct ice_aqc_add_rdma_qset_data *qset_list,
		      u16 buf_size, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_set_ctx(struct ice_hw *hw, u8 *src_ctx, u8 *dest_ctx,
			    const struct ice_ctx_ele *ce_info)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_get_internal_data(struct ice_hw *hw, u8 cluster_id, u16 table_id,
			 u32 start, void *buf, u16 buf_size, u16 *ret_buf_size,
			 u16 *ret_next_table, u32 *ret_next_index,
			 struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_set_mac_cfg(struct ice_hw *hw, u16 max_frame_size, bool auto_drop,
		   struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_dump_port_topo(struct ice_hw *hw, u8 port_num)
{
	mock().actualCall(__func__);
}

enum ice_status ice_dump_sw_cfg(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_dump_caps(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_dump_port_info(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

enum ice_status ice_get_ctx(u8 *src_ctx, u8 *dest_ctx,
				 struct ice_ctx_ele *ce_info)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}


enum ice_status ice_init_all_ctrlq(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_shutdown_all_ctrlq(struct ice_hw *hw, bool unloading)
{
	mock().actualCall(__func__);
}

enum ice_status ice_get_caps(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ena_vsi_rdma_qset(struct ice_port_info *pi,
		      u16 vsi_handle, u8 tc, u16 *rdma_qset, u16 num_qsets,
		      u32 *qset_teid)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_ena_vsi_txq(struct ice_port_info *pi, u16 vsi_handle, u8 tc, u16 q_handle,
		u8 num_q_groups, struct ice_aqc_add_tx_qgrp *buff,
		u16 buf_size, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_dis_vsi_txq(struct ice_port_info *pi, u16 vsi_handle, u8 tc, u8 num_queues,
		u16 *q_handles, u16 *q_ids, u32 *q_teids,
		enum ice_disq_rst_src rst_src, u16 vmvf_num,
		struct ice_sq_cd *cmd_details)
{
	mock().actualCall(__func__)
		.withIntParameter("num_queues", num_queues);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_cfg_fw_log(struct ice_hw *hw, bool enable)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_output_fw_log(struct ice_hw *hw, struct ice_aq_desc *desc, void *buf)
{
	mock().actualCall(__func__);
}

#ifndef NO_RECOVERY_MODE_SUPPORT
enum ice_fw_modes ice_get_fw_mode(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_fw_modes)
		mock().returnIntValueOrDefault(ICE_FW_MODE_NORMAL);
}
#endif

enum ice_status
ice_aq_set_event_mask(struct ice_hw *hw, u8 port_num, u16 mask, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_get_link_info(struct ice_port_info *pi, bool ena_lse,
		     struct ice_link_status *link, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status) mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_cfg_vsi_lan(struct ice_port_info *pi, u16 vsi_handle,
		u16 tc_bitmap, u16 *max_lanqs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_cfg_vsi_rdma(struct ice_port_info *pi, u16 vsi_handle,
		 u16 tc_bitmap, u16 *max_rdmaqs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

struct ice_port_info *ice_find_port_info(struct ice_hw *hw, u8 lport)
{
	mock().actualCall(__func__);
	return (ice_port_info *)mock().returnPointerValueOrDefault(NULL);
}

s8 ice_find_port_info_idx(struct ice_hw *hw, u8 lport)
{
	mock().actualCall(__func__);
	return (s8)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_set_link_restart_an(struct ice_port_info *pi, bool ena_link,
			   struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_fc_mode ice_caps_to_fc_mode(u8 caps)
{
	mock().actualCall(__func__);
	return (enum ice_fc_mode)mock().returnIntValueOrDefault(0);
}

enum ice_fec_mode ice_caps_to_fec_mode(u8 caps, u8 fec_options)
{
	mock().actualCall(__func__);
	return (enum ice_fec_mode)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_set_fc(struct ice_port_info *pi, u8 *aq_failures, bool atomic_restart)
{
	mock().actualCall(__func__)
		.withOutputParameter("aq_failures", aq_failures);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_sbq_rw_reg(struct ice_hw *hw, ice_sbq_msg_input *msg)
{
	msg->data = 0;
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_sbq_rw_reg_lp(struct ice_hw *hw, ice_sbq_msg_input *msg, bool lock)
{
	msg->data = 0;
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_sbq_lock(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_sbq_unlock(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

bool ice_is_100m_speed_supported(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

u32 ice_conv_link_speed_to_virtchnl(bool adv_link_support, u16 link_speed)
{
	mock().actualCall(__func__)
		.withParameter("adv_link_support", adv_link_support)
		.withParameter("link_speed", link_speed);

	if (adv_link_support)
		return mock().returnUnsignedIntValueOrDefault(ICE_LINK_SPEED_UNKNOWN);
	else
		return mock().returnUnsignedIntValueOrDefault((u32)VIRTCHNL_LINK_SPEED_UNKNOWN);
}

#ifndef NO_UNUSED_SCHED_CODE
enum ice_status
ice_cfg_q_bw_lmt(struct ice_port_info *pi, u32 q_id, enum ice_rl_type rl_type,
		 u32 bw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* !NO_UNUSED_SCHED_CODE */

enum ice_status
ice_aq_get_phy_caps(struct ice_port_info *pi, bool qual_mods, u8 report_mode,
		    struct ice_aqc_get_phy_caps_data *pcaps,
	    	    struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withOutputParameterOfType("struct ice_aqc_get_phy_caps_data *",
					   "pcaps", pcaps);

	if (report_mode == ICE_AQC_REPORT_TOPO_CAP_MEDIA) {
		pi->phy.phy_type_low = LE64_TO_CPU(pcaps->phy_type_low);
		pi->phy.phy_type_high = LE64_TO_CPU(pcaps->phy_type_high);
	}

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_phy_cfg(struct ice_hw *hw, struct ice_port_info *pi,
		   struct ice_aqc_set_phy_cfg_data *cfg, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameterOfType("struct ice_aqc_set_phy_cfg_data *", "cfg",
				     cfg);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

void ice_update_phy_type(u64 *phy_type_low, u64 *phy_type_high,
			 u16 link_speeds_bitmap)
{
	mock().actualCall(__func__)
		.withOutputParameter("phy_type_low", phy_type_low)
		.withOutputParameter("phy_type_high", phy_type_high)
                .withParameter("link_speeds_bitmap", link_speeds_bitmap);
}

enum ice_status
#ifdef BMSM_MODE
ice_replay_vsi(struct ice_hw *hw, u16 vsi_idx, u8 lport)
#else
ice_replay_vsi(struct ice_hw *hw, u16 vsi_idx)
#endif
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

void ice_replay_post(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_stat_update40(struct ice_hw *hw, u32 reg, bool prev_stat_loaded,
		       u64 *prev_stat, u64 *cur_stat)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("reg", reg)
		.withParameter("prev_stat_loaded", prev_stat_loaded)
		.withOutputParameter("prev_stat", prev_stat)
		.withOutputParameter("cur_stat", cur_stat);
}

void ice_stat_update32(struct ice_hw *hw, u32 reg, bool prev_stat_loaded,
		       u64 *prev_stat, u64 *cur_stat)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("reg", reg)
		.withParameter("prev_stat_loaded", prev_stat_loaded)
		.withOutputParameter("prev_stat", prev_stat)
		.withOutputParameter("cur_stat", cur_stat);
}

enum ice_status
ice_aq_set_port_id_led(struct ice_port_info *pi, bool is_orig_mode,
		       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("pi", pi)
		.withParameter("is_orig_mode", is_orig_mode);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_aq_set_mac_loopback(struct ice_hw *hw, u8 mode, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_port_params(struct ice_port_info *pi, u16 bad_frame_vsi,
		       bool save_bad_pac, bool pad_short_pac, bool double_vlan,
#if defined(SWITCH_MODE) && defined(BMSM_MODE)
		       u16 *sw_id, struct ice_sq_cd *cd)
#else
		       struct ice_sq_cd *cd)
#endif /* SWITCH_MODE && BMSM_MODE */
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

bool
ice_phy_caps_equals_cfg(struct ice_aqc_get_phy_caps_data *phy_caps,
                        struct ice_aqc_set_phy_cfg_data *phy_cfg)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

void ice_copy_phy_caps_to_cfg(struct ice_port_info* pi,
			      struct ice_aqc_get_phy_caps_data *caps,
			      struct ice_aqc_set_phy_cfg_data *cfg)
{
	mock().actualCall(__func__)
		.withParameter("pi", pi)
		.withParameter("caps", caps)
                .withOutputParameterOfType("struct ice_aqc_set_phy_cfg_data *",
					   "cfg", cfg);
}

//#ifdef PHY_PERSIST_SUPPORT
enum ice_status
ice_cfg_phy_fec(struct ice_port_info *pi, struct ice_aqc_set_phy_cfg_data *cfg,
		enum ice_fec_mode fec)
{
#if 0
	mock().actualCall(__func__)
                .withOutputParameter("pi", pi)
                .withOutputParameter("cfg", cfg)
		.withParameter("fec", fec);
#endif

	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}
//#else
#if 0
void
ice_cfg_phy_fec(struct ice_aqc_set_phy_cfg_data *cfg, enum ice_fec_mode fec)
{
	mock().actualCall(__func__)
                .withOutputParameter("cfg", cfg)
		.withParameter("fec", fec);
}
#endif /* PHY_PERSIST_SUPPORT */

enum ice_status
ice_cfg_phy_fc(struct ice_port_info *pi, struct ice_aqc_set_phy_cfg_data *cfg,
	       enum ice_fc_mode req_mode)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

bool ice_fw_supports_link_override(struct ice_hw *hw)
{

	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status
ice_aq_send_driver_ver(struct ice_hw *hw, struct ice_driver_ver *dv,
                       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

void ice_dev_onetime_setup(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}

void ice_set_safe_mode_caps(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	hw->func_caps.common_cap.num_txq = 1;
	hw->func_caps.common_cap.num_rxq = 1;
	hw->func_caps.common_cap.num_msix_vectors = 2;
	hw->func_caps.guar_num_vsi = 1;

	hw->dev_caps.common_cap.num_rxq = 16;
	hw->dev_caps.common_cap.num_txq = 16;
	hw->dev_caps.common_cap.num_msix_vectors = 24;
}

void ice_print_rollback_msg(struct ice_hw *hw)
{
	mock().actualCall(__func__);
}


#ifdef SWITCH_MODE
int ice_get_port_info_idx(struct ice_hw *hw, u8 n)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault((int)n);
}
#endif /* SWITCH_MODE */

enum ice_status
ice_aq_sff_eeprom(struct ice_hw *hw, u16 lport, u8 bus_addr,
		  u16 mem_addr, u8 page, u8 set_page, u8 *data, u8 length,
		  bool write, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_get_link_default_override(struct ice_link_default_override_tlv *ldo,
			      struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

bool ice_is_generic_mac(struct ice_hw *hw)
{
	return 1;
}

bool ice_is_e810(struct ice_hw *hw)
{
	return 0;
}

bool ice_is_e810t(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return 0;
}

bool ice_is_e823(struct ice_hw *hw)
{
	return 0;
}

enum ice_status
ice_cfg_vsi_rdma(struct ice_port_info *p, u16 vsi_handle,
		 u8 tc_bitmap, u16 *max_rdmaqs)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

enum ice_status
ice_aq_send_cmd(struct ice_hw *hw, struct ice_aq_desc *desc,
		void *buf, u16 buf_size, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("desc->flags", desc->flags)
		.withParameter("desc->opcode", desc->opcode)
		.withParameter("desc->datalen", desc->datalen)
		.withParameter("desc->params", desc->params.raw, sizeof(desc->params))
		.withOutputParameter("desc->retval", &desc->retval)
		.withOutputParameter("desc->params", &desc->params.raw)
		.withParameter("buf", (u8 *)buf, buf_size)
		.withParameter("buf_size", buf_size)
		.withOutputParameter("buf", (u8 *)buf)
		.withParameter("cd", cd);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

bool ice_is_phy_caps_an_enabled(struct ice_aqc_get_phy_caps_data *caps)
{
	mock().actualCall(__func__);
	return mock().boolReturnValue();
}

enum ice_status
ice_aq_read_i2c(struct ice_hw *hw, struct ice_aqc_link_topo_addr topo_addr,
		u16 bus_addr, __le16 addr, u8 params, u8 *data,
		struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_write_i2c(struct ice_hw *hw, struct ice_aqc_link_topo_addr topo_addr,
		 u16 bus_addr, __le16 addr, u8 params, u8 *data,
		 struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_read_pca9575_reg_e810t(struct ice_hw *hw, u8 offset, u8 *data)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_write_pca9575_reg_e810t(struct ice_hw *hw, u8 offset, u8 data)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_driver_param(struct ice_hw *hw, enum ice_aqc_driver_params idx,
			u32 value, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("idx", (u8)idx)
		.withParameter("value", value)
		.withParameter("cd", cd);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_get_driver_param(struct ice_hw *hw, enum ice_aqc_driver_params idx,
			u32 *value, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("idx", (u8)idx)
		.withOutputParameter("value", value)
		.withParameter("cd", cd);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_list_caps(struct ice_hw *hw, void *buf, u16 buf_size, u32 *cap_count,
		 enum ice_adminq_opc opc, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("buf", buf)
		.withParameter("buf_size", buf_size)
		.withOutputParameter("cap_count", cap_count)
		.withParameter("opc", opc)
		.withParameter("cd", cd);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef DCF_SUPPORT
enum ice_status
ice_aq_alloc_free_res(struct ice_hw *hw, u16 num_entries,
		      struct ice_aqc_alloc_free_res_elem *buf, u16 buf_size,
		      enum ice_adminq_opc opc, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

enum ice_status
ice_discover_dev_caps(struct ice_hw *hw, struct ice_hw_dev_caps *dev_caps)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("dev_caps", dev_caps);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_dis_vsi_rdma_qset(struct ice_port_info *pi, u16 count, u32 *qset_teid, u16 *q_id)
{
	mock().actualCall(__func__);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

bool ice_fw_supports_report_dflt_cfg(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_fw_supports_fec_dis_auto(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_is_fw_health_report_supported(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status
ice_aq_get_cgu_abilities(struct ice_hw *hw,
			 struct ice_aqc_get_cgu_abilities *abilities)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withOutputParameter("abilities", abilities);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_get_cgu_ref_prio(struct ice_hw *hw, u8 dpll_num, u8 ref_idx,
			u8 *ref_prio)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll_num)
		.withParameter("ref_idx", ref_idx)
		.withOutputParameter("ref_prio", ref_prio);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_cgu_ref_prio(struct ice_hw *hw, u8 dpll_num, u8 ref_idx,
			u8 ref_prio)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll_num)
		.withParameter("ref_idx", ref_idx)
		.withParameter("ref_prio", ref_prio);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_output_pin_cfg(struct ice_hw *hw, u8 output_idx, u8 flags,
			  u8 src_sel, u32 freq, u32 phase_comp)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("output_idx", output_idx)
		.withParameter("flags", flags)
		.withParameter("src_sel", src_sel)
		.withParameter("freq", freq)
		.withParameter("phase_comp", phase_comp);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_get_output_pin_cfg(struct ice_hw *hw, u8 output_idx, u8 *flags,
			  u8 *src_sel, u32 *freq, u32 *src_freq)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("output_idx", output_idx)
		.withOutputParameter("flags", flags)
		.withOutputParameter("src_sel", src_sel)
		.withOutputParameter("freq", freq)
		.withOutputParameter("src_freq", src_freq);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_get_input_pin_cfg(struct ice_hw *hw,
			 struct ice_aqc_get_cgu_input_config *cfg, u8 input_idx)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("input_idx", input_idx)
		.withOutputParameter("cfg", cfg);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}
enum ice_status
ice_aq_set_input_pin_cfg(struct ice_hw *hw, u8 input_idx, u8 flags1, u8 flags2,
			 u32 freq, s32 phase_delay)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("input_idx", input_idx)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", freq)
		.withParameter("phase_delay", phase_delay);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_phy_rec_clk_out(struct ice_hw *hw, u8 phy_output, bool enable,
			   u32 *freq)
{
	mock().actualCall(__func__);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_get_cgu_dpll_status(struct ice_hw *hw, u8 dpll_num, u8 *ref_state,
			   u16 *dpll_state, u64 *phase_offset, u8 *eec_mode)
{
	mock().actualCall(__func__);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}

enum ice_status
ice_aq_set_cgu_dpll_config(struct ice_hw *hw, u8 dpll_num, u8 ref_state,
			   u8 config, u8 eec_mode)
{
	mock().actualCall(__func__);

	return (enum ice_status)mock().returnIntValueOrDefault(ICE_SUCCESS);
}
