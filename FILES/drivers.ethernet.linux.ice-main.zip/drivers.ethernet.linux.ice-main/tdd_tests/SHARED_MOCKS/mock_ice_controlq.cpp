enum ice_status ice_clean_rq_elem(struct ice_hw *hw,
				       struct ice_ctl_q_info *cq,
				       struct ice_rq_event_info *e,
				       u16 *pending)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

void ice_idle_aq(struct ice_hw *hw, struct ice_ctl_q_info *cq)
{
	mock().actualCall(__func__);
}

bool ice_check_sq_alive(struct ice_hw *hw, struct ice_ctl_q_info *cq)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

// just put the real function since it is a helper
static void
ice_fill_dflt_direct_cmd_desc(struct ice_aq_desc *desc,
			      enum ice_adminq_opc opcode)
{
	/* zero out the desc */
	ice_memset(desc, 0, sizeof(*desc), ICE_NONDMA_MEM);
	desc->opcode = CPU_TO_LE16(opcode);
	desc->flags = CPU_TO_LE16(ICE_AQ_FLAG_SI);
}

enum ice_status
ice_sq_send_cmd(struct ice_hw *hw, struct ice_ctl_q_info *cq,
		struct ice_aq_desc *desc, void *buf, u16 buf_size,
		struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().intReturnValue();
}

