enum ice_status ice_add_rss_cfg(struct ice_hw *hw, u16 vsi, const struct ice_rss_hash_cfg *cfg)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);

}
enum ice_status ice_rem_vsi_rss_cfg(struct ice_hw *hw, u16 vsi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
void ice_rem_vsi_rss_list(struct ice_hw *hw, u16 vsi)
{
	mock().actualCall(__func__);
}
u64 ice_get_rss_cfg(struct ice_hw *hw, u16 vsi, u32 hdrs)
{
	mock().actualCall(__func__);
	return (u64)mock().returnIntValueOrDefault(0);
}
enum ice_status ice_add_avf_rss_cfg(struct ice_hw *hw, u16 vsi, u64 avf_hash)
{
	mock().actualCall(__func__)
		.withParameter("hw", hw)
		.withParameter("vsi_idx", vsi)
		.withParameter("avf_hash", avf_hash);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_flow_add_prof(struct ice_hw *hw, enum ice_block blk, enum ice_flow_dir dir,
		  u64 prof_id, struct ice_flow_seg_info *segs, u8 segs_cnt,
		  struct ice_flow_action *acts, u8 acts_cnt,
		  struct ice_flow_prof **prof)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_flow_rem_prof(struct ice_hw *hw, enum ice_block blk, u64 prof_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void
ice_flow_set_fld(struct ice_flow_seg_info *seg, enum ice_flow_field fld,
		 u16 val_loc, u16 mask_loc, u16 last_loc, bool range)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_flow_get_hw_prof(struct ice_hw *hw, enum ice_block blk, u64 prof_id,
		     u8 *hw_prof)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_flow_set_hw_prof(struct ice_hw *hw, u16 dest_vsi_handle,
		     u16 fdir_vsi_handle, struct ice_parser_profile *prof,
		     enum ice_block blk)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_flow_add_entry(struct ice_hw *hw, enum ice_block blk, u64 prof_id,
		   u64 entry_id, u16 vsi, enum ice_flow_priority prio,
		   void *data, struct ice_flow_action *acts, u8 acts_cnt,
		   u64 *entry_h)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_flow_add_fld_raw(struct ice_flow_seg_info *seg, u16 off, u8 len,
			  u16 val_loc, u16 mask_loc)
{
	mock().actualCall(__func__);
}

enum ice_status ice_flow_rem_vsi_prof(struct ice_hw *hw, enum ice_block blk,
				      u16 vsi_handle, u64 prof_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_flow_rem_entry(struct ice_hw *hw, enum ice_block blk,
				   u64 entry_h)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_flow_find_entry(struct ice_hw *hw, enum ice_block blk,
				   u64 entry_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
enum ice_status
ice_rem_rss_cfg(struct ice_hw *hw, u16 vsi_handle,
		const struct ice_rss_hash_cfg *cfg)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void ice_rss_update_raw_symm(struct ice_hw *hw,
			     struct ice_rss_raw_cfg *cfg, u64 id)
{
	mock().actualCall(__func__);
}
