bool ice_is_dvm_ena(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}
