bool ice_mac_fltr_exist(struct ice_hw *hw, u8 *mac, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

bool ice_vlan_fltr_exist(struct ice_hw *hw, u16 vlan_id, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status
ice_remove_mac(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_add_mac(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
enum ice_status
ice_add_mac_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list, u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_mac_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list,
		       u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

void ice_remove_vsi_fltr(struct ice_hw *hw, u16 vsi_id)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_add_to_vsi_fltr_list(struct ice_hw *hw, u16 vsi_id,
			   struct LIST_HEAD_TYPE *lkup_list_head,
			   struct LIST_HEAD_TYPE *vsi_list_head)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_add_vsi(struct ice_hw *hw, struct ice_vsi_ctx *vsi_ctx,
	       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_add_vsi(struct ice_hw *hw, u64 vsi_handle, struct ice_vsi_ctx *vsi_ctx,
	    struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_free_vsi(struct ice_hw *hw, u64 vsi_handle, struct ice_vsi_ctx *vsi_ctx,
	     bool keep_vsi_alloc, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_update_vsi(struct ice_hw *hw, u64 vsi_handle, struct ice_vsi_ctx *vsi_ctx,
	       struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return(enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_aq_get_vsi_params(struct ice_hw *hw,
		      struct ice_vsi_ctx *vsi_ctx,
		      struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_add_vlan(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_vlan(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
enum ice_status
ice_add_vlan_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list, u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_vlan_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list,
			u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

enum ice_status
ice_add_mac_vlan(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
enum ice_status
ice_add_mac_vlan_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list,
			 u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_mac_vlan_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list,
			    u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

enum ice_status
ice_cfg_dflt_vsi(struct ice_port_info *pi, u16 vsi_id, bool set, u8 direction)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

bool
ice_check_if_dflt_vsi(struct ice_port_info *pi, u16 vsi_handle, bool *rule_exists)
{
	mock().actualCall(__func__).withOutputParameter("rule_exists", rule_exists);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status
ice_set_vsi_promisc(struct ice_hw *hw, u16 vsi_id, u8 promisc_mask, u16 vid)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
enum ice_status
ice_update_sw_rule_bridge_mode(struct ice_hw *hw, u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#else
enum ice_status
ice_update_sw_rule_bridge_mode(struct ice_hw *hw)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* BMSM_MODE */

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
enum ice_status ice_est_pass_rule_per_port(struct ice_hw *hw,
					   struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_trd_pass_rule_per_port(struct ice_hw *hw,
					   struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_add_pass_vsi_per_port(struct ice_hw *hw, u16 vsi_handle,
					  struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_rem_pass_vsi_per_port(struct ice_hw *hw, u16 vsi_handle,
					  struct ice_port_info *pi)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif /* SWITCH_MODE && !BMSM_MODE */

enum ice_status
ice_remove_mac_vlan(struct ice_hw *hw, struct LIST_HEAD_TYPE *v_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_add_adv_rule(struct ice_hw *hw, struct ice_adv_lkup_elem *lkups,
		 u16 lkups_cnt, struct ice_adv_rule_info *rinfo,
		 struct ice_rule_query_data *added_entry)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

u16 ice_get_hw_vsi_num(struct ice_hw *hw, u16 vsi_idx)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

bool ice_is_vsi_valid(struct ice_hw *hw, u16 vsi_idx)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(true);
}

enum ice_status
ice_alloc_sw(struct ice_hw *hw, bool ena_stats, bool shared_res, u16 *sw_id,
	     u16 *counter_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status ice_free_sw(struct ice_hw *hw, u16 sw_id, u16 counter_id)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_set_vlan_vsi_promisc(struct ice_hw *hw, u16 vsi_id, u8 promisc_mask,
			 u16 vid)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_clear_vsi_promisc(struct ice_hw *hw, u16 vsi_id, u8 promisc_mask, u16 vid)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_rem_adv_rule_by_id(struct ice_hw *hw,
		       struct ice_rule_query_data *remove_entry)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_eth_mac(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_add_eth_mac(struct ice_hw *hw, struct LIST_HEAD_TYPE *m_list)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

#ifdef BMSM_MODE
enum ice_status
ice_add_eth_mac_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *em_list,
			u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_remove_eth_mac_on_port(struct ice_hw *hw, struct LIST_HEAD_TYPE *em_list,
			   u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

void
ice_remove_vsi_fltr_on_port(struct ice_hw *hw, u16 vsi_handle, u8 lport)
{
	mock().actualCall(__func__);
}

enum ice_status
ice_set_vlan_vsi_promisc_on_port(struct ice_hw *hw, u16 vsi_handle,
				 u8 promisc_mask, bool rm_vlan_promisc,
				 u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_clear_vsi_promisc_on_port(struct ice_hw *hw, u16 vsi_handle,
			      u8 promisc_mask, u16 vid, u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_set_vsi_promisc_on_port(struct ice_hw *hw, u16 vsi_handle, u8 promisc_mask,
			    u16 vid, u8 lport)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

#if defined(DCF_SUPPORT) || defined(ESWITCH_SUPPORT)
enum ice_status
ice_aq_sw_rules(struct ice_hw *hw, void *rule_list, u16 rule_list_sz,
		u8 num_rules, enum ice_adminq_opc opc, struct ice_sq_cd *cd)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
#endif

enum ice_status
ice_update_dflt_vsi_action_flag(struct ice_port_info *pi, u16 lkup_type, u16 id,
				u16 vsi_handle, bool lan_en, bool lb_en)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_cfg_iwarp_fltr(struct ice_hw *hw, u16 vsi_handle, bool enable)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_alloc_rss_global_lut(struct ice_hw *hw, bool shared_res, u16 *global_lut_id)
{
	mock().actualCall(__func__)
		.withParameter("shared_res", shared_res)
		.withOutputParameter("global_lut_id", global_lut_id);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

enum ice_status
ice_free_rss_global_lut(struct ice_hw *hw, u16 global_lut_id)
{
	mock().actualCall(__func__)
		.withParameter("global_lut_id", global_lut_id);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

struct ice_vsi_ctx *ice_get_vsi_ctx(struct ice_hw *hw, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return (struct ice_vsi_ctx *)mock().returnPointerValueOrDefault(NULL);
}

enum ice_status
ice_rem_adv_rule_for_vsi(struct ice_hw *hw, u16 vsi_handle)
{
	mock().actualCall(__func__);
	return (enum ice_status)mock().returnIntValueOrDefault(0);
}
