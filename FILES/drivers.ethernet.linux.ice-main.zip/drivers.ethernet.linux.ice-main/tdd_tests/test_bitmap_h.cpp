// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright(c) 2019 Intel Corporation
 */

/* some quick tests to verify that our bitmap operations are working */

#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_bitmap_tests {
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/bitmap.h>
}
/////////////////////////////////////////////////
using namespace ns_bitmap_tests;

TEST_GROUP(bitmap)
{
	void setup() {
	};

	void teardown() {
		mock().checkExpectations();
		mock().clear();
	};
};

TEST(bitmap, bitmap_check_weight)
{
	// delcare a bitmap of 128 bits for us to test on
	DECLARE_BITMAP(weight_test, 128);

	// manually set some bits
	weight_test[0] = BIT_ULL(1) | BIT_ULL(6) | BIT_ULL(28) | BIT_ULL(31) |
		       BIT_ULL(42) | BIT_ULL(49) | BIT_ULL(62);
	weight_test[1] = BIT_ULL(2) | BIT_ULL(7) | BIT_ULL(29) | BIT_ULL(30) |
		       BIT_ULL(41) | BIT_ULL(48) | BIT_ULL(61);

	// hamming weight means count the number of bits.
	int result = bitmap_weight(weight_test, 128);

	// we expect the above to return 14
	CHECK_EQUAL(14, result);
}

TEST(bitmap, bitmap_check_equal)
{
	// delcare a bitmap of 128 bits for us to test on
	DECLARE_BITMAP(equal_test, 128);
	DECLARE_BITMAP(_test, 128);

	// manually set some bits
	equal_test[0] = BIT_ULL(1) | BIT_ULL(6) | BIT_ULL(28) | BIT_ULL(31) |
		       BIT_ULL(42) | BIT_ULL(49) | BIT_ULL(62);
	equal_test[1] = BIT_ULL(2) | BIT_ULL(7) | BIT_ULL(29) | BIT_ULL(30) |
		       BIT_ULL(41) | BIT_ULL(48) | BIT_ULL(61);

	memcpy(_test, equal_test, (128/BITS_PER_LONG) * sizeof(unsigned long));

	// compare the bitmaps
	int result = bitmap_equal(equal_test, _test, 128);

	// we expect the above to return 1 (aka true) for equal
	CHECK_EQUAL(1, result);

	// change a bit to make sure it biffs
	equal_test[1] |= BIT_ULL(3);
	result = bitmap_equal(equal_test, _test, 128);

	// we expect the above to return 0 (aka false) for !equal
	CHECK_EQUAL(0, result);
}
