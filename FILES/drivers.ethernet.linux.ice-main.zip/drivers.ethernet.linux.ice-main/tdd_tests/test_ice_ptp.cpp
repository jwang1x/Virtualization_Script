#include "ice_utest.h"

#define WQ_MEM_RECLAIM 0
#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_ptp {
#include "tdd_shared_code_transform.h"
#include "include/asm-generic/bitops/const_hweight.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/netdevice.h>
#include <linux/compiler.h>
#include "../src/CORE/ice.h"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_mbx.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_workqueue.cpp"
#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_kthread.cpp"
#include "CORE_MOCKS/stdmock_ice_idc_int.cpp"
#include "CORE_MOCKS/stdmock_ice_ptp.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "../src/CORE/ice_ptp.c"
}
/////////////////////////////////////////////////
using namespace ns_ptp;

static bool fake_ice_is_generic_mac_e810(struct ice_hw *hw)
{
	return false;
}
/*
int vscnprintf(char *buf, size_t size, const char *fmt, va_list args)
{
	size_t i;

	i = vsnprintf(buf, size, fmt, args);

	if (i < size)
		return i;
	if (size != 0)
		return size - 1;
	return 0;
}

int scnprintf(char *buf, size_t size, const char *fmt, ...)
{
	va_list args;
	int i;

	va_start(args, fmt);
	i = vscnprintf(buf, size, fmt, args);
	va_end(args);

	return i;
}
*/
struct test_hw {
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_ptp)
{
		struct device *dev;
		struct iidc_core_dev_info *cdi;
		struct pci_dev *pdev;
		struct device_driver *drv;
		struct net_device *netdev;
		struct ice_netdev_priv *np;
		struct ice_pf *pf;
		struct ice_hw *hw;
		struct ice_vsi *vsi;
		struct ice_port_info *pi;
		struct ice_sched_node *node;
		struct devreg devlist;

		void setup(void)
		{
			struct ice_ring *tx_ring, *rx_ring;
			//dev = (struct device *)calloc(1, sizeof(struct device));
			pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
			cdi = (struct iidc_core_dev_info *)
				   calloc(1, sizeof(struct iidc_core_dev_info));
			//drv = (struct device_driver *)
			 // 	calloc(1, sizeof(struct device_driver));
			pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
			hw = &pf->hw;
			pf->vsi = (struct ice_vsi **)calloc(1, sizeof(*pf->vsi));
			pf->hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
			pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
			vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
			pf->vsi[0] = vsi;
			pi = (struct ice_port_info *)
				calloc(1, sizeof(struct ice_port_info));
			node = (struct ice_sched_node *)
				calloc(1,sizeof(struct ice_sched_node));
			netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv),
							1, 1);
			cdi->pdev = pdev;
			pdev->dev.driver_data = pf;
			np = netdev_priv(netdev);
			np->vsi = vsi;

			vsi->alloc_txq = 1;
			vsi->alloc_rxq = 1;
			vsi->num_txq = 1;
			vsi->num_rxq = 1;
			vsi->tx_rings = (struct ice_ring **)calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
			vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
			vsi->rx_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
			vsi->rx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

			tx_ring = vsi->tx_rings[0];
			tx_ring->q_index = 0;
			tx_ring->reg_idx = 10;
			tx_ring->size = 0;
			tx_ring->count = 10;
			tx_ring->desc = (struct ice_tx_desc *)calloc(tx_ring->count, sizeof(struct ice_tx_desc));
			tx_ring->tx_buf = (struct ice_tx_buf *)calloc(tx_ring->count, sizeof(struct ice_tx_buf));

			rx_ring = vsi->rx_rings[0];
			rx_ring->q_index = 0;
			rx_ring->reg_idx = 10;
			rx_ring->size = 0;
			rx_ring->count = 10;
			rx_ring->desc = (union ice_32b_rx_flex_desc *)calloc(rx_ring->count,
									     sizeof(union ice_32b_rx_flex_desc));
			rx_ring->rx_buf = (struct ice_rx_buf *)calloc(rx_ring->count, sizeof(struct ice_rx_buf));

			vsi->netdev = netdev;
			vsi->back = pf;
			vsi->port_info = pi;
			vsi->type = ICE_VSI_PF;
			pf->hw.port_info = pi;
			pf->num_alloc_vsi=1;
#ifdef SWITCH_MODE
			pf->hw.port_info[0].is_internal_port = true;
			pf->hw.num_lports = 20;
			pf->hw.ena_lports = 0xfffff;
#endif
			mutex_init(&pf->sw_mutex);
			mutex_init(&pf->avail_q_mutex);

			/* init our dev tracking list */
			INIT_LIST_HEAD(&devlist.devreg_list);
			global_devreg_list = &devlist;
		}

		void teardown(void)
		{
			mock().checkExpectations();
			mock().clear();
			mutex_destroy(&pf->avail_q_mutex);
			mutex_destroy(&pf->sw_mutex);
			free(pf->hw.hw_addr);
			free(pdev);
			free(cdi);
			//free(drv);
			free(pi);


			free(vsi->rx_rings[0]->desc);
			free(vsi->rx_rings[0]->tx_buf);
			free(vsi->rx_rings[0]);
			free(vsi->rx_rings);
			free(vsi->tx_rings[0]->desc);
			free(vsi->tx_rings[0]->tx_buf);
			free(vsi->tx_rings[0]);
			free(vsi->tx_rings);
			free(vsi);

			free(pf->vsi);
			free(pf->pdev);
			free(pf);
			free(node);
			free_netdev(netdev);
		}
};

#ifndef SWITCH_MODE
TEST(ice_ptp, ice_get_main_vsi)
{
	struct ice_vsi *vsi;

	vsi = ice_get_main_vsi(pf);
	CHECK(vsi != 0);
}
#endif


TEST(ice_ptp, ice_ptp_create_clock)
{
	long status;

#ifdef FEATURE_BITS_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.withParameter("pf", pf)
		.withParameter("f", ICE_F_PTP_EXTTS)
		.andReturnValue(true);
#endif
	status = ice_ptp_create_clock(pf);
	CHECK_EQUAL(0, status);
}

TEST(ice_ptp, tx_tstamp_on)
{
	ice_set_tx_tstamp(pf, true);
}

TEST(ice_ptp, tx_tstamp_off)
{
	ice_set_tx_tstamp(pf, false);
}

TEST(ice_ptp, rx_tstamp_on)
{
	ice_set_rx_tstamp(pf, true);
}

TEST(ice_ptp, rx_tstamp_off)
{
	ice_set_rx_tstamp(pf, false);
}

#if 0
TEST(ice_ptp, ice_port_enabled_owned)
{
	bool ena;

	ena = ice_port_enabled_owned(pf, 1);
	CHECK_EQUAL(0, ena);
}
#endif

TEST_GROUP_BASE(clock_index, TGN(ice_ptp))
{
	struct ptp_clock *clock;

	TEST_SETUP()
	{
		TGN(ice_ptp)::setup();

		clock = (struct ptp_clock *)calloc(1, sizeof(*clock));
		clock->index = 5;
	}

	void setup_src_pf(void)
	{
		pf->ptp.clock = clock;
	}

	TEST_TEARDOWN()
	{
		pf->ptp.clock = NULL;
		free(clock);
		clock = NULL;

		TGN(ice_ptp)::teardown();

	}
};

#ifndef SWITCH_MODE
TEST(clock_index, src_pf_reports_clock_index)
{
	int idx;

	setup_src_pf();

	mock().expectNoCall("ice_aq_get_driver_param");

	idx = ice_get_ptp_clock_index(pf);
	CHECK_EQUAL(5, idx);
}

TEST(clock_index, other_pf_reports_clock_index_tmr0)
{
	u32 expected = 5 | PTP_SHARED_CLK_IDX_VALID;
	int idx;

	mock().expectOneCall("ice_aq_get_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withOutputParameterReturning("value", &expected, sizeof(expected))
		.withParameter("cd", (void *)NULL);

	idx = ice_get_ptp_clock_index(pf);
	CHECK_EQUAL(5, idx);
}

TEST(clock_index, other_pf_reports_clock_index_tmr1)
{
	u32 expected = 5 | PTP_SHARED_CLK_IDX_VALID;
	int idx;

	hw->func_caps.ts_func_info.tmr_index_assoc = 1;

	mock().expectOneCall("ice_aq_get_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR1)
		.withOutputParameterReturning("value", &expected, sizeof(expected))
		.withParameter("cd", (void *)NULL);

	idx = ice_get_ptp_clock_index(pf);
	CHECK_EQUAL(5, idx);
}

TEST(clock_index, other_pf_ignores_invalid_clock_index)
{
	u32 expected = 0;
	int idx;

	mock().expectOneCall("ice_aq_get_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withOutputParameterReturning("value", &expected, sizeof(expected))
		.withParameter("cd", (void *)NULL);

	idx = ice_get_ptp_clock_index(pf);
	CHECK_EQUAL(-1, idx);
}

TEST(clock_index, other_pf_read_fails)
{
	int idx;

	mock().expectOneCall("ice_aq_get_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);
	mock().expectOneCall("ice_aq_str");

	idx = ice_get_ptp_clock_index(pf);
	CHECK_EQUAL(-1, idx);
}

TEST(clock_index, set_clock_index_no_ptp_clock)
{
	ice_set_ptp_clock_index(pf);
}

TEST(clock_index, set_clock_index_src_pf_tmr0)
{
	setup_src_pf();

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withParameter("value", 5 | PTP_SHARED_CLK_IDX_VALID)
		.withParameter("cd", (void *)NULL);

	ice_set_ptp_clock_index(pf);
}

TEST(clock_index, set_clock_index_src_pf_tmr1)
{
	setup_src_pf();

	hw->func_caps.ts_func_info.tmr_index_assoc = 1;

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR1)
		.withParameter("value", 5 | PTP_SHARED_CLK_IDX_VALID)
		.withParameter("cd", (void *)NULL);

	ice_set_ptp_clock_index(pf);
}

TEST(clock_index, set_clock_index_src_pf_out_of_bounds)
{
	setup_src_pf();
	clock->index = -1;

	mock().expectNoCall("ice_aq_set_driver_param");

	ice_set_ptp_clock_index(pf);
}

TEST(clock_index, set_clock_index_src_pf_fails)
{
	setup_src_pf();

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withParameter("value", 5 | PTP_SHARED_CLK_IDX_VALID)
		.withParameter("cd", (void *)NULL)
		.andReturnValue(ICE_ERR_CFG);

	mock().expectOneCall("ice_aq_str");

	ice_set_ptp_clock_index(pf);
}

TEST(clock_index, clear_ptp_clock_index_not_owner)
{
	mock().expectNoCall("ice_aq_set_driver_param");

	ice_clear_ptp_clock_index(pf);
}

TEST(clock_index, clear_ptp_clock_index_owner_tmr0)
{
	hw->func_caps.ts_func_info.src_tmr_owned = 1;

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withParameter("value", 0)
		.withParameter("cd", (void *)NULL);

	ice_clear_ptp_clock_index(pf);
}

TEST(clock_index, clear_ptp_clock_index_owner_tmr0_fails)
{
	hw->func_caps.ts_func_info.src_tmr_owned = 1;

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR0)
		.withParameter("value", 0)
		.withParameter("cd", (void *)NULL)
		.andReturnValue(ICE_ERR_CFG);

	mock().expectOneCall("ice_aq_str");

	ice_clear_ptp_clock_index(pf);
}

TEST(clock_index, clear_ptp_clock_index_owner_tmr1)
{
	hw->func_caps.ts_func_info.src_tmr_owned = 1;
	hw->func_caps.ts_func_info.tmr_index_assoc = 1;

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR1)
		.withParameter("value", 0)
		.withParameter("cd", (void *)NULL);

	ice_clear_ptp_clock_index(pf);
}

TEST(clock_index, clear_ptp_clock_index_owner_tmr1_fails)
{
	hw->func_caps.ts_func_info.src_tmr_owned = 1;
	hw->func_caps.ts_func_info.tmr_index_assoc = 1;

	mock().expectOneCall("ice_aq_set_driver_param")
		.withParameter("hw", hw)
		.withParameter("idx", ICE_AQC_DRIVER_PARAM_CLK_IDX_TMR1)
		.withParameter("value", 0)
		.withParameter("cd", (void *)NULL)
		.andReturnValue(ICE_ERR_CFG);

	mock().expectOneCall("ice_aq_str");

	ice_clear_ptp_clock_index(pf);
}
#endif /* !SWITCH_MODE */

TEST(ice_ptp, ice_ptp_gettimex64)
{
	struct timespec64 ts;

	mock().expectOneCall("ice_get_ptp_src_clock_index")
		.withParameter("hw", hw);

	ice_ptp_gettimex64(&pf->ptp.info, &ts, NULL);
}

#ifndef ADK_SUPPORT
TEST(ice_ptp, ice_ptp_request_ts)
{
	struct ice_tx_tstamp tstamps[16] = {};
	struct napi_struct napi = {};
	struct ice_ptp_tx tx = {};
	struct sk_buff *skb0, *skb1;
	DECLARE_BITMAP(in_use, 16) = {};
	DECLARE_BITMAP(stale, 16) = {};
	s8 idx;

	spin_lock_init(&tx.lock);

	skb0 = __napi_alloc_skb(&napi, 0, GFP_KERNEL);
	skb1 = __napi_alloc_skb(&napi, 0, GFP_KERNEL);

	tx.tstamps = tstamps;
	tx.len = ARRAY_SIZE(tstamps);
	tx.init = 1;
	tx.in_use = in_use;
	tx.stale = stale;

	idx = ice_ptp_request_ts(&tx, skb0);
	CHECK_EQUAL(0, idx);
	CHECK_TRUE(test_bit(0, in_use));
	POINTERS_EQUAL(skb0, tstamps[0].skb);

	idx = ice_ptp_request_ts(&tx, skb1);
	CHECK_EQUAL(1, idx);
	CHECK_TRUE(test_bit(1, in_use));
	POINTERS_EQUAL(skb1, tstamps[1].skb);

	dev_kfree_skb(skb0);
	dev_kfree_skb(skb1);
}
#else
TEST(ice_ptp, ice_ptp_adk_tx_hwtstamp)
{
	u8 tx_idx[1] = { };
	u8 bank_id = 0;
	u64 ts[1], tstamp;

	cdi->port_info[0].lwr_netdev = netdev;

	/* Set a reasonable time for the cached value of source timer */
	pf->ptp.cached_phc_time = 0x00001000DEAD0000;

	/* Timestamps returned by ice_read_phy_tstamp are the 40bit values.
	 * Pretend this timestamp was 0xBEEF nanoseconds in the future. The
	 * lower 8 bits are ignored, and the timestamp is only 40bits wide
	 * total.
	 */
	tstamp = 0xDEADBEEFAFULL;

	mock().expectOneCall("ice_read_phy_tstamp")
		.withParameter("hw", hw)
		.withParameter("block", 0)
		.withParameter("idx", 0)
		.withOutputParameterReturning("tstamp", &tstamp, sizeof(tstamp));

	mock().expectOneCall("time_is_before_jiffies")
		.withParameter("time", 2 * HZ)
		.andReturnValue(false);

	ice_ptp_adk_tx_hwtstamp(cdi, tx_idx, 1, bank_id, ts,1);
	CHECK_EQUAL(0x1000DEADBEEFULL, ts[0]);

}
#endif
TEST(ice_ptp, ice_ptp_cfg_timestamp)
{
	using namespace ns_ptp;
#ifdef SWITCH_MODE
	pf->hw.port_info[0].is_internal_port = false;
#endif
	/* Enable timestamping */
	ice_ptp_cfg_timestamp(pf, true);
	CHECK_EQUAL(true, vsi->tx_rings[0]->ptp_tx);
	CHECK_EQUAL(true, vsi->rx_rings[0]->ptp_rx);


	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
	CHECK_EQUAL(HWTSTAMP_TX_ON, pf->ptp.tstamp_config.tx_type);

	/* Disable timestamping */
	ice_ptp_cfg_timestamp(pf, false);
	CHECK_EQUAL(false, vsi->tx_rings[0]->ptp_tx);
	CHECK_EQUAL(false, vsi->rx_rings[0]->ptp_rx);

	CHECK_EQUAL(HWTSTAMP_FILTER_NONE, pf->ptp.tstamp_config.rx_filter);
	CHECK_EQUAL(HWTSTAMP_TX_OFF, pf->ptp.tstamp_config.tx_type);
}

#ifdef SWITCH_MODE
TEST(ice_ptp, ice_ptp_get_src_phy_time)
{
	int status;
	struct iidc_ptp_timer_info ts;

	mock().expectOneCall("ice_ptp_src_cmd")
		.withParameter("hw", hw)
		.withParameter("cmd", ICE_PTP_READ_TIME);

	mock().expectNCalls(ICE_NUM_EXTERNAL_PORTS, "ice_ptp_one_port_cmd_e822")
		.withParameter("hw", hw)
		.withParameter("cmd", ICE_PTP_READ_TIME)
		.withParameter("lock_sbq", true)
		.ignoreOtherParameters();

	mock().expectNCalls(ICE_NUM_EXTERNAL_PORTS, "ice_ptp_read_port_capture_e822")
		.withParameter("hw", hw)
		.ignoreOtherParameters();

	mock().expectNCalls(ICE_NUM_EXTERNAL_PORTS, "ice_ptp_read_phy_incval_e822")
		.withParameter("hw", hw)
		.ignoreOtherParameters();

	status = ice_ptp_get_src_phy_time(pf, &ts);
	CHECK_EQUAL(0, status);
}
#endif /* SWITCH_MODE */

TEST(ice_ptp, ice_ptp_extend_32b_ts)
{
	/* Helper macros for convenience of generating good input values */
#define SYSTIME(high, low) (((u64)(high) << 32) | (u64)(low))
#define TSTAMP(low) ((u32)(low))

	/* Nearby future timestamp */
	CHECK_EQUAL(SYSTIME(105, 55),
		    ice_ptp_extend_32b_ts(SYSTIME(105, 5), TSTAMP(55)));

	/* Nearby past timestamp */
	CHECK_EQUAL(SYSTIME(105, 5),
		    ice_ptp_extend_32b_ts(SYSTIME(105, 5005), TSTAMP(5)));

	/* Farther apart future timestamp */
	CHECK_EQUAL(SYSTIME(105, 150015),
		    ice_ptp_extend_32b_ts(SYSTIME(105, 5), TSTAMP(150015)));

	/* Farther apart past timestamp */
	CHECK_EQUAL(SYSTIME(300, 75),
		    ice_ptp_extend_32b_ts(SYSTIME(300, 35000), TSTAMP(75)));

	/* Nearby future timestamp, just after rollover */
	CHECK_EQUAL(SYSTIME(406, 5),
		    ice_ptp_extend_32b_ts(SYSTIME(405, 0xFFFFFF01), TSTAMP(5)));

	/* Nearby past timestamp, just before rollover */
	CHECK_EQUAL(SYSTIME(405, 0xFFFFFF01),
		    ice_ptp_extend_32b_ts(SYSTIME(406, 5), TSTAMP(0xFFFFFF01)));

	/* Farther apart future timestamp, just after rollover */
	CHECK_EQUAL(SYSTIME(501, 50000),
		    ice_ptp_extend_32b_ts(SYSTIME(500, 0xFFFFFFF5), TSTAMP(50000)));

	/* Farther apart past timestamp, just before rollover */
	CHECK_EQUAL(SYSTIME(500, 0xFFFFFFF5),
		    ice_ptp_extend_32b_ts(SYSTIME(501, 75000), TSTAMP(0xFFFFFFF5)));
}

TEST(ice_ptp, ice_ptp_cfg_clkout)
{
	unsigned int chan = PPS_CLK_GEN_CHAN;
	struct ice_perout_channel config;
	struct ice_hw *hw = &pf->hw;
	u64 current_time;
	u8 tmr_idx = 0;
	int status;

	config.start_time = NSEC_PER_SEC;
	config.ena = true;
	config.period = NSEC_PER_SEC;
	config.gpio_pin = PPS_PIN_INDEX;

	mock().expectOneCall("ice_get_ptp_src_clock_index")
		.withParameter("hw", hw)
		.andReturnValue(tmr_idx);

	/* Set the time */
	current_time = rd32(hw, GLTSYN_TIME_L(tmr_idx));
	current_time |= (((u64)rd32(hw, GLTSYN_TIME_H(tmr_idx))) << 32);
#define PROP_DELAY 11
	/* Enabling clock */
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	config.start_time += roundup(current_time, NSEC_PER_SEC);
	CHECK_EQUAL(500000000, rd32(hw, GLTSYN_CLKO(chan, tmr_idx)));
	CHECK_EQUAL(config.start_time - PROP_DELAY,
		    rd32(hw, GLTSYN_TGT_L(chan, tmr_idx)));
	CHECK_EQUAL(0, rd32(hw, GLTSYN_TGT_H(chan, tmr_idx)));
	CHECK_EQUAL(7, rd32(hw, GLTSYN_AUX_OUT(chan, tmr_idx)));
	CHECK_EQUAL(2832, rd32(hw, GLGEN_GPIO_CTL(config.gpio_pin)));
	CHECK_EQUAL(0, status);

	/* Invalid (odd) period value */
	config.period = 1000000001L;
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	CHECK_EQUAL(-EFAULT, status);

	/* Invalid (smaller than inc_h) period value */
	config.period = 1;
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	CHECK_EQUAL(-EFAULT, status);

	/* Invalid (larger than U32_MAX) period value */
	config.period = (U32_MAX << 1) + 1ULL;
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	CHECK_EQUAL(-EFAULT, status);

	/* Disabling clock */
	config.ena = false;
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	CHECK_EQUAL(0, rd32(hw, GLTSYN_CLKO(chan, tmr_idx)));
	CHECK_EQUAL(0, rd32(hw, GLTSYN_TGT_L(chan, tmr_idx)));
	CHECK_EQUAL(0, rd32(hw, GLTSYN_TGT_H(chan, tmr_idx)));
	CHECK_EQUAL(GLGEN_GPIO_CTL_PIN_DIR_M,
		    rd32(hw, GLGEN_GPIO_CTL(config.gpio_pin)));
	CHECK_EQUAL(0, status);

	/* Period == 0 should disable the clock as well */
	config.period = 0;
	status = ice_ptp_cfg_clkout(pf, chan, &config, true);
	CHECK_EQUAL(0, status);
}

#ifdef SWITCH_MODE
TEST(ice_ptp, ice_ptp_update_incval_locked)
{
	int err;

	USE_STD_MOCK(ice_ptp_reset_phy_timestamping);

	set_bit(ICE_FLAG_PTP, pf->flags);

	mock().expectOneCall("ice_ptp_write_incval")
		.withParameter("hw", hw)
		.withParameter("incval", 0x100000000ULL);

	/* TODO: make ktime_get_real return a real value? */
	mock().expectOneCall("ice_ptp_init_time")
		.withParameter("hw", hw)
		.withParameter("time", 0);

	mock().expectOneCall("ice_ptp_reset_ts_memory")
		.withParameter("hw", hw);

	mock().expectOneCall("ice_ptp_reset_phy_timestamping")
		.withParameter("pf", pf);

	err = ice_ptp_update_incval(pf, ICE_TIME_REF_FREQ_25_000,
				    ICE_SRC_TMR_MODE_LOCKED);
	CHECK_EQUAL(0, err);
}

TEST(ice_ptp, ov_work_container_of_switch_mode)
{
	struct ice_ptp_port *port = &pf->ptp.ports[4];
	struct ice_pf *calculated_pf_addr;

	port->port_num = 4;

	calculated_pf_addr = ptp_port_to_pf(port);

	POINTERS_EQUAL(pf, calculated_pf_addr);
}
#else
TEST(ice_ptp, ov_work_container_of)
{
	struct ice_ptp_port *port = &pf->ptp.port;
	struct ice_pf *calculated_pf_addr;

	calculated_pf_addr = ptp_port_to_pf(port);

	POINTERS_EQUAL(pf, calculated_pf_addr);
}
#endif

TEST(ice_ptp, ice_ptp_wait_for_offset_valid)
{
	struct ice_ptp_port *port;

	USE_STD_MOCK(ice_ptp_check_tx_fifo);

#ifdef SWITCH_MODE
	port = &pf->ptp.ports[7];
#else
	port = &pf->ptp.port;
#endif
	port->port_num = 7;

	mock().expectOneCall("ice_is_reset_in_progress");

	mock().expectOneCall("ice_ptp_check_tx_fifo")
		.withParameter("port", port);

	mock().expectOneCall("ice_phy_cfg_tx_offset_e822")
		.withParameter("hw", hw)
		.withParameter("port", 7);

	mock().expectOneCall("ice_phy_cfg_rx_offset_e822")
		.withParameter("hw", hw)
		.withParameter("port", 7);

	ice_ptp_wait_for_offset_valid(&port->ov_work.work);
}
#ifdef SYNCE_SUPPORT
TEST_GROUP(ice_ptp_sysfs)
{
	struct ice_pf *pf;
	struct ice_hw *hw;
	char dpll_str[5];
	char dpll_val[2];
	char prio_str[5];
	char prio_val[3];
	char pin_str[4];
	char pin_val[3];
	char wrong_str[6];
	char wrong_val[3];
	char direction_str[4];
	char dummy_buf[6];
	u8 dpll, prio, pin, flags1, flags2;
	u32 freq, src_freq, old_freq, old_src_freq;
	u8 old_flags, old_src_sel;
	bool bool_ret;
	int argc_pin_prio;
	int ret, dummy_size;
	int argc_pin_cfg_1_item;
	int argc_pin_cfg_2_items;
	int argc_pin_cfg_3_items;
	int argc_pin_cfg_4_items;
	int argc_dir_pin_cfg_1_item;
	int argc_dir_pin_cfg_2_items;
	int argc_dir_pin_cfg_3_items;
	char phase_str[12];
	char phase_val[12];
	char freq_str[5];
	char freq_val[12];
	char esync_str[6];
	char esync_val[2];
	char enable_str[7];
	char enable_val[2];
	char *argv_freq_esync_phase[8];
	char *argv_phase[4];
	char *argv_esync[4];
	char *argv_freq[4];
	char *argv_enable[4];
	char *argv_freq_esync[6];
	char *argv_dir_freq_esync[7];
	char *argv_dir_esync[5];
	char *argv_dir_freq_esync_phase[9];
	char *argv_pin_prio[6];
	char *argv_freq_esync_phase_enable[10];
	struct device *dev;
	struct device_attribute dummy_attr;
	struct ice_aqc_get_cgu_input_config pin_input_cfg;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		hw = &pf->hw;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		pf->pdev->dev.driver_data = pf;
		dev = &pf->pdev->dev;
		strcpy(dpll_str, "dpll");
		strcpy(dpll_val, "0");
		strcpy(prio_str, "prio");
		strcpy(prio_val, "7");
		strcpy(pin_str, "pin");
		strcpy(pin_val, "1");
		strcpy(wrong_str, "wrong");
		strcpy(wrong_val, "-1");
		strcpy(phase_str, "phase_delay");
		strcpy(phase_val, "10000000");
		strcpy(freq_str, "freq");
		strcpy(freq_val, "10000000");
		strcpy(esync_str, "esync");
		strcpy(esync_val, "1");
		strcpy(direction_str, "in");
		strcpy(enable_str, "enable");
		strcpy(enable_val, "1");
		strcpy(dummy_buf, "dummy");
		dummy_size = 5;
		dpll = 0;
		pin = 1;
		prio = 7;
		argv_pin_prio[0] = &dpll_str[0];
		argv_pin_prio[1] = &dpll_val[0];
		argv_pin_prio[2] = &prio_str[0];
		argv_pin_prio[3] = &prio_val[0];
		argv_pin_prio[4] = &pin_str[0];
		argv_pin_prio[5] = &pin_val[0];
		argc_pin_prio = 6;
		argc_pin_cfg_1_item = 4;
		argc_pin_cfg_2_items = 6;
		argc_pin_cfg_3_items = 8;
		argc_pin_cfg_4_items = 10;
		argc_dir_pin_cfg_1_item = argc_pin_cfg_1_item + 1;
		argc_dir_pin_cfg_2_items = argc_pin_cfg_2_items + 1;
		argc_dir_pin_cfg_3_items = argc_pin_cfg_3_items + 1;
		argv_freq_esync_phase[0] = &pin_str[0];
		argv_freq_esync_phase[1] = &pin_val[0];
		argv_freq_esync_phase[2] = &freq_str[0];
		argv_freq_esync_phase[3] = &freq_val[0];
		argv_freq_esync_phase[4] = &esync_str[0];
		argv_freq_esync_phase[5] = &esync_val[0];
		argv_freq_esync_phase[6] = &phase_str[0];
		argv_freq_esync_phase[7] = &phase_val[0];
		argv_freq_esync_phase_enable[0] = &pin_str[0];
		argv_freq_esync_phase_enable[1] = &pin_val[0];
		argv_freq_esync_phase_enable[2] = &freq_str[0];
		argv_freq_esync_phase_enable[3] = &freq_val[0];
		argv_freq_esync_phase_enable[4] = &esync_str[0];
		argv_freq_esync_phase_enable[5] = &esync_val[0];
		argv_freq_esync_phase_enable[6] = &phase_str[0];
		argv_freq_esync_phase_enable[7] = &phase_val[0];
		argv_freq_esync_phase_enable[8] = &enable_str[0];
		argv_freq_esync_phase_enable[9] = &enable_val[0];
		argv_dir_freq_esync_phase[0] = &direction_str[0];
		argv_dir_freq_esync_phase[1] = &pin_str[0];
		argv_dir_freq_esync_phase[2] = &pin_val[0];
		argv_dir_freq_esync_phase[3] = &freq_str[0];
		argv_dir_freq_esync_phase[4] = &freq_val[0];
		argv_dir_freq_esync_phase[5] = &esync_str[0];
		argv_dir_freq_esync_phase[6] = &esync_val[0];
		argv_dir_freq_esync_phase[7] = &phase_str[0];
		argv_dir_freq_esync_phase[8] = &phase_val[0];
		argv_phase[0] = &pin_str[0];
		argv_phase[1] = &pin_val[0];
		argv_phase[2] = &phase_str[0];
		argv_phase[3] = &phase_val[0];
		argv_esync[0] = &pin_str[0];
		argv_esync[1] = &pin_val[0];
		argv_esync[2] = &esync_str[0];
		argv_esync[3] = &esync_val[0];
		argv_dir_esync[0] = &direction_str[0];
		argv_dir_esync[1] = &pin_str[0];
		argv_dir_esync[2] = &pin_val[0];
		argv_dir_esync[3] = &esync_str[0];
		argv_dir_esync[4] = &esync_val[0];
		argv_freq[0] = &pin_str[0];
		argv_freq[1] = &pin_val[0];
		argv_freq[2] = &freq_str[0];
		argv_freq[3] = &freq_val[0];
		argv_enable[0] = &pin_str[0];
		argv_enable[1] = &pin_val[0];
		argv_enable[2] = &enable_str[0];
		argv_enable[3] = &enable_val[0];
		argv_freq_esync[0] = &pin_str[0];
		argv_freq_esync[1] = &pin_val[0];
		argv_freq_esync[2] = &freq_str[0];
		argv_freq_esync[3] = &freq_val[0];
		argv_freq_esync[4] = &esync_str[0];
		argv_freq_esync[5] = &esync_val[0];
		argv_dir_freq_esync[0] = &direction_str[0];
		argv_dir_freq_esync[1] = &pin_str[0];
		argv_dir_freq_esync[2] = &pin_val[0];
		argv_dir_freq_esync[3] = &freq_str[0];
		argv_dir_freq_esync[4] = &freq_val[0];
		argv_dir_freq_esync[5] = &esync_str[0];
		argv_dir_freq_esync[6] = &esync_val[0];
		flags1 = 0;
		flags2 = 0;
		bool_ret = true;
		old_freq = 0;
		old_src_freq = 0;
		old_flags = 0;
		old_src_sel = 0;

		memset(&pin_input_cfg, 0, sizeof(pin_input_cfg));
	}

	void test_expect_ice_aq_get_output_pin_cfg() {
		mock().expectOneCall("ice_aq_get_output_pin_cfg")
			.withParameter("hw", hw)
			.withParameter("output_idx", pin)
			.withOutputParameterReturning("flags", &old_flags, sizeof(old_flags))
			.withOutputParameterReturning("src_sel", &old_src_sel, sizeof(old_src_sel))
			.withOutputParameterReturning("freq", &old_freq, sizeof(old_freq))
			.withOutputParameterReturning("src_freq", &old_src_freq, sizeof(old_src_freq));
	}

	void teardown()
	{
		mock().checkExpectations();
		mock().clear();
		free(pf->pdev);
		free(pf);
	}
};

TEST(ice_ptp_sysfs, parse_pin_prio_success)
{
	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", prio)
		.andReturnValue(0);
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_1)
{
	/* bad first config item name */
	argv_pin_prio[0] = &wrong_str[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_out_of_range)
{
	/* prio should be in range 0-14 */
	const char* prio = "17";
	argv_pin_prio[3] = (char*) prio;
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_out_of_range_2)
{
	/* prio should be in range 0-14 */
	const char* prio = "15";
	argv_pin_prio[3] = (char*) prio;
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_in_range_boundary)
{
	/* prio should be in range 0-14 */
	const char* prio = "14";
	argv_pin_prio[3] = (char*) prio;

	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", 14)
		.andReturnValue(0);
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_2)
{
	/* bad middle config item name */
	argv_pin_prio[2] = &wrong_str[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(1, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_3)
{
	/* bad last config item name */
	argv_pin_prio[4] = &wrong_str[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(2, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_val_1)
{
	/* bad first config item value */
	argv_pin_prio[1] = &wrong_val[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_val_2)
{
	/* bad middle config item value */
	argv_pin_prio[3] = &wrong_val[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(0);
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_arg_val_3)
{
	/* bad last config item value */
	argv_pin_prio[5] = &wrong_val[0];
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNCalls(2, "kstrtou8")
		.andReturnValue(0);
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_bad_dpll_id)
{
	dpll = 7;
	/* dpll = 7 -> out of range */
	argv_pin_prio[1][0] = '7';

	mock().expectNCalls(3, "kstrtou8");
	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", prio)
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_synce_dpll_bad_pin_id)
{
	pin = 10;
	/* dpll = 0 && pin = 10 -> out of range */
	argv_pin_prio[5][1] = '0';
	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", prio)
		.andReturnValue(-EINVAL);
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, parse_pin_prio_fail_ptp_dpll_bad_pin_id)
{
	dpll = 1;
	pin = 5;
	argv_pin_prio[1][0] = '1';
	argv_pin_prio[5][0] = '5';
	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", prio)
		.andReturnValue(-EINVAL);
	mock().expectNCalls(3, "kstrtou8");

	ret = ice_ptp_parse_and_apply_pin_prio(pf, argc_pin_prio, argv_pin_prio);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_freq)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_freq);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_phase)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_UPDATE_PHASE;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("phase_comp", 10000000)
		.withParameter("freq", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_phase);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_esync)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 0)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_esync_off)
{
	strcpy(esync_val, "0");
	flags1 = 0;
	bool_ret = false;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 0)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_enable)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_OUT_EN;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 0)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_enable);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_enable_off)
{
	flags1 = 0;
	strcpy(enable_val, "0");
	bool_ret = false;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 0)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_enable);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_freq_esync)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_2_items, argv_freq_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_freq_esync_phase)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_OUT_CFG_UPDATE_PHASE |
		 ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_success_freq_esync_phase_enable)
{
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_OUT_CFG_UPDATE_PHASE |
		 ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN |
		 ICE_AQC_SET_CGU_OUT_CFG_OUT_EN;

	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectNCalls(2, "kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_4_items, argv_freq_esync_phase_enable);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_freq_negative)
{
	strcpy(freq_val, "-1");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_freq);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_phase_negative)
{
	strcpy(phase_val, "-1");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtos32")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_bad_esync)
{
	strcpy(esync_val, "2");
	bool_ret = false;

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.ignoreOtherParameters()
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_freq_ok_esync_nok)
{
	argv_freq_esync[2] = &wrong_str[0];

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_2_items, argv_freq_esync);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_freq_ok_esync_ok_phase_nok)
{
	strcpy(phase_str, "phas");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_freq_ok_esync_ok_phase_ok_enable_nok)
{
	strcpy(enable_str, "enabled");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_4_items, argv_freq_esync_phase_enable);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_pin_negative)
{
	strcpy(pin_val, "-1");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_pin_over_max)
{
	strcpy(pin_val, "10");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_output_pin_cfg_fail_pin_str_nok)
{
	strcpy(pin_str, "pins");

	mock().expectNoCall("ice_aq_set_output_pin_cfg");
	mock().expectNoCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_output_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_freq)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_freq);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_phase)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_DELAY;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("phase_delay", 10000000)
		.withParameter("freq", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_phase);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_esync)
{
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags2", flags2)
		.withParameter("freq", 0)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_esync_off)
{
	strcpy(esync_val, "0");
	bool_ret = false;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags2", flags2)
		.withParameter("freq", 0)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_enable)
{
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_INPUT_EN;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags2", flags2)
		.withParameter("freq", 0)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_enable);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_enable_off)
{
	strcpy(enable_val, "0");
	bool_ret = false;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags2", flags2)
		.withParameter("freq", 0)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_enable);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_freq_esync)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
		mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_2_items, argv_freq_esync);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_freq_esync_phase)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_DELAY;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_freq_negative)
{
	strcpy(freq_val, "-1");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_freq);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_success_freq_esync_phase_enable)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_DELAY;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN |
		 ICE_AQC_SET_CGU_IN_CFG_FLG2_INPUT_EN;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectNCalls(2, "kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_4_items, argv_freq_esync_phase_enable);

	CHECK_EQUAL(0, ret);
}


TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_phase_negative)
{
	strcpy(phase_val, "-1");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtos32")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_bad_esync)
{
	strcpy(esync_val, "2");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.ignoreOtherParameters()
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_esync);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_freq_ok_esync_nok)
{
	argv_freq_esync[2] = &wrong_str[0];

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectOneCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_2_items, argv_freq_esync);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_freq_ok_esync_ok_phase_nok)
{
	strcpy(phase_str, "pase");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_pin_negative)
{
	strcpy(pin_val, "-1");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_pin_over_max)
{
	strcpy(pin_val, "10");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectNCalls(1, "kstrtou8")
		.andReturnValue(-EINVAL);

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_fail_pin_str_nok)
{
	strcpy(pin_str, "pins");

	mock().expectNoCall("ice_aq_set_input_pin_cfg");
	mock().expectNoCall("kstrtou8");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_3_items, argv_freq_esync_phase);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_in_esync_success)
{
	argv_split_return = argv_dir_esync;
	argc_split_return = 5;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags2", flags2)
		.withParameter("freq", 0)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_in_esync_freq_success)
{
	argv_split_return = argv_dir_freq_esync;
	argc_split_return = 7;
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_in_esync_freq_phase_success)
{
	argv_split_return = argv_dir_freq_esync_phase;
	argc_split_return = 9;
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_DELAY;
	flags2 = ICE_AQC_SET_CGU_IN_CFG_FLG2_ESYNC_EN;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_out_esync_success)
{
	argv_split_return = argv_dir_esync;
	argc_split_return = 5;
	strcpy(direction_str, "out");
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 0)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_out_esync_freq_success)
{
	argv_split_return = argv_dir_freq_esync;
	argc_split_return = 7;
	strcpy(direction_str, "out");
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN |
		 ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_out_esync_freq_phase_success)
{
	argv_split_return = argv_dir_freq_esync_phase;
	argc_split_return = 9;
	strcpy(direction_str, "out");
	flags1 = ICE_AQC_SET_CGU_OUT_CFG_ESYNC_EN |
		 ICE_AQC_SET_CGU_OUT_CFG_UPDATE_FREQ |
		 ICE_AQC_SET_CGU_OUT_CFG_UPDATE_PHASE;

	test_expect_ice_aq_get_output_pin_cfg();

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_output_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("output_idx", pin)
		.withParameter("flags", flags1)
		.withParameter("freq", 10000000)
		.withParameter("phase_comp", 10000000)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtobool")
		.withOutputParameterReturning("res", &bool_ret, sizeof(bool_ret));
	mock().expectOneCall("kstrtou32");
	mock().expectOneCall("kstrtos32");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_pin_prio_success)
{
	argv_split_return = argv_pin_prio;
	argc_split_return = 6;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectOneCall("ice_aq_set_cgu_ref_prio")
		.withParameter("hw", hw)
		.withParameter("dpll_num", dpll)
		.withParameter("ref_idx", pin)
		.withParameter("ref_prio", prio);
	mock().expectNCalls(3, "kstrtou8");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(dummy_size, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_pin_prio_fail)
{
	argv_split_return = argv_pin_prio;
	argv_pin_prio[1] = wrong_str;
	argc_split_return = 6;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectOneCall("kstrtou8")
		.andReturnValue(-EINVAL);
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_fail_arg_count_8)
{
	argv_split_return = argv_pin_prio;
	argc_split_return = 8;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNoCall("kstrtou8");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_fail_arg_count_4)
{
	argv_split_return = argv_pin_prio;
	argc_split_return = 4;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNoCall("kstrtou8");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_store_fail_arg_count_10)
{
	argv_split_return = argv_pin_prio;
	argc_split_return = 10;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("argv_split");
	mock().expectNoCall("ice_aq_set_cgu_ref_prio");
	mock().expectNoCall("ice_aq_get_cgu_ref_prio");
	mock().expectNoCall("kstrtou8");
	mock().expectOneCall("argv_free");

	ret = pin_cfg_store(dev, &dummy_attr, dummy_buf, dummy_size);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_anyfreq_success_1hz)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	pin_input_cfg.flags1 |= ICE_AQC_GET_CGU_IN_CFG_FLG1_ANYFREQ;
	char *argv_anyfreq[4];
	const char *freq = "1";
	argv_anyfreq[0] = argv_freq[0];
	argv_anyfreq[1] = argv_freq[1];
	argv_anyfreq[2] = argv_freq[2];
	argv_anyfreq[3] = (char*)freq;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 1)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withOutputParameterReturning("cfg", &pin_input_cfg, sizeof(pin_input_cfg))
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_anyfreq);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_anyfreq_success_500hz)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	pin_input_cfg.flags1 |= ICE_AQC_GET_CGU_IN_CFG_FLG1_ANYFREQ;
	char *argv_anyfreq[4];
	const char *freq = "500";
	argv_anyfreq[0] = argv_freq[0];
	argv_anyfreq[1] = argv_freq[1];
	argv_anyfreq[2] = argv_freq[2];
	argv_anyfreq[3] = (char*)freq;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 500)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withOutputParameterReturning("cfg", &pin_input_cfg, sizeof(pin_input_cfg))
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_anyfreq);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_no_anyfreq_success_10mhz)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	char *argv_anyfreq[4];
	const char *freq = "10000000";
	argv_anyfreq[0] = argv_freq[0];
	argv_anyfreq[1] = argv_freq[1];
	argv_anyfreq[2] = argv_freq[2];
	argv_anyfreq[3] = (char*)freq;

	mock().expectOneCall("ice_aq_set_input_pin_cfg")
		.withParameter("hw", hw)
		.withParameter("input_idx", pin)
		.withParameter("flags1", flags1)
		.withParameter("flags2", flags2)
		.withParameter("freq", 10000000)
		.withParameter("phase_delay", 0)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withOutputParameterReturning("cfg", &pin_input_cfg, sizeof(pin_input_cfg))
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_anyfreq);

	CHECK_EQUAL(0, ret);
}

TEST(ice_ptp_sysfs, ice_ptp_parse_and_apply_input_pin_cfg_no_anyfreq_fail_500hz)
{
	flags1 = ICE_AQC_SET_CGU_IN_CFG_FLG1_UPDATE_FREQ;
	char *argv_anyfreq[4];
	const char *freq = "500";
	argv_anyfreq[0] = argv_freq[0];
	argv_anyfreq[1] = argv_freq[1];
	argv_anyfreq[2] = argv_freq[2];
	argv_anyfreq[3] = (char*)freq;

	mock().expectOneCall("ice_aq_get_input_pin_cfg")
		.withParameter("hw", hw)
		.withOutputParameterReturning("cfg", &pin_input_cfg, sizeof(pin_input_cfg))
		.withParameter("input_idx", pin)
		.ignoreOtherParameters();
	mock().expectOneCall("kstrtou8");
	mock().expectOneCall("kstrtou32");

	ret = ice_ptp_parse_and_apply_input_pin_cfg(pf, argc_pin_cfg_1_item, argv_anyfreq);

	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ptp_sysfs, pin_cfg_show)
{
	struct ice_aqc_get_cgu_abilities abilities = {};
	struct ice_aqc_get_cgu_input_config cfg = {};
	flags1 = ICE_AQC_GET_CGU_OUT_CFG_OUT_EN |
		 ICE_AQC_GET_CGU_OUT_CFG_ESYNC_EN;
	dpll = 0;
	freq = 1000000000;
	src_freq = 1000000000;
	prio = 4;
	cfg.freq = freq;
	cfg.phase_delay = freq;
	cfg.input_idx = 3;
	cfg.status = ICE_AQC_GET_CGU_IN_CFG_STATUS_SCM_FAIL;
	cfg.flags2 = 0;
	abilities.num_inputs = 10;
	abilities.num_outputs = 10;

	char buf[PAGE_SIZE];
	char expected[] =
		"in\n"
		"| pin| enabled|   state|       freq| phase_delay| esync| DPLL0 prio| DPLL1 prio|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"|   3|       0| invalid| 1000000000|  1000000000|     0|          4|          4|\n"
		"out\n"
		"| pin| enabled| dpll|       freq| esync|\n"
		"|   0|       1|    0| 1000000000|     1|\n"
		"|   1|       1|    0| 1000000000|     1|\n"
		"|   2|       1|    0| 1000000000|     1|\n"
		"|   3|       1|    0| 1000000000|     1|\n"
		"|   4|       1|    0| 1000000000|     1|\n"
		"|   5|       1|    0| 1000000000|     1|\n"
		"|   6|       1|    0| 1000000000|     1|\n"
		"|   7|       1|    0| 1000000000|     1|\n"
		"|   8|       1|    0| 1000000000|     1|\n"
		"|   9|       1|    0| 1000000000|     1|\n";

	mock().expectOneCall("ice_aq_get_cgu_abilities")
		.withParameter("hw", hw)
		.withOutputParameterReturning("abilities", &abilities, sizeof(abilities));
	mock().expectNCalls(20, "ice_aq_get_cgu_ref_prio")
		.withOutputParameterReturning("ref_prio", &prio, sizeof(prio))
		.ignoreOtherParameters();
	mock().expectNCalls(10, "ice_aq_get_input_pin_cfg")
		.withOutputParameterReturning("cfg", &cfg, sizeof(cfg))
		.ignoreOtherParameters();
	mock().expectNCalls(10, "ice_aq_get_output_pin_cfg")
		.withParameter("hw", hw)
		.withOutputParameterReturning("flags", &flags1, sizeof(flags1))
		.withOutputParameterReturning("src_sel", &dpll, sizeof(dpll))
		.withOutputParameterReturning("freq", &freq, sizeof(freq))
		.withOutputParameterReturning("src_freq", &src_freq, sizeof(src_freq))
		.ignoreOtherParameters();

	ret = pin_cfg_show(dev, &dummy_attr, buf);

	STRCMP_EQUAL(expected, buf);
}

TEST(ice_ptp_sysfs, dpll_1_offset_show)
{
	char offset[10];
	char expected[] = "-1000\n";

	pf->ptp_dpll_phase_offset = -1000;

	dpll_1_offset_show(dev, &dummy_attr, offset);

	STRCMP_EQUAL(expected, offset);
}

TEST(ice_ptp_sysfs, dpll_name_show_synce)
{
	struct dpll_attribute dpll_attr;
	char name[5];
	char expected[] = "EEC\n";

	dpll_attr.dpll_num = ICE_CGU_DPLL_SYNCE;

	dpll_name_show(dev, &dpll_attr.attr, name);

	STRCMP_EQUAL(expected, name);
}

TEST(ice_ptp_sysfs, dpll_name_show_ptp)
{
	struct dpll_attribute dpll_attr;
	char name[5];
	char expected[] = "PPS\n";

	dpll_attr.dpll_num = ICE_CGU_DPLL_PTP;

	dpll_name_show(dev, &dpll_attr.attr, name);

	STRCMP_EQUAL(expected, name);
}

TEST(ice_ptp_sysfs, dpll_state_show_synce)
{
	struct dpll_attribute dpll_attr;
	char state[3];
	char expected[] = "3\n";

	pf->synce_dpll_state = ICE_CGU_STATE_LOCKED_HO_ACQ;
	dpll_attr.dpll_num = ICE_CGU_DPLL_SYNCE;

	dpll_state_show(dev, &dpll_attr.attr, state);

	STRCMP_EQUAL(expected, state);
}

TEST(ice_ptp_sysfs, dpll_state_show_ptp)
{
	struct dpll_attribute dpll_attr;
	char state[3];
	char expected[] = "2\n";

	pf->ptp_dpll_state = ICE_CGU_STATE_LOCKED;
	dpll_attr.dpll_num = ICE_CGU_DPLL_PTP;

	dpll_state_show(dev, &dpll_attr.attr, state);

	STRCMP_EQUAL(expected, state);
}

TEST(ice_ptp_sysfs, dpll_ref_pin_show_synce)
{
	struct dpll_attribute dpll_attr;
	char ref_pin[3];
	char expected[] = "5\n";

	pf->synce_dpll_state = ICE_CGU_STATE_LOCKED_HO_ACQ;
	pf->synce_ref_pin = 5;
	dpll_attr.dpll_num = ICE_CGU_DPLL_SYNCE;

	dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);

	STRCMP_EQUAL(expected, ref_pin);
}

TEST(ice_ptp_sysfs, dpll_ref_pin_show_ptp)
{
	struct dpll_attribute dpll_attr;
	char ref_pin[3];
	char expected[] = "7\n";

	pf->ptp_dpll_state = ICE_CGU_STATE_LOCKED;
	pf->ptp_ref_pin = 7;
	dpll_attr.dpll_num = ICE_CGU_DPLL_PTP;

	dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);

	STRCMP_EQUAL(expected, ref_pin);
}

TEST(ice_ptp_sysfs, dpll_ref_pin_show_valid_states)
{
	struct dpll_attribute dpll_attr;
	char ref_pin[3];
	char expected[] = "6\n";

	pf->synce_ref_pin = 6;
	dpll_attr.dpll_num = ICE_CGU_DPLL_SYNCE;

	pf->synce_dpll_state = ICE_CGU_STATE_LOCKED;
	dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL(expected, ref_pin);

	pf->synce_dpll_state = ICE_CGU_STATE_LOCKED_HO_ACQ;
	dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL(expected, ref_pin);

	pf->synce_dpll_state = ICE_CGU_STATE_HOLDOVER;
	dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL(expected, ref_pin);
}

TEST(ice_ptp_sysfs, dpll_ref_pin_show_invalid_states)
{
	struct dpll_attribute dpll_attr;
	char ref_pin[3] = "";
	ssize_t ret;

	pf->synce_ref_pin = 6;
	dpll_attr.dpll_num = ICE_CGU_DPLL_SYNCE;

	pf->synce_dpll_state = ICE_CGU_STATE_UNKNOWN;
	ret = dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL("", ref_pin);
	CHECK_EQUAL(-EAGAIN, ret);

	pf->synce_dpll_state = ICE_CGU_STATE_INVALID;
	ret = dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL("", ref_pin);
	CHECK_EQUAL(-EAGAIN, ret);

	pf->synce_dpll_state = ICE_CGU_STATE_FREERUN;
	ret = dpll_ref_pin_show(dev, &dpll_attr.attr, ref_pin);
	STRCMP_EQUAL("", ref_pin);
	CHECK_EQUAL(-EAGAIN, ret);
}

/* Release devm allocated memory manually, as it will not be freed by devm
 * in tdd_tests */
static void
ice_ptp_sysfs_release_devm_mem(struct dpll_attribute *dpll_attributes)
{
	int i;

	for (i = 0; i < ICE_CGU_DPLL_MAX; ++i) {
		if (dpll_attributes[i].attr.attr.name)
			kfree((char *) dpll_attributes[i].attr.attr.name);
	}

	kfree(dpll_attributes);
}

TEST(ice_ptp_sysfs, ice_ptp_sysfs_init_deinit)
{
	pf->hw.func_caps.ts_func_info.src_tmr_owned = 1;
	struct kobject phy_kobj;

	mock().expectOneCall("kobject_create_and_add")
		.withParameter("name", "phy")
		.withParameter("parent", &dev->kobj)
		.andReturnValue(&phy_kobj);
	mock().expectOneCall("sysfs_create_file")
		.withParameter("kobj", &phy_kobj)
		.withConstPointerParameter("attr", &synce_attribute.attr);
	mock().expectNCalls(8, "device_create_file")
		.withParameter("device", dev)
		.ignoreOtherParameters();
	mock().expectOneCall("ice_is_feature_supported")
		.withParameter("pf", pf)
                .withParameter("f", ICE_F_PHY_RCLK)
                .andReturnValue(true);
	mock().expectOneCall("ice_is_feature_supported")
		.withParameter("pf", pf)
                .withParameter("f", ICE_F_CGU)
                .andReturnValue(true);
	ice_ptp_sysfs_init(pf);

	CHECK_EQUAL(pf->ptp.phy_kobj, &phy_kobj);

	mock().expectNCalls(8, "device_remove_file")
		.withParameter("device", dev)
		.ignoreOtherParameters();
	mock().expectOneCall("sysfs_remove_file")
		.withParameter("kobj", pf->ptp.phy_kobj)
		.ignoreOtherParameters();
	mock().expectOneCall("kobject_put")
		.withParameter("kobj", pf->ptp.phy_kobj);
	mock().expectOneCall("ice_is_feature_supported")
		.withParameter("pf", pf)
                .withParameter("f", ICE_F_CGU)
                .andReturnValue(true);

	ice_ptp_sysfs_release(pf);

	CHECK_EQUAL(0, pf->ptp.phy_kobj);

	/* Release devm allocated memory manually */
	ice_ptp_sysfs_release_devm_mem(dpll_name_attrs);
	ice_ptp_sysfs_release_devm_mem(dpll_state_attrs);
	ice_ptp_sysfs_release_devm_mem(dpll_ref_pin_attrs);
}

TEST_GROUP_BASE(ice_ptp_set_ts_config, TGN(ice_ptp))
{
	struct hwtstamp_config *config;
	struct ifreq *ifr;

	TEST_SETUP() {
		TGN(ice_ptp)::setup();

		ifr = (struct ifreq *)calloc(1, sizeof(*ifr));
		config = (struct hwtstamp_config *)calloc(1, sizeof(*config));

		ifr->ifr_data = (char *)config;

		pf->ptp.tstamp_config.tx_type = HWTSTAMP_TX_OFF;
		pf->ptp.tstamp_config.rx_filter = HWTSTAMP_FILTER_NONE;

		set_bit(ICE_FLAG_PTP, pf->flags);
	}

	TEST_TEARDOWN() {
		free(ifr);
		free(config);

		TGN(ice_ptp)::teardown();
	}
};

TEST(ice_ptp_set_ts_config, all_packets)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_ALL;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v1_l4_event)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V1_L4_EVENT;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v1_l4_sync)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V1_L4_SYNC;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v1_l4_delay_req)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V1_L4_DELAY_REQ;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_event)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_EVENT;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l2_event)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L2_EVENT;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l4_event)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L4_EVENT;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l2_sync)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L2_SYNC;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l4_sync)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L4_SYNC;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_delay_req)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_DELAY_REQ;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l2_DELAY_REQ)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L2_DELAY_REQ;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, v2_l4_delay_req)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_PTP_V2_L4_DELAY_REQ;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST(ice_ptp_set_ts_config, ntp_packets)
{
	int err;

	config->rx_filter = HWTSTAMP_FILTER_NTP_ALL;

	err = ice_ptp_set_ts_config(pf, ifr);
	CHECK_EQUAL(0, err);

	/* Make sure we get value we expect */
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, config->rx_filter);
	CHECK_EQUAL(HWTSTAMP_FILTER_ALL, pf->ptp.tstamp_config.rx_filter);
}

TEST_GROUP_BASE(ice_adjfine, TGN(ice_ptp))
{
	struct ptp_clock_info *info;

	TEST_SETUP() {
		TGN(ice_ptp)::setup();

		info = &pf->ptp.info;

		pf->ptp.src_tmr_mode = ICE_SRC_TMR_MODE_NANOSECONDS;
	}

	TEST_TEARDOWN() {
		TGN(ice_ptp)::teardown();
	}
};

TEST(ice_adjfine, scaled_ppm_zero_25_000)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_25_000);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_25_000;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_zero_122_880)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_122_880);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_122_880;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_zero_125_000)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_125_000);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_125_000;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_zero_153_600)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_153_600);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_153_600;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_zero_156_250)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_156_250);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_156_250;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_zero_245_760)
{
	uint64_t incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_245_760);
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_245_760;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", incval)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}

#ifndef SWITCH_MODE
bool force_ice_is_e810(struct ice_hw *hw)
{
	return true;
}

TEST(ice_adjfine, scaled_ppm_zero_e810)
{
	int err;

	hw->mac_type = ICE_MAC_E810;

	USE_MOCK(ice_is_e810, force_ice_is_e810);

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", ICE_PTP_NOMINAL_INCVAL_E810)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 0);
	CHECK_EQUAL(0, err);
}
#endif

TEST(ice_adjfine, scaled_ppm_small_value)
{
	uint64_t base_incval, adj;
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_25_000;
	base_incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_25_000);

	/* adjfine takes in a scaled_ppm adjustment and will calculate an
	 * appropriate addition or subtraction from the base increment value
	 * as a fractional adjustment. Scaled ppm is parts per million scaled
	 * up by a factor of 2^16, or '1000000 << 16'. An input of '1' is
	 * a request to scale up the frequency by 1 part in 65,536,000,000.
	 *
	 * Our increment register value does not have high enough resolution
	 * to handle that small of an adjustment so it will round down to
	 * a change of zero.
	 *
	 * With the 25 MHz clock source, our base increment value is
	 * 0x136e44fabULL. A request to increase by 50 scaled_ppm should
	 * result in performing the following calculations:
	 *
	 * (0x136e44fabULL * 50) / (1000000 << 16)
	 *
	 * Which comes to a value of 3 as the amount to add to the base
	 * increment value.
	 */
	adj = 3;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", base_incval + adj)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 50);
	CHECK_EQUAL(0, err);
}

TEST(ice_adjfine, scaled_ppm_max_value)
{
	uint64_t base_incval, adj;
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_25_000;
	base_incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_25_000);

	/* With an input of 1,000,000 << 16 we expect an adjustment of exactly
	 * equal to the base increment value, i.e. to double the clock rate.
	 * Note that although this could trigger the lossy implementation to
	 * drop precision, it divides both values equally resulting in
	 * a perfect cancellation that avoids the precision loss.
	 */
	adj = base_incval;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", base_incval + adj)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, (1000000UL) << 16);
	CHECK_EQUAL(0, err);
}

#if defined(__SIZEOF_INT128__)
TEST(ice_adjfine, scaled_ppm_large_value_high_precision)
{
	uint64_t base_incval, adj;
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_25_000;
	base_incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_25_000);

	/* With the use of mul_u64_u64_div_u64 on platforms that support
	 * 128bit arithmetic, the intermediate multiplication won't overflow
	 * due to the higher precision type.
	 */
	adj = 0x136E44FA3;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", base_incval + adj)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 65535999900);
	CHECK_EQUAL(0, err);
}
#endif

TEST(ice_adjfine, scaled_ppm_large_value_lose_precision)
{
	uint64_t base_incval, adj;
	int err;

	hw->mac_type = ICE_MAC_GENERIC;
	hw->func_caps.ts_func_info.time_ref = ICE_TIME_REF_FREQ_25_000;
	base_incval = ice_e822_nominal_incval(ICE_TIME_REF_FREQ_25_000);

	USE_MOCK(mul_u64_u64_div_u64, lossy_mul_u64_u64_div_u64);

	/* With an input that is very near the maximum value, we might lose
	 * some precision. The TDD mul_u64_u64_div_u64 implementation in that
	 * case will fall back to a lossy algorithm that forgoes precision for
	 * large adjustments.
	 *
	 * The maximum value we accept is 65536000000 so a value near (but not
	 * equal to) this should lose precision when adjusting.
	 */
	adj = 0x136E44FA0;

	mock().expectOneCall("ice_ptp_write_incval_locked")
		.withParameter("hw", hw)
		.withParameter("incval", base_incval + adj)
		.andReturnValue(0);

	err = ice_ptp_adjfine(info, 65535999900);
	CHECK_EQUAL(0, err);
}

#endif /* SYNCE_SUPPORT */
