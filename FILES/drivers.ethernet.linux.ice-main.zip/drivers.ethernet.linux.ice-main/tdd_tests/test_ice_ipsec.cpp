/*
 * Copyright(c) 2018 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#ifdef BMSM_MODE
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_ipsec {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "../src/CORE/ice.h"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "../src/CORE/ice_ipsec.c"
}
/////////////////////////////////////////////////
using namespace ns_ipsec;

static const u16 mocked_req_id = 32;
static const u32 mocked_response = 24;

static bool vf_not_capable(struct ice_vf *vf)
{
	return false;
}

static bool vf_capable(struct ice_vf *vf)
{
	return true;
}

int validate_response_msg(struct ice_vf *vf, u32 opcode,
			  enum virtchnl_status_code v_ret, u8 *msg, u16 len)
{
	struct inline_ipsec_msg *ipsec = (struct inline_ipsec_msg *)msg;

	CHECK_EQUAL(ipsec->ipsec_opcode, INLINE_IPSEC_OP_RESP);
	CHECK_EQUAL(ipsec->req_id, mocked_req_id);
	CHECK_EQUAL(ipsec->ipsec_data.ipsec_resp->resp, mocked_response);
	return 0;
}

TEST_GROUP(ipsec_grp)
{
	struct device *dev;
	struct ice_vsi *vsi;
	struct ice_vfs *vfs;
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct inline_ipsec_msg ipsec_msg;

	void test_del_vfs() {
		struct hlist_node *tmp;
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each_safe(pf->vfs.table, bkt, tmp, vf, entry) {
			hash_del(&vf->entry);
			mutex_destroy(&vf->cfg_lock);
			kfree(vf);
		}
	}

	struct ice_vf *test_add_one_vf(int i) {
		struct ice_vf *vf;

		vf = (struct ice_vf *)kzalloc(sizeof(*vf), GFP_KERNEL);

		vf->pf = pf;
		vf->vf_id = i;
		mutex_init(&vf->cfg_lock);
		kref_init(&vf->refcnt);

		hash_add(vfs->table, &vf->entry, i);
		return vf;
	}

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));

		vfs = &pf->vfs;
		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);

		vf = test_add_one_vf(0);
	}

	void teardown(void)
	{
		test_del_vfs();
		mutex_destroy(&vfs->table_lock);
		free(pf->pdev);
		free(pf);
		pf = NULL;
		vf = NULL;
	}
};

TEST(ipsec_grp, ipsec_not_available_because_of_no_driver_caps)
{
	vf->driver_caps = 0;
	CHECK_FALSE(ice_is_vf_ipsec_capable(vf));
}

TEST(ipsec_grp, ipsec_available)
{
	vf->driver_caps = VIRTCHNL_VF_OFFLOAD_INLINE_IPSEC_CRYPTO;
	CHECK_TRUE(ice_is_vf_ipsec_capable(vf));
}

TEST(ipsec_grp, receive_idc_success)
{
	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("vf", vf)
		.withParameter("v_opcode", VIRTCHNL_OP_INLINE_IPSEC)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.withParameter("msg", (u8 *)&ipsec_msg, sizeof(ipsec_msg))
		.withParameter("msglen", sizeof(ipsec_msg))
		.andReturnValue(0);
	USE_MOCK(ice_is_vf_ipsec_capable, vf_capable);
	CHECK_EQUAL(0, ice_vc_send_msg_to_vf(vf, VIRTCHNL_OP_INLINE_IPSEC,
			VIRTCHNL_STATUS_SUCCESS, (u8 *)&ipsec_msg, sizeof(ipsec_msg)));
}

TEST(ipsec_grp, send_response_frame_success)
{
	USE_MOCK(ice_vc_send_msg_to_vf, validate_response_msg);
	CHECK_EQUAL(0, ice_ipsec_send_response_to_vc(vf, mocked_req_id,
						     mocked_response));
}

TEST(ipsec_grp, ipsec_send_vc_msg_unicast)
{
	u32 vf_id = 0;

	mock().expectOneCall("ice_vc_send_msg_to_vf")
		.withParameter("v_opcode", VIRTCHNL_OP_INLINE_IPSEC)
		.withParameter("v_retval", VIRTCHNL_STATUS_SUCCESS)
		.ignoreOtherParameters()
		.andReturnValue(0);
	CHECK_EQUAL(0, ice_ipsec_send_vc_msg(pf, (u8 *)&ipsec_msg,
				sizeof(ipsec_msg), vf_id));
}
#endif /* BMSM_MODE */
