/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"
#include "math.h"
#include <stdint.h>
#include <cstdio>
#include <algorithm>
#include <linux/types.h>
#include <sys/mman.h>
#include "CppUTest/TestHarness.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_kcompat_pldmfw {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "linux/log2.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/compiler.h>
#include <linux/bitmap.h>
#include <linux/kobject.h>
#include <linux/kconfig.h>
#include <asm/byteorder.h>

#include "KERNEL_MOCKS/mock_kernel.cpp"

#include "KERNEL_LIBS/crc32.c"

#include "../src/COMPAT/kcompat_pldmfw.c"
}
/////////////////////////////////////////////////
using namespace ns_kcompat_pldmfw;

static const pldmfw_ops tdd_fwu_ops = {
	.match_record = pldmfw_op_pci_match_record,
};

#include "tdd_fw_object.h"

TEST_GROUP_BASE(setup_pldm_fwu, load_fw_object)
{
	struct pldmfw_priv data;
	struct pldmfw context;
	struct pci_dev pdev;
	struct device *dev;

	TEST_SETUP()
	{
		load_fw_object::setup();

		memset(&pdev, 0, sizeof(pdev));
		memset(&data, 0, sizeof(data));
		memset(&context, 0, sizeof(context));

		dev = &pdev.dev;

		context.dev = dev;
		context.ops = &tdd_fwu_ops;
		data.context = &context;

		INIT_LIST_HEAD(&data.records);
		INIT_LIST_HEAD(&data.components);

		pdev.vendor = 0x8086;
		pdev.subsystem_vendor = 0x8086;
	}

	TEST_TEARDOWN()
	{
		pldmfw_free_priv(&data);

		load_fw_object::teardown();
	}
};

TEST_GROUP_BASE(setup_image_data, TGN(setup_pldm_fwu))
{
	void tdd_load_fw(const char *filename, bool increase_map_size)
	{
		TGN(setup_pldm_fwu)::tdd_load_fw(filename, increase_map_size);

		data.fw = &fw;
	}

	void tdd_load_fw(const char *filename)
	{
		tdd_load_fw(filename, true);
	}

	TEST_SETUP()
	{
		TGN(setup_pldm_fwu)::setup();
	}

	TEST_TEARDOWN()
	{
		data.fw = &fw;

		TGN(setup_pldm_fwu)::teardown();
	}
};

/* Macro to reduce copy-paste boilerplate for many test files */
#define TEST_PLDM_HEADER_FILE(name, expected)				\
TEST(setup_image_data, parse_##name)					\
{									\
	int err;							\
									\
	tdd_load_fw("pldm_fw_files/" __stringify(name) ".bin");		\
									\
	err = pldm_parse_image(&data);				\
	CHECK_EQUAL(expected, err);					\
}

/* Known good files */
TEST_PLDM_HEADER_FILE(E810_BACKPLANE_100G_NRB, 0)
TEST_PLDM_HEADER_FILE(E810_BACKPLANE_10G_NRB, 0)
TEST_PLDM_HEADER_FILE(E810_BACKPLANE_25G_NRB, 0)
TEST_PLDM_HEADER_FILE(E810_CQDA1_O, 0)
TEST_PLDM_HEADER_FILE(E810_CQDA1_OCP2_O, 0)
TEST_PLDM_HEADER_FILE(E810_CQDA2_O, 0)
TEST_PLDM_HEADER_FILE(E810_CQDA2_OCP_O, 0)
TEST_PLDM_HEADER_FILE(E810_LDA2_O, 0)
TEST_PLDM_HEADER_FILE(E810_QSFP_100G_NRB_INV, 0)
TEST_PLDM_HEADER_FILE(E810_SFP_10G_NRB, 0)
TEST_PLDM_HEADER_FILE(E810_SFP_25G_NRB_INV, 0)
TEST_PLDM_HEADER_FILE(E810_SFP_25G_NRB_SD, 0)
TEST_PLDM_HEADER_FILE(E810_XXVDA2_OCP_O, 0)
TEST_PLDM_HEADER_FILE(E810_XXVDA2_SD_O, 0)
TEST_PLDM_HEADER_FILE(E810_XXVDA2_SD_OCP_O, 0)
TEST_PLDM_HEADER_FILE(E810_XXVDA4_FH_O, 0)
TEST_PLDM_HEADER_FILE(E810_XXVDA4_LP_O, 0)

/* Files with invalid formatting, to test that the parser will reject them.
 * For details on exactly what was changed, read pldm_fw_files/README.md
 */
TEST_PLDM_HEADER_FILE(invalid_uuid, -EINVAL)
TEST_PLDM_HEADER_FILE(revision_2_not_supported, -EOPNOTSUPP)
TEST_PLDM_HEADER_FILE(bitmap_len_not_multiple_of_8, -EINVAL)
TEST_PLDM_HEADER_FILE(bitmap_len_too_large, -EINVAL)
TEST_PLDM_HEADER_FILE(header_size_too_small, -EFAULT)
TEST_PLDM_HEADER_FILE(header_size_too_large, -EFAULT)
TEST_PLDM_HEADER_FILE(invalid_record_length, -EFAULT)
TEST_PLDM_HEADER_FILE(invalid_record_version_length, -EINVAL)
TEST_PLDM_HEADER_FILE(invalid_record_package_length, -EFAULT)
TEST_PLDM_HEADER_FILE(invalid_record_desc_count, -EINVAL)
TEST_PLDM_HEADER_FILE(invalid_descriptor_length, -EINVAL)
TEST_PLDM_HEADER_FILE(invalid_component_version_length, -EFAULT)
TEST_PLDM_HEADER_FILE(invalid_crc, -EBADMSG)
TEST_PLDM_HEADER_FILE(invalid_crc2, -EBADMSG)

TEST(setup_image_data, parse_incomplete_E810_CQDA2_O)
{
	int err;

	/* Do not load with the forced size increase */
	tdd_load_fw("pldm_fw_files/E810_CQDA2_O.bin", false);

	err = pldm_parse_image(&data);
	CHECK_EQUAL(-EFAULT, err);
}

TEST(setup_image_data, parse_complete_E810_CQDA2_O)
{
	int err;

	tdd_load_fw("pldm_fw_files/complete_E810_CQDA2_O.bin");

	err = pldm_parse_image(&data);
	CHECK_EQUAL(0, err);
}

TEST_GROUP_BASE(find_record, TGN(setup_image_data))
{
	TEST_SETUP()
	{
		TGN(setup_image_data)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(setup_image_data)::teardown();
	}
};

#define TEST_PLDM_HAS_RECORD(name, expected_device)			\
TEST(find_record, find_record_##name)					\
{									\
	int err;						\
									\
	tdd_load_fw("pldm_fw_files/" __stringify(name) ".bin");		\
									\
	pdev.device = expected_device;					\
									\
	err = pldm_parse_image(&data);					\
	CHECK_EQUAL(0, err);				\
									\
	err = pldm_find_matching_record(&data);				\
	CHECK_EQUAL(0, err);				\
}

/* Known good files */
TEST_PLDM_HAS_RECORD(E810_BACKPLANE_100G_NRB, 0x1592)
TEST_PLDM_HAS_RECORD(E810_BACKPLANE_10G_NRB, 0x1593)
TEST_PLDM_HAS_RECORD(E810_BACKPLANE_25G_NRB, 0x1593)
TEST_PLDM_HAS_RECORD(E810_CQDA1_O, 0x1592)
TEST_PLDM_HAS_RECORD(E810_CQDA1_OCP2_O, 0x1592)
TEST_PLDM_HAS_RECORD(E810_CQDA2_O, 0x1592)
TEST_PLDM_HAS_RECORD(E810_CQDA2_OCP_O, 0x1592)
TEST_PLDM_HAS_RECORD(E810_LDA2_O, 0x1592)
TEST_PLDM_HAS_RECORD(E810_QSFP_100G_NRB_INV, 0x1592)
TEST_PLDM_HAS_RECORD(E810_SFP_10G_NRB, 0x1593)
TEST_PLDM_HAS_RECORD(E810_SFP_25G_NRB_INV, 0x1593)
TEST_PLDM_HAS_RECORD(E810_SFP_25G_NRB_SD, 0x159b)
TEST_PLDM_HAS_RECORD(E810_XXVDA2_OCP_O, 0x1593)
TEST_PLDM_HAS_RECORD(E810_XXVDA2_SD_O, 0x159b)
TEST_PLDM_HAS_RECORD(E810_XXVDA2_SD_OCP_O, 0x159b)
TEST_PLDM_HAS_RECORD(E810_XXVDA4_FH_O, 0x1593)
TEST_PLDM_HAS_RECORD(E810_XXVDA4_LP_O, 0x1593)

TEST(find_record, find_record_E810_XXVDA2_OCP_O_subdev_id)
{
	int err;

	tdd_load_fw("pldm_fw_files/E810_XXVDA2_OCP_O.bin");

	pdev.device = 0x1593;
	pdev.subsystem_device = 0x0002;

	err = pldm_parse_image(&data);
	CHECK_EQUAL(0, err);

	err = pldm_find_matching_record(&data);
	CHECK_EQUAL(0, err);
}
