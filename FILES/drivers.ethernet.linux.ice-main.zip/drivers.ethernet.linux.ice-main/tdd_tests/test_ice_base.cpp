#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_base {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "ice_flex_pipe.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/dim.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/kernel.h>
#include <linux/cpumask.h>
#include <linux/pm_wakeup.h>
#include <linux/rtnetlink.h>
#include <net/act_api.h>
#include <net/pkt_cls.h>
#include <net/tc_act/tc_gact.h>
#include <linux/netdevice.h>

#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_adminq_cmd.h"
#include "../src/CORE/ice.h"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_dcb.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_dcb_nl.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "local_ice_common.cpp"

#include "CORE_MOCKS/stdmock_ice_header.cpp"
#include "CORE_MOCKS/stdmock_ice_base.cpp"

#include "../src/CORE/ice_base.c"
}
/////////////////////////////////////////////////
using namespace ns_base;

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

/* XPS: the xps map should not be set if there is more than one TC */
TEST_GROUP(ice_xps_cfg)
{
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	struct ice_q_vector *q_vector;
	struct net_device *netdev;
	void setup(void)
	{
		ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		ring->vsi = vsi;
		ring->netdev = netdev;
		ring->q_vector = q_vector;
		clear_bit(ICE_TX_XPS_INIT_DONE, ring->xps_state);
	}
	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(vsi);
		free_netdev(netdev);
		free(q_vector);
		free(ring);
	}
};

TEST(ice_xps_cfg, set_xps_map)
{
	vsi->tc_cfg.numtc = 1;
	mock().expectOneCall("netif_set_xps_queue")
		.ignoreOtherParameters()
		.andReturnValue(0);
	ice_cfg_xps_tx_ring(ring);
	CHECK_EQUAL(1, test_bit(ICE_TX_XPS_INIT_DONE, ring->xps_state));
}

TEST(ice_xps_cfg, check_tc_priority)
{
	vsi->tc_cfg.numtc = 2;
	ice_cfg_xps_tx_ring(ring);
	CHECK_EQUAL(0, test_bit(ICE_TX_XPS_INIT_DONE, ring->xps_state));
}

TEST_GROUP(ice_itr)
{
	struct ice_q_vector *q_vector;
	struct ice_hw hw;

	void setup()
	{
		q_vector = (struct ice_q_vector *)calloc(1, sizeof(*q_vector));
		q_vector->reg_idx = 13;
		/* itr param is seting to default in alloc function */
		q_vector->rx.itr_setting = ICE_DFLT_RX_ITR;
		q_vector->tx.itr_setting = ICE_DFLT_TX_ITR;
		/* Make just enough space for PF0INT_ITR_1 */
		hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw) +
					  PF0INT_ITR_1(q_vector->reg_idx));
		hw.itr_gran = 2;
	}

	void teardown()
	{
		free(q_vector);
		q_vector = NULL;
		free(hw.hw_addr);
		hw.hw_addr = NULL;
	}
};

TEST(ice_itr, ice_cfg_itr_gran_reg_all_0s_initially)
{
	u32 regval;

	ice_cfg_itr_gran(&hw);

	regval = rd32(&hw, GLINT_CTL);
	CHECK_EQUAL(0, (regval & GLINT_CTL_DIS_AUTOMASK_M) >>
		    GLINT_CTL_DIS_AUTOMASK_M);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_200_M) >>
		    GLINT_CTL_ITR_GRAN_200_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_100_M) >>
		    GLINT_CTL_ITR_GRAN_100_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_50_M) >>
		    GLINT_CTL_ITR_GRAN_50_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_25_M) >>
		    GLINT_CTL_ITR_GRAN_25_S);
}

TEST(ice_itr, ice_cfg_itr_gran_reg_incorrect_values)
{
	u32 regval;

	/*  write different values than we expect */
	regval = ((1 << GLINT_CTL_DIS_AUTOMASK_S) &
		  GLINT_CTL_DIS_AUTOMASK_M) |
		 ((8 << GLINT_CTL_ITR_GRAN_200_S) &
		  GLINT_CTL_ITR_GRAN_200_M) |
		 ((4 << GLINT_CTL_ITR_GRAN_100_S) &
		  GLINT_CTL_ITR_GRAN_100_M) |
		 ((6 << GLINT_CTL_ITR_GRAN_50_S) &
		  GLINT_CTL_ITR_GRAN_50_M) |
		 ((5 << GLINT_CTL_ITR_GRAN_25_S) &
		  GLINT_CTL_ITR_GRAN_25_M);
	wr32(&hw, GLINT_CTL, regval);

	/* make sure our dummy values got written */
	regval = rd32(&hw, GLINT_CTL);
	CHECK_EQUAL(1, (regval & GLINT_CTL_DIS_AUTOMASK_M) >>
		    GLINT_CTL_DIS_AUTOMASK_S);
	CHECK_EQUAL(8, (regval & GLINT_CTL_ITR_GRAN_200_M) >>
		    GLINT_CTL_ITR_GRAN_200_S);
	CHECK_EQUAL(4, (regval & GLINT_CTL_ITR_GRAN_100_M) >>
		    GLINT_CTL_ITR_GRAN_100_S);
	CHECK_EQUAL(6, (regval & GLINT_CTL_ITR_GRAN_50_M) >>
		    GLINT_CTL_ITR_GRAN_50_S);
	CHECK_EQUAL(5, (regval & GLINT_CTL_ITR_GRAN_25_M) >>
		    GLINT_CTL_ITR_GRAN_25_S);

	ice_cfg_itr_gran(&hw);

	/* check that all values are as back to what we want */
	regval = rd32(&hw, GLINT_CTL);
	CHECK_EQUAL(0, (regval & GLINT_CTL_DIS_AUTOMASK_M) >>
		    GLINT_CTL_DIS_AUTOMASK_M);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_200_M) >>
		    GLINT_CTL_ITR_GRAN_200_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_100_M) >>
		    GLINT_CTL_ITR_GRAN_100_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_50_M) >>
		    GLINT_CTL_ITR_GRAN_50_S);
	CHECK_EQUAL(ICE_ITR_GRAN_US, (regval & GLINT_CTL_ITR_GRAN_25_M) >>
		    GLINT_CTL_ITR_GRAN_25_S);
}

TEST(ice_itr, num_ring_rx_tx_zero)
{
	q_vector->num_ring_rx = 0;
	q_vector->num_ring_tx = 0;

	mock().expectNoCall("ice_write_itr");
	mock().expectOneCall("ice_write_intrl")
		.ignoreOtherParameters();
	ice_cfg_itr(&hw, q_vector);
	CHECK_EQUAL(0, rd32(&hw, GLINT_ITR(q_vector->rx.itr_idx,
					   q_vector->reg_idx)));
	CHECK_EQUAL(0, rd32(&hw, GLINT_ITR(q_vector->tx.itr_idx,
					   q_vector->reg_idx)));
}

TEST(ice_itr, default_value_test)
{
	using namespace ns_base;

	q_vector->num_ring_rx = 1;
	q_vector->num_ring_tx = 1;

	mock().expectNCalls(2, "ice_write_itr");
	mock().expectOneCall("ice_write_intrl")
		.ignoreOtherParameters();
	ice_cfg_itr(&hw, q_vector);
}

TEST_GROUP(ice_get_qs)
{
	struct mutex qs_mutex;
	void setup(void)
	{
		mutex_init(&qs_mutex);
	}
	void teardown(void)
	{
		mock().checkExpectations();
		mutex_destroy(&qs_mutex);
	}
};

TEST(ice_get_qs, get_qs_ok)
{
	int ret, i;
	unsigned int offset;
	// pf map with pf map size
	DECLARE_BITMAP(avail_txqs, 10);
	// vsi map
	u16 txq_map[10];
	struct ice_qs_cfg qs_cfg = { .qs_mutex = &qs_mutex,
				     .pf_map = avail_txqs,
				     .pf_map_size = 10,
				     .q_count = 4,
				     .scatter_count = 4,
				     .vsi_map = txq_map,
				     .vsi_map_offset = 0,
				     .mapping_mode = ICE_VSI_MAP_CONTIG};

	bitmap_zero(avail_txqs, 10);
	// init vsi map with ICE_INVAL_Q_INDEX
	memset(txq_map, 0xff, sizeof(txq_map));
	CHECK_EQUAL(txq_map[9], ICE_INVAL_Q_INDEX);

	// get first 4 queues
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(0, ret);

	// get next 4 queues from pf map
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(0, ret);
	// make sure that we overwrite the previous values in vsi map
	// so the entries are filled from [0, q_count)
	for (i = qs_cfg.q_count; i < 10; i++)
		CHECK_EQUAL(txq_map[i], ICE_INVAL_Q_INDEX);

	// at this point, only 2 qs are left in pf map and we're requesting 4
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(-ENOMEM, ret);

	// put qs from 1st request
	for (i = 0; i < 4; i++)
		clear_bit(i, avail_txqs);

	qs_cfg.q_count = 6;
	qs_cfg.scatter_count = 6;
	qs_cfg.mapping_mode = ICE_VSI_MAP_CONTIG;
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(0, ret);
	// there was no contigous requested space in pf map - should go with scatter
	CHECK_EQUAL(ICE_VSI_MAP_SCATTER, qs_cfg.mapping_mode);
	// at this point the pf map is full
	offset = find_next_zero_bit(qs_cfg.pf_map, qs_cfg.pf_map_size, 0);
	CHECK_TRUE(offset >= qs_cfg.pf_map_size);
}

/**
 * This test is to simulate the behavior of adding xdp queues when doing
 * xdp setup; they will be stored in vsi->txq_map just after the tx queues
 */
TEST(ice_get_qs, get_qs_xdp_case)
{
	int ret, i;
	unsigned int offset;
	// pf map with pf map size
	DECLARE_BITMAP(avail_txqs, 10);
	// vsi map
	u16 txq_map[10];
	struct ice_qs_cfg qs_cfg = { .qs_mutex = &qs_mutex,
				     .pf_map = avail_txqs,
				     .pf_map_size = 10,
				     .q_count = 4,
				     .scatter_count = 4,
				     .vsi_map = txq_map,
				     .vsi_map_offset = 0,
				     .mapping_mode = ICE_VSI_MAP_CONTIG};

	bitmap_zero(avail_txqs, 10);
	// init vsi map with ICE_INVAL_Q_INDEX
	memset(txq_map, 0xff, sizeof(txq_map));
	CHECK_EQUAL(txq_map[9], ICE_INVAL_Q_INDEX);

	// get first 4 queues (tx)
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(0, ret);

	// get next 4 queues from pf map (xdp) and store them after tx qs
	qs_cfg.vsi_map_offset = qs_cfg.q_count;
	ret = __ice_vsi_get_qs(&qs_cfg);
	CHECK_EQUAL(0, ret);
	// make sure that we didn't overwrite the qs from 1st assignment
	// so the entries are filled from [0, q_count * 2)
	for (i = qs_cfg.q_count * 2; i < 10; i++)
		CHECK_EQUAL(txq_map[i], ICE_INVAL_Q_INDEX);

	offset = find_next_zero_bit(qs_cfg.pf_map, qs_cfg.pf_map_size, 0);
	CHECK_TRUE(offset == qs_cfg.q_count * 2);
}

TEST_GROUP(rx_ring_ctx)
{
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	struct ice_hw hw;
	struct ice_pf *back;
	struct pci_dev *pdev;
	void setup(void)
	{
		ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		ring->vsi = vsi;
		vsi->back = back;
		vsi->back->hw = hw;
		vsi->back->pdev = pdev;
		vsi->alloc_rxq = 8;
		vsi->rxq_map = (u16*) calloc(vsi->alloc_rxq, sizeof(u16));
		vsi->rxq_map[ring->q_index] = 2;
		vsi->type = ICE_VSI_PF;
	}
	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(hw.hw_addr);
		free(back);
		free(pdev);
		free(vsi->rxq_map);
		free(vsi);
		free(ring);
	}
};

TEST(rx_ring_ctx, bad_ptr_write_rxq_ctx)
{
	int ret;
	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(true);
	mock().expectOneCall("ice_write_qrxflxp_cntxt")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_write_rxq_ctx")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_BAD_PTR);
	ret = ice_setup_rx_ctx(ring);
	CHECK_EQUAL(ICE_ERR_BAD_PTR, ret);
}

TEST(rx_ring_ctx, err_param_write_rxq_ctx)
{
	int ret;
	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(true);
	mock().expectOneCall("ice_write_qrxflxp_cntxt")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_write_rxq_ctx")
		.ignoreOtherParameters()
		.andReturnValue(-EIO);
	ret = ice_setup_rx_ctx(ring);
	CHECK_EQUAL(-EIO, ret);
}

TEST(rx_ring_ctx, rxq_ctx_success )
{
	int ret;
	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(true);
	mock().expectOneCall("ice_write_qrxflxp_cntxt")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_write_rxq_ctx")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	ret = ice_setup_rx_ctx(ring);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST_GROUP(cfg_rx_ring)
{
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	struct ice_hw hw;
	struct ice_pf *back;
	struct pci_dev *pdev;
	void setup(void)
	{
		ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		ring->q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		back->pdev = pdev;
		ring->vsi = vsi;
		vsi->back = back;
		vsi->back->hw = hw;
		vsi->alloc_rxq = 8;
		vsi->rxq_map = (u16*) calloc(vsi->alloc_rxq, sizeof(u16));
		vsi->rxq_map[ring->q_index] = 2;
		vsi->type = ICE_VSI_PF;
	}
	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(hw.hw_addr);
		free(back);
		free(pdev);
		free(vsi->rxq_map);
		free(vsi);
		free(ring->q_vector);
		free(ring);
	}
};

TEST(cfg_rx_ring, bad_ptr_write_rxq_ctx )
{
	int ret;
	USE_STD_MOCK(ice_setup_rx_ctx);
	mock().expectOneCall("ice_setup_rx_ctx")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_BAD_PTR);
#ifdef XDP_SUPPORT
	USE_STD_MOCK(ice_xsk_pool);
	mock().expectOneCall("ice_xsk_pool");
#endif
	ret = ice_vsi_cfg_rxq(ring);
	CHECK_EQUAL(ICE_ERR_BAD_PTR, ret);
}

TEST(cfg_rx_ring, err_param_write_rxq_ctx )
{
	int ret;
	USE_STD_MOCK(ice_setup_rx_ctx);
	mock().expectOneCall("ice_setup_rx_ctx")
		.ignoreOtherParameters()
		.andReturnValue(-EIO);
#ifdef XDP_SUPPORT
	USE_STD_MOCK(ice_xsk_pool);
	mock().expectOneCall("ice_xsk_pool");
#endif
	ret = ice_vsi_cfg_rxq(ring);
	CHECK_EQUAL(-EIO, ret);
}

TEST(cfg_rx_ring, rxq_ctx_success )
{
	int ret;
	USE_STD_MOCK(ice_setup_rx_ctx);
	mock().expectOneCall("ice_setup_rx_ctx")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_alloc_rx_bufs")
		.ignoreOtherParameters()
		.andReturnValue(false);
#ifdef XDP_SUPPORT
	USE_STD_MOCK(ice_xsk_pool);
	mock().expectOneCall("ice_xsk_pool");
#endif
	ret = ice_vsi_cfg_rxq(ring);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

