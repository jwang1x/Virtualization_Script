/*
 * Copyright(c) 2018 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_fltr {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "../src/CORE/ice_fltr.c"
}
/////////////////////////////////////////////////
using namespace ns_fltr;

TEST_GROUP(fltr_grp)
{
	struct ice_vsi *vsi;
	struct ice_pf *pf;

	void setup(void)
	{
		vsi = (struct ice_vsi *) calloc(1, sizeof(*vsi));
		pf = (struct ice_pf *)  calloc(1, sizeof(*pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		vsi->port_info = (struct ice_port_info *)
			calloc(1, sizeof(*vsi->port_info));
		vsi->back = pf;
	}

	void teardown(void)
	{
		free(pf->pdev);
		free(pf);
		pf = NULL;
		free(vsi->port_info);
		free(vsi);
		vsi = NULL;
	}
};

TEST(fltr_grp, alloc_list)
{
	LIST_HEAD(tmp_list);
	ice_fltr_info info;
	int ret;

	ret = ice_fltr_add_entry_to_list(ice_pf_to_dev(pf), &info, &tmp_list);
	CHECK(!LIST_EMPTY(&tmp_list));
	CHECK_EQUAL(0, ret);
	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_mac").andReturnValue(0);
#endif
	ret = ice_fltr_add_mac_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, remove_mac_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_mac").andReturnValue(0);
#endif
	ret = ice_fltr_remove_mac_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, add_vlan_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_add_vlan_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, remove_vlan_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_remove_vlan_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, add_eth_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_eth_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_eth_mac").andReturnValue(0);
#endif
	ret = ice_fltr_add_eth_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, remove_eth_list)
{
	LIST_HEAD(tmp_list);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_eth_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_eth_mac").andReturnValue(0);
#endif
	ret = ice_fltr_remove_eth_list(vsi, &tmp_list);
	CHECK_EQUAL(ICE_SUCCESS, ret);
}

TEST(fltr_grp, add_mac_to_list)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	struct ice_fltr_list_entry *entry;
	LIST_HEAD(tmp_list);
	int ret;

	ret = ice_fltr_add_mac_to_list(vsi, &tmp_list, mac, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_TX);
		CHECK_EQUAL(entry->fltr_info.src_id, ICE_SRC_ID_VSI);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_MAC);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_FWD_TO_VSI);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		STRNCMP_EQUAL((const char *)
			      entry->fltr_info.l_data.mac.mac_addr,
			      (const char *)mac, sizeof(mac));
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_vlan_to_list)
{
	u16 vid = 2;
	struct ice_vlan vlan = ICE_VLAN(ETH_P_8021Q, vid, 0, ICE_FWD_TO_VSI);
	struct ice_fltr_list_entry *entry;
	LIST_HEAD(tmp_list);
	int ret;

	ret = ice_fltr_add_vlan_to_list(vsi, &tmp_list, &vlan);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_TX);
		CHECK_EQUAL(entry->fltr_info.src_id, ICE_SRC_ID_VSI);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_VLAN);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_FWD_TO_VSI);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		CHECK_EQUAL(entry->fltr_info.l_data.vlan.vlan_id, vid);
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_vlan_to_list_fwd)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	struct ice_fltr_list_entry *entry;
	LIST_HEAD(tmp_list);
	u16 vid = 2;
	int ret;

	ret = ice_fltr_add_mac_vlan_to_list(vsi, &tmp_list, mac, vid,
					    ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_TX_RX);
		CHECK_EQUAL(entry->fltr_info.src_id, 0);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_MAC_VLAN);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_FWD_TO_VSI);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		CHECK_EQUAL(entry->fltr_info.l_data.mac_vlan.vlan_id, vid);
		STRNCMP_EQUAL((const char *)
			      entry->fltr_info.l_data.mac.mac_addr,
			      (const char *)mac, sizeof(mac));
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_vlan_to_list_drop)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	struct ice_fltr_list_entry *entry;
	LIST_HEAD(tmp_list);
	u16 vid = 2;
	int ret;

	ret = ice_fltr_add_mac_vlan_to_list(vsi, &tmp_list, mac, vid,
					    ICE_DROP_PACKET);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_TX_RX);
		CHECK_EQUAL(entry->fltr_info.src_id, 0);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_MAC_VLAN);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_DROP_PACKET);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		CHECK_EQUAL(entry->fltr_info.l_data.mac_vlan.vlan_id, vid);
		STRNCMP_EQUAL((const char *)
			      entry->fltr_info.l_data.mac.mac_addr,
			      (const char *)mac, sizeof(mac));
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_vlan_to_list_fail_vid)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	LIST_HEAD(tmp_list);
	u16 vid = 0;
	int ret;

	ret = ice_fltr_add_mac_vlan_to_list(vsi, &tmp_list, mac, vid,
					    ICE_DROP_PACKET);
	CHECK_EQUAL(-EINVAL, ret);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_vlan_to_list_fail_mac)
{
	const u8 mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	LIST_HEAD(tmp_list);
	u16 vid = 2;
	int ret;

	ret = ice_fltr_add_mac_vlan_to_list(vsi, &tmp_list, mac, vid,
					    ICE_DROP_PACKET);
	CHECK_EQUAL(-EINVAL, ret);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_eth_to_list)
{
	struct ice_fltr_list_entry *entry;
	u16 ethertype = 0x8888;
	LIST_HEAD(tmp_list);
	int ret;

	ret = ice_fltr_add_eth_to_list(vsi, &tmp_list, ethertype, ICE_FLTR_TX,
				       ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_TX);
		CHECK_EQUAL(entry->fltr_info.src_id, ICE_SRC_ID_VSI);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_ETHERTYPE);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_FWD_TO_VSI);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		CHECK_EQUAL(entry->fltr_info.l_data.ethertype_mac.ethertype,
			    ethertype);
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));

	ret = ice_fltr_add_eth_to_list(vsi, &tmp_list, ethertype, ICE_FLTR_RX,
				       ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
	CHECK(!LIST_EMPTY(&tmp_list));

	LIST_FOR_EACH_ENTRY(entry, &tmp_list, ice_fltr_list_entry, list_entry) {
		CHECK_EQUAL(entry->fltr_info.flag, ICE_FLTR_RX);
		CHECK_EQUAL(entry->fltr_info.src_id, ICE_SRC_ID_LPORT);
		CHECK_EQUAL(entry->fltr_info.lkup_type, ICE_SW_LKUP_ETHERTYPE);
		CHECK_EQUAL(entry->fltr_info.fltr_act, ICE_FWD_TO_VSI);
		CHECK_EQUAL(entry->fltr_info.vsi_handle, vsi->idx);
		CHECK_EQUAL(entry->fltr_info.l_data.ethertype_mac.ethertype,
			    ethertype);
	}

	ice_fltr_free_list(ice_pf_to_dev(pf), &tmp_list);
	CHECK(LIST_EMPTY(&tmp_list));
}

TEST(fltr_grp, add_mac_and_broadcast)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_mac").andReturnValue(0);
#endif
	ret = ice_fltr_add_mac_and_broadcast(vsi, mac, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, remove_all)
{
	using namespace ns_fltr;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_vsi_fltr_on_port");
#else
	mock().expectOneCall("ice_remove_vsi_fltr");
#endif
	ice_fltr_remove_all(vsi);
}

TEST(fltr_grp, add_mac)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_mac").andReturnValue(0);
#endif
	ret = ice_fltr_add_mac(vsi, mac, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, remove_mac)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_mac").andReturnValue(0);
#endif
	ret = ice_fltr_remove_mac(vsi, mac, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, add_vlan)
{
	u16 vid = 2;
	struct ice_vlan vlan = ICE_VLAN(ETH_P_8021Q, vid, 0, ICE_FWD_TO_VSI);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_add_vlan(vsi, &vlan);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, remove_vlan)
{
	u16 vid = 2;
	struct ice_vlan vlan = ICE_VLAN(ETH_P_8021Q, vid, 0, ICE_FWD_TO_VSI);
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_remove_vlan(vsi, &vlan);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, add_mac_vlan)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	int ret;
	u16 vid = 2;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_mac_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_mac_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_add_mac_vlan(vsi, mac, vid, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, remove_mac_vlan)
{
	const u8 mac[ETH_ALEN] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
	int ret;
	u16 vid = 2;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_mac_vlan_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_mac_vlan").andReturnValue(0);
#endif
	ret = ice_fltr_remove_mac_vlan(vsi, mac, vid, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, add_eth)
{
	u16 ethertype = 0x8888;
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_add_eth_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_add_eth_mac").andReturnValue(0);
#endif
	ret = ice_fltr_add_eth(vsi, ethertype, ICE_FLTR_TX, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

TEST(fltr_grp, remove_eth)
{
	u16 ethertype = 0x8888;
	int ret;

#ifdef BMSM_MODE
	mock().expectOneCall("ice_remove_eth_mac_on_port").andReturnValue(0);
#else
	mock().expectOneCall("ice_remove_eth_mac").andReturnValue(0);
#endif
	ret = ice_fltr_remove_eth(vsi, ethertype, ICE_FLTR_TX, ICE_FWD_TO_VSI);
	CHECK_EQUAL(0, ret);
}

#ifdef ESWITCH_SUPPORT
struct ice_aqc_sw_rules_elem pattern_s_rule;

TEST_GROUP_BASE(change_flags, TGN(fltr_grp))
{
	const u16 regular_rule_id_bad_act = 9;
	const u16 regular_recipe_id = 2;
	const u16 regular_rule_id = 3;

	const u16 adv_rule_id_bad_act = 10;
	const u16 adv_recipe_id = 8;
	const u16 adv_rule_id = 14;

	struct ice_sw_recipe *recipe;
	struct ice_hw hw = {};

	struct ice_fltr_info info;
	struct ice_adv_rule_info adv_info;

	TEST_SETUP()
	{
		TGN(fltr_grp)::setup();

		pf->hw = hw;
		pf->hw.port_info = (struct ice_port_info *)
			calloc(1, sizeof(struct ice_port_info));
		pf->hw.port_info->lport = 1;
		pf->hw.switch_info = (struct ice_switch_info *)
			calloc(1, sizeof(struct ice_switch_info));
		pf->hw.switch_info->recp_list = (struct ice_sw_recipe *)
			calloc(ICE_MAX_NUM_RECIPES, sizeof(struct ice_sw_recipe));
		recipe = pf->hw.switch_info->recp_list;

		for (int i = 0; i < ICE_MAX_NUM_RECIPES; i++) {
			struct list_head *rules =
				&pf->hw.switch_info->recp_list[i].filt_rules;

			INIT_LIST_HEAD(rules);
		}

		vsi->vsi_num = 9;

		info.fltr_act = ICE_FWD_TO_VSI;
		info.fwd_id.hw_vsi_id = vsi->vsi_num;
		info.flag = ICE_FLTR_RX;
		info.src = pf->hw.port_info->lport;

		adv_info.sw_act.fltr_act = ICE_FWD_TO_VSI;
		adv_info.sw_act.fwd_id.hw_vsi_id = vsi->vsi_num;
		adv_info.sw_act.flag = ICE_FLTR_RX;
		adv_info.sw_act.src = pf->hw.port_info->lport;

		/* Add few random regular and advance rules to
		 * check if flags can be changed in different ways */
		test_ice_fltr_add_regular(recipe, regular_recipe_id,
					  regular_rule_id, info);
		test_ice_fltr_add_adv(recipe, adv_recipe_id, adv_rule_id,
				      adv_info);
		test_ice_fltr_add_regular(recipe, regular_recipe_id,
					  regular_rule_id + 1, info);
		test_ice_fltr_add_adv(recipe, adv_recipe_id, adv_rule_id + 1,
				      adv_info);
		test_ice_fltr_add_regular(recipe, regular_recipe_id,
					  regular_rule_id + 2, info);
		test_ice_fltr_add_adv(recipe, adv_recipe_id, adv_rule_id + 2,
				      adv_info);

		info.fltr_act = ICE_DROP_PACKET;
		adv_info.sw_act.fltr_act = ICE_DROP_PACKET;

		test_ice_fltr_add_regular(recipe, regular_recipe_id,
					  regular_rule_id_bad_act, info);
		test_ice_fltr_add_adv(recipe, adv_recipe_id, adv_rule_id_bad_act,
				      adv_info);
	}

	TEST_TEARDOWN()
	{
		test_ice_fltr_remove_all_regular(recipe, regular_recipe_id);
		test_ice_fltr_remove_all_adv(recipe, adv_recipe_id);

		free(pf->hw.switch_info->recp_list);
		free(pf->hw.switch_info);
		free(pf->hw.port_info);

		TGN(fltr_grp)::teardown();
	}

	static void
	test_ice_fltr_add_regular(struct ice_sw_recipe *recipe, u16 recipe_id,
				  u16 new_id, struct ice_fltr_info info)
	{
		struct ice_fltr_mgmt_list_entry *entry = (struct ice_fltr_mgmt_list_entry *)
			calloc(1, sizeof(struct ice_fltr_mgmt_list_entry));
		struct list_head *rules = &recipe[recipe_id].filt_rules;

		entry->fltr_info = info;
		entry->fltr_info.fltr_rule_id = new_id;
		list_add(&entry->list_entry, rules);
	}

	static void
	test_ice_fltr_add_adv(struct ice_sw_recipe *recipe, u16 recipe_id,
			      u16 new_id, struct ice_adv_rule_info info)
	{
		struct ice_adv_fltr_mgmt_list_entry *entry =
			(struct ice_adv_fltr_mgmt_list_entry *)
			calloc(1, sizeof(struct ice_fltr_mgmt_list_entry));
		struct list_head *rules = &recipe[recipe_id].filt_rules;

		entry->rule_info = info;
		entry->rule_info.fltr_rule_id = new_id;
		list_add(&entry->list_entry, rules);
	}

	static void
	test_ice_fltr_remove_all_regular(struct ice_sw_recipe *recipe,
					 u16 recipe_id)
	{
		struct list_head *rules = &recipe[recipe_id].filt_rules;
		struct ice_fltr_mgmt_list_entry *entry, *temp;

		list_for_each_entry_safe(entry, temp, rules, list_entry) {
			list_del(&entry->list_entry);
			free(entry);
		}
	}

	static void
	test_ice_fltr_remove_all_adv(struct ice_sw_recipe *recipe, u16 recipe_id)
	{
		struct list_head *rules = &recipe[recipe_id].filt_rules;
		struct ice_adv_fltr_mgmt_list_entry *entry, *temp;

		list_for_each_entry_safe(entry, temp, rules, list_entry) {
			list_del(&entry->list_entry);
			free(entry);
		}
	}

	static int
	mock_ice_aq_sw_rules(struct ice_hw *hw, void *rule_list, u16 rule_list_sz,
			     u8 num_rules, enum ice_adminq_opc opc, struct ice_sq_cd *cd)
	{
		struct ice_aqc_sw_rules_elem *rule = (struct ice_aqc_sw_rules_elem *)
			rule_list;
		char msg[100];

		if (pattern_s_rule.pdata.lkup_tx_rx.recipe_id !=
		    rule->pdata.lkup_tx_rx.recipe_id) {
			snprintf(msg, sizeof(msg), "recipe_id in s_rule different than expected <was %d, should be %d>",
			     rule->pdata.lkup_tx_rx.recipe_id,
			     pattern_s_rule.pdata.lkup_tx_rx.recipe_id);
			FAIL(msg);
		}

		if (pattern_s_rule.pdata.lkup_tx_rx.index !=
		    rule->pdata.lkup_tx_rx.index) {
			snprintf(msg, sizeof(msg), "rule_id in s_rule different than expected <was %d, should be %d>",
				 rule->pdata.lkup_tx_rx.index,
				 pattern_s_rule.pdata.lkup_tx_rx.index);
			FAIL(msg);
		}

		if (pattern_s_rule.pdata.lkup_tx_rx.act !=
		    rule->pdata.lkup_tx_rx.act) {
			snprintf(msg, sizeof(msg), "action in s_rule different than expected <was 0x%X, should be 0x%X>",
				 rule->pdata.lkup_tx_rx.act,
				 pattern_s_rule.pdata.lkup_tx_rx.act);
			FAIL(msg);
		}

		if (pattern_s_rule.pdata.lkup_tx_rx.src !=
		    rule->pdata.lkup_tx_rx.src) {
			snprintf(msg, sizeof(msg), "source in s_rule different than expected <was %d, should be %d>",
				 rule->pdata.lkup_tx_rx.src,
				 pattern_s_rule.pdata.lkup_tx_rx.src);
			FAIL(msg);
		}

		if (pattern_s_rule.type != rule->type) {
			snprintf(msg, sizeof(msg), "type in s_rule different than expected <was %d, should be %d>",
				 rule->type,
				 pattern_s_rule.type);
			FAIL(msg);
		}

		return 0;
	}
};

TEST_GROUP_BASE(default_rules, TGN(change_flags))
{
	const u16 default_rule_id = ICE_SW_LKUP_DFLT;

	TEST_SETUP()
	{
		TGN(change_flags)::setup();

		pattern_s_rule.pdata.lkup_tx_rx.recipe_id = CPU_TO_LE32(ICE_SW_LKUP_DFLT);
		pattern_s_rule.pdata.lkup_tx_rx.index = CPU_TO_LE16(default_rule_id);
		pattern_s_rule.pdata.lkup_tx_rx.src = pf->hw.port_info->lport;
		pattern_s_rule.type = CPU_TO_LE16(ICE_AQC_SW_RULES_T_LKUP_RX);
		pattern_s_rule.pdata.lkup_tx_rx.act =
			((vsi->vsi_num << ICE_SINGLE_ACT_VSI_ID_S) &
			 ICE_SINGLE_ACT_VSI_ID_M)
			| ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	}

	TEST_TEARDOWN()
	{
		TGN(change_flags)::teardown();
	}
};
#endif /* ESWITCH_SUPPORT */
