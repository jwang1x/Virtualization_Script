#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_vsi_vlan_lib {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "../src/CORE/ice.h"

#include "../src/SHARED/ice_adminq_cmd.h"
#include "../src/SHARED/ice_switch.h"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"

#include "../src/CORE/ice_vsi_vlan_lib.c"
}
/////////////////////////////////////////////////
using namespace ns_vsi_vlan_lib;

TEST_GROUP(ice_vsi_manage_vlan_stripping)
{
	struct ice_vsi *vsi;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
	}

	void teardown()
	{
		free(vsi->back);
		free(vsi);
	}
};

TEST(ice_vsi_manage_vlan_stripping, port_based_inner_vlan_field_set_return_success_dont_update_vsi_context)
{
	int actual;

	vsi->info.port_based_inner_vlan = cpu_to_le16(10);
	vsi->info.inner_vlan_flags = ICE_AQ_VSI_INNER_VLAN_TX_MODE_ACCEPTUNTAGGED;
	vsi->info.sw_flags2 = ICE_AQ_VSI_SW_FLAG_RX_VLAN_PRUNE_ENA;

	actual = ice_vsi_manage_vlan_stripping(vsi, true);
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(cpu_to_le16(10), vsi->info.port_based_inner_vlan);
	CHECK_EQUAL(ICE_AQ_VSI_INNER_VLAN_TX_MODE_ACCEPTUNTAGGED, vsi->info.inner_vlan_flags);
	CHECK_EQUAL(ICE_AQ_VSI_SW_FLAG_RX_VLAN_PRUNE_ENA, vsi->info.sw_flags2);

	actual = ice_vsi_manage_vlan_stripping(vsi, false);
	CHECK_EQUAL(0, actual);
	CHECK_EQUAL(cpu_to_le16(10), vsi->info.port_based_inner_vlan);
	CHECK_EQUAL(ICE_AQ_VSI_INNER_VLAN_TX_MODE_ACCEPTUNTAGGED, vsi->info.inner_vlan_flags);
	CHECK_EQUAL(ICE_AQ_VSI_SW_FLAG_RX_VLAN_PRUNE_ENA, vsi->info.sw_flags2);
}


TEST_GROUP(tpid_to_vsi_outer_vlan_type)
{
	u8 tag_type;
	int result;

	void setup()
	{
		tag_type = 0;
	}
};

TEST(tpid_to_vsi_outer_vlan_type, tpid_8021q_to_vsi_based_tag_type)
{
	result = tpid_to_vsi_outer_vlan_type(ETH_P_8021Q, &tag_type);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(ICE_AQ_VSI_OUTER_TAG_VLAN_8100, tag_type);
}

TEST(tpid_to_vsi_outer_vlan_type, tpid_8021ad_to_vsi_based_tag_type)
{
	result = tpid_to_vsi_outer_vlan_type(ETH_P_8021AD, &tag_type);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(ICE_AQ_VSI_OUTER_TAG_STAG, tag_type);
}

TEST(tpid_to_vsi_outer_vlan_type, tpid_9100_to_vsi_based_tag_type)
{
	result = tpid_to_vsi_outer_vlan_type(ETH_P_QINQ1, &tag_type);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(ICE_AQ_VSI_OUTER_TAG_VLAN_9100, tag_type);
}

TEST(tpid_to_vsi_outer_vlan_type, invalid_tpid)
{
	result = tpid_to_vsi_outer_vlan_type(ETH_P_QINQ2, &tag_type);
	CHECK_EQUAL(-EINVAL, result);
	CHECK_EQUAL(0, tag_type);
}

TEST_GROUP(ice_vsi_outer_vlan_offload)
{
	u8 expected_outer_vlan_flags, actual_outer_vlan_flags;
	__le16 expected_port_based_outer_vlan;
	struct ice_vsi *vsi;
	int result;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		expected_outer_vlan_flags = 0;
		actual_outer_vlan_flags = 0;
		expected_port_based_outer_vlan = 0;
	}

	void teardown()
	{
		free(vsi->back);
		free(vsi);
	}
};

TEST(ice_vsi_outer_vlan_offload, enabling_outer_stripping_for_8021Q_ethertype)
{
	expected_outer_vlan_flags =
		(ICE_AQ_VSI_OUTER_VLAN_EMODE_SHOW_BOTH << ICE_AQ_VSI_OUTER_VLAN_EMODE_S) |
		(ICE_AQ_VSI_OUTER_TAG_VLAN_8100 << ICE_AQ_VSI_OUTER_TAG_TYPE_S);

	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(0);
	result = ice_vsi_ena_outer_stripping(vsi, ETH_P_8021Q);

	actual_outer_vlan_flags = vsi->info.outer_vlan_flags;
	CHECK_EQUAL(expected_outer_vlan_flags, actual_outer_vlan_flags);
	CHECK_EQUAL(result, 0);
}

#define EXPECTED_OUTER_PORT_VLAN_TAG_FLAGS(tag_type)	\
	(ICE_AQ_VSI_OUTER_VLAN_EMODE_SHOW << ICE_AQ_VSI_OUTER_VLAN_EMODE_S) | \
	(tag_type << ICE_AQ_VSI_OUTER_TAG_TYPE_S) | \
	ICE_AQ_VSI_OUTER_VLAN_BLOCK_TX_DESC | ICE_AQ_VSI_OUTER_VLAN_PORT_BASED_INSERT | \
	(ICE_AQ_VSI_OUTER_VLAN_TX_MODE_ACCEPTUNTAGGED << ICE_AQ_VSI_OUTER_VLAN_TX_MODE_S)

TEST(ice_vsi_outer_vlan_offload, enabling_outer_stripping_for_8021Q_ethertype_when_port_based_outer_vlan_is_set_does_nothing)
{
	__le16 vlan_info = cpu_to_le16(10);

	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(0);

	/* set the port VLAN tag and flags */
	__ice_vsi_set_outer_port_vlan(vsi, vlan_info, ETH_P_QINQ1);

	result = ice_vsi_ena_outer_stripping(vsi, ETH_P_8021Q);

	actual_outer_vlan_flags = vsi->info.outer_vlan_flags;
	expected_outer_vlan_flags = EXPECTED_OUTER_PORT_VLAN_TAG_FLAGS(ICE_AQ_VSI_OUTER_TAG_VLAN_9100);
	CHECK_EQUAL(expected_outer_vlan_flags, actual_outer_vlan_flags);
	expected_port_based_outer_vlan = vlan_info;
	CHECK_EQUAL(expected_port_based_outer_vlan, vsi->info.port_based_outer_vlan);
	CHECK_EQUAL(0, result);
}

TEST(ice_vsi_outer_vlan_offload, disabling_outer_stripping_for_8021ad_ethertype_when_port_based_outer_vlan_is_set_does_nothing)
{
	__le16 vlan_info = cpu_to_le16(13);

	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(0);

	/* set the port VLAN tag and flags */
	__ice_vsi_set_outer_port_vlan(vsi, vlan_info, ETH_P_8021AD);

	result = ice_vsi_dis_outer_stripping(vsi);

	actual_outer_vlan_flags = vsi->info.outer_vlan_flags;
	expected_outer_vlan_flags = EXPECTED_OUTER_PORT_VLAN_TAG_FLAGS(ICE_AQ_VSI_OUTER_TAG_STAG);
	CHECK_EQUAL(expected_outer_vlan_flags, actual_outer_vlan_flags);
	expected_port_based_outer_vlan = vlan_info;
	CHECK_EQUAL(expected_port_based_outer_vlan, vsi->info.port_based_outer_vlan);
	CHECK_EQUAL(0, result);
}
