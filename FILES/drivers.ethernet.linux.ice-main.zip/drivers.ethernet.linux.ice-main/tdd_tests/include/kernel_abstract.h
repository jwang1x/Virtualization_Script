#ifndef __KERNEL_ABSTRACT
#define __KERNEL_ABSTRACT

#include <linux/compiler.h>
#include <linux/compiler_attributes.h>

#define __init
#define __iomem
#define __force
#define __rcu
#define EXPORT_SYMBOL(sym)
#define likely(a) (a)
#define unlikely(a) (a)
#define __packed __attribute__((__packed__))
#define __must_check __attribute__((__warn_unused_result__))
#define __pure __attribute__((__pure__))
#define __weak __attribute__((__weak__))
#define __alias(symbol) __attribute__((__alias__(#symbol)))
#define __printf(a, b) __attribute__((__format__(printf, a, b)))

static void prefetch(void *addr __always_unused)
{
}

static void prefetchw(void *addr __always_unused)
{
}

static void net_prefetch(void *addr __always_unused)
{
}

#define	EPERM		 1	/* Operation not permitted */
#define	ENOENT		 2	/* No such file or directory */
#define	ESRCH		 3	/* No such process */
#define	EINTR		 4	/* Interrupted system call */
#define	EIO		 5	/* I/O error */
#define	ENXIO		 6	/* No such device or address */
#define	E2BIG		 7	/* Argument list too long */
#define	ENOEXEC		 8	/* Exec format error */
#define	EBADF		 9	/* Bad file number */
#define	ECHILD		10	/* No child processes */
#define	EAGAIN		11	/* Try again */
#define	ENOMEM		12	/* Out of memory */
#define	EACCES		13	/* Permission denied */
#define	EFAULT		14	/* Bad address */
#define	ENOTBLK		15	/* Block device required */
#define	EBUSY		16	/* Device or resource busy */
#define	EEXIST		17	/* File exists */
#define	EXDEV		18	/* Cross-device link */
#define	ENODEV		19	/* No such device */
#define	ENOTDIR		20	/* Not a directory */
#define	EISDIR		21	/* Is a directory */
#define	EINVAL		22	/* Invalid argument */
#define	ENFILE		23	/* File table overflow */
#define	EMFILE		24	/* Too many open files */
#define	ENOTTY		25	/* Not a typewriter */
#define	ETXTBSY		26	/* Text file busy */
#define	EFBIG		27	/* File too large */
#define	ENOSPC		28	/* No space left on device */
#define	ESPIPE		29	/* Illegal seek */
#define	EROFS		30	/* Read-only file system */
#define	EMLINK		31	/* Too many links */
#define	EPIPE		32	/* Broken pipe */
#define	EDOM		33	/* Math argument out of domain of func */
#define	ERANGE		34	/* Math result not representable */
#define	EADDRNOTAVAIL	99	/* Cannot assign requested address */
#define	ENOTSUPP	524	/* Operation is not supported */

#define L1_CACHE_BYTES 64
#define ____cacheline_aligned_in_smp
#define ____cacheline_internodealigned_in_smp
#define ____cacheline_aligned
#define __aligned(n) __attribute__((__aligned__(n)))
#define	IFNAMSIZ	16
#define smp_mb()
#define wmb()
#define in_interrupt() 0
#define WARN_ON_ONCE(condition) WARN_ON(condition)
#define WARN_ON(condition) ({						\
	int __ret_warn_on = !!(condition);				\
	CHECK_FALSE(condition);						\
	__ret_warn_on;							\
})
#define WARN(condition, fmt, ...) ({					\
	int __ret_warn_on = !!(condition);				\
	CHECK_FALSE_TEXT(condition, StringFromFormat(fmt, ##__VA_ARGS__).asCharString()); \
	__ret_warn_on;							\
})
#define BUG_ON(a) CHECK_FALSE(a)
#define __ALIGN_KERNEL_MASK(x, mask)	(((x) + (mask)) & ~(mask))
#define __ALIGN_KERNEL(x, a)		__ALIGN_KERNEL_MASK(x, (typeof(x))(a) - 1)
#define ALIGN(x, a) __ALIGN_KERNEL((x), (a))
#define GFP_ATOMIC 0
#define __GFP_NOWARN 0
#define MAKEMASK(m, s) ((m) << (s))
#define min(a, b)    (std::min((a),(b)))
#define min_t(t,a,b) min((t)(a), (t)(b))
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define ETH_ALEN 6
#define ETH_MIN_MTU 68

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef unsigned long long u64;
typedef int16_t s16;
typedef int32_t s32;
typedef long long s64;
typedef u16 __sum16;
typedef u32 __wsum;
typedef signed char s8;

enum lock_state {
	LOCK_NEW, /* Lock is uninitialized */
	LOCK_UNLOCKED, /* Lock is unlocked */
	LOCK_LOCKED, /* Lock is locked */
};

struct mutex {
	char *mem;
	enum lock_state state;
};

struct netlink_ext_ack {
	const char *_msg;
};

static void mutex_init(struct mutex *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		lock->mem = new char();
		/* newly initialized mutex is unlocked */
		lock->state = LOCK_UNLOCKED;
		break;
	case LOCK_UNLOCKED:
		FAIL("mutex: attempting to init already initialized mutex");
		break;
	case LOCK_LOCKED:
		FAIL("mutex: attempting to init locked mutex");
		break;
	default:
		FAIL("mutex: lock state is invalid");
		break;
	}
}

static void mutex_lock(struct mutex *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("mutex: attempting to lock an uninitialized mutex");
		break;
	case LOCK_UNLOCKED:
		lock->state = LOCK_LOCKED;
		break;
	case LOCK_LOCKED:
		FAIL("mutex: attempting to lock an already locked mutex");
		break;
	default:
		FAIL("mutex: lock state is invalid");
		break;
	}
}

static bool mutex_trylock(struct mutex *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("mutex: attempting to lock an uninitialized mutex");
		break;
	case LOCK_UNLOCKED:
		lock->state = LOCK_LOCKED;
		break;
	case LOCK_LOCKED:
		FAIL("mutex: attempting to lock an already locked mutex");
		break;
	default:
		FAIL("mutex: lock state is invalid");
		break;
	}

	return true;
}

static void mutex_unlock(struct mutex *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("mutex: attempting to unlock an uninitialized mutex");
		break;
	case LOCK_UNLOCKED:
		FAIL("mutex: attempting to unlock mutex that wasn't locked");
		break;
	case LOCK_LOCKED:
		lock->state = LOCK_UNLOCKED;
		break;
	default:
		FAIL("mutex: lock state is invalid");
		break;
	}
}

static void mutex_destroy(struct mutex *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("mutex: attempting to destroy an uninitialized mutex");
		break;
	case LOCK_UNLOCKED:
		delete lock->mem;
		lock->mem = NULL;
		lock->state = LOCK_NEW;
		break;
	case LOCK_LOCKED:
		FAIL("mutex: attempting to destroy a locked mutex");
		break;
	default:
		FAIL("mutex: lock state is invalid");
		break;
	}
}

#define INIT_MUTEX(mutex_name)		\
	{ .mem = new char(),		\
	  .state = LOCK_INITIALIZED }

#define DEFINE_MUTEX(mutex_name)	\
	struct mutex mutex_name = INIT_MUTEX(mutex_name)

#define lockdep_assert_held(l)	\
	CHECK_EQUAL(LOCK_LOCKED, (l)->state)

struct callback_head {
	struct callback_head *next;
	void (*func)(struct callback_head *head);
} __attribute__((aligned(sizeof(void *))));
#define rcu_head callback_head
#define rcu_read_lock()
#define rcu_read_unlock()

#define smp_rmb()

#define READ_ONCE(x) (x)

static inline void unit_test_print(struct device *dev, const char *fmt, ...)
{
	va_list args;

	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);
}

/* verbose version which prints messages unless the mock() variable
 * "disable_dbg_prints" is set to true. This can be useful to help reduce
 * a large number of debug print messages that come from specific tests.
 */
static inline void unit_test_dbg_print(struct device *dev, const char *fmt, ...)
{
	va_list args;

	if (mock().hasData("disable_dbg_prints") &&
	    mock().getData("disable_dbg_prints").getBoolValue())
		return;

	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);
}

/*
 * These can be used to print at the various log levels.
 * All of these will print unconditionally, although note that pr_debug()
 * and other debug macros are compiled out unless either DEBUG is defined
 * or CONFIG_DYNAMIC_DEBUG is set.
 */
#define pr_emerg(fmt, ...) unit_test_print(NULL, ("emerg: " fmt), ##__VA_ARGS__)
#define pr_alert(fmt, ...) unit_test_print(NULL, ("alert: " fmt), ##__VA_ARGS__)
#define pr_crit(fmt, ...)  unit_test_print(NULL, ("crit: " fmt), ##__VA_ARGS__)
#define pr_err(fmt, ...)   unit_test_print(NULL, ("err: " fmt), ##__VA_ARGS__)
#define pr_warning(fmt, ...) unit_test_print(NULL, ("warning: " fmt), ##__VA_ARGS__)
#define pr_warn pr_warning
#define pr_notice(fmt, ...) unit_test_print(NULL, ("notice: " fmt), ##__VA_ARGS__)
#define pr_info(fmt, ...)  unit_test_print(NULL, ("info: " fmt), ##__VA_ARGS__)
#define pr_debug(fmt, ...)  unit_test_dbg_print(NULL, ("debug: " fmt), ##__VA_ARGS__)

#define dev_err(dev, fmt, ...) unit_test_print(dev, ("dev_err: " fmt), ##__VA_ARGS__)
#define dev_warn(dev, fmt, ...) unit_test_print(dev, ("dev_warn: " fmt), ##__VA_ARGS__)
#define dev_warn_once(dev, fmt, ...) unit_test_print(dev, ("dev_warn: " fmt), ##__VA_ARGS__)
#define dev_notice(dev, fmt, ...) unit_test_print(dev, ("dev_notice: " fmt), ##__VA_ARGS__)
#define dev_info(dev, fmt, ...) unit_test_print(dev, ("dev_info: " fmt), ##__VA_ARGS__)
#define dev_dbg(dev, fmt, ...) unit_test_dbg_print(dev, ("dev_dbg: " fmt), ##__VA_ARGS__)

#include <linux/ktime.h>

#define NR_CPUS 4096

typedef struct cpumask { DECLARE_BITMAP(bits, NR_CPUS); } cpumask_t;

#include <linux/kobject.h>

struct device {
	struct device		*parent;
	struct bus_type	*bus;		/* type of bus device is on */
	struct device_driver *driver;	/* which driver has allocated this */
	void *driver_data;
	void (*release)(struct device *dev);
	struct kobject kobj;
};

#define STATIC
#define INLINE
#define GFP_KERNEL 0
#define __GFP_ZERO 0

typedef unsigned gfp_t;

#define FIELD_SIZEOF(t, f) (sizeof(((t*)0)->f))
#define sizeof_field(TYPE, MEMBER) (sizeof((((TYPE *)0)->MEMBER)))

/**
 * offsetofend(TYPE, MEMBER)
 *
 * @TYPE: The type of the structure
 * @MEMBER: The member within the structure to get the end offset of
 */
#define offsetofend(TYPE, MEMBER) \
	(offsetof(TYPE, MEMBER)	+ sizeof_field(TYPE, MEMBER))

typedef u64 resource_size_t;

/* for dma_addr_t */
#include <linux/dma-mapping.h>

extern void *dmam_alloc_coherent(struct device *dev, size_t size,
                                 dma_addr_t *dma_handle, gfp_t gfp);
extern void dmam_free_coherent(struct device *dev, size_t size, void *vaddr,
                               dma_addr_t dma_handle);

char *kasprintf(gfp_t gfp, const char *fmt, ...);
char *kvasprintf(gfp_t gfp, const char *fmt, va_list args);

#define page_to_nid(p) 0
#define page_is_pfmemalloc(x) 0
#define numa_mem_id() 0

#include <linux/atomic.h>

typedef struct qspinlock {
	atomic_t	val;
} arch_spinlock_t;

typedef struct raw_spinlock {
	arch_spinlock_t raw_lock;
} raw_spinlock_t;

typedef struct spinlock {
	enum lock_state state;
} spinlock_t;

/* there is no equivalent spin_lock_destroy */
static void spin_lock_init(spinlock_t *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
	case LOCK_UNLOCKED:
		/* newly initialized spinlock is unlocked */
		lock->state = LOCK_UNLOCKED;
		break;
	case LOCK_LOCKED:
		FAIL("spinlock: attempting to init locked spinlock");
		break;
	default:
		FAIL("spinlock: lock state is invalid");
		break;
	}
}

static void spin_lock(spinlock_t *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("spinlock: attempting to lock an uninitialized spinlock");
		break;
	case LOCK_UNLOCKED:
		lock->state = LOCK_LOCKED;
		break;
	case LOCK_LOCKED:
		FAIL("spinlock: attempting to lock an already locked spinlock");
		break;
	default:
		FAIL("spinlock: lock state is invalid");
		break;
	}
}

static bool spin_trylock(spinlock_t *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("spinlock: attempting to lock an uninitialized spinlock");
		break;
	case LOCK_UNLOCKED:
		lock->state = LOCK_LOCKED;
		break;
	case LOCK_LOCKED:
		FAIL("spinlock: attempting to lock an already locked spinlock");
		break;
	default:
		FAIL("spinlock: lock state is invalid");
		break;
	}

	return true;
}

static void spin_unlock(spinlock_t *lock)
{
	switch (lock->state) {
	case LOCK_NEW:
		FAIL("spinlock: attempting to unlock an uninitialized spinlock");
		break;
	case LOCK_UNLOCKED:
		FAIL("spinlock: attempting to unlock spinlock that wasn't locked");
		break;
	case LOCK_LOCKED:
		lock->state = LOCK_UNLOCKED;
		break;
	default:
		FAIL("spinlock: lock state is invalid");
		break;
	}
}

static void spin_lock_bh(spinlock_t *lock)
{
	spin_lock(lock);
}

static void spin_lock_irqsave(spinlock_t *lock, unsigned long flags)
{
	spin_lock(lock);
}

static void spin_unlock_bh(spinlock_t *lock)
{
	spin_unlock(lock);
}

static void spin_unlock_irqrestore(spinlock_t *lock, unsigned long flags)
{
	spin_unlock(lock);
}

static void synchronize_irq(unsigned int irq)
{
}

enum net_device_flags {
/* for compatibility with glibc net/if.h */
	IFF_UP				= 1<<0,  /* sysfs */
	IFF_BROADCAST			= 1<<1,  /* volatile */
	IFF_DEBUG			= 1<<2,  /* sysfs */
	IFF_LOOPBACK			= 1<<3,  /* volatile */
	IFF_POINTOPOINT			= 1<<4,  /* volatile */
	IFF_NOTRAILERS			= 1<<5,  /* sysfs */
	IFF_RUNNING			= 1<<6,  /* volatile */
	IFF_NOARP			= 1<<7,  /* sysfs */
	IFF_PROMISC			= 1<<8,  /* sysfs */
	IFF_ALLMULTI			= 1<<9,  /* sysfs */
	IFF_MASTER			= 1<<10, /* volatile */
	IFF_SLAVE			= 1<<11, /* volatile */
	IFF_MULTICAST			= 1<<12, /* sysfs */
	IFF_PORTSEL			= 1<<13, /* sysfs */
	IFF_AUTOMEDIA			= 1<<14, /* sysfs */
	IFF_DYNAMIC			= 1<<15, /* sysfs */
	IFF_LOWER_UP			= 1<<16, /* volatile */
	IFF_DORMANT			= 1<<17, /* volatile */
	IFF_ECHO			= 1<<18, /* volatile */
};

/* for compatibility with glibc net/if.h */
#define IFF_UP				IFF_UP
#define IFF_BROADCAST			IFF_BROADCAST
#define IFF_DEBUG			IFF_DEBUG
#define IFF_LOOPBACK			IFF_LOOPBACK
#define IFF_POINTOPOINT			IFF_POINTOPOINT
#define IFF_NOTRAILERS			IFF_NOTRAILERS
#define IFF_RUNNING			IFF_RUNNING
#define IFF_NOARP			IFF_NOARP
#define IFF_PROMISC			IFF_PROMISC
#define IFF_ALLMULTI			IFF_ALLMULTI
#define IFF_MASTER			IFF_MASTER
#define IFF_SLAVE			IFF_SLAVE
#define IFF_MULTICAST			IFF_MULTICAST
#define IFF_PORTSEL			IFF_PORTSEL
#define IFF_AUTOMEDIA			IFF_AUTOMEDIA
#define IFF_DYNAMIC			IFF_DYNAMIC

#define jiffies 0x12345678ULL

#define time_before(x,y) 0
/* FIXME: maybe this needs to be a mock instead so that we can force taking
 * different branches?
 */
#define time_after(a,b) \
	((long)((b) - (a)) < 0)

#define smp_mb__before_atomic() do {} while(0)

#define kfree_rcu(ptr, rcu_head) free(ptr)

#define kmalloc(size, flags) calloc(size, sizeof(char))
#define kfree(obj) free(obj)

#define vzalloc(size) calloc(size, sizeof(char))
#define vmalloc(size) calloc(size, sizeof(char))
/* a real function pointer is needed for devlink region ops */
static inline void vfree(const void *obj)
{
	free((__force void *)obj);
}

#define vfree(obj) free(obj)

#define HZ 1000

#define htonl(x) cpu_to_be32(x)

static void cpumask_set_cpu(unsigned int cpu, struct cpumask *dstp) {}

struct tcphdr {
	__be16  source;
	__be16  dest;
	__be32  seq;
	__be32  ack_seq;
	__u16	res1:4,
		doff:4,
		fin:1,
		syn:1,
		rst:1,
		psh:1,
		ack:1,
		urg:1,
		ece:1,
		cwr:1;
	__be16  window;
	__sum16 check;
	__be16  urg_ptr;
};

struct udphdr {
	__be16  source;
	__be16  dest;
	__be16  len;
	__sum16 check;
};

/* Included from include/netinet/in.h */
/* Standard well-defined IP protocols. */
enum {
	IPPROTO_IP = 0,		/* Dummy protocol for TCP.  */
#define IPPROTO_IP		IPPROTO_IP
	IPPROTO_ICMP = 1,	/* Internet Control Message Protocol.  */
#define IPPROTO_ICMP		IPPROTO_ICMP
	IPPROTO_IGMP = 2,	/* Internet Group Management Protocol. */
#define IPPROTO_IGMP		IPPROTO_IGMP
	IPPROTO_IPIP = 4, /* IPIP tunnels (older KA9Q tunnels use 94).  */
#define IPPROTO_IPIP		IPPROTO_IPIP
	IPPROTO_TCP = 6,	/* Transmission Control Protocol.  */
#define IPPROTO_TCP		IPPROTO_TCP
	IPPROTO_EGP = 8,	/* Exterior Gateway Protocol.  */
#define IPPROTO_EGP		IPPROTO_EGP
	IPPROTO_PUP = 12,	/* PUP protocol.  */
#define IPPROTO_PUP		IPPROTO_PUP
	IPPROTO_UDP = 17,	/* User Datagram Protocol.  */
#define IPPROTO_UDP		IPPROTO_UDP
	IPPROTO_IDP = 22,	/* XNS IDP protocol.  */
#define IPPROTO_IDP		IPPROTO_IDP
	IPPROTO_TP = 29,	/* SO Transport Protocol Class 4.  */
#define IPPROTO_TP		IPPROTO_TP
	IPPROTO_DCCP = 33,	/* Datagram Congestion Control Protocol.  */
#define IPPROTO_DCCP		IPPROTO_DCCP
	IPPROTO_IPV6 = 41,	/* IPv6 header.  */
#define IPPROTO_IPV6		IPPROTO_IPV6
	IPPROTO_RSVP = 46,	/* Reservation Protocol.  */
#define IPPROTO_RSVP		IPPROTO_RSVP
	IPPROTO_GRE = 47,	/* General Routing Encapsulation.  */
#define IPPROTO_GRE		IPPROTO_GRE
	IPPROTO_ESP = 50,	/* encapsulating security payload.  */
#define IPPROTO_ESP		IPPROTO_ESP
	IPPROTO_AH = 51,	/* authentication header.  */
#define IPPROTO_AH		IPPROTO_AH
	IPPROTO_MTP = 92,	/* Multicast Transport Protocol.  */
#define IPPROTO_MTP		IPPROTO_MTP
	IPPROTO_BEETPH = 94,	/* IP option pseudo header for BEET.  */
#define IPPROTO_BEETPH		IPPROTO_BEETPH
	IPPROTO_ENCAP = 98,	/* Encapsulation Header.  */
#define IPPROTO_ENCAP		IPPROTO_ENCAP
	IPPROTO_PIM = 103,	/* Protocol Independent Multicast.  */
#define IPPROTO_PIM		IPPROTO_PIM
	IPPROTO_COMP = 108,	/* Compression Header Protocol.  */
#define IPPROTO_COMP		IPPROTO_COMP
	IPPROTO_SCTP = 132,	/* Stream Control Transmission Protocol.  */
#define IPPROTO_SCTP		IPPROTO_SCTP
	IPPROTO_UDPLITE = 136,	/* UDP-Lite protocol.  */
#define IPPROTO_UDPLITE		IPPROTO_UDPLITE
	IPPROTO_MPLS = 137,	/* MPLS in IP.  */
#define IPPROTO_MPLS		IPPROTO_MPLS
	IPPROTO_RAW = 255,	/* Raw IP packets.  */
#define IPPROTO_RAW		IPPROTO_RAW
	IPPROTO_MAX
};


typedef unsigned short sa_family_t;

/* From include/net/udp_tunnel.h */
enum udp_parsable_tunnel_type {
	UDP_TUNNEL_TYPE_VXLAN,		/* RFC 7348 */
	UDP_TUNNEL_TYPE_GENEVE,		/* draft-ietf-nvo3-geneve */
	UDP_TUNNEL_TYPE_VXLAN_GPE,	/* draft-ietf-nvo3-vxlan-gpe */
};

struct udp_tunnel_info {
	unsigned short type;
	sa_family_t sa_family;
	__be16 port;
};

/* Internet address. */
struct in_addr {
	__be32	s_addr;
};

/* maybe someone should include linux/stringify.h */
#define __stringify_1(x...)	#x
#define __stringify(x...)	__stringify_1(x)

/* put this here, and not in limits.h because there is a uapi limits.h that we
 * like the content of, which is replaced by the local one if we add it.
 */
#define U8_MAX		((u8)~0U)
#define S8_MAX		((s8)(U8_MAX >> 1))
#define S8_MIN		((s8)(-S8_MAX - 1))
#define U16_MAX		((u16)~0U)
#define S16_MAX		((s16)(U16_MAX >> 1))
#define S16_MIN		((s16)(-S16_MAX - 1))
#define U32_MAX		((u32)~0U)
#define U32_MIN		((u32)0)
#define S32_MAX		((s32)(U32_MAX >> 1))
#define S32_MIN		((s32)(-S32_MAX - 1))
#define U64_MAX		((u64)~0ULL)
#define S64_MAX		((s64)(U64_MAX >> 1))
#define S64_MIN		((s64)(-S64_MAX - 1))

#endif /* __KERNEL_ABSTRACT */
