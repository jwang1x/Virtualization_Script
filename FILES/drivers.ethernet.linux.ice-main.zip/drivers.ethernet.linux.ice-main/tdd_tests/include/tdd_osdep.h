#ifndef _TDD_OSDEP_H_
#define _TDD_OSDEP_H_

#include <arpa/inet.h>
#define min(a, b) (std::min((a), (b)))

/* grab some linux specific code from the linux repo */
#include "../../../tdd_tests/include/list.h"
#include "linux/kernel.h"

#define LIST_ENTRY_TYPE list_head
#define LIST_HEAD_TYPE list_head
#define LIST_EMPTY list_empty
#define LIST_ADD list_add
#define LIST_ADD_AFTER list_add
#define LIST_ADD_TAIL list_add_tail
#define LIST_DEL list_del
#define LIST_FIRST_ENTRY list_first_entry
#define LIST_NEXT_ENTRY(one, two, three) list_next_entry(one, three)
#define LIST_LAST_ENTRY list_last_entry
#define LIST_FOR_EACH_ENTRY(one, two, three, four) \
	list_for_each_entry(one, two, four)
#define LIST_FOR_EACH_ENTRY_SAFE(pos, tmp, head, entrytype, member) \
	list_for_each_entry_safe(pos, tmp, head, member)
#define LIST_REPLACE_INIT list_replace_init

#define BIT_M(nr)		(1UL << ((nr) % BITS_PER_LONG))
#define BIT_WORD(nr)		((nr) / BITS_PER_LONG)
#define BITS_PER_BYTE		8
#define BITS_PER_LONG		64
#define BITS_TO_LONGS(nr)	DIV_ROUND_UP(nr, BITS_PER_BYTE * sizeof(long))
#define DECLARE_BITMAP(name, bits)	unsigned long name[BITS_TO_LONGS(bits)]
#ifndef UNREFERENCED_XPARAMETER
#define UNREFERENCED_XPARAMETER
#define UNREFERENCED_1PARAMETER(_p) (_p = _p)
#define UNREFERENCED_2PARAMETER(_p, _q) do { (_p = _p); (_q = _q); } while (0)
#define UNREFERENCED_3PARAMETER(_p, _q, _r) do { (_p = _p); (_q = _q); (_r = _r); } while (0)
#define UNREFERENCED_4PARAMETER(_p, _q, _r, _s) do { (_p = _p); (_q = _q); (_r = _r); (_s = _s); } while (0)
#endif
#ifdef ice_is_bit_set
#undef ice_is_bit_set
#define ice_is_bit_set test_bit
#endif
#ifdef ice_declare_bitmap
#undef ice_declare_bitmap
#define ice_declare_bitmap DECLARE_BITMAP
#endif
#ifdef ice_and_bitmap
#undef ice_and_bitmap
#define ice_and_bitmap and_bitmap
#endif
#ifdef ice_set_bit
#undef ice_set_bit
#define ice_set_bit set_bit
#endif
/* This printf is a trick to consume all the args to prevent an unused variable
 * warning
 */
#define ice_debug(hw, level, str, args...) \
	do { (void)hw; printf("", ##args); } while (0)
#define ice_debug_array(_hw, _mask, _rowsize, _groupsize, _buf, _length) do { } while (0)
#define ice_debug_fw_log(_hw, _mask, _rowsize, _groupsize, _buf, _length) do { } while (0)
#define ice_info_fwlog(_hw, _rowsize, _groupsize, _buf, _length) do {} while (0)
#define ice_info(hw, str, args...) fprintf(stderr, (str), ##args)
#define ice_warn(hw, str, args...) fprintf(stderr, (str), ##args)
static void set_bit(unsigned int bit, unsigned long *p)
{
	unsigned long mask = BIT_M(bit);

	p += BIT_WORD(bit);
	*p |= mask;
}

static bool test_bit(unsigned long *p, unsigned int bit)
{
	unsigned long mask = BIT_M(bit);

	p += BIT_WORD(bit);
	return *p & mask;
}

/**
 * and_bitmap - bitwise AND 2 bitmaps and store result in dst bitmap
 * @dst: Destination bitmap that receive the result of the operation
 * @bmp1: The first bitmap to intersect
 * @bmp2: The second bitmap to intersect wit the first
 * @sz: Size of the bitmaps in bits
 */
static int
and_bitmap(unsigned long *dst, const unsigned long *bmp1,
	   const unsigned long *bmp2, unsigned int sz)
{
	unsigned long res = 0;
	int cnt, i;

	cnt = BITS_TO_LONGS(sz);
	for (i = 0; i < cnt; i++) {
		dst[i] = bmp1[i] & bmp2[i];
		res |= dst[i];
	}

	if (sz % BITS_PER_LONG) {
		unsigned long mask = ~0 >>
			(BITS_PER_LONG - (sz % BITS_PER_LONG));

		dst[i] = bmp1[i] & bmp2[i] & mask;
		res |= dst[i];
	}

	return res != 0;
}

#define SNPRINTF snprintf

#define CPU_TO_LE16(a) htole16(a)
#define CPU_TO_LE32(a) htole32(a)
#define CPU_TO_LE64(a) htole64(a)
#define LE16_TO_CPU(a) le16toh(a)
#define LE32_TO_CPU(a) le32toh(a)
#define LE64_TO_CPU(a) le64toh(a)
#define CPU_TO_BE16(a) htobe16(a)
#define CPU_TO_BE32(a) htobe32(a)
#define CPU_TO_BE64(a) htobe64(a)
#define BE16_TO_CPU(a) be16toh(a)
#define BE32_TO_CPU(a) be32toh(a)
#define BE64_TO_CPU(a) be64toh(a)

#endif /* _TDD_OSDEP_H_ */
