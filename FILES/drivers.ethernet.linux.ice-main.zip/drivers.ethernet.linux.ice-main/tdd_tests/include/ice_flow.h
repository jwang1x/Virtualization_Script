#ifndef __ICE_FLOW_LOCAL_H
#define __ICE_FLOW_LOCAL_H

#include "../src/SHARED/ice_flow.h"

#endif
