#ifndef _ICE_LINUX_LIST_H_
#define _ICE_LINUX_LIST_H_

/* grab some linux specific code from the linux repo */
#include "list.h"

#define LIST_ENTRY_TYPE list_head
#define LIST_HEAD_TYPE list_head
#define LIST_EMPTY list_empty
#define LIST_ADD list_add
#define LIST_DEL list_del
/* in this case "member" can't be surrounded by () because of the way
 * it is used by the underlying functions in the two below
 * macros.
 */
#define LIST_FOR_EACH_ENTRY(iter,head,stype,member) \
	list_for_each_entry((iter), (head), member)
#define LIST_FOR_EACH_ENTRY_SAFE(iter,tmp,head,stype,member) \
	list_for_each_entry_safe((iter), (tmp), (head), member)

#endif /* _ICE_LINUX_LIST_H_ */
