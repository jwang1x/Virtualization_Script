#ifndef _LOCAL_ICE_DCB_H_
#define _LOCAL_ICE_DCB_H_

#include "../src/SHARED/ice_dcb.h"

#endif /* _LOCAL_ICE_DCB_H_ */
