/*

This file was taken from sparse-devel which contains the following license:

The 'sparse' C parser front-end library is copyrighted by Transmeta Corp
and other authors and licensed under the "MIT License" as
obtained from www.opensource.org (and included here-in for easy
reference).

[ This copy of the license is the flat-text version of original,
  available in its full glory at

	 http://opensource.org/licenses/MIT

  please refer to there for the authoritative and slightly more
  pretty-printed version ]

------

			The MIT License (MIT)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
#ifndef BITMAP_H
#define BITMAP_H

#include "include/linux/bitops.h"
#define SPARSE_DIV_ROUND_UP(n, d)	(((n) + (d) - 1) / (d))
#define BITS_PER_BYTE		8

#define BITS_IN_LONG	(sizeof(unsigned long)*8)
#define LONGS(nr) SPARSE_DIV_ROUND_UP(nr, BITS_PER_BYTE * sizeof(long))

/* Every bitmap gets its own type */
#define DECLARE_BITMAP(name, x) unsigned long name[LONGS(x)]

static int test_bit(unsigned int nr, const unsigned long *bitmap)
{
	unsigned long offset = nr / BITS_IN_LONG;
	unsigned long bit = nr & (BITS_IN_LONG-1);
	return (bitmap[offset] >> bit) & 1;
}

static void set_bit(unsigned int nr, unsigned long *bitmap)
{
	unsigned long offset = nr / BITS_IN_LONG;
	unsigned long bit = nr & (BITS_IN_LONG-1);
	bitmap[offset] |= 1UL << bit;
}

static void clear_bit(unsigned int nr, unsigned long *bitmap)
{
	unsigned long offset = nr / BITS_IN_LONG;
	unsigned long bit = nr & (BITS_IN_LONG-1);
	bitmap[offset] &= ~(1UL << bit);
}

static int test_and_set_bit(unsigned int nr, unsigned long *bitmap)
{
	unsigned long offset = nr / BITS_IN_LONG;
	unsigned long bit = nr & (BITS_IN_LONG-1);
	unsigned long old = bitmap[offset];
	unsigned long mask = 1UL << bit;
	bitmap[offset] = old | mask;
	return (old & mask) != 0;
}

static int test_and_clear_bit(unsigned int nr, unsigned long *bitmap)
{
	unsigned long offset = nr / BITS_IN_LONG;
	unsigned long bit = nr & (BITS_IN_LONG-1);
	unsigned long old = bitmap[offset];
	unsigned long mask = 1UL << bit;
	bitmap[offset] = old & ~mask;
	return (old & mask) != 0;
}

static inline void change_bit(int nr, unsigned long *addr)
{
	unsigned long mask = BIT_MASK(nr);
	unsigned long *p = ((unsigned long *)addr) + BIT_WORD(nr);

	*p ^= mask;
}
#endif /* BITMAP_H */
