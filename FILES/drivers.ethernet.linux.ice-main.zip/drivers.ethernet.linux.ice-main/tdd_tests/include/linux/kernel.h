#ifndef _LOCAL_KERNEL_H
#define _LOCAL_KERNEL_H

#define __ALIGN_KERNEL_MASK(x, mask)	(((x) + (mask)) & ~(mask))
#define __ALIGN_KERNEL(x, a)		__ALIGN_KERNEL_MASK(x, (typeof(x))(a) - 1)
#define ALIGN(x, a) __ALIGN_KERNEL((x), (a))

#define __ALIGN_MASK(x, mask)	__ALIGN_KERNEL_MASK((x), (mask))
#define PTR_ALIGN(p, a)		((typeof(p))ALIGN((unsigned long)(p), (a)))
#define IS_ALIGNED(x, a)	(((x) & ((typeof(x))(a) - 1)) == 0)

/*
 * This looks more complex than it should be. But we need to
 * get the type for the ~ right in round_down (it needs to be
 * as wide as the result!), and we want to evaluate the macro
 * arguments just once each.
 */
#define __round_mask(x, y) ((__typeof__(x))((y)-1))
#define round_up(x, y) ((((x)-1) | __round_mask(x, y))+1)
#define round_down(x, y) ((x) & ~__round_mask(x, y))

#define FIELD_SIZEOF(t, f) (sizeof(((t*)0)->f))
#define __KERNEL_DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#define DIV_ROUND_UP __KERNEL_DIV_ROUND_UP
#define DIV_ROUND_UP_ULL(ll,d) \
	({ unsigned long long _tmp = (ll)+(d)-1; do_div(_tmp, d); _tmp; })
;
inline int trace_printk(const char *fmt, ...)
{
	return 0;
}

inline int kstrtoint(const char *s, unsigned int base, int *res)
{
	int ret;

	ret = sscanf(s, "%i", res);
	if (ret == 1)
		return 0;

	return -EINVAL;
}

typedef unsigned char	u8;
typedef unsigned int	u32;

#define HTONL htonl
#define HTONS htons

#define min3(x, y, z) min_t(typeof((x)), min_t(typeof((x)), (x), (y)), (z))

/**
 * upper_32_bits - return bits 32-63 of a number
 * @n: the number we're accessing
 *
 * A basic shift-right of a 64- or 32-bit quantity.  Use this to suppress
 * the "right shift count >= width of type" warning when that quantity is
 * 32-bits.
 */
#define upper_32_bits(n) ((u32)(((n) >> 16) >> 16))

/**
 * lower_32_bits - return bits 0-31 of a number
 * @n: the number we're accessing
 */
#define lower_32_bits(n) ((u32)((n) & 0xffffffff))

/**
 * roundup - round up to the next specified multiple
 * @x: the value to up
 * @y: multiple to round up to
 *
 * Rounds @x up to next multiple of @y. If @y will always be a power
 * of 2, consider using the faster round_up().
 */
#define roundup(x, y) (					\
{							\
	typeof(y) __y = y;				\
	(((x) + (__y - 1)) / __y) * __y;		\
}							\
)

/**
 * __same_type - check if two types are compatible
 * @a: variable of the first type
 * @b: variable of the second type
 *
 * Evaluate if the type of two variables is the same, ignoring qualifiers.
 * C code could use __builtin_types_compatible_p, but this is a GCC specific
 * extension that is only supported for C code, and not by g++. Instead, rely
 * on std::is_same instead.
 *
 * Note that unlike the __builtin_types_compatible_p, this implementation does
 * not ignore const/volatile. We haven't found a good mechanism to remove
 * const from all layers of a pointer.
 *
 * Also note that this implementation of __same_type cannot be passed
 * a statement expression '({ })'. These are a GCC extension and it seems that
 * typeof doesn't handle converting them to a type properly.
 */
#define __same_type(a, b) \
	(std::is_same<typeof(a), typeof(b)>::value)

/**
 * compiletime_assert - break build and emit msg if condition is false
 * @condition: a compile-time constant condition to check
 * @msg:       a message to emit if condition is false
 *
 * In tradition of POSIX assert, this macro will break the build if the
 * supplied condition is *false*, emitting the supplied error message if the
 * compiler has support to do so.
 *
 * For TDD C++, we rely on static_assert to generate the warning, assuming
 * that the condition must be a valid constexpr.
 */
#define compiletime_assert(condition, msg) \
	do { static_assert(condition, msg); } while (0)


/**
 * BUILD_BUG_ON_MSG - break compile if a condition is true & emit supplied
 *		      error message.
 * @condition: the condition which the compiler should know is false.
 *
 * See BUILD_BUG_ON for description.
 */
#define BUILD_BUG_ON_MSG(cond, msg) compiletime_assert(!(cond), msg)

/**
 * container_of - cast a member of a structure out to the containing structure
 * @ptr:	the pointer to the member.
 * @type:	the type of the container struct this is embedded in.
 * @member:	the name of the member within the struct.
 *
 * TDD NOTE: this implementation *does not* type check. Adding a type check is
 * very tricky to get right in C++. Previous implementations tried to use
 * std::is_same in order to ensure that the types are compatible. This
 * unfortunately broke down when the piece being passed in is a compound
 * statement expression. This GCC extension did not play nicely with the
 * typeof in the __same_type implementation. The expectation is that the type
 * check isn't very useful because we'll get the type check when compiling in
 * C code.
 *
 * We cast mptr to a u8 * before doing arithmetic in order to avoid
 * a -Wpointer-arith warning.
 */
#define container_of(ptr, type, member) ({				\
	void *__mptr = (void *)(ptr);					\
	((type *)((u8 *)__mptr - offsetof(type, member))); })

int vscnprintf(char *buf, size_t size, const char *fmt, va_list args);
int scnprintf(char *buf, size_t size, const char *fmt, ...);

#endif /* _LOCAL_KERNEL_H */
