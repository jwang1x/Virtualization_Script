#ifndef _PM_H_
#define _PM_H_

#include <linux/completion.h>

typedef struct pm_message {
	int event;
} pm_message_t;

#endif /* _PM_H_ */
