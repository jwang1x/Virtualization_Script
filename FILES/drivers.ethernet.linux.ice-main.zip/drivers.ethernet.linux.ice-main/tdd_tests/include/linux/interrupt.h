#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_

#include <linux/workqueue.h>

#define IRQF_SHARED          0x00000080

enum irqreturn {
	IRQ_NONE		= (0 << 0),
	IRQ_HANDLED		= (1 << 0),
	IRQ_WAKE_THREAD		= (1 << 1),
};

typedef enum irqreturn irqreturn_t;
#define IRQ_RETVAL(x)	((x) ? IRQ_HANDLED : IRQ_NONE)

struct irq_affinity_notify {
	unsigned int irq;
//	struct kref kref;
	struct work_struct work;
	void (*notify)(struct irq_affinity_notify *, const cpumask_t *mask);
	void (*release)(struct kref *ref);
};

typedef irqreturn_t (*irq_handler_t)(int, void *);

static int
devm_request_threaded_irq(struct device *dev, unsigned int irq,
			  irq_handler_t handler, irq_handler_t thread_fn,
			  unsigned long irqflags, const char *devname,
			  void *dev_id)
{
	return 0;
}

/* have a mock take this one so we can fail it during testing
 *
static
int devm_request_irq(struct device *dev, unsigned int irq,
		     irq_handler_t handler, unsigned long irqflags,
		     const char *devname, void *dev_id)
{
	return 1;
}
*/

static void free_irq(unsigned int irq, void *dev_id)
{
}

static
void devm_free_irq(struct device *dev, unsigned int irq, void *dev_id)
{
}

static int irq_set_affinity(unsigned int irq, const struct cpumask *m)
{
	return -1;
}

static
int irq_force_affinity(unsigned int irq, const struct cpumask *cpumask)
{
	return 0;
}

static int irq_can_set_affinity(unsigned int irq)
{
	return 0;
}

static int irq_select_affinity(unsigned int irq)  { return 0; }

static int irq_set_affinity_hint(unsigned int irq,
					const struct cpumask *m)
{
	return -1;
}

static int
irq_set_affinity_notifier(unsigned int irq, struct irq_affinity_notify *notify)
{
	return 0;
}

static struct cpumask *
irq_create_affinity_masks(const struct cpumask *affinity, int nvec)
{
	return NULL;
}

static
int irq_calc_affinity_vectors(const struct cpumask *affinity, int maxvec)
{
	return maxvec;
}

struct tasklet_struct
{
	struct tasklet_struct *next;
	unsigned long state;
	atomic_t count;
	bool use_callback;
	union {
		void (*func)(unsigned long data);
		void (*callback)(struct tasklet_struct *t);
	};
	unsigned long data;
};

#define from_tasklet(var, callback_tasklet, tasklet_fieldname)	\
	container_of(callback_tasklet, typeof(*var), tasklet_fieldname)

enum
{
	TASKLET_STATE_SCHED,	/* Tasklet is scheduled for execution */
	TASKLET_STATE_RUN	/* Tasklet is running (SMP only) */
};

static inline void tasklet_schedule(struct tasklet_struct *t) {}

static inline void tasklet_kill(struct tasklet_struct *t) {}
static inline void
tasklet_init(struct tasklet_struct *t, void (*func)(unsigned long),
	     unsigned long data) {}
static inline void
tasklet_setup(struct tasklet_struct *t,
	      void (*callback)(struct tasklet_struct *)) {}

#endif // _INTERRUPT_H_
