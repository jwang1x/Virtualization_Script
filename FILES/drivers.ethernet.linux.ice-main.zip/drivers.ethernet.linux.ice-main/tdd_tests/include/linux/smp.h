#ifndef _SMP_H_
#define _SMP_H_

#define smp_processor_id() 0

#endif /* _SMP_H_ */
