#ifndef _LINUX_FIRMWARE_H
#define _LINUX_FIRMWARE_H

struct firmware {
	size_t size;
	const u8 *data;
	struct page **pages;

	/* firmware loader private fields */
	void *priv;
};

static int
firmware_request_nowarn(const struct firmware **firmware, const char *name,
			struct device *device)
{
	int retval;

	mock().actualCall(__func__)
		.withParameter("name", name)
		.withParameter("device", device);

	retval = mock().returnIntValueOrDefault(0);

	if (!retval) {
		struct firmware *fw_p;

		fw_p = (struct firmware *)malloc(sizeof(*fw_p));
		fw_p->size = 1024;
		fw_p->data = (u8 *)malloc(fw_p->size);
		*firmware = fw_p;
	}

	return retval;
}

static int request_firmware(const struct firmware **fw, const char *name,
		     struct device *device)
{
	int retval;

	mock().actualCall(__func__);
	retval = mock().returnIntValueOrDefault(0);

	if (!retval) {
		struct firmware *fw_p;

		fw_p = (struct firmware *)malloc(sizeof(*fw_p));
		fw_p->size = 1024;
		fw_p->data = (u8 *)malloc(fw_p->size);
		*fw = fw_p;
	}

	return retval;
}

static int
request_firmware_nowait(struct module *module, bool uevent, const char *name,
			struct device *device, gfp_t gfp, void *context,
			void (*cont)(const struct firmware *fw, void *context))
{
	return 0;
}

static void release_firmware(const struct firmware *fw)
{
	free((void *)fw->data);
	free((void *)fw);
};

#endif
