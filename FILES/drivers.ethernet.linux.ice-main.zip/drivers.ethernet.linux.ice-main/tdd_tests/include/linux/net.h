#ifndef _LINUX_NET_H
#define _LINUX_NET_H

static int net_ratelimit(void)
{
	return 1;
}

#endif  /* _LINUX_NET_H */
