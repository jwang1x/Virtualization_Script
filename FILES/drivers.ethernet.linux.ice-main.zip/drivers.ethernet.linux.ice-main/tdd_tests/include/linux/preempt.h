#define in_task() 1 /* dummy implementation to avoid all the dependencies */
