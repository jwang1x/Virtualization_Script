/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __LINUX_TC_GACT_H
#define __LINUX_TC_GACT_H
#define TCA_ACT_GACT 5
#endif
