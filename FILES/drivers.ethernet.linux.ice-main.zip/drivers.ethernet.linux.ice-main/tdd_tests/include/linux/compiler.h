#ifndef _TOOLS_LINUX_COMPILER_H_
#define _TOOLS_LINUX_COMPILER_H_

#define __always_unused __attribute__((unused))
#define __maybe_unused __attribute__((unused))

#ifndef WRITE_ONCE
#define WRITE_ONCE(x, val)				\
	({typeof((x)) __val = (val); memcpy((void *)&(x),   \
		(void *)&__val, sizeof(__val)); __val; })
#endif

/* below macro originally resides in 'linux/atomic.h */
#ifndef xchg
#define xchg(old, _new)						\
({								\
	__typeof__(*(old)) __ret = *old;			\
	*old = _new;						\
	__ret;							\
})
#endif

/* hack for avoiding */
#define BUILD_BUG_ON_ZERO(e) (0)

/* &a[0] degrades to a pointer: a different type from an array */
#define __must_be_array(a)	BUILD_BUG_ON_ZERO(__same_type((a), &(a)[0]))

#define __user
#endif /* _TOOLS_LINUX_COMPILER_H */
