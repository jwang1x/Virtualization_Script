#ifndef _KOBJECT_H_
#define _KOBJECT_H_

#include <linux/sysfs.h>

struct kobject {
	const char	*name;
	struct kobject	*parent;
};

struct kobj_attribute {
	struct attribute attr;
	ssize_t (*show)(struct kobject *kobj, struct kobj_attribute *attr,
			char *buf);
	ssize_t (*store)(struct kobject *kobj, struct kobj_attribute *attr,
			 const char *buf, size_t count);
};

#endif /* _KOBJECT_H_ */
