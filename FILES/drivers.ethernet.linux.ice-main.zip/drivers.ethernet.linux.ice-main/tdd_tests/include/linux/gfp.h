#ifndef __LINUX_GFP_H
#define __LINUX_GFP_H

#include <linux/mm.h>

static struct page *alloc_page(gfp_t mask)
{
	struct page *page;

	page = (struct page *)calloc(1, sizeof(*page));

	return page;
}

static void __free_pages(struct page *page, unsigned int order)
{
	free(page);
}

#define page_address(page) (unsigned char *)&(page)->data

static void __page_frag_cache_drain(struct page *page,
					   unsigned int count)
{
	__free_pages(page, 0);
}

#endif
