#ifndef _LINUX_WORKQUEUE_H
#define _LINUX_WORKQUEUE_H

#include <linux/timer.h>

typedef void (*work_func_t)(struct work_struct *work);

struct work_struct {
	atomic_long_t data;
	struct list_head entry;
	work_func_t func;
#ifdef CONFIG_LOCKDEP
	struct lockdep_map lockdep_map;
#endif
};

#define INIT_WORK(a,b)
#define INIT_DELAYED_WORK(a,b)

static bool cancel_work_sync(struct work_struct *work)
{
	return false;
}

static bool cancel_delayed_work_sync(struct delayed_work *work)
{
	return false;
}

static bool schedule_work(struct work_struct *work)
{
	/* true means work was scheduled */
	return true;
}

struct delayed_work {
	struct work_struct work;
	struct timer_list timer;

	/* target workqueue and CPU ->timer uses to queue ->work */
	struct workqueue_struct *wq;
	int cpu;
};

static bool schedule_delayed_work(struct delayed_work *dwork,
					 unsigned long delay)
{
	return true;
}

#define flush_scheduled_work(work)

#endif
