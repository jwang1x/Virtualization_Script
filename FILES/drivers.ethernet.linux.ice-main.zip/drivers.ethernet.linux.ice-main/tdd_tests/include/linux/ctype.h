/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_CTYPE_H
#define _LINUX_CTYPE_H

#define isascii(c) (((unsigned char)(c))<=0x7f)

#endif
