#ifndef __MODULE_H
#define __MODULE_H

#define __exit

#define module_init(x)
#define module_exit(a)

#define module_param(a,b,c)
#define MODULE_PARM_DESC(a,b)

#define MODULE_AUTHOR(a)
#define MODULE_EXIT(a)
#define MODULE_DESCRIPTION(a)
#define MODULE_LICENSE(a)
#define MODULE_VERSION(a)
#define MODULE_FIRMWARE(a)

#define MODULE_DEVICE_TABLE(a,b)

#define max(a, b) ((a) <= (b) ? (b) : (a))
#define max_t(t, a, b) ((a) <= (b) ? (b) : (a))

static void WARN_ONCE(int a, const char *str) {}

#endif
