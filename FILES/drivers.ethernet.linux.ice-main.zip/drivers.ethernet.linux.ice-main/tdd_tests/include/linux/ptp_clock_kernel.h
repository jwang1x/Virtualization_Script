#ifndef PTP_CLOCK_KERNEL_H
#define PTP_CLOCK_KERNEL_H

#include <linux/ktime.h>
#include <linux/time64.h>
#include <linux/ptp_clock.h>

#define SIOCSHWTSTAMP 0x89b0
#define ACCESS_ONCE(x) (*(volatile typeof(x) *)&(x))
#define THIS_MODULE ((struct module *)0)

struct ifreq {
	char *ifr_data;
};

struct module {
	const char *version;
};

enum ptp_clock_request_type {
	PTP_CLK_REQ_EXTTS,
	PTP_CLK_REQ_PEROUT,
	PTP_CLK_REQ_PPS,
};

struct ptp_clock_request {
	enum ptp_clock_request_type type;
	union {
		struct ptp_extts_request extts;
		struct ptp_perout_request perout;
	};
};

struct ptp_clock_info {
	struct module *owner;
	char name[16];
	s32 max_adj;
	int n_alarm;
	int n_ext_ts;
	int n_per_out;
	int n_pins;
	int pps;
	struct ptp_pin_desc *pin_config;
	int (*adjfine)(struct ptp_clock_info *ptp, long scaled_ppm);
	int (*adjfreq)(struct ptp_clock_info *ptp, s32 delta);
	int (*adjphase)(struct ptp_clock_info *ptp, s32 phase);
	int (*adjtime)(struct ptp_clock_info *ptp, s64 delta);
	int (*gettime)(struct ptp_clock_info *ptp, struct timespec *ts);
	int (*gettime64)(struct ptp_clock_info *ptp, struct timespec64 *ts);
	int (*gettimex64)(struct ptp_clock_info *ptp, struct timespec64 *ts,
			  struct ptp_system_timestamp *sts);
	int (*getcrosststamp)(struct ptp_clock_info *ptp,
			      struct system_device_crosststamp *cts);
	int (*settime)(struct ptp_clock_info *ptp, const struct timespec *ts);
	int (*settime64)(struct ptp_clock_info *p, const struct timespec64 *ts);
	int (*enable)(struct ptp_clock_info *ptp,
		      struct ptp_clock_request *request, int on);
	int (*verify)(struct ptp_clock_info *ptp, unsigned int pin,
		      enum ptp_pin_function func, unsigned int chan);
	long (*do_aux_work)(struct ptp_clock_info *ptp);
};

struct ptp_clock {
	struct device *dev;
	struct ptp_clock_info *info;
	int index;
};

struct pps_event_time {
#ifdef CONFIG_NTP_PPS
	struct timespec64 ts_raw;
#endif /* CONFIG_NTP_PPS */
	struct timespec64 ts_real;
};

struct ptp_clock_event {
	int type;
	int index;
	union {
		u64 timestamp;
		struct pps_event_time pps_times;
	};
};

enum ptp_clock_events {
	PTP_CLOCK_ALARM,
	PTP_CLOCK_EXTTS,
	PTP_CLOCK_PPS,
	PTP_CLOCK_PPSUSR,
};

void ptp_clock_event(struct ptp_clock *ptp, struct ptp_clock_event *event) {
	;
}


static inline void
ptp_read_system_prets(struct ptp_system_timestamp __always_unused *sts)
{
	;
}

static inline void
ptp_read_system_postts(struct ptp_system_timestamp __always_unused *sts)
{
	;
}
#endif
