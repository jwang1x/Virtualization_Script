#ifndef _LINUX_UDP_H
#define _LINUX_UDP_H

#include <linux/skbuff.h>

static inline struct udphdr *udp_hdr(const struct sk_buff *skb)
{
	return (struct udphdr *)skb_transport_header(skb);
}

static inline struct udphdr *inner_udp_hdr(const struct sk_buff *skb)
{
	return (struct udphdr *)skb_inner_transport_header(skb);
}

#endif	/* _LINUX_UDP_H */
