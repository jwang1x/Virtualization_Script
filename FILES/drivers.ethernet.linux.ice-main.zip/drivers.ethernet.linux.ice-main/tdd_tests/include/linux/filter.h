#ifndef _LINUX_FILTER_H
#define _LINUX_FILTER_H

#include <uapi/linux/bpf.h>

struct sock_filter {	/* Filter block */
	__u16	code;   /* Actual filter code */
	__u8	jt;	/* Jump true */
	__u8	jf;	/* Jump false */
	__u32	k;      /* Generic multiuse field */
};

struct bpf_prog {
	u16			pages;		/* Number of allocated pages */
	u16			jited:1,	/* Is our filter JIT'ed? */
				locked:1,	/* Program image locked? */
				gpl_compatible:1, /* Filter GPL compatible? */
				cb_access:1,	/* Is control block accessed? */
				dst_needed:1;	/* Do we need dst entry? */
	enum bpf_prog_type	type;		/* Type of BPF program */
	u32			len;		/* Number of filter blocks */
	u32			jited_len;	/* Size of jited insns */
	u8			tag[BPF_TAG_SIZE];
	struct bpf_prog_aux	*aux;		/* Auxiliary fields */
	struct sock_fprog_kern	*orig_prog;	/* Original BPF program */
	unsigned int		(*bpf_func)(const void *ctx,
					    const struct bpf_insn *insn);
	/* Instructions for interpreter */
	union {
		struct sock_filter	insns[0];
		struct bpf_insn		insnsi[0];
	};
};

static __always_inline u32 bpf_prog_run_xdp(const struct bpf_prog *prog,
					    struct xdp_buff *xdp)
{
	return 0;
}

#ifndef xdp_do_flush_map
#define xdp_do_flush_map(_x) { do { } while (0); }
#endif /* xdp_do_flush_map */
#endif /* _LINUX_FILTER_H */
