#ifndef _DELAY_H_
#define _DELAY_H_

static void udelay(unsigned long usecs)
{
}

static void usleep_range(unsigned long min, unsigned long max)
{
	//printf("range slept %d, %d\n", min, max);
}

static void msleep(unsigned int msecs)
{
}

static unsigned long msleep_interruptible(unsigned int msecs)
{
	return msecs + 1;
}

#define ndelay(x)
#define udelay(x)

#endif /* _DELAY_H_ */
