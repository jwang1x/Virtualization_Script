#ifndef __LINUX_CPUMASK_H
#define __LINUX_CPUMASK_H

#endif /* __LINUX_CPUMASK_H */
