#ifndef _LINUX_WAIT_H
#define _LINUX_WAIT_H

struct __wait_queue_head {
	bool initialized;
};
typedef struct __wait_queue_head wait_queue_head_t;

static inline void init_waitqueue_head(wait_queue_head_t *q)
{
	q->initialized = true;
}

static inline void wake_up(wait_queue_head_t *wq)
{
	mock().actualCall(__func__)
		.withParameter("wq", wq);
}

/**
 * tdd_set_wait_cb - Set a callback for wait_event_timeout and
 * wait_event_interruptible_timeout.
 *
 * Once set, the wait_event_timeout and wait_event_timeout_interruptible
 * macros will all the provided cb function with the provided cb_arg pointer.
 * This can be used to cause a modification to the event structure to simulate
 * a successful event.
 */
static inline void tdd_set_wait_cb(void (*cb)(void *), void *cb_arg)
{
	mock().setData("wait_event_cb", (void (*)())cb);
	mock().setData("wait_event_cb_arg", cb_arg);

}

#define wait_event_timeout(wq, condition, timeout)			\
({									\
	if (mock().hasData("wait_event_cb") &&				\
	    mock().hasData("wait_event_cb_arg")) {			\
		void (*cb)(void *);					\
		void *cb_arg;						\
									\
		cb = (void (*)(void *))mock().getData("wait_event_cb")	\
			.getFunctionPointerValue();			\
		cb_arg = mock().getData("wait_event_cb_arg")		\
			.getPointerValue();				\
									\
		cb(cb_arg);						\
	}								\
									\
	mock().actualCall("wait_event_timeout")				\
		.withParameter("wq", &wq)				\
		.withParameter("condition", # condition)		\
		.withParameter("timeout", timeout);			\
									\
	mock().returnLongIntValueOrDefault(0);				\
})

#define wait_event_interruptible_timeout(wq, condition, timeout)	\
({									\
	if (mock().hasData("wait_event_cb") &&				\
	    mock().hasData("wait_event_cb_arg")) {			\
		void (*cb)(void *);					\
		void *cb_arg;						\
									\
		cb = (void (*)(void *))mock().getData("wait_event_cb")	\
			.getFunctionPointerValue();			\
		cb_arg = mock().getData("wait_event_cb_arg")		\
			.getPointerValue();				\
									\
		cb(cb_arg);						\
	}								\
									\
	mock().actualCall("wait_event_interruptible_timeout")		\
		.withParameter("wq", &wq)				\
		.withParameter("condition", # condition)		\
		.withParameter("timeout", timeout);			\
									\
	mock().returnLongIntValueOrDefault(0);				\
})

#define DECLARE_WAIT_QUEUE_HEAD(name) \
	wait_queue_head_t name;

#endif /* _LINUX_WAIT_H */
