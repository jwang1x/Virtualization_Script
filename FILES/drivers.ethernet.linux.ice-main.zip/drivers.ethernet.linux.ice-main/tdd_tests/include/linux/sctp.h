#ifndef __LINUX_SCTP_H__
#define __LINUX_SCTP_H__

/* Section 3.1.  SCTP Common Header Format */
struct sctphdr {
	__be16 source;
	__be16 dest;
	__be32 vtag;
	__le32 checksum;
};
#endif /* __LINUX_SCTP_H__ */
