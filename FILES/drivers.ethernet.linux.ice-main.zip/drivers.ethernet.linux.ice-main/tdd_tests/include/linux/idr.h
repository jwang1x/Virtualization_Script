#ifndef __IDR_H__
#define __IDR_H__

#include <linux/types.h>
#include <linux/bitops.h>

#define __rcu

/*
 * Using 6 bits at each layer allows us to allocate 7 layers out of each page.
 * 8 bits only gave us 3 layers out of every pair of pages, which is less
 * efficient except for trees with a largest element between 192-255 inclusive.
 */
#define IDR_BITS 6
#define IDR_SIZE (1 << IDR_BITS)
#define IDR_MASK ((1 << IDR_BITS)-1)

struct idr_layer {
	int			prefix;	/* the ID prefix of this idr_layer */
	int			layer;	/* distance from leaf */
	struct idr_layer __rcu	*ary[1<<IDR_BITS];
	int			count;	/* When zero, we can release it */
	union {
		/* A zero bit means "space here" */
		DECLARE_BITMAP(bitmap, IDR_SIZE);
		struct rcu_head		rcu_head;
	};
};

struct idr {
	struct idr_layer __rcu	*hint;	/* the last layer allocated from */
	struct idr_layer __rcu	*top;
	int			layers;	/* only valid w/o concurrent changes */
	int			cur;	/* current pos for cyclic allocation */
	spinlock_t		lock;
	int			id_free_cnt;
	struct idr_layer	*id_free;
};

#define IDR_INIT(name)							\
{									\
	.lock			= name.lock,	\
}
#define DEFINE_IDR(name)	struct idr name = IDR_INIT(name)

/*
 * IDA - IDR based id allocator, use when translation from id to
 * pointer isn't necessary.
 *
 * IDA_BITMAP_LONGS is calculated to be one less to accommodate
 * ida_bitmap->nr_busy so that the whole struct fits in 128 bytes.
 */
#define IDA_CHUNK_SIZE		128	/* 128 bytes per chunk */
#define IDA_BITMAP_LONGS	(IDA_CHUNK_SIZE / sizeof(long) - 1)
#define IDA_BITMAP_BITS 	(IDA_BITMAP_LONGS * sizeof(long) * 8)

struct ida_bitmap {
	long			nr_busy;
	unsigned long		bitmap[IDA_BITMAP_LONGS];
};

struct ida {
	struct idr		idr;
	struct ida_bitmap	*free_bitmap;
};

static void ida_destroy(struct ida *ida)
{
	mock().actualCall(__func__);
	return;
}

static int ida_simple_get(struct ida *ida, unsigned int start, unsigned int end,
		   gfp_t gfp_mask)
{
	mock().actualCall(__func__)
		.withParameter("ida", ida)
		.withParameter("start", start)
		.withParameter("end", end);

	return mock().intReturnValue();
}


static void ida_simple_remove(struct ida *ida, unsigned int id)
{
	mock().actualCall(__func__);
	return;
}

#define IDA_INIT(name)		{ .idr = IDR_INIT((name).idr), .free_bitmap = NULL, }
//#define DEFINE_IDA(name)	struct ida name = { 0 }
// use c++ style init instead
#define DEFINE_IDA(name)	struct ida name = { }

#endif
