#ifndef _MM_H_
#define _MM_H_

struct page {
	unsigned long flags;
	u8 data[4096];
};

#define mmiowb()
#define smp_wmb()

#endif /* _MM_H_ */
