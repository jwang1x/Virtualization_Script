#ifndef _LINUX_PM_WAKEUP_H
#define _LINUX_PM_WAKEUP_H

static int device_set_wakeup_enable(struct device *dev, bool enable)
{
	mock().actualCall(__func__);
	return mock().intReturnValue();
}
#endif /* _LINUX_PM_WAKEUP_H */
