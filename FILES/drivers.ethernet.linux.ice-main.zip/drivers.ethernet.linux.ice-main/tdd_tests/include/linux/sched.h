#ifndef _SCHED_H
#define _SCHED_H

static __always_inline bool need_resched(void)
{
	return false;
}

#endif /* _SCHED_H */
