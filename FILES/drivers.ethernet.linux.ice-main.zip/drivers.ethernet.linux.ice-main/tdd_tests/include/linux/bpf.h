#ifndef _LINUX_BPF_H
#define _LINUX_BPF_H

#include <uapi/linux/bpf.h>

struct bpf_prog;

struct bpf_prog_aux {
	atomic_t refcnt;
	u32 used_map_cnt;
	u32 max_ctx_offset;
	u32 stack_depth;
	u32 id;
	u32 func_cnt;
	bool offload_requested;
	struct bpf_prog **func;
	void *jit_data; /* JIT specific data. arch dependent */
	/* struct latch_tree_node ksym_tnode;
	 * struct list_head ksym_lnode;
	 */
	const struct bpf_prog_ops *ops;
	struct bpf_map **used_maps;
	struct bpf_prog *prog;
	struct user_struct *user;
	u64 load_time; /* ns since boottime */
	char name[BPF_OBJ_NAME_LEN];
#ifdef CONFIG_SECURITY
	void *security;
#endif
	struct bpf_prog_offload *offload;
	/* union {
	 *	struct work_struct work;
	 *	struct rcu_head	rcu;
	 * };
	 */
};

#endif /* _LINUX_BPF_H */

