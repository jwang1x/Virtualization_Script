#ifndef _LINUX_ATOMIC_H
#define _LINUX_ATOMIC_H

typedef struct {
	int counter;
} atomic_t;

typedef struct {
	long long counter;
} atomic_long_t;

static inline void atomic_inc(atomic_t *v)
{
	++v->counter;
}

static inline void atomic_dec(atomic_t *v)
{
	--v->counter;
}

static inline int atomic_read(const atomic_t *v)
{
	return v->counter;
}

static inline void atomic_set(atomic_t *v, int set)
{
	v->counter = set;
}

static inline int atomic_inc_return(atomic_t *v)
{
	return ++v->counter;
}

static inline int atomic_dec_if_positive(atomic_t *v)
{
	int dec, c = atomic_read(v);

	do {
		dec = c - 1;
		if (unlikely(dec < 0))
			break;
		atomic_set(v, dec);
	} while (0);

	return dec;
}
#endif /* _LINUX_ATOMIC_H */
