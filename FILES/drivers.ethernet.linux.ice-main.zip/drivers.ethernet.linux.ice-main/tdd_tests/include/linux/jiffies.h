#ifndef _JIFFIES_H
#define _JIFFIES_H

#include <linux/time64.h>

#define HZ 1000

/* The following are taken from the Kernel when HZ=1000. You will need to
 * update these if you want to test with a different HZ value.
 */
#define HZ_TO_MSEC_MUL32	U64_C(0x80000000)
#define HZ_TO_MSEC_SHR32	31
#define HZ_TO_MSEC_NUM		1
#define HZ_TO_MSEC_DEN		1

static unsigned long msecs_to_jiffies(const unsigned int m)
{
	return (m + (MSEC_PER_SEC / HZ) - 1) / (MSEC_PER_SEC / HZ);
}

static unsigned int jiffies_to_usecs(const unsigned long j)
{
#if !(USEC_PER_SEC % HZ)
	return (USEC_PER_SEC / HZ) * j;
#else
# if BITS_PER_LONG == 32
	return (HZ_TO_USEC_MUL32 * j) >> HZ_TO_USEC_SHR32;
# else
	return (j * HZ_TO_USEC_NUM) / HZ_TO_USEC_DEN;
# endif
#endif
}

static unsigned int jiffies_to_msecs(const unsigned long j)
{
#if HZ <= MSEC_PER_SEC && !(MSEC_PER_SEC % HZ)
	return (MSEC_PER_SEC / HZ) * j;
#elif HZ > MSEC_PER_SEC && !(HZ % MSEC_PER_SEC)
	return (j + (HZ / MSEC_PER_SEC) - 1)/(HZ / MSEC_PER_SEC);
#else
# if BITS_PER_LONG == 32
	return (HZ_TO_MSEC_MUL32 * j) >> HZ_TO_MSEC_SHR32;
# else
	return (j * HZ_TO_MSEC_NUM) / HZ_TO_MSEC_DEN;
# endif
#endif
}

#endif
