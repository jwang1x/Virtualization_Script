#ifndef _DEVICE_H_
#define _DEVICE_H_

#include <linux/pm.h>

struct device_attribute {
	struct attribute attr;
	ssize_t (*show)(struct device *dev, struct device_attribute *attr, char *buf);
	ssize_t (*store)(struct device *dev, struct device_attribute *attr,
			 const char *buf, size_t count);
};

#define DEVICE_ATTR(_name, _mode, _show, _store) \
		struct device_attribute dev_attr_##_name = __ATTR(_name, _mode, _show, _store)

#define DEVICE_ATTR_RW(_name) \
		struct device_attribute dev_attr_##_name = __ATTR_RW(_name)

#define DEVICE_ATTR_RO(_name) \
		struct device_attribute dev_attr_##_name = __ATTR_RO(_name)

static inline struct device *kobj_to_dev(struct kobject *kobj)
{
	return container_of(kobj, struct device, kobj);
}

/* these allocation routines use calloc which always
 * zeroes the memory upon allocation, and returns
 * void pointers which is better for our code's consistency
 */
static void *devm_kzalloc(struct device *dev __attribute((__unused__)), size_t size, gfp_t gfp)
{
	void *incoming = calloc(size, sizeof(char));

	//fprintf(stderr, "devm_kzalloc: 0x%p %ld\n", incoming, size);
	return incoming;
}

static void *devm_kcalloc(struct device *dev, size_t n, size_t size, gfp_t gfp)
{
	return calloc(n, size);
}

static void *kcalloc(size_t n, size_t size, gfp_t gfp)
{
	return calloc(n, size);
}

static void *
devm_kmemdup(struct device *dev, const void *src, size_t len, gfp_t gfp)
{
	void *p;

	p = devm_kzalloc(dev, len, gfp);
	if (p)
		memcpy(p, src, len);

	return p;
}

static void devm_kfree(struct device *dev __attribute__((unused)), void *p)
{
	free(p);
}

/**
 * kzalloc - allocate memory. The memory is set to zero.
 * @size: how many bytes of memory are required.
 * @flags: the type of memory to allocate (see kmalloc).
 */
#ifndef MEM_DEBUG
#define kzalloc(size, gfp) calloc(size, sizeof(char))
#else
static void *kzalloc(size_t size, gfp_t flags __attribute__((unused)))
{
	return calloc(size, sizeof(char));
}
#endif

static void *
kmemdup(const void *src, size_t len, gfp_t gfp __attribute__((unused)))
{
	void *p;

	p = calloc(len, sizeof(char));
	if (p)
		memcpy(p, src, len);

	return p;
}

static const char *dev_driver_string(const struct device *dev)
{
	return "DRIVERSTRING";
}

static const char *dev_name(const struct device *dev)
{
	return "DEVNAME";
}

static inline void *dev_get_drvdata(const struct device *dev)
{
	return dev->driver_data;
}

static inline void dev_set_drvdata(struct device *dev, void *data)
{
	dev->driver_data = data;
}

/**
 * enum probe_type - device driver probe type to try
 *	Device drivers may opt in for special handling of their
 *	respective probe routines. This tells the core what to
 *	expect and prefer.
 *
 * @PROBE_DEFAULT_STRATEGY: Used by drivers that work equally well
 *	whether probed synchronously or asynchronously.
 * @PROBE_PREFER_ASYNCHRONOUS: Drivers for "slow" devices which
 *	probing order is not essential for booting the system may
 *	opt into executing their probes asynchronously.
 * @PROBE_FORCE_SYNCHRONOUS: Use this to annotate drivers that need
 *	their probe routines to run synchronously with driver and
 *	device registration (with the exception of -EPROBE_DEFER
 *	handling - re-probing always ends up being done asynchronously).
 *
 * Note that the end goal is to switch the kernel to use asynchronous
 * probing by default, so annotating drivers with
 * %PROBE_PREFER_ASYNCHRONOUS is a temporary measure that allows us
 * to speed up boot process while we are validating the rest of the
 * drivers.
 */
enum probe_type {
	PROBE_DEFAULT_STRATEGY,
	PROBE_PREFER_ASYNCHRONOUS,
	PROBE_FORCE_SYNCHRONOUS,
};

/**
 * struct device_driver - The basic device driver structure
 * @name:	Name of the device driver.
 * @bus:	The bus which the device of this driver belongs to.
 * @owner:	The module owner.
 * @mod_name:	Used for built-in modules.
 * @suppress_bind_attrs: Disables bind/unbind via sysfs.
 * @probe_type:	Type of the probe (synchronous or asynchronous) to use.
 * @of_match_table: The open firmware table.
 * @acpi_match_table: The ACPI match table.
 * @probe:	Called to query the existence of a specific device,
 *		whether this driver can work with it, and bind the driver
 *		to a specific device.
 * @remove:	Called when the device is removed from the system to
 *		unbind a device from this driver.
 * @shutdown:	Called at shut-down time to quiesce the device.
 * @suspend:	Called to put the device to sleep mode. Usually to a
 *		low power state.
 * @resume:	Called to bring a device from sleep mode.
 * @groups:	Default attributes that get created by the driver core
 *		automatically.
 * @pm:		Power management operations of the device which matched
 *		this driver.
 * @p:		Driver core's private data, no one other than the driver
 *		core can touch this.
 *
 * The device driver-model tracks all of the drivers known to the system.
 * The main reason for this tracking is to enable the driver core to match
 * up drivers with new devices. Once drivers are known objects within the
 * system, however, a number of other things become possible. Device drivers
 * can export information and configuration variables that are independent
 * of any specific device.
 */
struct device_driver {
	const char		*name;
	struct bus_type		*bus;

	struct module		*owner;
	const char		*mod_name;	/* used for built-in modules */

	bool suppress_bind_attrs;	/* disables bind/unbind via sysfs */
	enum probe_type probe_type;

	const struct of_device_id	*of_match_table;
	const struct acpi_device_id	*acpi_match_table;

	int (*probe) (struct device *dev);
	int (*remove) (struct device *dev);
	void (*shutdown) (struct device *dev);
//	int (*suspend) (struct device *dev, pm_message_t state);
//	int (*resume) (struct device *dev);
	const struct attribute_group **groups;

	const struct dev_pm_ops *pm;

	struct driver_private *p;
};

/**
 * struct bus_type - The bus type of the device
 *
 * @name:	The name of the bus.
 * @dev_name:	Used for subsystems to enumerate devices like ("foo%u", dev->id).
 * @dev_root:	Default device to use as the parent.
 * @dev_attrs:	Default attributes of the devices on the bus.
 * @bus_groups:	Default attributes of the bus.
 * @dev_groups:	Default attributes of the devices on the bus.
 * @drv_groups: Default attributes of the device drivers on the bus.
 * @match:	Called, perhaps multiple times, whenever a new device or driver
 *		is added for this bus. It should return a positive value if the
 *		given device can be handled by the given driver and zero
 *		otherwise. It may also return error code if determining that
 *		the driver supports the device is not possible. In case of
 *		-EPROBE_DEFER it will queue the device for deferred probing.
 * @uevent:	Called when a device is added, removed, or a few other things
 *		that generate uevents to add the environment variables.
 * @probe:	Called when a new device or driver add to this bus, and callback
 *		the specific driver's probe to initial the matched device.
 * @remove:	Called when a device removed from this bus.
 * @shutdown:	Called at shut-down time to quiesce the device.
 *
 * @online:	Called to put the device back online (after offlining it).
 * @offline:	Called to put the device offline for hot-removal. May fail.
 *
 * @suspend:	Called when a device on this bus wants to go to sleep mode.
 * @resume:	Called to bring a device on this bus out of sleep mode.
 * @pm:		Power management operations of this bus, callback the specific
 *		device driver's pm-ops.
 * @iommu_ops:  IOMMU specific operations for this bus, used to attach IOMMU
 *              driver implementations to a bus and allow the driver to do
 *              bus-specific setup
 * @p:		The private data of the driver core, only the driver core can
 *		touch this.
 * @lock_key:	Lock class key for use by the lock validator
 *
 * A bus is a channel between the processor and one or more devices. For the
 * purposes of the device model, all devices are connected via a bus, even if
 * it is an internal, virtual, "platform" bus. Buses can plug into each other.
 * A USB controller is usually a PCI device, for example. The device model
 * represents the actual connections between buses and the devices they control.
 * A bus is represented by the bus_type structure. It contains the name, the
 * default attributes, the bus' methods, PM operations, and the driver core's
 * private data.
 */
struct bus_type {
	const char		*name;
	const char		*dev_name;
	struct device		*dev_root;
	struct device_attribute	*dev_attrs;	/* use dev_groups instead */
	const struct attribute_group **bus_groups;
	const struct attribute_group **dev_groups;
	const struct attribute_group **drv_groups;

	int (*match)(struct device *dev, struct device_driver *drv);
	int (*uevent)(struct device *dev, struct kobj_uevent_env *env);
	int (*probe)(struct device *dev);
	int (*remove)(struct device *dev);
	void (*shutdown)(struct device *dev);

	int (*online)(struct device *dev);
	int (*offline)(struct device *dev);

	//int (*suspend)(struct device *dev, pm_message_t state);
	//int (*resume)(struct device *dev);

	const struct dev_pm_ops *pm;

	const struct iommu_ops *iommu_ops;

	struct subsys_private *p;
	//struct lock_class_key lock_key;
};

static
struct device *bus_find_device_by_name(struct bus_type *bus, void *data,
				       char *name)
{
	mock().actualCall(__func__);
	return NULL;
}

static int bus_for_each_dev(struct bus_type *bus, struct device *start,
		     void *data, int (*fn)(struct device *, void *))
{
	mock().actualCall(__func__);
	return 0;
}

static int bus_for_each_drv(struct bus_type *bus, struct device_driver *start,
			    void *data, int (*fn)(struct device_driver *,
			    void *))
{
	mock().actualCall(__func__);
	return 0;
}

static int bus_register(struct bus_type *bus)
{
	mock().actualCall(__func__);
	return 0;
}

static void bus_unregister(struct bus_type *bus)
{
	mock().actualCall(__func__);
	return;
}

/* our local little list type for storing devs */
struct devreg {
	LIST_HEAD(devreg_list);
	struct device *dev;
};

/* store a list of dev's that were registered so we can unwind
 * and check them later
 */
static struct devreg *global_devreg_list;

static int device_register(struct device *dev)
{
	mock().actualCall(__func__);
	struct devreg *entry = (struct devreg *)
					calloc(1, sizeof(struct devreg));
	entry->dev = dev;
	list_add(&entry->devreg_list, &global_devreg_list->devreg_list);
	return 0;
}

static void device_unregister(struct device *dev)
{
	mock().actualCall(__func__);
	return;
}

static void put_device(struct device *dev)
{
	mock().actualCall(__func__);
	return;
}

static int dev_set_promiscuity(struct net_device *dev, int inc)
{
	mock().actualCall(__func__);
	return 0;
}

#define dev_set_name(dev, name, ...)

int devm_add_action(struct device *dev, void (*action)(void *), void *data);

static void device_del(struct device *dev)
{
	mock().actualCall(__func__);
}

static inline int ida_alloc(struct ida *ida, gfp_t gfp)
{
	mock().actualCall(__func__);
	return 1;
}

static inline void device_lock(struct device *dev)
{
	mock().actualCall(__func__);
}

static inline void device_unlock(struct device *dev)
{
	mock().actualCall(__func__);
}

#endif /* _DEVICE_H_ */
