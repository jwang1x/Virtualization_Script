#ifndef _LINUX_ETHERDEVICE_H
#define _LINUX_ETHERDEVICE_H

#include <linux/netdevice.h>

#define ETH_ALEN 6
#define VLAN_HLEN 4

static void eth_broadcast_addr(u8 *addr)
{
	memset(addr, 0xff, ETH_ALEN);
}

static void eth_zero_addr(u8 *addr)
{
	memset(addr, 0x00, ETH_ALEN);
}

static void eth_random_addr(u8 *addr)
{
	memset(addr, 0x06, ETH_ALEN);
}

static void eth_hw_addr_random(struct net_device *dev)
{
	eth_random_addr(dev->dev_addr);
}

static void ether_addr_copy(u8 *dst, const u8 *src)
{
	u16 *a = (u16 *)dst;
	const u16 *b = (const u16 *)src;

	a[0] = b[0];
	a[1] = b[1];
	a[2] = b[2];
}

static void eth_hw_addr_set(struct net_device *dev, const void *addr)
{
	ether_addr_copy(dev->dev_addr, (const u8*)addr);
}

static bool ether_addr_equal(const u8 *addr1, const u8 *addr2)
{
	const u16 *a = (const u16 *)addr1;
	const u16 *b = (const u16 *)addr2;

	return ((a[0] ^ b[0]) | (a[1] ^ b[1]) | (a[2] ^ b[2])) == 0;
}

static bool is_multicast_ether_addr(const u8 *addr)
{
	u16 a = *(const u16 *)addr;
	return 0x01 & a;
}

static bool is_unicast_ether_addr(const u8 *addr)
{
	return !is_multicast_ether_addr(addr);
}

static bool is_link_local_ether_addr(const u8 *addr)
{
	static const u8 eth_reserved_addr_base[ETH_ALEN] = { 0x01, 0x80, 0xc2,
							     0x00, 0x00, 0x00 };
	static const u16 *b = (const u16 *)eth_reserved_addr_base;
	static const u16 m = cpu_to_be16(0xfff0);
	u16 *a = (u16 *)addr;

	return ((a[0] ^ b[0]) | (a[1] ^ b[1]) | ((a[2] ^ b[2]) & m)) == 0;
}

static bool is_zero_ether_addr(const u8 *addr)
{
	return (*(const u16 *)(addr + 0) |
		*(const u16 *)(addr + 2) |
		*(const u16 *)(addr + 4)) == 0;
}

static bool is_valid_ether_addr(const u8 *addr)
{
	/* FF:FF:FF:FF:FF:FF is a multicast address so we don't need to
	 * explicitly check for it here. */
	return !is_multicast_ether_addr(addr) && !is_zero_ether_addr(addr);
}

static
struct net_device *alloc_etherdev_mqs(int sizeof_priv, unsigned int txqs,
				      unsigned int rxqs)
{
	struct net_device *newnetdev;
	int alloc_size;

	alloc_size = sizeof(struct net_device);
	if (sizeof_priv) {
		/* ensure 32-byte alignment of private area */
		alloc_size = ALIGN(alloc_size, NETDEV_ALIGN);
		alloc_size += sizeof_priv;
	}
	/* ensure 32-byte alignment of whole construct */
	alloc_size += NETDEV_ALIGN - 1;

	newnetdev = (struct net_device *)calloc(1, alloc_size);

	newnetdev->dev_addr = (unsigned char *)calloc(1, ETH_ALEN);

	newnetdev->addr_len = ETH_ALEN;

	return newnetdev;
}

#define alloc_etherdev(sizeof_priv) alloc_etherdev_mq(sizeof_priv, 1)
#define alloc_etherdev_mq(sizeof_priv, count) alloc_etherdev_mqs(sizeof_priv, count, count)
#endif
