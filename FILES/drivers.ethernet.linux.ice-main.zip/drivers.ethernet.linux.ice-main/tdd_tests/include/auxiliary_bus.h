/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2019-2020 Intel Corporation
 *
 * Please see Documentation/driver-api/auxiliary_bus.rst for more information.
 */

#ifndef _AUXILIARY_BUS_H_
#define _AUXILIARY_BUS_H_

#include <linux/device.h>
#include <linux/slab.h>

#define AUXILIARY_NAME_SIZE 32
#define AUXILIARY_MODULE_PREFIX "auxiliary:"

struct auxiliary_device_id {
	char name[AUXILIARY_NAME_SIZE];
	u64 driver_data;
};

struct auxiliary_device {
	struct device dev;
	const char *name;
	u32 id;
};

struct auxiliary_driver {
	int (*probe)(struct auxiliary_device *auxdev, const struct auxiliary_device_id *id);
	int (*remove)(struct auxiliary_device *auxdev);
	void (*shutdown)(struct auxiliary_device *auxdev);
	int (*suspend)(struct auxiliary_device *auxdev, int state);
	int (*resume)(struct auxiliary_device *auxdev);
	struct device_driver driver;
	const struct auxiliary_device_id *id_table;
};

static inline struct auxiliary_device *to_auxiliary_dev(struct device *dev)
{
	return container_of(dev, struct auxiliary_device, dev);
}

static inline struct auxiliary_driver *to_auxiliary_drv(struct device_driver *drv)
{
	return container_of(drv, struct auxiliary_driver, driver);
}

/* Helper macro to ensure unique driver name for the auxdrv->driver.name */
#define AUX_DRV_NAME(adn) KBUILD_MODNAME "_" adn

int auxiliary_device_initialize(struct auxiliary_device *auxdev);
int __auxiliary_device_add(struct auxiliary_device *auxdev, const char *modname);
#define auxiliary_device_add(auxdev) __auxiliary_device_add(auxdev, KBUILD_MODNAME)

static inline void auxiliary_device_uninitialize(struct auxiliary_device *auxdev)
{
	return;
}

static inline void auxiliary_device_delete(struct auxiliary_device *auxdev)
{
	return;
}

int __auxiliary_driver_register(struct auxiliary_driver *auxdrv, struct module *owner);
#define auxiliary_driver_register(auxdrv) __auxiliary_driver_register(auxdrv, THIS_MODULE)

static inline void auxiliary_driver_unregister(struct auxiliary_driver *auxdrv)
{
	//driver_unregister(&auxdrv->driver);
}

/**
 * module_auxiliary_driver() - Helper macro for registering an auxiliary driver
 * @__auxiliary_driver: auxiliary driver struct
 *
 * Helper macro for auxiliary drivers which do not do anything special in
 * module init/exit. This eliminates a lot of boilerplate. Each module may only
 * use this macro once, and calling it replaces module_init() and module_exit()
 */
#define module_auxiliary_driver(__auxiliary_driver) \
	module_driver(__auxiliary_driver, auxiliary_driver_register, auxiliary_driver_unregister)

#endif /* _AUXILIARY_BUS_H_ */
