#ifndef _ICE_LOCAL_COMMON_H_
#define _ICE_LOCAL_COMMON_H_

extern const struct ice_ctx_ele ice_tlan_ctx_info[];

#endif /* _ICE_LOCAL_COMMON_H_ */
