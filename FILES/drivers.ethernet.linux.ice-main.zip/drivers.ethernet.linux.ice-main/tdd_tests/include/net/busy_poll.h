/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * net busy poll support
 * Copyright(c) 2013 Intel Corporation.
 *
 * Author: Eliezer Tamir
 *
 * Contact Information:
 * e1000-devel Mailing List <e1000-devel@lists.sourceforge.net>
 */

#ifndef _LINUX_NET_BUSY_POLL_H
#define _LINUX_NET_BUSY_POLL_H

/*		0 - Reserved to indicate value not set
 *     1..NR_CPUS - Reserved for sender_cpu
 *  NR_CPUS+1..~0 - Region available for NAPI IDs
 */
/* To avoid multiple def of NR_CPUS (which is also defined kernel_abstract.h */
#define TEMP_NR_CPUS 4096

#define MIN_NAPI_ID ((unsigned int)(TEMP_NR_CPUS + 1))

#endif /* _LINUX_NET_BUSY_POLL_H */
