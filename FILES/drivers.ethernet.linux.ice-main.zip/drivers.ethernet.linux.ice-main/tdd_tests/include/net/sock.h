/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef _SOCK_H
#define _SOCK_H

#include <linux/types.h>

/*
 * @sk_napi_id: id of the last napi context to receive data for sk
 * @sk_ll_usec: usecs to busypoll when there is no data
 * @sk_allocation: allocation mode
 * @sk_priority: %SO_PRIORITY setting
 * @sk_type: socket type (%SOCK_STREAM, etc)
 * @sk_protocol: which protocol this socket belongs in this network family
 */
struct sock {
#ifdef CONFIG_NET_RX_BUSY_POLL
	unsigned int		sk_ll_usec;
	/* ===== mostly read cache line ===== */
	unsigned int		sk_napi_id;
#endif
	/* ===== cache line for TX ===== */
	__u32			sk_priority;
	__u32			sk_mark;

	u16			sk_type;
	u16			sk_protocol;
};

#endif	/* _SOCK_H */
