/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __NET_TC_GACT_H
#define __NET_TC_GACT_H

#include <net/act_api.h>
#include <linux/tc_act/tc_gact.h>

struct tcf_gact {
	struct tc_action	common;
#ifdef CONFIG_GACT_PROB
	u16			tcfg_ptype;
	u16			tcfg_pval;
	int			tcfg_paction;
	atomic_t		packets;
#endif
};

#define to_gact(a) ((struct tcf_gact *)a)

/* There is a special kind of actions called "extended actions",
 * which need a value parameter. These have a local opcode located in
 * the highest nibble, starting from 1. The rest of the bits
 * are used to carry the value. These two parts together make
 * a combined opcode.
 */

#define __TC_ACT_EXT_SHIFT 28
#define __TC_ACT_EXT(local) ((local) << __TC_ACT_EXT_SHIFT)
#define TC_ACT_EXT_VAL_MASK ((1 << __TC_ACT_EXT_SHIFT) - 1)
#define TC_ACT_EXT_CMP(combined, opcode) \
	(((combined) & (~TC_ACT_EXT_VAL_MASK)) == opcode)

static inline bool __is_tcf_gact_act(const struct tc_action *a, int act,
				     bool is_ext)
{
	struct tcf_gact *gact;

	if (a->ops && a->ops->type != TCA_ACT_GACT)
		return false;

	gact = to_gact(a);
	if ((!is_ext && gact->tcf_action == act) ||
	    (is_ext && TC_ACT_EXT_CMP(gact->tcf_action, act)))
		return true;
	return false;
}

static inline bool is_tcf_gact_ok(const struct tc_action *a)
{
	return __is_tcf_gact_act(a, TC_ACT_OK, false);
}

static inline bool is_tcf_gact_shot(const struct tc_action *a)
{
	return __is_tcf_gact_act(a, TC_ACT_SHOT, false);
}

#endif /* __NET_TC_GACT_H */
