#ifndef __NET_NET_NAMESPACE_H
#define __NET_NET_NAMESPACE_H

struct net {
	bool initialized;
};

extern struct net init_net;

typedef struct {
#ifdef CONFIG_NET_NS
	struct net *net;
#endif
} possible_net_t;

#endif /* __NET_NET_NAMESPACE_H */
