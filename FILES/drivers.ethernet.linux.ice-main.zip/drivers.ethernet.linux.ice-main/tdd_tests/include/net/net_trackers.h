/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __NET_NET_TRACKERS_H
#define __NET_NET_TRACKERS_H
#include <linux/ref_tracker.h>

#ifndef NO_TDD_TEST_FRAMEWORK
/* We always enable ref_trackers for TDD, so these typedefs aren't wrapped in
 * CONFIG_NET_DEV_REFCNT_TRACKER and CONFIG_NET_NS_REFCNT_TRACKER.
 */
#endif

typedef struct ref_tracker *netdevice_tracker;
typedef struct ref_tracker *netns_tracker;

#endif /* __NET_NET_TRACKERS_H */
