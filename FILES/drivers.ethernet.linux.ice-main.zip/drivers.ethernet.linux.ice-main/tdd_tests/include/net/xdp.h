#ifndef _XDP_H_
#define _XDP_H_
#include <linux/netdevice.h>

#define REG_STATE_NEW           0x0
#define REG_STATE_REGISTERED    0x1
#define REG_STATE_UNREGISTERED  0x2
#define REG_STATE_UNUSED        0x3

enum xdp_mem_type {
	MEM_TYPE_PAGE_SHARED = 0, /* Split-page refcnt based model */
	MEM_TYPE_PAGE_ORDER0,     /* Orig XDP full page model */
	MEM_TYPE_PAGE_POOL,
	MEM_TYPE_ZERO_COPY,
	MEM_TYPE_XSK_BUFF_POOL,
	MEM_TYPE_MAX,
};

/* Drivers not supporting XDP metadata can use this helper, which
 * rejects any room expansion for metadata as a result.
 */
static __always_inline void
xdp_set_data_meta_invalid(struct xdp_buff *xdp)
{
}
struct zero_copy_allocator {
	void (*free)(struct zero_copy_allocator *zca, unsigned long handle);
};

/* XDP flags for ndo_xdp_xmit */
#define XDP_XMIT_FLUSH		(1U << 0)	/* doorbell signal consumer */
#define XDP_XMIT_FLAGS_MASK	XDP_XMIT_FLUSH

struct xdp_mem_info {
	u32 type; /* enum xdp_mem_type, but known size type */
	u32 id;
};

struct xdp_rxq_info {
	struct net_device *dev;
	u32 queue_index;
	u32 reg_state;
	struct xdp_mem_info mem;
};

struct xdp_buff {
	void *data;
	void *data_end;
	void *data_meta;
	void *data_hard_start;
	unsigned long handle;
	struct xdp_rxq_info *rxq;
};

static inline int xdp_rxq_info_reg_mem_model(struct xdp_rxq_info *xdp_rxq,
					     enum xdp_mem_type type,
					     void *allocator)
{
	xdp_rxq->mem.type = type;
	return 0;
}

static inline void xdp_rxq_info_unreg(struct xdp_rxq_info *xdp_rxq)
{
	xdp_rxq->reg_state = REG_STATE_UNREGISTERED;
}

static inline bool xdp_rxq_info_is_reg(struct xdp_rxq_info *xdp_rxq)
{
	return xdp_rxq->reg_state == REG_STATE_REGISTERED;
}

static inline int xdp_rxq_info_reg(struct xdp_rxq_info *xdp_rxq,
				   struct net_device *dev, u32 queue_index,
				   unsigned int napi_id)
{
	xdp_rxq->reg_state = REG_STATE_REGISTERED;
	return 0;
}

#endif /* _XDP_H_ */
