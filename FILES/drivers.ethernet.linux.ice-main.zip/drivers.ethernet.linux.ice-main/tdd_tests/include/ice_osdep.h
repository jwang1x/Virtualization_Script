#ifndef _ICE_TEST_OSDEP_H
#define _ICE_TEST_OSDEP_H

#include <sparse/bitmap.h>
#include "linux_list.h"
#include <kernel_abstract.h>
#include <linux/dma-mapping.h>
#include "ice_alloc.h"

struct ice_hw;
struct device *ice_hw_to_dev(struct ice_hw *hw);

static u32 readl(void *addr)
{
	return *(u32 *)addr;
}

static u64 readq(void *addr)
{
	return *(u64 *)addr;
}

static void writel(u32 val, void *addr)
{
	*(u32 *)addr = val;
}

static void writel_relaxed(u32 val, void *addr)
{
	*(u32 *)addr = val;
}

static void writeq(u64 val, void *addr)
{
	*(u64 *)addr = val;
}

static void *ice_malloc(struct ice_hw *hw, size_t size)
{
	return calloc(size, sizeof(char));
}

static void *ice_calloc(struct ice_hw *hw, int cnt, size_t size)
{
	return calloc(size, cnt);
}

static void ice_free(struct ice_hw *hw, void *ptr)
{
	free(ptr);
}

static void *ice_memset(void *addr, int c, size_t n, ice_memset_type direction)
{
	return memset(addr, c, n);
}

static void *ice_memcpy(void *d, const void *s, size_t n, ice_memcpy_type dir)
{
	return memcpy(d, s, n);
}

static void *ice_memdup(struct ice_hw *hw, const void *s, size_t n,
			ice_memcpy_type dir)
{
	void *p;

	p = ice_malloc(hw, n);
	if (p)
		memcpy(p, s, n);
	return p;
}

#define wr32(a, reg, value)	writel((value), ((a)->hw_addr + (reg)))
#define rd32(a, reg)		readl((a)->hw_addr + (reg))
#define wr64(a, reg, value)	writeq((value), ((a)->hw_addr + (reg)))
#define rd64(a, reg)		readq((a)->hw_addr + (reg))

struct ice_dma_mem {
	void *va;
	dma_addr_t pa;
	size_t size;
};

struct ice_lock {
	int *lock;
};

#ifdef __cplusplus
extern "C" {
#endif
static void ice_init_lock(struct ice_lock *lock)
{
	if (lock)
		fprintf(stderr, "lock %p already initialized\n", lock);
	lock->lock = (int *)calloc(1, sizeof(int));
	if (!lock->lock) {
		fprintf(stderr, "oh god!\n");
		return;
	}
	*lock->lock = 0;
}

static void ice_acquire_lock(struct ice_lock *lock)
{
	if (*lock->lock)
		fprintf(stderr, "lock %p already held\n", lock);
	*lock->lock = 1;
}

static void ice_release_lock(struct ice_lock *lock)
{
	if (!*lock->lock)
		fprintf(stderr, "lock %p already released\n", lock);
	*lock->lock = 0;
}

static void ice_destroy_lock(struct ice_lock *lock)
{
	if (lock->lock) {
		free(lock->lock);
		lock->lock = NULL;
	}
}
#ifdef __cplusplus
}
#endif

#define ice_flush(a)    readl((a)->hw_addr + GLGEN_STAT)

#define ice_print_errno(func, obj, code, fmt, args...)		\
	func(obj, fmt ", error: %ld\n", ##args, (long)code)
#define ice_err_arg(err) ((long)err)
#define ice_err_format() "%ld"
#define ice_dev_err_errno(dev, code, fmt, args...)		\
	ice_print_errno(dev_err, dev, code, fmt, ##args)
#define ice_dev_warn_errno(dev, code, fmt, args...)		\
	ice_print_errno(dev_warn, dev, code, fmt, ##args)
#define ice_dev_info_errno(dev, code, fmt, args...)		\
	ice_print_errno(dev_info, dev, code, fmt, ##args)
#define ice_dev_dbg_errno(dev, code, fmt, args...)		\
	ice_print_errno(dev_dbg, dev, code, fmt, ##args)

/* This printf is a trick to consume all the args to prevent an unused variable
 * warning
 */
#define ice_debug(hw, level, str, args...) \
	do { (void)hw; printf("", ##args); } while (0)
#define ice_debug_array(_hw, _mask, _rowsize, _groupsize, _buf, _length) do { } while (0)
#define ice_info(hw, str, args...) fprintf(stderr, (str), ##args)
#define ice_warn(hw, str, args...) fprintf(stderr, (str), ##args)

#define CPU_TO_LE16(a) htole16(a)
#define CPU_TO_LE32(a) htole32(a)
#define CPU_TO_LE64(a) htole64(a)
#define LE16_TO_CPU(a) le16toh(a)
#define LE32_TO_CPU(a) le32toh(a)
#define LE64_TO_CPU(a) le64toh(a)
#define CPU_TO_BE16(a) htobe16(a)
#define CPU_TO_BE32(a) htobe32(a)
#define CPU_TO_BE64(a) htobe64(a)
#define BE16_TO_CPU(a) be16toh(a)
#define BE32_TO_CPU(a) be32toh(a)
#define BE64_TO_CPU(a) be64toh(a)

#define cpu_to_le16(a) htole16(a)
#define cpu_to_le32(a) htole32(a)
#define cpu_to_le64(a) htole64(a)
#define le16_to_cpu(a) le16toh(a)
#define le32_to_cpu(a) le32toh(a)
#define le64_to_cpu(a) le64toh(a)
#define cpu_to_be16(a) htobe16(a)
#define cpu_to_be32(a) htobe32(a)
#define cpu_to_be64(a) htobe64(a)
#define be16_to_cpu(a) be16toh(a)
#define be32_to_cpu(a) be32toh(a)
#define be64_to_cpu(a) be64toh(a)
#define IEEE_8021QAZ_MAX_TCS    8
#endif
