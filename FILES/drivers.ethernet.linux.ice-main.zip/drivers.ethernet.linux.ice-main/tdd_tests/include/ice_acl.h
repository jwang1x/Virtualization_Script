#ifndef __ICE_ACL_LOCAL_H
#define __ICE_ACL_LOCAL_H

#include "../src/SHARED/ice_acl.h"

#endif
