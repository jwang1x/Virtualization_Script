#ifndef _UAPI_IPV6_H
#define _UAPI_IPV6_H

/*
 *	IPv6 address structure
 */
#include "kernel_abstract.h"
#include <linux/in6.h>

struct ipv6hdr {
#if defined(__LITTLE_ENDIAN_BITFIELD)
	__u8			priority:4,
				version:4;
#elif defined(__BIG_ENDIAN_BITFIELD)
	__u8			version:4,
				priority:4;
#else
#error	"Please fix <asm/byteorder.h>"
#endif
	__u8			flow_lbl[3];

	__be16			payload_len;
	__u8			nexthdr;
	__u8			hop_limit;

	struct	in6_addr	saddr;
	struct	in6_addr	daddr;
};

#endif /* _UAPI_IPV6_H */
