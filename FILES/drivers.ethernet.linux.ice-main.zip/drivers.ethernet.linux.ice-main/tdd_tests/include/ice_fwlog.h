#ifndef _ICE_FWLOG_H_
#define _ICE_FWLOG_H_

#endif /* _ICE_FWLOG_H_ */
