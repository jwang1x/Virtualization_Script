#ifndef __ICE_FDIR_LOCAL_H
#define __ICE_FDIR_LOCAL_H

#include "../src/SHARED/ice_fdir.h"

#endif
