#ifndef __ICE_SWITCH_LOCAL_H
#define __ICE_SWITCH_LOCAL_H

#include "../src/SHARED/ice_switch.h"

#endif
