#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_txrx {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "net/xdp.h"
#include <linux/device.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <linux/pkt_sched.h>
#include <linux/compiler.h>
#include "linux/netdevice.h"
#include <linux/workqueue.h>
#include <linux/dim.h>

#include "ice_status.h"
#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_net_core.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_dcb_nl.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fdir.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_fsub.cpp"
#include "CORE_MOCKS/stdmock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"

#include "../src/CORE/ice_txrx_lib.c"
#include "../src/CORE/ice_txrx.c"
}
////////////////////////////////////////
using namespace ns_txrx;

/* this initializes a list to keep track of received
 * skbs
 */
struct rx_list_skb {
	LIST_HEAD(rx_list);
	struct sk_buff *skb;
};

struct rx_list_skb *global_ice_rx_list;

static
gro_result_t mock_napi_gro_receive(struct napi_struct *napi, struct sk_buff *skb)
{
	mock().actualCall("napi_gro_receive")
		.withParameter("skb", skb);

	struct rx_list_skb *entry = new rx_list_skb();

	/* this is the way that we track what skb's are received
	 * during the callchain in the tests, so we can check
	 * them after the fact
	 */
	entry->skb = skb;
	list_add(&entry->rx_list, &global_ice_rx_list->rx_list);
	return GRO_NORMAL;
}

TEST_GROUP(ice_structs)
{
	/* this groups is for a really simple set of tests that just makes
	 * sure the work we did for cache line alignment isn't hosed
	 */
	void setup(void)
	{
	}

	void teardown(void)
	{
	}
};

TEST(ice_structs, ice_test_tests)
{
	DECLARE_BITMAP(test_check_64bits, 64);
	DECLARE_BITMAP(test_check_128bits, 128);

	/* lets hope our size of long is 64 bits */
	CHECK_EQUAL(64, BITS_IN_LONG);
	/* check the intermediate macro */
	CHECK_EQUAL(1, LONGS(64));
	CHECK_EQUAL(2, LONGS(128));
	CHECK_EQUAL(4, LONGS(256));

	/* we expect that we'll have 64 bits of storage */
	CHECK_EQUAL(sizeof(u64), ARRAY_SIZE(test_check_64bits) * sizeof(unsigned long));

	/* we expect that we'll have 128 bits of storage */
	CHECK_EQUAL(sizeof(u64)*2, ARRAY_SIZE(test_check_128bits) * sizeof(unsigned long));
}

TEST(ice_structs, ice_check_ring_offsets)
{
	/* expect the second cache line to start with ...*/
	CHECK_EQUAL(64, offsetof(ice_ring, q_index));

	/* expect the third cache line to start with rcu
	 * and subtract the size of the empty struct called
	 * u64_stats_sync that c++ makes 8 bytes long
	 */
#define EMPTY_SIZE 8
#ifndef SWITCH_MODE
	CHECK_EQUAL(136, offsetof(ice_ring, rcu) - EMPTY_SIZE);
#else
	/* switch mode struct has better alignment of this line */
	CHECK_EQUAL(128, offsetof(ice_ring, rcu) - EMPTY_SIZE);
#endif
};

#ifdef FDIR_SUPPORT
TEST_GROUP(ice_fdir)
{
	struct net_device *netdev; /* not used... but need to allocate */
	struct ice_vsi *vsi;
	u32 real_tx_tail = 0;
	u32 real_rx_tail = 0;

	void setup(void)
	{
		struct ice_ring *tx_ring, *rx_ring;
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);

		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->alloc_txq = 1;
		vsi->alloc_rxq = 1;
		vsi->num_txq = 1;
		vsi->num_rxq = 1;
		vsi->tx_rings = (struct ice_ring **)calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
		vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->rx_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		vsi->rx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->netdev = netdev;

		tx_ring = vsi->tx_rings[0];
		tx_ring->q_index = 0;
		tx_ring->reg_idx = 10;
		tx_ring->size = 0;
		tx_ring->count = 10;
		tx_ring->desc = (struct ice_tx_desc *)calloc(tx_ring->count+2, sizeof(struct ice_tx_desc));
		tx_ring->tx_buf = (struct ice_tx_buf *)calloc(tx_ring->count+2, sizeof(struct ice_tx_buf));

		tx_ring->tail = (u8 *)&real_tx_tail;
		writel(0, tx_ring->tail);

		rx_ring = vsi->rx_rings[0];
		rx_ring->q_index = 0;
		rx_ring->reg_idx = 10;
		rx_ring->size = 0;
		rx_ring->count = 10;
		rx_ring->desc = (union ice_32b_rx_flex_desc *)calloc(rx_ring->count,
								     sizeof(union ice_32b_rx_flex_desc));
		rx_ring->rx_buf = (struct ice_rx_buf *)calloc(rx_ring->count, sizeof(struct ice_rx_buf));

		rx_ring->tail = (u8 *)&real_rx_tail;
		writel(0, rx_ring->tail);

		/* needed ???
		ice_alloc_rx_bufs(ring, ICE_DESC_UNUSED(ring));
		*/
	}

	void teardown(void)
	{
		free_netdev(netdev);
		free(vsi->rx_rings[0]->desc);
		free(vsi->rx_rings[0]->tx_buf);
		free(vsi->rx_rings[0]);
		free(vsi->rx_rings);
		free(vsi->tx_rings[0]->desc);
		free(vsi->tx_rings[0]->tx_buf);
		free(vsi->tx_rings[0]);
		free(vsi->tx_rings);
		free(vsi);
	}
};

TEST(ice_fdir, fdir_prgm_filter_success)
{
	/* Programming a filter adds 2 descriptors to the tx ring - an fdir descriptor
	 * and a data descriptor. Leaving the data in the ring to be cleaned later.
	 */
	struct ice_fltr_desc desc;
	struct ice_ring *tx_ring;
	int ret;
	u8 *pkt;

	pkt = (u8 *)malloc(ICE_FDIR_MAX_RAW_PKT_SIZE);

	tx_ring = vsi->tx_rings[0];
	tx_ring->next_to_use = 0;

	ret = ice_prgm_fdir_fltr(vsi, &desc, pkt);

	CHECK_EQUAL(0, ret); /* 0 ==> success */
	CHECK_EQUAL(2, tx_ring->next_to_use); /* 2 new items on ring */

	free(pkt);
}

TEST(ice_fdir, fdir_prgm_filter_wrap)
{
	/* testing wrapping in ice_prgm_fdir_fltr()... it's not as simple as
	 * it appears.
	 */
	struct ice_fltr_desc zero_desc;
	struct ice_fltr_desc *desc_arr;
	struct ice_fltr_desc desc;
	struct ice_ring *tx_ring;
	int ret;
	u8 *pkt;

	pkt = (u8 *)malloc(ICE_FDIR_MAX_RAW_PKT_SIZE);

	memset(&zero_desc, 0, sizeof(zero_desc));

	tx_ring = vsi->tx_rings[0];
	tx_ring->next_to_use = tx_ring->count - 3;
	tx_ring->next_to_clean = tx_ring->next_to_use;
	desc_arr = (struct ice_fltr_desc *)tx_ring->desc;

	ret = ice_prgm_fdir_fltr(vsi, &desc, pkt);
	if (ret)
		printf("error: ice_prgm_fdir_fltr returned error %d\n", ret);
	ret = ice_prgm_fdir_fltr(vsi, &desc, pkt);
	if (ret)
		printf("error: ice_prgm_fdir_fltr returned error %d\n", ret);
	ret = ice_prgm_fdir_fltr(vsi, &desc, pkt);
	if (ret)
		printf("error: ice_prgm_fdir_fltr returned error %d\n", ret);
	ret = ice_prgm_fdir_fltr(vsi, &desc, pkt);
	if (ret)
		printf("error: ice_prgm_fdir_fltr returned error %d\n", ret);

	/* end of ring should be non-zero */
	CHECK(memcmp(&desc_arr[tx_ring->count-1], &zero_desc, sizeof(zero_desc)));
	/* one past end of ring should still be zero */
	CHECK(!memcmp(&desc_arr[tx_ring->count], &zero_desc, sizeof(zero_desc)));
	/* start of ring should be non-zero */
	CHECK(memcmp(&desc_arr[0], &zero_desc, sizeof(zero_desc)));

	free(pkt);
}
#endif

TEST_GROUP(ice_tx)
{
	struct sk_buff *test_skb;
	struct skb_shared_info *skb_info;
	struct page *tx_page;
	struct napi_struct napi = { };
	struct ice_ring *ring;
	struct ice_netdev_priv *np;
	struct ice_pf *pf;
	u32 tx_tail = 0;
#ifdef TXPP_SUPPORT
	struct ice_ring *tstamp_ring = NULL;
#endif /* TXPP_SUPPORT */

	void setup(void)
	{
		u32 un_frag_len = 4096;
		tx_page = (struct page *)calloc(2, sizeof(*tx_page));

		test_skb = __napi_alloc_skb(&napi, un_frag_len, GFP_KERNEL);
		__skb_put(test_skb, 66);
		skb_reset_mac_header(test_skb);
		test_skb->ip_summed = CHECKSUM_PARTIAL;
		skb_add_rx_frag(test_skb, 0, tx_page, 0, 4096, 4096);
		skb_add_rx_frag(test_skb, 1, tx_page, 4096, 2048, 2048);
		skb_add_rx_frag(test_skb, 2, tx_page, 6144, 2048, 2048);

		ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		ring->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		ring->tail = (u8 *)&tx_tail;
		ring->vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		ring->dev = (struct device *)calloc(1, sizeof(struct device));
		ring->netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		ring->netdev->_tx = (struct netdev_queue *)calloc(1, sizeof(struct netdev_queue));
		np = netdev_priv(ring->netdev);
		np->vsi = ring->vsi;
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		ring->vsi->back = pf;
		bitmap_zero(pf->flags, ICE_PF_FLAGS_NBITS);
		ring->tail = (u8 *)&tx_tail;
		ring->q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
	}

	void teardown(void)
	{
		dev_kfree_skb(test_skb);
		test_skb = NULL;
		free(pf);
		free(tx_page);
		free(ring->q_vector);
		free(ring->vsi->port_info);
		free(ring->vsi);
		free(ring->netdev->_tx);
		free_netdev(ring->netdev);
		free(ring->dev);
		free(ring);
		tx_page = NULL;
		//printf("free data bytes\n");
		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_tx, check_tx_map)
{
	struct ice_tx_buf *first;
	struct ice_tx_offload_params off = { };

	ring->desc = (struct ice_tx_desc *)calloc(8, sizeof(struct ice_tx_desc));
	ring->count = 8;
	ring->tx_buf = (struct ice_tx_buf *)calloc(8, sizeof(struct ice_tx_buf));

	first = &ring->tx_buf[ring->next_to_use];
	first->skb = test_skb;
#ifdef TXPP_SUPPORT
	ice_tx_map(ring, first, tstamp_ring, &off);
#else
	ice_tx_map(ring, first, &off);
#endif /* TXPP_SUPPORT */
#ifndef ADK_SUPPORT
	CHECK_EQUAL(4, ring->next_to_use);
	CHECK_EQUAL(ICE_TX_DESC(ring, 3), first->next_to_watch);
#else
	CHECK_EQUAL(4, ring->next_to_use);
#endif

	//check next to use ring overflow
#ifdef TXPP_SUPPORT
	ice_tx_map(ring, first, tstamp_ring, &off);
#else
	ice_tx_map(ring, first, &off);
#endif /* TXPP_SUPPORT */
	CHECK_EQUAL(0, ring->next_to_use);
#ifndef ADK_SUPPORT
	CHECK_EQUAL(ICE_TX_DESC(ring, 7), first->next_to_watch);
#endif

	//check next to watch overflow
#ifdef TXPP_SUPPORT
	ice_tx_map(ring, first, tstamp_ring, &off);
#else
	ice_tx_map(ring, first, &off);
#endif /* TXPP_SUPPORT */
#ifndef ADK_SUPPORT
	CHECK_EQUAL(4, ring->next_to_use);
	CHECK_EQUAL(ICE_TX_DESC(ring, 3), first->next_to_watch);
#else
	CHECK_EQUAL(4, ring->next_to_use);
#endif

	free(ring->desc);
	free(ring->tx_buf);
}

TEST(ice_tx, test_check_xmit_frame_ring)
{
	ring->tx_buf = (struct ice_tx_buf *)calloc(8, sizeof(struct ice_tx_buf));
	ring->desc = (struct ice_tx_desc *)calloc(8, sizeof(struct ice_tx_desc));

#ifdef ESWITCH_SUPPORT
	ring->vsi->back->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;
	pf->switchdev.is_running = true;
	mock().expectOneCall("ice_eswitch_set_target_vsi")
		.ignoreOtherParameters();
#endif
	mock().expectOneCall("eth_type_vlan")
		.ignoreOtherParameters()
		.andReturnValue(false);
#ifndef NO_DCB_SUPPORT
	set_bit(ICE_FLAG_DCB_ENA, pf->flags);
	mock().expectOneCall("ice_tx_prepare_vlan_flags_dcb");
#endif
	mock().expectNCalls(1,"skb_checksum_help");
	mock().expectOneCall("vlan_get_protocol")
		.withParameter("skb", test_skb).andReturnValue(htons(ETH_P_IP));

#ifdef TXPP_SUPPORT
	ice_xmit_frame_ring(test_skb, ring, tstamp_ring);
#else
	ice_xmit_frame_ring(test_skb, ring);
#endif /* TXPP_SUPPORT */

	free(ring->desc);
	free(ring->tx_buf);
}

#ifndef SWITCH_MODE
TEST(ice_tx, test_check_xmit_frame_ring_wrap)
{
	/* this test is all about making sure that the
	 * data structure for ice_tx_buf is completely
	 * re-initialized by the transmit path
	 */

#define DESCS 64
	ring->tx_buf = (struct ice_tx_buf *)calloc(DESCS, sizeof(struct ice_tx_buf));
	ring->desc = (struct ice_tx_desc *)calloc(DESCS, sizeof(struct ice_tx_desc));
	ring->count = DESCS;

#define DESC_LOOPS 14
#ifdef ESWITCH_SUPPORT
	ring->vsi->back->eswitch_mode = DEVLINK_ESWITCH_MODE_SWITCHDEV;
	pf->switchdev.is_running = true;
	mock().expectNCalls(DESC_LOOPS, "ice_eswitch_set_target_vsi")
		.ignoreOtherParameters();
#endif
	mock().expectNCalls(DESC_LOOPS, "eth_type_vlan")
		.ignoreOtherParameters()
		.andReturnValue(false);
#ifndef NO_DCB_SUPPORT
	mock().expectNCalls(DESC_LOOPS, "ice_tx_prepare_vlan_flags_dcb");
#endif
	mock().expectNCalls(DESC_LOOPS,"skb_checksum_help");
	mock().expectNCalls(DESC_LOOPS, "vlan_get_protocol")
		.withParameter("skb", test_skb).andReturnValue(htons(ETH_P_IP));

	/* make sure to fill the ring, it will stop before filling the ring
	 * because once we don't have enough descriptors to handle a maximum
	 * size send, we pause the qdisc.
	 */
	int i, status;
	for (i = 0; i < 16; i++) {
#ifdef TXPP_SUPPORT
		status = ice_xmit_frame_ring(test_skb, ring, tstamp_ring);
#else
		status = ice_xmit_frame_ring(test_skb, ring);
#endif /* TXPP_SUPPORT */
		if (status != NETDEV_TX_OK)
			break;
	}

	/* check that the ring filled */
	CHECK_EQUAL(NETDEV_TX_BUSY, status);
	CHECK_EQUAL(DESCS - 8, ring->next_to_use);

	free(ring->desc);
	free(ring->tx_buf);
}
#endif /* SWITCH_MODE */

TEST(ice_tx, check_csum_l3_protocol)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off = { };
#ifdef GCO_SUPPORT
	struct ice_ring tx_ring = { };
#endif /* GCO_SUPPORT */

	first = &buffer;
	first->skb = test_skb;
	first->skb->encapsulation = 0;
#ifdef GCO_SUPPORT
	tx_ring.flags |= ICE_TXRX_FLAGS_GCS_ENA;
	off.tx_ring = &tx_ring;
#endif /* GCO_SUPPORT */

	mock().expectOneCall("vlan_get_protocol").withParameter("skb", first->skb).andReturnValue(1);
	CHECK_EQUAL(-1, ice_tx_csum(first, &off));
}

TEST(ice_tx, check_tso_is_ip_summed)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off = { };

	first = &buffer;
	first->skb = test_skb;

	first->skb->ip_summed = CHECKSUM_NONE;
	CHECK_EQUAL(0, ice_tso(first, &off));
}

TEST(ice_tx, check_tso_skb_is_gso)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off = { };

	first = &buffer;
	first->skb = test_skb;

	skb_shinfo(first->skb)->gso_size = 0;
	CHECK_EQUAL(0, ice_tso(first, &off));
}

TEST(ice_tx, check_tso_skb_cow_head)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off = { };

	first = &buffer;
	first->skb = test_skb;
	skb_shinfo(first->skb)->gso_size = 10;

	mock().expectOneCall("skb_cow_head")
		.withParameter("skb", first->skb)
		.withParameter("headroom", 0)
		.ignoreOtherParameters()
		.andReturnValue(-1);

	CHECK_EQUAL(-1, ice_tso(first, &off));
}

TEST(ice_tx, test_ice_xmit_descriptor_count)
{
	int descriptor_count;

	//check the test setup  where we have 3 frag pages in the skb, and one header
	descriptor_count = ice_xmit_desc_count(test_skb);
	CHECK_EQUAL(4, descriptor_count);

	//check the skb with no frag pages
	test_skb->data_len = 0;
	skb_shinfo(test_skb)->nr_frags = 0;
	descriptor_count = ice_xmit_desc_count(test_skb);
	CHECK_EQUAL(1, descriptor_count);
}

TEST(ice_tx, test_ice_chk_linearize)
{
	bool result;

	result = __ice_chk_linearize(test_skb);
	CHECK_FALSE(result);

	/* TODO: add more tests for known bad skbs */
}


#ifdef ADK_SUPPORT
TEST(ice_tx, ice_adk_tstamp)
{
	struct ice_tx_offload_params off = {};
	struct ice_tx_buf first = {};
	struct sk_buff skb = {};
	int result;

	ring->ptp_tx = true;
	ring->ptp_ts_ena = true;
	first.tx_flags = 0;
	ice_adk_tstamp(ring, &skb, &first, &off);
	result = first.tx_flags & ICE_TX_FLAGS_TSYN;
	CHECK_EQUAL(16, result);
}
#endif

TEST_GROUP(ice_tunnel_offload)
{
	struct sk_buff *test_skb;
	struct skb_shared_info *skb_info;
	const int eth_frm_offset = 14 ;
	struct napi_struct napi = { };

	void setup(void)
	{
		u32 len = ICE_MAX_DATA_PER_TXD + 1;

		test_skb = __napi_alloc_skb(&napi, len, GFP_KERNEL);
		__skb_put(test_skb, eth_frm_offset);
		test_skb->ip_summed = CHECKSUM_PARTIAL;
		skb_info = skb_shinfo(test_skb);
	}

	void teardown(void)
	{
		dev_kfree_skb(test_skb);
		test_skb = NULL;

		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_tunnel_offload, test_tx_csum_tunnel_offload_1)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off;
#ifdef GCO_SUPPORT
	struct ice_ring tx_ring = { };
#endif /* GCO_SUPPORT */
	int status;

	first = &buffer;
	first->skb = test_skb;
	first->skb->encapsulation = 1;
	first->skb->protocol = ETH_P_IP;
	first->tx_flags |= ICE_TX_FLAGS_TSO;
#ifdef GCO_SUPPORT
	tx_ring.flags |= ICE_TXRX_FLAGS_GCS_ENA;
	off.tx_ring = &tx_ring;
#endif /* GCO_SUPPORT */

	/* Call tx_csum for tunneled pkt (i.e skb->encapsulation == 1)
	 * Outer header is IP but L4 protocol is not recognizable in skb
	 * Hence the function returns -1
	 */
	mock().expectOneCall("vlan_get_protocol").withParameter("skb", first->skb).andReturnValue(ETH_P_IP);
	status = ice_tx_csum(first, &off);

	CHECK_EQUAL(-1, status);
}

TEST(ice_tunnel_offload, test_tx_csum_tunnel_offload_2)
{
	struct ice_tx_buf *first, buffer = ice_tx_buf();
	struct ice_tx_offload_params off;
#ifdef GCO_SUPPORT
	struct ice_ring tx_ring = { };
#endif /* GCO_SUPPORT */
	int status;
	/* Valid Vxlan Packet
	 * Last 2 bytes of buffer is payload */
	static const u8 eth_frm[] =
	{ 0xDA, 0xDA, 0xDA, 0xDA, 0xDA, 0xDA, 0x55, 0x55,
	  0x55, 0x55, 0x55, 0x55, 0x08, 0x00, 0x45, 0x00,
	  0x00, 0x5C, 0x01, 0x1A, 0x40, 0x00, 0x40, 0x11,
	  0x59, 0x0E, 0x77, 0x77, 0x77, 0x55, 0x77, 0x77,
	  0x77, 0x57, 0x44, 0x44, 0x12, 0xb5, 0x00, 0x48,
	  0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x22, 0x22,
	  0x22, 0x00, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
	  0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x08, 0x00,
	  0x45, 0x00, 0x00, 0x2A, 0x11, 0x11, 0x00, 0x00,
	  0x40, 0x06, 0x99, 0x99, 0x0A, 0x0A, 0x0A, 0x0A,
	  0x0A, 0x0A, 0x0A, 0x14, 0x22, 0x22, 0x33, 0x33,
	  0x12, 0x34, 0x56, 0x78, 0x34, 0x34, 0x34, 0x34,
	  0xEE, 0xEE, 0x99, 0x99, 0x34, 0x34, 0x66, 0x66,
	  0xDA, 0x2A };

	first = &buffer;
	first->skb = test_skb;
	first->skb->encapsulation = 1;
	first->skb->protocol = ETH_P_IP;
	first->tx_flags |= ICE_TX_FLAGS_TSO;

	memcpy(test_skb->head, eth_frm, ARRAY_SIZE(eth_frm));
	test_skb->mac_header = 14;
	test_skb->mac_len = 14;  /* 6 src mac + 6 dst mac + 2-ether tye */
	test_skb->data = test_skb->head + test_skb->mac_len;
	test_skb->network_header = test_skb->mac_len;
	test_skb->transport_header = test_skb->network_header + 20;
	test_skb->inner_mac_header = 14 + 20 + 8 + 8; /* L2+IP+UDP+Vxlan */
	test_skb->inner_network_header = test_skb->inner_mac_header + 14;
	test_skb->inner_transport_header = test_skb->inner_network_header + 20;
	test_skb->tail = ARRAY_SIZE(eth_frm);
	skb_info->gso_type = 0;
	off.cd_tunnel_params = 0;
#ifdef GCO_SUPPORT
	tx_ring.flags |= ICE_TXRX_FLAGS_GCS_ENA;
	off.tx_ring = &tx_ring;
#endif /* GCO_SUPPORT */

	/* Call tx_csum for tunneled pkt (i.e skb->encapsulation == 1)
	 * Pkt format is L2+IP+UDP+VXLAN+MAC+IP+TCP+2B Data
	 */
	mock().expectOneCall("vlan_get_protocol").withParameter("skb", first->skb).andReturnValue(htons(ETH_P_IP));
	status = ice_tx_csum(first, &off);

	/* 1 means success */
	CHECK_EQUAL(1, status);

	/* ICE_TX_FLAGS_IPV4	BIT(5) */
	CHECK_EQUAL(0x20, first->tx_flags & ICE_TX_FLAGS_IPV4);
	/* ICE_TX_FLAGS_TUNNEL	BIT(7) */
	CHECK_EQUAL(0x80, first->tx_flags & ICE_TX_FLAGS_TUNNEL);

	/* Verify Tunneling params field of TX descriptor */
	/* EIPT (bit 0-1) == 01b */
	CHECK_EQUAL(3, off.cd_tunnel_params & ICE_TX_CTX_EIPT_IPV4);
	/* EIPLEN (bit 2-8) == 101b. Outer IP header length in DWords */
	CHECK_EQUAL(0x0014, off.cd_tunnel_params & ICE_TXD_CTX_QW0_EIPLEN_M);
	/* L4TUNT (bit 9-10) == 01b. UDP tunneling */
	CHECK_EQUAL(0x0200, off.cd_tunnel_params & ICE_TXD_CTX_UDP_TUNNELING);
	/* L4TUNLEN (bit 12:18) == 15 words
	 * i.e distance from beginning of outer L4 header to beginning of
	 * inner IP header. 8 (UDP) + 8 (VxLan) + 14 (inner mac)
	 */
	CHECK_EQUAL(0x0F000, off.cd_tunnel_params & ICE_TXD_CTX_QW0_NATLEN_M);
}

#ifdef TXPP_SUPPORT
TEST_GROUP(ice_setup_tstamp_ring)
{
	struct ice_ring tstamp_ring;
	struct device dev;
#define NUM_DESC 64
	const unsigned int dsize = ALIGN(NUM_DESC * sizeof(struct ice_tx_desc), 4096);
	void *desc;

	void setup(void)
	{
		tstamp_ring.dev = &dev;
		desc = calloc(1, dsize);
	}

	void teardown(void)
	{
		free(desc);

		if (tstamp_ring.tstamp_buf) {
			devm_kfree(&dev, tstamp_ring.tstamp_buf);
			tstamp_ring.tstamp_buf = NULL;
		}
	}
};

TEST(ice_setup_tstamp_ring, expects_success)
{
	int ret = -1;

	mock().expectOneCall("dmam_alloc_coherent")
		.ignoreOtherParameters()
		.andReturnValue(desc);

	ret = ice_setup_tstamp_ring(&tstamp_ring);
	CHECK_EQUAL(ret, 0);
}
#endif /* TXPP_SUPPORT */

TEST_GROUP(ice_tx_rings)
{
	void setup(void)
	{

	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_tx_rings, tx_ring_cycle)
{
#ifdef TXPP_SUPPORT
	struct ice_ring *tstamp_ring = NULL;
#endif /* TXPP_SUPPORT */
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	int i = 0;

	ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
	vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
	vsi->netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);

	ring->q_index = i;
	ring->reg_idx = 10;
	ring->vsi = vsi;
	ring->netdev = vsi->netdev;
	ring->dev = (struct device *)calloc(1, sizeof(struct device));
#define NUM_DESC 64
	ring->count = ALIGN(NUM_DESC, ICE_REQ_DESC_MULTIPLE);
	ring->size = 0;
#ifndef NO_DCB_SUPPORT
	ring->dcb_tc = 0;
#endif /* !NO_DCB_SUPPORT */

	unsigned int dsize = ALIGN(NUM_DESC * sizeof(struct ice_tx_desc), 4096);
	void *desc = calloc(1, dsize);

	mock().expectOneCall("dmam_alloc_coherent")
		.withParameter("size", dsize)
		.ignoreOtherParameters()
		.andReturnValue(desc);

	int ret = ice_setup_tx_ring(ring);

	CHECK_EQUAL(ret, 0);
	CHECK_EQUAL(ring->size, dsize);

	mock().checkExpectations();
	mock().clear();

	mock().expectOneCall("dmam_free_coherent")
		.withParameter("size", dsize)
		.ignoreOtherParameters();

#ifdef TXPP_SUPPORT
	ice_free_tx_ring(ring, tstamp_ring);
#else
	ice_free_tx_ring(ring);
#endif /* TXPP_SUPPORT */

	CHECK(ring->tx_buf == NULL);
	CHECK(ring->desc == NULL);

	/* have to free it ourselves because dmam_free_coherent was mocked */
	free(desc);
	free(ring->dev);
	free_netdev(vsi->netdev);
	free(vsi);
	free(ring);
}

TEST_GROUP(ice_rx_rings)
{
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	int i = 0;

	void setup(void)
	{
		ring = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		ring->q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);

		ring->q_index = i;
		ring->reg_idx = 10;
		ring->vsi = vsi;
		ring->netdev = vsi->netdev;
		ring->dev = (struct device *)calloc(1, sizeof(struct device));
#define NUM_DESC 64
		ring->count = ALIGN(NUM_DESC, ICE_REQ_DESC_MULTIPLE);
		ring->size = 0;
#ifndef NO_DCB_SUPPORT
		ring->dcb_tc = 0;
#endif /* !NO_DCB_SUPPORT */
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(ring->dev);
		free_netdev(vsi->netdev);
		free(vsi);
		free(ring->q_vector);
		free(ring);
	}
};

TEST(ice_rx_rings, rx_ring_cycle)
{
	unsigned int dsize = ALIGN(NUM_DESC * sizeof(union ice_32byte_rx_desc), 4096);
	void *desc = calloc(1, dsize);

	mock().expectOneCall("dmam_alloc_coherent")
		.withParameter("size", dsize)
		.ignoreOtherParameters()
		.andReturnValue(desc);

	int ret = ice_setup_rx_ring(ring);

	CHECK_EQUAL(ret, 0);
	CHECK_EQUAL(ring->size, dsize);

	mock().checkExpectations();
	mock().clear();

	mock().expectOneCall("dmam_free_coherent")
		.withParameter("size", dsize)
		.ignoreOtherParameters();

	ice_free_rx_ring(ring);

	CHECK(ring->rx_buf == NULL);
	CHECK(ring->desc == NULL);

	/* have to free it ourselves because dmam_free_coherent was mocked */
	free(desc);
}

TEST_GROUP(ice_rx)
{
	struct net_device *netdev;
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	void *desc;
	struct rx_list_skb ice_rx_list;
	u32 real_tail = 0;
	int dsize = ALIGN(NUM_DESC * sizeof(struct ice_32b_rx_flex_desc_nic), 4096);

	void setup(void)
	{
		/* do we need a hw_mem too? */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		struct ice_netdev_priv *np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->port_info = (struct ice_port_info *)calloc(1,
			sizeof(struct ice_port_info));
		vsi->port_info->lport = 0;
		ring = (struct ice_ring *)calloc(1, sizeof(*ring));
		ring->q_index = 0;
		ring->reg_idx = 10;
		ring->vsi = vsi;
		ring->netdev = vsi->netdev;
		ring->dev = (struct device *)calloc(1, sizeof(struct device));
#define NUM_DESC 64
		ring->count = ALIGN(NUM_DESC, ICE_REQ_DESC_MULTIPLE);
		ring->size = 0;
#ifndef NO_DCB_SUPPORT
		ring->dcb_tc = 0;
#endif /* !NO_DCB_SUPPORT */
		ring->q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
		ring->q_vector->napi.dev = netdev;

		/* init our tracking list */
		INIT_LIST_HEAD(&ice_rx_list.rx_list);
		global_ice_rx_list = &ice_rx_list;

		desc = calloc(1, dsize);
		mock().expectOneCall("dmam_alloc_coherent")
			.withParameter("size", dsize)
			.ignoreOtherParameters()
			.andReturnValue(desc);

		/* this just sets up the descriptor ring and ice_rx_buf structs */
		ice_setup_rx_ring(ring);

		mock().checkExpectations();
		mock().clear();

		/* this spoofs the tail register so we don't write to non
		 * existent memory, don't need a whole hardware struct
		 */
		ring->tail = (u8 *)&real_tail;
		writel(0, ring->tail);

		ice_alloc_rx_bufs(ring, ICE_DESC_UNUSED(ring));
	}

	void teardown(void)
	{
		/* clean up, clean up, everybody everywhere */

		/* get rid of the skb's in the rx list */
		struct rx_list_skb *pos = NULL, *tmp = NULL;
		list_for_each_entry_safe(pos, tmp, &global_ice_rx_list->rx_list, rx_list) {
			dev_kfree_skb(pos->skb);
			list_del(&pos->rx_list);
			/* free the memory allocated in mock_napi_gro_receive */
			delete pos;
		}
		/* list better be empty or we missed some */
		CHECK(list_empty(&ice_rx_list.rx_list));

		mock().expectOneCall("dmam_free_coherent")
			.withParameter("size", dsize)
			.ignoreOtherParameters();

		/* this one calls clean ring and free */
		ice_free_rx_ring(ring);

		/* we mocked the free_coherent, so clean up for realz */
		free(desc);

		mock().checkExpectations();
		mock().clear();

		free(ring->q_vector);
		free(ring->dev);
		free(vsi->back);
		free(vsi->port_info);
		free(vsi);
		free_netdev(netdev);
		free(ring);
	}
};

#define TCPPACK1_LEN 0xC6ULL /* 198 */
static const unsigned char tcppack1[TCPPACK1_LEN] = {
0x00, 0x00, 0x5e, 0x00, 0x01, 0x01, 0x00, 0x1e,
0x67, 0x4d, 0xd3, 0x5f, 0x08, 0x00, 0x45, 0x10,
0x00, 0xb8, 0xb5, 0x72, 0x40, 0x00, 0x40, 0x06,
0x91, 0x19, 0x0a, 0xa5, 0xfc, 0x15, 0x0a, 0xf1,
0xe1, 0xf8, 0x00, 0x16, 0xcb, 0xfa, 0x84, 0x0f,
0x77, 0xf2, 0xa5, 0x3b, 0x80, 0xf3, 0x50, 0x18,
0x01, 0x80, 0xf4, 0x4e, 0x00, 0x00, 0x6f, 0x13,
0x86, 0xc2, 0xeb, 0x18, 0x54, 0x05, 0x2a, 0xd5,
0xd8, 0x77, 0x64, 0xc2, 0xc3, 0x63, 0x4e, 0x88,
0x0d, 0xa4, 0x43, 0x9c, 0x8c, 0x57, 0x2f, 0x43,
0x6b, 0x67, 0xc8, 0xca, 0x5a, 0x9a, 0x6e, 0x22,
0x67, 0x39, 0x71, 0x9a, 0x78, 0x52, 0x66, 0xd0,
0x90, 0x90, 0x85, 0xf8, 0xbb, 0x1e, 0x9f, 0x62,
0xed, 0xbf, 0x6d, 0xfa, 0x9c, 0x92, 0x91, 0x5b,
0x13, 0xcf, 0x97, 0x82, 0x0e, 0x2f, 0xf9, 0x09,
0x7c, 0xba, 0x17, 0x9c, 0xf6, 0x94, 0xba, 0x81,
0xb9, 0x84, 0xf8, 0xd5, 0x73, 0x7b, 0x8a, 0x43,
0x33, 0x4e, 0x2c, 0x4f, 0xd6, 0xa0, 0xe6, 0xfc,
0xc6, 0x7c, 0x2a, 0x9e, 0xbc, 0xb4, 0xbe, 0xc3,
0x39, 0xd3, 0x77, 0x89, 0x8a, 0x0a, 0xf8, 0x11,
0xa5, 0x0d, 0x25, 0xcb, 0xa3, 0x39, 0x2f, 0x5c,
0xbb, 0xae, 0x4f, 0xcd, 0x08, 0x5e, 0x7c, 0x27,
0x3e, 0x74, 0x6f, 0xf8, 0x1d, 0xca, 0xde, 0xef,
0x30, 0x40, 0x30, 0x84, 0xa6, 0x0e, 0xf7, 0xcd,
0x8e, 0x99, 0x34, 0xcd, 0x77, 0x82
};

#ifdef SWITCH_MODE
static const u64 tcpdesc1_sw_flex[4] = {
	0x0000000000000000ULL | (TCPPACK1_LEN << 32) | (u64)ICE_RXDID_FLEX_SW,
	0x0000000000000000ULL |
	    BIT_ULL(ICE_RX_DESC_STATUS_DD_S) | BIT_ULL(ICE_RX_DESC_STATUS_EOF_S),
	0x0000000000000000ULL,
	0x0000000000000000ULL
};
#else
static const u64 tcpdesc1_nic_flex[4] = {
	0x0000000000000000ULL | (TCPPACK1_LEN << 32) | (u64)ICE_RXDID_FLEX_NIC,
	0x0000000000000000ULL |
	    BIT_ULL(ICE_RX_DESC_STATUS_DD_S) | BIT_ULL(ICE_RX_DESC_STATUS_EOF_S),
	0x0000000000000000ULL,
	0x0000000000000000ULL
};
#endif

static void print_skb(struct sk_buff *skb) {
	/* this function pretty prints an SKB */
	char printbuf[1024] = { };
	int cur;

	cur =  sprintf(printbuf,     "\nskb: \n");
	cur += sprintf(printbuf + cur, "skb: len %d\n", skb->len);
	cur += sprintf(printbuf + cur, "skb: data_len %d\n", skb->data_len);
	cur += sprintf(printbuf + cur, "skb: ip_summed %d\n", skb->ip_summed);
	cur += sprintf(printbuf + cur, "skb: l4_hash %d\n", skb->l4_hash);
	cur += sprintf(printbuf + cur, "skb: csum_valid: %d, csum_complete_sw: %d, csum_level: %d, csum_bad: %d\n",
		skb->csum_valid, skb->csum_complete_sw, skb->csum_level, skb->csum_bad);
	cur += sprintf(printbuf + cur, "skb: encapsulation: %d, encap_hdr_csum: 0x%x\n", skb->encapsulation, skb->encap_hdr_csum);
	cur += sprintf(printbuf + cur, "skb: hash: 0x%x\n", skb->hash);
	cur += sprintf(printbuf + cur, "skb: vlan_proto: 0x%x, vlan_tci: 0x%x\n", skb->vlan_proto, skb->vlan_tci);
	cur += sprintf(printbuf + cur, "skb: protocol: 0x%x\n", skb->protocol);
	cur += sprintf(printbuf + cur, "skb: truesize: 0x%x\n", skb->truesize);
	cur += sprintf(printbuf + cur, "skb: users: %d\n", skb->users.counter);

	printf("%d bytes: %s", cur, printbuf);
}

#if 0
 { { {
	next = 0x0, prev = 0x0,
	{ tstamp = { tv64 = 0x0} ,
	  skb_mstamp = { { v64 = 0x0, { stamp_us = 0x0, stamp_jiffies = 0x0} } }
	}
     }
   } ,
	dev = 0x173dfe0,
	cb = { 0x0 < repeats 48 times >} ,
	_skb_refdst = 0x0, destructor = 0x0,
	len = 0xc6,
	data_len = 0x0,
	mac_len = 0x0, hdr_len = 0x0,
	queue_mapping = 0x0,
	cloned = 0x0, nohdr = 0x0, fclone = 0x0, peeked = 0x0,
	head_frag = 0x0,
	xmit_more = 0x0,
	headers_start = 0x173fbb0,
	__pkt_type_offset = 0x173fbb0,
	pkt_type = 0x0,
	pfmemalloc = 0x0,
	ignore_df = 0x0,
	nfctinfo = 0x0, nf_trace = 0x0,
	ip_summed = 0x0,
	ooo_okay = 0x0,
	l4_hash = 0x0,
	sw_hash = 0x0,
	wifi_acked_valid = 0x0, wifi_acked = 0x0, no_fcs = 0x0,
	encapsulation = 0x0, encap_hdr_csum = 0x0,
	csum_valid = 0x0, csum_complete_sw = 0x0, csum_level = 0x0, csum_bad = 0x0,
	ipvs_property = 0x0,
	inner_protocol_type = 0x0,
	remcsum_offload = 0x0,
	{ csum = 0x0, { csum_start = 0x0, csum_offset = 0x0} } ,
	priority = 0x0,
	skb_iif = 0x0,
	hash = 0x0,
	vlan_proto = 0x0, vlan_tci = 0x0,
	{ nothin = 0x0} ,
	{ mark = 0x0, reserved_tailroom = 0x0} ,
	{ inner_protocol = 0x0, inner_ipproto = 0x0} ,
	inner_transport_header = 0x0, inner_network_header = 0x0, inner_mac_header = 0x0,
	protocol = 0x800,
	transport_header = 0xffff, network_header = 0x0, mac_header = 0xffff, headers_end = 0x173fbe0,
	tail = 0x108,
	end = 0x142,
	head = 0x173d920,
	data = 0x173d962,
	truesize = 0x342,
	users = { counter = 0x1 }
 }

#endif


TEST(ice_rx, rx_one_ipv4_tcp)
{
	struct ice_rx_buf *rxbuf = (struct ice_rx_buf *)&ring->rx_buf[0];
	struct ice_32b_rx_flex_desc_nic *rxdesc;

	USE_MOCK(napi_gro_receive, mock_napi_gro_receive);

#ifdef CONFIG_ICE_USE_SKB
	/* set up packet data pointed to by skb data */
	memcpy(rxbuf->skb->data, &tcppack1, sizeof(tcppack1));
#else /* CONFIG_ICE_USE_SKB */
	/* set up packet data pointed to by buffer_info->page */
	memcpy(rxbuf->page->data, &tcppack1, sizeof(tcppack1));
#endif /* CONFIG_ICE_USE_SKB */

	/* set up desc */
	rxdesc = (struct ice_32b_rx_flex_desc_nic *)ICE_RX_DESC(ring, 0);
#ifdef SWITCH_MODE
	memcpy(rxdesc, &tcpdesc1_sw_flex, sizeof(*rxdesc));
#else
	memcpy(rxdesc, &tcpdesc1_nic_flex, sizeof(*rxdesc));
#endif

#ifndef SWITCH_MODE
	mock().expectOneCall("netif_is_ice").andReturnValue(true);
#endif

#ifndef ADK_SUPPORT
	mock().expectOneCall("ice_update_rx_ring_stats");
	mock().expectOneCall("napi_gro_receive")
		.ignoreOtherParameters();
#endif /* !SWITCH_MODE */

	ice_clean_rx_irq(ring, 64);

#ifndef SWITCH_MODE
	/* grab the first skb off the rx list */
	struct rx_list_skb *curr_list_item;
	curr_list_item = list_first_entry(&global_ice_rx_list->rx_list, rx_list_skb, rx_list);

	struct sk_buff *rx_skb = curr_list_item->skb;
	/* make sure the skb received was kosher */
	CHECK_EQUAL(sizeof(tcppack1), rx_skb->len);
#endif /* !SWITCH_MODE */
}

/* just receive 10 of the same packet as above */
TEST(ice_rx, rx_10_ipv4_tcp)
{
	struct ice_32b_rx_flex_desc_nic *rxdesc;
	struct ice_rx_buf *rxbuf;

	USE_MOCK(napi_gro_receive, mock_napi_gro_receive);

#define NUM_TEST_PACKETS 10
	for (int i = 0; i < NUM_TEST_PACKETS; i++) {
		rxbuf = (struct ice_rx_buf *)&ring->rx_buf[i];
#ifdef CONFIG_ICE_USE_SKB
		/* set up packet data in skb */
		memcpy(rxbuf->skb->data, &tcppack1, sizeof(tcppack1));
#else /* CONFIG_ICE_USE_SKB */
		/* set up packet data pointed to by buffer_info->page */
		memcpy(rxbuf->page->data, &tcppack1, sizeof(tcppack1));
#endif

		/* set up desc */
		rxdesc = (struct ice_32b_rx_flex_desc_nic *)ICE_RX_DESC(ring, i);
#ifdef SWITCH_MODE
		memcpy(rxdesc, &tcpdesc1_sw_flex, sizeof(*rxdesc));
#else
		memcpy(rxdesc, &tcpdesc1_nic_flex, sizeof(*rxdesc));
#endif
	}

#ifndef SWITCH_MODE
	mock().expectNCalls(NUM_TEST_PACKETS, "netif_is_ice")
		.andReturnValue(true);
#endif
#ifndef ADK_SUPPORT
	mock().expectOneCall("ice_update_rx_ring_stats");
	mock().expectNCalls(NUM_TEST_PACKETS, "napi_gro_receive")
		.ignoreOtherParameters();
#endif /* !SWITCH_MODE */
#define DEFAULT_NAPI_BUDGET 64
	ice_clean_rx_irq(ring, DEFAULT_NAPI_BUDGET);

	struct rx_list_skb *pos = NULL;
	list_for_each_entry(pos, &global_ice_rx_list->rx_list, rx_list) {
		struct sk_buff *rx_skb = pos->skb;

		/* make sure the skb received was kosher */
		CHECK_EQUAL(sizeof(tcppack1), rx_skb->len);
	}
}

TEST_GROUP(ice_receive)
{
	struct net_device *netdev;
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	void *desc;
	struct rx_list_skb ice_rx_list;
	struct bpf_prog *prog;
	u32 real_tail = 0;
	int dsize = ALIGN(NUM_DESC * sizeof(struct ice_32b_rx_flex_desc_nic), 4096);

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		struct ice_netdev_priv *np = netdev_priv(netdev);

		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		ring = (struct ice_ring *)calloc(1, sizeof(*ring));
		ring->netdev = vsi->netdev;
		ring->dev = (struct device *)calloc(1, sizeof(struct device));
#define NUM_DESCRIPTORS 32
		ring->count = ALIGN(NUM_DESCRIPTORS, ICE_REQ_DESC_MULTIPLE);
		ring->q_vector = (struct ice_q_vector *)calloc(1, sizeof(struct ice_q_vector));
		ring->q_vector->napi.dev = netdev;
		vsi->type = ICE_VSI_PF;
		ring->vsi = vsi;

		/* init our tracking list */
		INIT_LIST_HEAD(&ice_rx_list.rx_list);
		global_ice_rx_list = &ice_rx_list;

		desc = calloc(1, dsize);
		mock().expectOneCall("dmam_alloc_coherent")
			.withParameter("size", dsize)
			.ignoreOtherParameters()
			.andReturnValue(desc);

		/* this just sets up the descriptor ring and ice_rx_buf structs */
		ice_setup_rx_ring(ring);

		mock().checkExpectations();
		mock().clear();

		/* this spoofs the tail register so we don't write to non
		 * existent memory, don't need a whole hardware struct
		 */
		ring->tail = (u8 *)&real_tail;
		writel(0, ring->tail);
	}

	void teardown(void)
	{
		/* clean up, clean up, everybody everywhere */

		/* get rid of the skb's in the rx list */
		struct rx_list_skb *pos = NULL, *tmp = NULL;
		list_for_each_entry_safe(pos, tmp, &global_ice_rx_list->rx_list, rx_list) {
			dev_kfree_skb(pos->skb);
			list_del(&pos->rx_list);
			/* free the memory allocated in napi_gro_receive */
			delete pos;
		}
		/* list better be empty or we missed some */
		CHECK(list_empty(&ice_rx_list.rx_list));

		mock().expectOneCall("dmam_free_coherent")
			.withParameter("size", dsize)
			.ignoreOtherParameters();

		/* this one calls clean ring and free */
		ice_free_rx_ring(ring);

		/* we mocked the free_coherent, so clean up for real */
		free(desc);

		mock().checkExpectations();
		mock().clear();

		free(ring->q_vector);
		free(ring->dev);
		free(vsi->back);
		free(vsi);
		free_netdev(netdev);
		free(ring);
	}
};

TEST(ice_receive, ice_alloc_rx_buffs_success)
{
	union ice_32b_rx_flex_desc *rxdesc;
	struct ice_rx_buf *rxbuf;

	rxbuf = (struct ice_rx_buf *)&ring->rx_buf[0];
	rxdesc = ICE_RX_DESC(ring, 0);
	u16 cleaned_count = ICE_DESC_UNUSED(ring);

#ifndef CONFIG_ICE_USE_SKB
#ifdef XDP_SUPPORT
	USE_STD_MOCK(ice_rx_offset);
	mock().expectNCalls(cleaned_count, "ice_rx_offset")
		.andReturnValue(ICE_SUCCESS);
#endif
#endif
	bool ret = ice_alloc_rx_bufs(ring, cleaned_count);

	CHECK_FALSE(ret);
	CHECK_EQUAL(ring->next_to_use, cleaned_count);
	CHECK_EQUAL(rxdesc->read.pkt_addr, rxbuf->dma + rxbuf->page_offset);
}

TEST(ice_receive, ice_alloc_rx_buffs_fails)
{
	bool ret;

	/* function must return false when no netdev, use case
	 * is for VFs and VMDQ2 VSI, and must not move next_to_use
	 */
	ring->netdev = NULL;
	u16 old_ntu = ring->next_to_use;

	ret = ice_alloc_rx_bufs(ring, ICE_DESC_UNUSED(ring));

	CHECK_FALSE(ret);
	CHECK_EQUAL(ring->next_to_use, old_ntu);

	/* now test that a zero cleaned count means early return,
	 * aka must not move next_to_use
	 */
	ring->netdev = vsi->netdev;
	old_ntu = ring->next_to_use;

	ret = ice_alloc_rx_bufs(ring, 0);

	CHECK_FALSE(ret);
	CHECK_EQUAL(old_ntu, ring->next_to_use);
}

static bool
ice_alloc_mapped_page_detour(struct ice_ring *rx_ring, struct ice_rx_buf *bi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

static bool
ice_alloc_mapped_skb_detour(struct ice_ring *rx_ring, struct ice_rx_buf *bi)
{
	mock().actualCall(__func__);
	return mock().returnBoolValueOrDefault(false);
}

TEST(ice_receive, ice_alloc_rx_buffs_fail_alloc)
{
#ifdef CONFIG_ICE_USE_SKB
	USE_MOCK(ice_alloc_mapped_skb, ice_alloc_mapped_skb_detour);
	mock().expectOneCall("ice_alloc_mapped_skb_detour")
		.andReturnValue(false);
#else
	USE_MOCK(ice_alloc_mapped_page, ice_alloc_mapped_page_detour);
	mock().expectOneCall("ice_alloc_mapped_page_detour")
		.andReturnValue(false);

#endif

	u16 cleaned_count = ICE_DESC_UNUSED(ring);

	/* the function should return true if any allocation failed,
	 * indicating that the caller should try again later
	 */
	bool ret = ice_alloc_rx_bufs(ring, cleaned_count);

	CHECK_TRUE(ret);
}

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_set_wb_on_itr)
{
	struct ice_q_vector *q_vector;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup()
	{
		q_vector = (struct ice_q_vector *)calloc(1, sizeof(*q_vector));
		q_vector->reg_idx = 1;
		q_vector->num_ring_rx = 1;
		q_vector->num_ring_tx = 1;
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		q_vector->vsi = vsi;
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		vsi->back = pf;
		hw = &pf->hw;

		/* Set interrupts to enabled and an ITR value so we can test
		 * against this
		 */
		wr32(hw, GLINT_DYN_CTL(q_vector->reg_idx),
		     GLINT_DYN_CTL_INTENA_M |
		     (8 << GLINT_DYN_CTL_INTERVAL_S));

	}

	void teardown()
	{
		free(q_vector);
		q_vector = NULL;
		free(pf->hw.hw_addr);
		pf->hw.hw_addr = NULL;
		free(pf);
		pf = NULL;
		free(vsi);
		vsi = NULL;
	}
};

TEST(ice_set_wb_on_itr, test_ice_set_wb_on_itr)
{
	u32 reg_val;

	ice_set_wb_on_itr(q_vector);
	reg_val = rd32(hw, GLINT_DYN_CTL(q_vector->reg_idx));

	CHECK_EQUAL(0, reg_val & GLINT_DYN_CTL_INTENA_M);
	CHECK_EQUAL(GLINT_DYN_CTL_WB_ON_ITR_M, reg_val & GLINT_DYN_CTL_WB_ON_ITR_M);
	CHECK_TRUE(q_vector->wb_on_itr);
	CHECK_EQUAL(GLINT_DYN_CTL_INTENA_MSK_M, reg_val & GLINT_DYN_CTL_INTENA_MSK_M);
}

TEST_GROUP(ice_rx_32b_flex_desc_bits)
{
	union ice_32b_rx_flex_desc *rx_desc;
	bool actual_result;

	void setup()
	{
		rx_desc = (union ice_32b_rx_flex_desc *)calloc(1, sizeof(*rx_desc));
	}

	void teardown()
	{
		free(rx_desc);
	}
};

TEST(ice_rx_32b_flex_desc_bits, dd_bit_not_set_in_status_error0_expect_return_false)
{
	actual_result = ice_test_staterr(rx_desc->wb.status_error0, BIT(ICE_RX_FLEX_DESC_STATUS0_DD_S));

	CHECK_EQUAL(false, actual_result);
}


TEST(ice_rx_32b_flex_desc_bits, rxe_bit_set_in_status_error0_expect_return_true)
{
	rx_desc->wb.status_error0 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS0_RXE_S));

	actual_result = ice_test_staterr(rx_desc->wb.status_error0, BIT(ICE_RX_FLEX_DESC_STATUS0_RXE_S));

	CHECK_EQUAL(true, actual_result);
}

TEST(ice_rx_32b_flex_desc_bits, dd_bit_set_in_status_error0_expect_return_true)
{
	rx_desc->wb.status_error0 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS0_DD_S));

	actual_result = ice_test_staterr(rx_desc->wb.status_error0, BIT(ICE_RX_FLEX_DESC_STATUS0_DD_S));

	CHECK_EQUAL(true, actual_result);
}

TEST(ice_rx_32b_flex_desc_bits, rxd_eof_bit_set_in_status_error0_expect_return_true)
{
	rx_desc->wb.status_error0 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS0_EOF_S));

	actual_result = ice_test_staterr(rx_desc->wb.status_error0, BIT(ICE_RX_FLEX_DESC_STATUS0_EOF_S));

	CHECK_EQUAL(true, actual_result);
}

TEST(ice_rx_32b_flex_desc_bits, l2tag1p_bit_set_in_status_error0_expect_return_true)
{
	rx_desc->wb.status_error0 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS0_L2TAG1P_S));

	actual_result = ice_test_staterr(rx_desc->wb.status_error0, BIT(ICE_RX_FLEX_DESC_STATUS0_L2TAG1P_S));

	CHECK_EQUAL(true, actual_result);
}

TEST(ice_rx_32b_flex_desc_bits, l2tag2p_bit_set_in_status_error1_expect_return_true)
{
	rx_desc->wb.status_error1 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS1_L2TAG2P_S));

	actual_result = ice_test_staterr(rx_desc->wb.status_error1, BIT(ICE_RX_FLEX_DESC_STATUS1_L2TAG2P_S));

	CHECK_EQUAL(true, actual_result);
}

TEST_GROUP(ice_get_vlan_tag_from_rx_desc)
{
	union ice_32b_rx_flex_desc *rx_desc;
	u16 vlan_tag;

	void setup()
	{
		rx_desc = (union ice_32b_rx_flex_desc *)calloc(1, sizeof(*rx_desc));
	}

	void teardown()
	{
		free(rx_desc);
	}
};

TEST(ice_get_vlan_tag_from_rx_desc, no_vlan_in_rx_desc_expect_return_0)
{
	vlan_tag = ice_get_vlan_tag_from_rx_desc(rx_desc);

	CHECK_EQUAL(0, vlan_tag);
}

TEST(ice_get_vlan_tag_from_rx_desc, inner_8100_vlan_13_in_rx_desc_expect_return_13)
{
	rx_desc->wb.status_error0 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS0_L2TAG1P_S));
	rx_desc->wb.l2tag1 = cpu_to_le16(13);

	vlan_tag = ice_get_vlan_tag_from_rx_desc(rx_desc);

	CHECK_EQUAL(13, vlan_tag);
}

TEST(ice_get_vlan_tag_from_rx_desc, outer_8100_vlan_15_in_rx_desc_expect_return_15)
{
	rx_desc->wb.status_error1 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS1_L2TAG2P_S));
	rx_desc->wb.l2tag2_2nd = cpu_to_le16(15);

	vlan_tag = ice_get_vlan_tag_from_rx_desc(rx_desc);

	CHECK_EQUAL(15, vlan_tag);
}

TEST(ice_get_vlan_tag_from_rx_desc, outer_stag_vlan_33_in_rx_desc_expect_return_33)
{
	rx_desc->wb.status_error1 = cpu_to_le16(BIT(ICE_RX_FLEX_DESC_STATUS1_L2TAG2P_S));
	rx_desc->wb.l2tag2_2nd = cpu_to_le16(33);

	vlan_tag = ice_get_vlan_tag_from_rx_desc(rx_desc);

	CHECK_EQUAL(33, vlan_tag);
}
