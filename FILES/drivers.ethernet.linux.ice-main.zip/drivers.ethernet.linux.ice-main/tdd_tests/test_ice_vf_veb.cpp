#ifdef BMSM_MODE
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

////////////////////////////////////////
namespace ns_vf_veb {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/skbuff.h>
#include <linux/compiler.h>
#include <linux/if_link.h>
#include <linux/pci_regs.h>

#include "../src/CORE/ice.h"

#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_mbx.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"

#include "../src/CORE/ice_vf_veb.c"
}
////////////////////////////////////////
using namespace ns_vf_veb;

TEST_GROUP(ice_pre_veb_rules)
{
	struct net_device *netdev;
	struct ice_vfs *vfs;
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct ice_vsi *pf_vsi;
	u8 mac_addresses[6][ETH_ALEN] = {
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xff },
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xfe },
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xfd },
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xfc },
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xfb },
		{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xfa }
	};
	int num_of_mac_addr;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		vf = (struct ice_vf *)calloc(1, sizeof(struct ice_vf));
		vfs = &pf->vfs;
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi**)calloc(1, sizeof(struct ice_vsi *) * pf->num_alloc_vsi);
		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);
		vf->pf = pf;
		vf->vf_id = 0;
		hash_add(vfs->table, &vf->entry, 0);
		vf->vf_id = 0;

		pf_vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[0] = pf_vsi;
		vf->lan_vsi_idx = 0;

		INIT_LIST_HEAD(&vf->pre_veb_rules_list.head);
		num_of_mac_addr = 6;

		spin_lock_init(&vf->pre_veb_rules_list.list_lock);
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(pf_vsi);
		free(pf->vsi);
		hash_del(&vf->entry);
		free(vf);
		mutex_destroy(&vfs->table_lock);
		free_netdev(netdev);
		free(pf);
		netdev = NULL;
	}
};

TEST(ice_pre_veb_rules, ice_add_and_delete_pre_veb_rules)
{
	int actual, i;

	for (i = 0; i < num_of_mac_addr; i++) {
		actual = ice_vf_add_pre_veb(vf, 1,  mac_addresses[i]);
		CHECK_EQUAL(0, actual);
	}

	for (i = 0; i < num_of_mac_addr; i++) {
		actual = ice_vf_update_pre_veb_status(vf, 1,  mac_addresses[i], i, true);
		CHECK_EQUAL(0, actual);
	}

	for (i = 0; i < num_of_mac_addr; i++)
		ice_vf_del_pre_veb(pf, i);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_vf_free_pre_veb)
{
	int actual, i;

	for (i = 0; i < num_of_mac_addr; i++) {
		actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[i]);
		CHECK_EQUAL(0, actual);
	}

	ice_vf_free_pre_veb(vf);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_vf_add_pre_veb_update_existing_rule)
{
	int actual;

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_update_pre_veb_status(vf, 1, mac_addresses[0], 1, true);
	CHECK_EQUAL(0, actual);

	ice_vf_del_pre_veb(pf, 1);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_vf_add_pre_veb_update_not_existing_rule)
{
	int actual;

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_update_pre_veb_status(vf, 1, mac_addresses[1], 1, true);
	CHECK_EQUAL(-ENOENT, actual);

	ice_vf_free_pre_veb(vf);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_add_duplicated_pre_veb_rule)
{
	int actual;

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(-EEXIST, actual);
	ice_vf_free_pre_veb(vf);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_vf_del_pre_veb_which_does_not_exists)
{
	int actual;

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_update_pre_veb_status(vf, 1, mac_addresses[0], 1, true);
	ice_vf_del_pre_veb(pf, 2);

	ice_vf_del_pre_veb(pf, 1);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}

TEST(ice_pre_veb_rules, ice_sync_pre_veb_rules_with_peer_one_rule_to_send)
{
	int actual;

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[0]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[1]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_update_pre_veb_status(vf, 1, mac_addresses[1], 2, true);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_add_pre_veb(vf, 1, mac_addresses[2]);
	CHECK_EQUAL(0, actual);

	actual = ice_vf_update_pre_veb_status(vf, 1, mac_addresses[2], 3, true);
	CHECK_EQUAL(0, actual);

	mock().expectOneCall("ice_mbx_send_msg_to_ies")
		.andReturnValue(0);
	ice_vf_sync_pre_veb_peer(pf);
	ice_vf_free_pre_veb(vf);
	CHECK(list_empty(&vf->pre_veb_rules_list.head));
}
#endif /* BMSM_MODE */
