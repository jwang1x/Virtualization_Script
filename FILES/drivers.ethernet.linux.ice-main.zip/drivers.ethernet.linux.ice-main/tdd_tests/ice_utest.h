#ifndef _ICE_UTEST_
#define _ICE_UTEST_

/* Intel ice Linux utest header
 * Copyright(c) 2017 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */

/* Standard library headers must always be included outside of any namespaces,
 * and are thus included first via the core_headers.h file
 */
#include "core_headers.h"

#include "CppUTest/TestHarness.h"
#include "CppUTest/TestRegistry.h"
#include "CppUTestExt/MockSupport.h"
#include "CppUTestExt/MockSupportPlugin.h"
#include "detour_function/detour_function.h"

#define ALLOC_NEW_MOCK(obj, _Original, _Fake) \
	obj = new detour_function(_Original, _Fake); \
	CHECK_TRUE_TEXT(obj->install(), "Detour failed!  Mock not installed: " #_Fake);

#define DELETE_MOCK(obj) \
	delete obj

#define USE_MOCK(_Original, _Fake)  \
	detour_function _Original##_Fake(_Original, _Fake); \
	CHECK_TRUE_TEXT(_Original##_Fake.install(), "Detour failed!  Mock not installed: " #_Fake);

/* TGN -- TestGroupName
 *
 * Used to reference the full class name for a TEST_GROUP, so that it can be
 * extended by a different TEST_GROUP, using TEST_GROUP_BASE. This avoids the
 * need to use TEST_BASE when you want to extend a test group, and essentially
 * allows tests to belong inside of base test classes.
 */
#define TGN(testGroup) \
	TEST_GROUP_##CppUTestGroup##testGroup

/*
 * Helper macro to USE_MOCK a function with its stdmock:: equivalent.
 * Generally static functions in files should have stdmock:: equivalents
 * created in a mock_src file that can be included for the purpose of allowing
 * testing individual functions in a file, even when it calls other static
 * functions in the same file. This allows keeping the mock functions in
 * a separate place to reduce code clutter.
 *
 * To use this macro, the mock function should be declared inside of
 * a "namespace stdmock {}", and have the same name as the original function.
 */
#define USE_STD_MOCK(_Original) \
	detour_function _Original##_stdmock(_Original, stdmock::_Original); \
	CHECK_TRUE_TEXT(_Original##_stdmock.install(), "Detour failed!  Mock not installed: stdmock::" #_Original);

#endif /* _ICE_UTEST_ */
