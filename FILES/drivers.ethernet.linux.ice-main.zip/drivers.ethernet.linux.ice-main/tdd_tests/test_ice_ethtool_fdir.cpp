#ifdef FDIR_SUPPORT
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_ethtool_fdir {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/compiler.h>

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_acl_main.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"

static inline ice_fltr_ptype& operator++(ice_fltr_ptype& val, int)
{
	return val = ice_fltr_ptype(val + 1);
}

#include "CORE_MOCKS/stdmock_ice_ethtool_fdir.cpp"

#include "../src/CORE/ice_ethtool_fdir.c"
}
/////////////////////////////////////////////////
using namespace ns_ethtool_fdir;

/* because the CORE part of the code allocates the memory for the
 * hw struct, we need to fake that here
 */
static struct ice_hw * fake_driver_init(struct ice_hw *hw)
{
	return hw;
}

struct test_hw {
	/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

/* getting all of the h files in line so that inet_pton() works for ipv6 is
 * a large effort. it is easier to just have some fixed addresses ready to use.
 */
static u8 ipv6_addr_fixed[] = {
	0xfe, 0xc0, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
};

static u8 ipv6_addr_1[] = {
	0xfe, 0xc0, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
	0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
};

/* some helper functions that generate fdir filters. */
static struct ice_fdir_fltr *TCP4_fltr(struct device *dev, u32 src, u16 port, int id)
{
	struct ice_fdir_fltr *fltr;

	fltr = (struct ice_fdir_fltr *)devm_kzalloc(dev, sizeof(struct ice_fdir_fltr), GFP_KERNEL);
	memset(fltr, 0, sizeof(struct ice_fdir_fltr));
	fltr->fltr_id = id;
	fltr->q_index = 100 + id;
#ifdef ADQ_SUPPORT
	fltr->orig_q_index = 200 + id;
#endif
	fltr->dest_vsi = id;
	fltr->dest_ctl = ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX;
	fltr->fltr_status = ICE_FLTR_PRGM_DESC_FD_STATUS_FD_ID;
	fltr->cnt_index = 0;
	fltr->flow_type = ICE_FLTR_PTYPE_NONF_IPV4_TCP;
	fltr->ip.v4.dst_port = port;
	fltr->ip.v4.src_port = port;
	fltr->ip.v4.dst_ip = 0x12345678;
	fltr->ip.v4.src_ip = src;
	// no masks set
	return fltr;
}

static struct ice_fdir_fltr *TCP6_fltr(struct device *dev, u8* addr, u16 port, int id)
{
	struct ice_fdir_fltr *fltr;

	fltr = (struct ice_fdir_fltr *)devm_kzalloc(dev, sizeof(struct ice_fdir_fltr), GFP_KERNEL);
	memset(fltr, 0, sizeof(struct ice_fdir_fltr));
	fltr->fltr_id = id;
	fltr->q_index = 100 + id;
#ifdef ADQ_SUPPORT
	fltr->orig_q_index = 200 + id;
#endif
	fltr->dest_vsi = id;
	fltr->dest_ctl = ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX;
	fltr->fltr_status = ICE_FLTR_PRGM_DESC_FD_STATUS_FD_ID;
	fltr->cnt_index = 0;
	fltr->flow_type = ICE_FLTR_PTYPE_NONF_IPV6_TCP;
	fltr->ip.v6.dst_port = port;
	fltr->ip.v6.src_port = port;
	memcpy(fltr->ip.v6.dst_ip, ipv6_addr_fixed, sizeof(struct in6_addr));
	memcpy(fltr->ip.v6.src_ip, addr, sizeof(struct in6_addr));
	// no masks set
	return fltr;
}

static bool fill_user_data(u16 data, u16 offset, ethtool_rx_flow_spec *fsp)
{
	u64 usrdef = offset << 16 | data;

	ns_ethtool_fdir::put_unaligned_be64(usrdef, &fsp->h_ext.data64);
	ns_ethtool_fdir::put_unaligned_be64(0xffffffff, &fsp->m_ext.data64);
	return false;
}

/* tests begin */
TEST_BASE(ice_ethtool_fdir_base)
{
	struct test_hw *tdd_hw;
	struct ice_pf *pf;
	struct ice_hw *hw;
	struct ice_vsi *vsi;
	struct device *dev;

	void setup() {
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		tdd_hw = (struct test_hw *)calloc(1, sizeof(*tdd_hw));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		dev = &pf->pdev->dev;
		vsi->back = pf;
		hw = &pf->hw;

		/* used by rd32/wr32 */
		hw->hw_addr = (u8 *)tdd_hw;
		hw->back = pf;
		hw->vendor_id = 0x8086;
		hw->device_id = 0xF0B5; /* ICE_DEV_ID_I200_FPGA */
#ifdef SWITCH_MODE
		hw->num_lports = 1;
		hw->num_total_ports = hw->num_lports + 1;
		hw->port_info = (struct ice_port_info *)
				ice_calloc(hw, hw->num_total_ports, sizeof(struct ice_port_info));
		for (int i = 0; i < hw->num_total_ports; i++) {
			hw->port_info[i].hw = hw;
			hw->port_info[i].lport = i;
		}
#else
		hw->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		hw->port_info->hw = hw;
		hw->port_info->lport = 0;
#endif
		ice_init_lock(&hw->fdir_fltr_lock);
		set_bit(ICE_FLAG_ADV_FEATURES, pf->flags);
		/* ADQ wants a vsi set up so that it can find it */
		pf->vsi = (struct ice_vsi **)calloc(10, sizeof(struct ice_vsi *));
		pf->vsi[0] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[0]->type = ICE_VSI_PF;
		pf->vsi[1] = vsi;
		pf->ctrl_vsi_idx = 1;
		pf->num_alloc_vsi = 1;
	}
	void teardown() {
		ice_destroy_lock(&hw->fdir_fltr_lock);
		free(hw->port_info);
		memset(hw, 0, sizeof (*hw));
		free(pf->vsi[0]);
		free(pf->vsi);
		free(pf->pdev);
		free(pf);
		free(vsi);
		free(tdd_hw);
	}
};

TEST_GROUP_BASE(ice_ethtool_fdir_calls, ice_ethtool_fdir_base)
{
	void setup() {
		ice_ethtool_fdir_base::setup();
		INIT_LIST_HEAD(&hw->fdir_list_head);
	}
	void teardown() {
		struct ice_fdir_fltr *rule, *tmp;

		LIST_FOR_EACH_ENTRY_SAFE(rule, tmp, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
			LIST_DEL(&rule->fltr_node);
			devm_kfree(dev, rule);
		}
		ice_ethtool_fdir_base::teardown();
	}
};

TEST_GROUP(ice_ethtool_fdir_plain)
{
	void setup() {
	}
	void teardown() {
	}
};

TEST(ice_ethtool_fdir_plain, ice_fltr_to_ethtool_flow_sanity)
{
	enum ice_fltr_ptype flow;
	int val;

	flow = ICE_FLTR_PTYPE_NONF_IPV4_TCP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, TCP_V4_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, UDP_V4_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV4_SCTP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, SCTP_V4_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV4_OTHER;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, IPV4_USER_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV6_TCP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, TCP_V6_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV6_UDP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, UDP_V6_FLOW);

	flow = ICE_FLTR_PTYPE_NONF_IPV6_SCTP;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, SCTP_V6_FLOW);

#ifdef HAVE_ETHTOOL_FLOW_UNION_IP6_SPEC
	flow = ICE_FLTR_PTYPE_NONF_IPV6_OTHER;
	val = ns_ethtool_fdir::ice_fltr_to_ethtool_flow(flow);
	CHECK_EQUAL(val, IPV6_USER_FLOW);
#endif
}

TEST(ice_ethtool_fdir_plain, ice_ethtool_flow_to_fltr_sanity)
{
	enum ice_fltr_ptype val;
	int eth;

	eth = TCP_V4_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV4_TCP);


	eth = UDP_V4_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV4_UDP);

	eth = SCTP_V4_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV4_SCTP);

	eth = IPV4_USER_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV4_OTHER);

	eth = TCP_V6_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV6_TCP);

	eth = UDP_V6_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV6_UDP);

	eth = SCTP_V6_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV6_SCTP);

#ifdef HAVE_ETHTOOL_FLOW_UNION_IP6_SPEC
	eth = IPV6_USER_FLOW;
	val = ns_ethtool_fdir::ice_ethtool_flow_to_fltr(eth);
	CHECK_EQUAL(val, ICE_FLTR_PTYPE_NONF_IPV6_OTHER);
#endif
}

TEST(ice_ethtool_fdir_calls, test_ice_get_ethtool_fdir_entry_missing)
{
	struct ice_fdir_fltr *fltr;
	struct ethtool_rxnfc *cmd;
	int err;

	cmd = (struct ethtool_rxnfc *)calloc(1, sizeof(struct ethtool_rxnfc));
	memset(cmd, 0, sizeof(*cmd));
	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)NULL);

	err = ns_ethtool_fdir::ice_get_ethtool_fdir_entry(hw, cmd);

	CHECK_EQUAL(err, -EINVAL);

	free(cmd);
}

TEST(ice_ethtool_fdir_calls, test_ice_get_ethtool_fdir_entry_tcp4)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ice_fdir_fltr *fltr;
	struct ethtool_rxnfc *cmd;
	u32 src_addr = 0x89abcdef;
	u32 dst_addr = 0x12345678;
	u32 test_port = 80;
	u64 id = 501;
	int err;

	cmd = (struct ethtool_rxnfc *)calloc(1, sizeof(struct ethtool_rxnfc));
	memset(cmd, 0, sizeof(*cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd->fs;

	fltr = TCP4_fltr(dev, src_addr, test_port, id);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	fsp->location = id;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)fltr);

	err = ns_ethtool_fdir::ice_get_ethtool_fdir_entry(hw, cmd);

	CHECK_EQUAL(err, 0);
	CHECK_EQUAL(fsp->flow_type, TCP_V4_FLOW);
#ifdef ADQ_SUPPORT
	CHECK_EQUAL(fsp->ring_cookie, id + 200); /* fltr rx queue value came from orig_q_index */
#else
	CHECK_EQUAL(fsp->ring_cookie, id + 100); /* fltr rx queue value */
#endif

	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.ip4src, src_addr);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.ip4dst, dst_addr);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.psrc, test_port);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.pdst, test_port);

	free(cmd);
}

TEST(ice_ethtool_fdir_calls, test_ice_get_ethtool_fdir_entry_tcp6)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ice_fdir_fltr *fltr;
	struct ethtool_rxnfc *cmd;
	u32 test_port = 210;
	u64 id = 777;
	int err;

	cmd = (struct ethtool_rxnfc *)calloc(1, sizeof(struct ethtool_rxnfc));
	memset(cmd, 0, sizeof(*cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd->fs;

	fltr = TCP6_fltr(dev, ipv6_addr_1, test_port, id);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	fsp->location = id;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)fltr);

	err = ns_ethtool_fdir::ice_get_ethtool_fdir_entry(hw, cmd);

	CHECK_EQUAL(err, 0);
	CHECK_EQUAL(fsp->flow_type, TCP_V6_FLOW);
#ifdef ADQ_SUPPORT
	CHECK_EQUAL(fsp->ring_cookie, id + 200); /* fltr rx queue value came from orig_q_index */
#else
	CHECK_EQUAL(fsp->ring_cookie, id + 100); /* fltr rx queue value */
#endif

#ifdef HAVE_ETHTOOL_FLOW_UNION_IP6_SPEC
	CHECK_EQUAL(0, memcmp(fsp->h_u.tcp_ip6_spec.ip6src, ipv6_addr_1,
			      sizeof(ipv6_addr_1)));
	CHECK_EQUAL(0, memcmp(fsp->h_u.tcp_ip6_spec.ip6dst, ipv6_addr_fixed,
			      sizeof(ipv6_addr_fixed)));
	CHECK_EQUAL(fsp->h_u.tcp_ip6_spec.psrc, test_port);
	CHECK_EQUAL(fsp->h_u.tcp_ip6_spec.pdst, test_port);
#endif /* HAVE_ETHTOOL_FLOW_UNION_IP6_SPEC */
	free(cmd);
}

TEST(ice_ethtool_fdir_calls, test_ice_ntuple_check_ip4_usr_seg_invalid)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ethtool_rxnfc cmd;
	int ret;

	memset(&cmd, 0, sizeof(cmd));
	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;

	/* Unsupported parameters */
	fsp->m_u.usr_ip4_spec.l4_4_bytes = 1;
	ret = ice_ntuple_check_ip4_usr_seg(&fsp->m_u.usr_ip4_spec);
	CHECK_EQUAL(-EINVAL, ret);
	fsp->m_u.usr_ip4_spec.l4_4_bytes = 0;

	fsp->m_u.usr_ip4_spec.tos = 1;
	ret = ice_ntuple_check_ip4_usr_seg(&fsp->m_u.usr_ip4_spec);
	CHECK_EQUAL(-EINVAL, ret);
	fsp->m_u.usr_ip4_spec.tos = 0;

	fsp->m_u.usr_ip4_spec.ip_ver = 1;
	ret = ice_ntuple_check_ip4_usr_seg(&fsp->m_u.usr_ip4_spec);
	CHECK_EQUAL(-EINVAL, ret);
	fsp->m_u.usr_ip4_spec.ip_ver = 0;

	fsp->m_u.usr_ip4_spec.proto = 1;
	ret = ice_ntuple_check_ip4_usr_seg(&fsp->m_u.usr_ip4_spec);
	CHECK_EQUAL(-EOPNOTSUPP, ret);
	fsp->m_u.usr_ip4_spec.proto = 0;

	fsp->m_u.usr_ip4_spec.ip4src = 0;
	fsp->m_u.usr_ip4_spec.ip4dst = 0;
	ret = ice_ntuple_check_ip4_usr_seg(&fsp->m_u.usr_ip4_spec);
	CHECK_EQUAL(-EINVAL, ret);
}

TEST(ice_ethtool_fdir_calls, test_ice_cfg_fdir_xtrct_seq_tcp4_add)
{
	struct ethtool_rx_flow_spec *fsp;
	int val, i;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	fsp->flow_type = TCP_V4_FLOW;
	fsp->m_u.tcp_ip4_spec.ip4src = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.ip4dst = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.psrc   = 0xFFFF;

	mock().expectNCalls(2, "ice_flow_add_prof")
		.ignoreOtherParameters();

	mock().expectNCalls(4, "ice_flow_add_entry")
		.ignoreOtherParameters();

	mock().expectNCalls(3, "ice_flow_set_fld")
		.ignoreOtherParameters();

	val = ice_cfg_fdir_xtrct_seq(pf, fsp, NULL);

	CHECK_EQUAL(0, val);

	if (hw->fdir_prof) {
		for (i=0;i<ICE_FLTR_PTYPE_MAX;i++) {
			int tun;
			if (!hw->fdir_prof[i])
				continue;
			for (tun = 0; tun < 2; tun++)
				if (hw->fdir_prof[i]->fdir_seg[tun])
					devm_kfree(dev, hw->fdir_prof[i]->fdir_seg[tun]);
			devm_kfree(dev, hw->fdir_prof[i]);
		}
		devm_kfree(dev, hw->fdir_prof);
	}
	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_cfg_fdir_xtrct_seq_tcp4_err)
{
	struct ethtool_rx_flow_spec *fsp;
	int val, i;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	fsp->flow_type = TCP_V4_FLOW;
	fsp->m_u.tcp_ip4_spec.ip4src = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.ip4dst = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.psrc   = 0xFFFF;
	fsp->m_u.tcp_ip4_spec.tos    = 5;

	val = ice_cfg_fdir_xtrct_seq(pf, fsp, NULL);

	CHECK_EQUAL(-95, val);

	if (hw->fdir_prof) {
		for (i = 0; i < ICE_FLTR_PTYPE_MAX; i++) {
			int tun;
			if (!hw->fdir_prof[i])
				continue;
			for (tun = 0; tun < 2; tun++)
				if (hw->fdir_prof[i]->fdir_seg[tun])
					devm_kfree(dev, hw->fdir_prof[i]->fdir_seg[tun]);
			devm_kfree(dev, hw->fdir_prof[i]);
		}
		devm_kfree(dev, hw->fdir_prof);
	}
	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_cfg_fdir_xtrct_seq_tcp4_nope)
{
	struct ethtool_rx_flow_spec *fsp;
	int val, i;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	fsp->flow_type = TCP_V4_FLOW;
	fsp->m_u.tcp_ip4_spec.ip4src = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.ip4dst = 0xFFFFFFFF;
	fsp->m_u.tcp_ip4_spec.psrc   = 0xFFFF;
	fsp->m_u.tcp_ip4_spec.pdst   = 0xFFFF;

	mock().expectNCalls(2, "ice_flow_add_prof")
		.ignoreOtherParameters();

	mock().expectNCalls(4, "ice_flow_add_entry")
		.ignoreOtherParameters();

	mock().expectNCalls(4, "ice_flow_set_fld")
		.ignoreOtherParameters();

	val = ice_cfg_fdir_xtrct_seq(pf, fsp, NULL);

	CHECK_EQUAL(0, val);

	if (hw->fdir_prof) {
		for (i=0;i<ICE_FLTR_PTYPE_MAX;i++) {
			int tun;
			if (!hw->fdir_prof[i])
				continue;
			for (tun = 0; tun < 2; tun ++)
				if (hw->fdir_prof[i]->fdir_seg[tun])
					devm_kfree(dev, hw->fdir_prof[i]->fdir_seg[tun]);
			devm_kfree(dev, hw->fdir_prof[i]);
		}
		devm_kfree(dev, hw->fdir_prof);
	}
	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_parse_rx_flow_user_data_success_44)
{
	/* small offset value from validation test */
	struct ethtool_rx_flow_spec *fsp;
	struct ice_rx_flow_userdef data;
	u16 value, offset;
	int val;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	value = 0x1234;
	offset = 0x0044;

	fsp->flow_type = FLOW_EXT;
	fill_user_data(value, offset, fsp);

	val = ns_ethtool_fdir::ice_parse_rx_flow_user_data(fsp, &data);

	CHECK_EQUAL(0, val);
	CHECK(data.flex_fltr);
	CHECK_EQUAL(value, data.flex_word);
	CHECK_EQUAL(offset, data.flex_offset);

	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_parse_rx_flow_user_data_success_1fe)
{
	/* 510 (0x1fe) is the largest meaningful value that can be placed in
	 * the flow director filter tables. 511 is a flag value for unused.
	 */
	struct ethtool_rx_flow_spec *fsp;
	struct ice_rx_flow_userdef data;
	u16 value, offset;
	int val;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	value = 0x1234;
	offset = 0x01fe;

	fsp->flow_type = FLOW_EXT;
	fill_user_data(value, offset, fsp);

	val = ns_ethtool_fdir::ice_parse_rx_flow_user_data(fsp, &data);

	CHECK_EQUAL(0, val);
	CHECK(data.flex_fltr);
	CHECK_EQUAL(value, data.flex_word);
	CHECK_EQUAL(offset, data.flex_offset);

	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_parse_rx_flow_user_data_fail_1ff)
{
	/* 510 (0x1fe) is the largest meaningful value that can be placed in
	 * the flow director filter tables. 511 is a flag value for unused.
	 */
	struct ethtool_rx_flow_spec *fsp;
	struct ice_rx_flow_userdef data;
	u16 value, offset;
	int val;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	value = 0x1234;
	offset = 0x0200;

	fsp->flow_type = FLOW_EXT;
	fill_user_data(value, offset, fsp);

	val = ns_ethtool_fdir::ice_parse_rx_flow_user_data(fsp, &data);

	CHECK_EQUAL(-22, val);

	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_parse_rx_flow_user_data_0_mask)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ice_rx_flow_userdef data;
	u16 value, offset;
	int val;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	value = 0x1234;
	offset = 0x0044;

	fsp->flow_type = FLOW_EXT;
	fill_user_data(value, offset, fsp);
	ns_ethtool_fdir::put_unaligned_be64(0, fsp->m_ext.data);

	val = ns_ethtool_fdir::ice_parse_rx_flow_user_data(fsp, &data);

	CHECK_EQUAL(0, val);
	CHECK_EQUAL(0, data.flex_fltr);
	CHECK_EQUAL(0, data.flex_word);
	CHECK_EQUAL(0, data.flex_offset);

	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_parse_rx_flow_user_data_ff_mask_fail)
{
	struct ethtool_rx_flow_spec *fsp;
	struct ice_rx_flow_userdef data;
	u16 value, offset;
	int val;

	fsp = (struct ethtool_rx_flow_spec *)
		calloc(1, sizeof(struct ethtool_rx_flow_spec));

	value = 0x1234;
	offset = 0x0044;

	fsp->flow_type = FLOW_EXT;
	fill_user_data(value, offset, fsp);
	ns_ethtool_fdir::put_unaligned_be64(0xff, fsp->m_ext.data);

	val = ns_ethtool_fdir::ice_parse_rx_flow_user_data(fsp, &data);

	CHECK_EQUAL(-22, val);
	CHECK_EQUAL(0, data.flex_fltr);
	CHECK_EQUAL(0, data.flex_word);
	CHECK_EQUAL(0, data.flex_offset);

	free(fsp);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_write_fltr_success_frag)
{
	struct ice_fdir_fltr *fltr;
	int err;

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	mock().expectOneCall("ice_fdir_has_frag")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectNCalls(2, "ice_fdir_get_prgm_desc")
		.ignoreOtherParameters();
	mock().expectNCalls(2, "ice_fdir_get_gen_prgm_pkt")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(2, "ice_prgm_fdir_fltr")
		.ignoreOtherParameters()
		.andReturnValue(0);
	err = ns_ethtool_fdir::ice_fdir_write_fltr(pf, fltr, true, false);

	CHECK_EQUAL(0, err);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_write_fltr_success_no_frag)
{
	struct ice_fdir_fltr *fltr;
	int err;

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	mock().expectOneCall("ice_fdir_has_frag")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_fdir_get_prgm_desc")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_fdir_get_gen_prgm_pkt")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_prgm_fdir_fltr")
		.ignoreOtherParameters()
		.andReturnValue(0);
	err = ns_ethtool_fdir::ice_fdir_write_fltr(pf, fltr, true, false);

	CHECK_EQUAL(0, err);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_update_list_entry_del_empty)
{
	/* this is test of finding a filter that is not there */
	int fltr_num = 12;
	int value;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)NULL);
	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	value = ns_ethtool_fdir::ice_ntuple_update_list_entry(pf, NULL, fltr_num);

	CHECK_EQUAL(-ENOENT, value);
}

int
ice_create_init_fdir_rule_success_mock(struct ice_pf *pf,
				       enum ice_fltr_ptype flow)
{
	return 0;
}

TEST(ice_ethtool_fdir_calls, test_ice_vsi_manage_fdir_enable)
{
	/* this is test of deleting a filter. */
	clear_bit(ICE_FLAG_FD_ENA, pf->flags);

	USE_MOCK(ice_create_init_fdir_rule,
		 ice_create_init_fdir_rule_success_mock);

	ice_vsi_manage_fdir(vsi, true);

	CHECK_EQUAL(true, test_bit(ICE_FLAG_FD_ENA, pf->flags));
}

TEST(ice_ethtool_fdir_calls, test_ice_vsi_manage_fdir_disable_no_filters)
{
	/* this is test of deleting a filter. */
	set_bit(ICE_FLAG_FD_ENA, pf->flags);

	ice_vsi_manage_fdir(vsi, false);

	CHECK_EQUAL(false, test_bit(ICE_FLAG_FD_ENA, pf->flags));
}

TEST(ice_ethtool_fdir_calls, test_ice_vsi_manage_fdir_disable_filters)
{
	/* this is test of deleting a filter. */
	struct ice_fdir_fltr *fltr, *rule;
	int count = 0;

	set_bit(ICE_FLAG_FD_ENA, pf->flags);
	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	mock().expectNCalls(2, "ice_get_open_tunnel_port")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectNCalls(2, "ice_fdir_update_cntrs")
		.ignoreOtherParameters();

	mock().expectNCalls(2, "ice_fdir_has_frag")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(2, "ice_fdir_get_prgm_desc")
		.ignoreOtherParameters();
	mock().expectNCalls(2, "ice_fdir_get_gen_prgm_pkt")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(2, "ice_prgm_fdir_fltr")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_vsi_manage_fdir(vsi, false);

	CHECK_EQUAL(false, test_bit(ICE_FLAG_FD_ENA, pf->flags));

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
	}
	CHECK_EQUAL(0, count);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_update_list_entry_del_found)
{
	/* this is test of deleting a filter. */
	struct ice_fdir_fltr *fltr, *del_fltr, *rule;
	int fltr_num = 502;
	int count = 0;
	int value;

	USE_STD_MOCK(ice_fdir_do_rem_flow);

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	del_fltr = fltr;
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 100, 503);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)del_fltr);

	mock().expectOneCall("ice_get_open_tunnel_port")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_fdir_update_cntrs")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_fdir_do_rem_flow")
		.withParameter("pf", pf)
		.withParameter("flow_type", ICE_FLTR_PTYPE_NONF_IPV4_TCP);

	mock().expectOneCall("ice_fdir_has_frag")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_fdir_get_prgm_desc")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_fdir_get_gen_prgm_pkt")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_prgm_fdir_fltr")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	value = ns_ethtool_fdir::ice_ntuple_update_list_entry(pf, NULL, fltr_num);

	CHECK_EQUAL(0, value);

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
	}
	CHECK_EQUAL(2, count);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_update_list_entry_del_not_found)
{
	/* this is test of deleting a filter but failing.
	 *
	 * create 3 filters + one filter not in the list
	 * mock - indicates filter not found.
	 * call ice_ntuple_update_list_entry()
	 * check
	 *   the return value should indicate not found error
	 *   there are still 3 filters
	 * delete extra filter if needed
	 */
	struct ice_fdir_fltr *fltr, *del_fltr, *rule;
	int fltr_num = 12;
	int count = 0;
	int value;

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 100, 503);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 504);
	del_fltr = fltr;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void *)NULL);
	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	value = ns_ethtool_fdir::ice_ntuple_update_list_entry(pf, NULL, fltr_num);

	CHECK_EQUAL(-ENOENT, value);

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
	}
	CHECK_EQUAL(3, count);

	if (value == -ENOENT)
		devm_kfree(dev, del_fltr);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_update_list_entry_add_not_found)
{
	/* this is test of insert a filter into list.
	 *
	 * create 3 filters + one filter not in the list
	 * mock - indicates filter not found.
	 * mock - functions to write a filter to HW
	 * call ice_ntuple_update_list_entry()
	 * check
	 *   the return value should indicate no error
	 *   there are 4 filters
	 */
	struct ice_fdir_fltr *fltr, *add_fltr, *rule;
	int fltr_num = 12;
	int count = 0;
	int value;

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 100, 503);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	add_fltr = fltr;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void *)NULL);

	mock().expectOneCall("ice_fdir_list_add_fltr")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_fdir_update_cntrs")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	value = ns_ethtool_fdir::ice_ntuple_update_list_entry(pf, add_fltr, fltr_num);

	CHECK_EQUAL(0, value);

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
	}
	CHECK_EQUAL(4, count);
}

TEST(ice_ethtool_fdir_calls, test_ice_fdir_update_list_entry_add_found)
{
	/* this is test of replacing a filter.
	 *
	 * create 3 filters + one filter not in the list
	 * mock - indicates filter not found.
	 * mock - functions to write a filter to HW
	 * call ice_ntuple_update_list_entry()
	 * check
	 *   the return value should indicate no error
	 *   there are 3 filters
	 */
	struct ice_fdir_fltr *fltr, *add_fltr, *del_fltr, *rule;
	int fltr_num = 12;
	int count = 0;
	int value;

	fltr = TCP4_fltr(dev, 0x89abcdef, 80, 501);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	del_fltr = fltr;
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
	fltr = TCP4_fltr(dev, 0x89abcdef, 100, 503);
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);

	fltr = TCP4_fltr(dev, 0x89abcdef, 90, 502);
	add_fltr = fltr;

	mock().expectOneCall("ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void *)del_fltr);

	mock().expectOneCall("ice_fdir_list_add_fltr")
		.ignoreOtherParameters();

	mock().expectNCalls(2, "ice_fdir_update_cntrs")
		.ignoreOtherParameters();

	mock().expectOneCall("ice_get_open_tunnel_port")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_fdir_has_frag")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("ice_fdir_get_prgm_desc")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_fdir_get_gen_prgm_pkt")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_prgm_fdir_fltr")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	value = ns_ethtool_fdir::ice_ntuple_update_list_entry(pf, add_fltr, fltr_num);

	CHECK_EQUAL(0, value);

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
	}
	CHECK_EQUAL(3, count);
}

void test_set_fsp_tcp4(struct ethtool_rx_flow_spec *fsp, u64 toq, u16 port)
{
	fsp->flow_type = TCP_V4_FLOW;
	fsp->ring_cookie = toq;
	fsp->location = 111;
	fsp->h_u.tcp_ip4_spec.psrc = cpu_to_be16(port);
	fsp->h_u.tcp_ip4_spec.pdst = cpu_to_be16(port);
	fsp->h_u.tcp_ip4_spec.ip4src = cpu_to_be32(0x01020304);
	fsp->h_u.tcp_ip4_spec.ip4dst = cpu_to_be32(0x05060708);
	fsp->m_u.tcp_ip4_spec.psrc = cpu_to_be16(0xffff);
	fsp->m_u.tcp_ip4_spec.pdst = cpu_to_be16(0xffff);
	fsp->m_u.tcp_ip4_spec.ip4src = cpu_to_be32(0xffffffff);
	fsp->m_u.tcp_ip4_spec.ip4dst = cpu_to_be32(0xffffffff);
}

static void
ice_fdir_list_add_fltr_mock(struct ice_hw *hw, struct ice_fdir_fltr *fltr)
{
	LIST_ADD(&fltr->fltr_node, &hw->fdir_list_head);
}

static int
ice_get_fdir_cnt_all_mock(struct ice_hw *hw)
{
	return hw->func_caps.fd_fltr_guar + hw->func_caps.fd_fltr_best_effort;
}

TEST(ice_ethtool_fdir_calls, test_ice_add_fdir_ethtool_drop_rule)
{
	/* This is a test of a ethtool drop filter. It creates a TCP4 drop
	 * filter. It also check that one and only one filter is created.
	 */
	struct ethtool_rx_flow_spec *fsp;
	struct ice_fdir_fltr *rule;
	struct ethtool_rxnfc cmd;
	int count = 0;
	int value;
	u64 port;

	port = 5001;

	fsp = (struct ethtool_rx_flow_spec *)&cmd.fs;
	test_set_fsp_tcp4(fsp, RX_CLS_FLOW_DISC, port);

	set_bit(ICE_FLAG_FD_ENA, pf->flags);

	pf->hw.func_caps.fd_fltr_guar = 512;
	pf->hw.func_caps.fd_fltr_best_effort = 512;

	USE_STD_MOCK(ice_cfg_fdir_xtrct_seq);
	USE_MOCK(ice_fdir_list_add_fltr, ice_fdir_list_add_fltr_mock);
	USE_STD_MOCK(ice_fdir_write_all_fltr);
	USE_MOCK(ice_get_fdir_cnt_all, ice_get_fdir_cnt_all_mock);

	mock().expectOneCall("ice_cfg_fdir_xtrct_seq")
		.withParameter("pf", pf)
		.withParameter("fsp->flow_type", TCP_V4_FLOW)
		.ignoreOtherParameters();

	mock().expectNCalls(2, "ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_get_open_tunnel_port")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectNCalls(2, "ice_fdir_find_fltr_by_idx")
		.ignoreOtherParameters()
		.andReturnValue((void*)NULL);

	mock().expectOneCall("ice_get_hw_vsi_num")
		.ignoreOtherParameters()
		.andReturnValue(1);

	mock().expectOneCall("ice_fdir_is_dup_fltr")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_fdir_update_cntrs");

	mock().expectOneCall("ice_fdir_write_all_fltr")
		.withParameter("pf", pf)
		.ignoreOtherParameters();

	value = ice_add_ntuple_ethtool(vsi, &cmd);

	CHECK_EQUAL(0, value);

	LIST_FOR_EACH_ENTRY(rule, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
		count++;
		CHECK_EQUAL(rule->flow_type, ICE_FLTR_PTYPE_NONF_IPV4_TCP);
		CHECK_EQUAL(rule->dest_ctl, ICE_FLTR_PRGM_DESC_DEST_DROP_PKT);
	}
	CHECK_EQUAL(1, count);
}

TEST_GROUP_BASE(ice_ntuple_calls, ice_ethtool_fdir_base)
{
	void setup() {
		ice_ethtool_fdir_base::setup();
		INIT_LIST_HEAD(&hw->fdir_list_head);
#ifdef ADQ_SUPPORT
		INIT_LIST_HEAD(&vsi->ch_list);
#endif /* ADQ_SUPPORT */
	}
	void teardown() {
		struct ice_fdir_fltr *rule, *tmp;

#ifdef ADQ_SUPPORT
		LIST_DEL(&vsi->ch_list);
#endif /* ADQ_SUPPORT */
		LIST_FOR_EACH_ENTRY_SAFE(rule, tmp, &hw->fdir_list_head, ice_fdir_fltr, fltr_node) {
			LIST_DEL(&rule->fltr_node);
			devm_kfree(dev, rule);
		}
		ice_ethtool_fdir_base::teardown();
	}
};

static void
test_validate_input(struct ethtool_rx_flow_spec *fsp,
		    struct ice_fdir_fltr *input)
{

	CHECK_EQUAL(fsp->location, input->fltr_id);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV4_TCP, input->flow_type);
	CHECK_EQUAL(fsp->ring_cookie, input->q_index);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.psrc, input->ip.v4.src_port);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.pdst, input->ip.v4.dst_port);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.ip4src, input->ip.v4.src_ip);
	CHECK_EQUAL(fsp->h_u.tcp_ip4_spec.ip4dst, input->ip.v4.dst_ip);
	CHECK_EQUAL(fsp->m_u.tcp_ip4_spec.psrc, input->mask.v4.src_port);
	CHECK_EQUAL(fsp->m_u.tcp_ip4_spec.pdst, input->mask.v4.dst_port);
	CHECK_EQUAL(fsp->m_u.tcp_ip4_spec.ip4src, input->mask.v4.src_ip);
	CHECK_EQUAL(fsp->m_u.tcp_ip4_spec.ip4dst, input->mask.v4.dst_ip);
}

TEST(ice_ntuple_calls, test_ice_set_ntuple_input_set_acl)
{
	/* This is a test that validates the input set. */
	struct ethtool_rx_flow_spec fsp;
	struct ice_fdir_fltr input;
	int to_queue;
	u64 port;
	int ret;

	memset(&fsp, 0, sizeof(struct ethtool_rx_flow_spec));
	memset(&input, 0, sizeof(struct ice_fdir_fltr));

	port = 5001;

	/* Drop packet */
	test_set_fsp_tcp4(&fsp, RX_CLS_FLOW_DISC, port);
	ret = ice_ntuple_set_input_set(vsi, ICE_BLK_ACL, &fsp, &input);
	CHECK_EQUAL(ICE_SUCCESS, ret);
	CHECK_EQUAL(fsp.location, input.fltr_id);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV4_TCP, input.flow_type);

	/* Forward to queue 2 */
	to_queue = 2;
	test_set_fsp_tcp4(&fsp, to_queue, port);
	vsi->num_rxq = 4;
	ret = ice_ntuple_set_input_set(vsi, ICE_BLK_ACL, &fsp, &input);
	CHECK_EQUAL(ICE_SUCCESS, ret);

	test_validate_input(&fsp, &input);
}

TEST(ice_ntuple_calls, test_ice_ntuple_set_input_set_invalid_input_acl)
{
	/* This is a test that checks for invalid input */
	struct ethtool_rx_flow_spec fsp;
	struct ice_fdir_fltr input;
	int ret;

	memset(&fsp, 0, sizeof(struct ethtool_rx_flow_spec));
	memset(&input, 0, sizeof(struct ice_fdir_fltr));

	/* Invalid fsp content: num_rxq=0  */
	vsi->num_rxq = 0;
	ret = ice_ntuple_set_input_set(vsi, ICE_BLK_ACL, &fsp, &input);
	CHECK_EQUAL(-EINVAL, ret);

	/* Invalid fsp content: flow_type */
	vsi->num_rxq = 64; /* random number */
	ret = ice_ntuple_set_input_set(vsi, ICE_BLK_ACL, &fsp, &input);
	CHECK_EQUAL(-EINVAL, ret);
}
#endif
