PLDM test files
===============

This directory contains test files which are used within
`test_pldm_fwu.cpp` and `test_ice_fw_update.cpp`. They were originally based
on example NVM images with the proper PLDM header. To save space, the NVM
contents have been stripped out, with the files only containing the header
data. The following is a brief summary of the files.

Unless otherwise specified, the original images these are based off of came
from the following share:

`\\npo\HEBO2\LAD_PAE\TME\Individual_TMEs\Matt Tedford\CVL\NVM\Image Archive\CVL1p3_Beta1`

 - `E810_BACKPLANE_100G_NRB.bin`
   Taken from `E810_BACKPLANE_100G_NRB_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003456.zip`

 - `E810_BACKPLANE_10G_NRB.bin`
   Taken from `E810_BACKPLANE_10G_NRB_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003454.zip`

 - `E810_BACKPLANE_25G_NRB.bin`
   Taken from `E810_BACKPLANE_25G_NRB_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003455.zip`

 - `E810_CQDA1_OCP2_O.bin`
   Taken from `E810_CQDA1_OCP2_O_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003445.zip`

 - `E810_CQDA1_O.bin`
   Taken from `E810_CQDA1_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_8000344F.zip`

 - `E810_CQDA2_OCP_O.bin`
   Taken from `E810_CQDA2_OCP_O_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003444.zip`

 - `E810_CQDA2_O.bin`
   Taken from `E810_CQDA2_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_8000344E.zip`

 - `E810_LDA2_O.bin`
   Taken from `E810_LDA2_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_80003447.zip`

 - `E810_QSFP_100G_NRB_INV.bin`
   Taken from `E810_QSFP_100G_NRB_INV_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003457.zip`

 - `E810_SFP_10G_NRB.bin`
   Taken from `E810_SFP_10G_NRB_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003441.zip`

 - `E810_SFP_25G_NRB_INV.bin`
   Taken from `E810_SFP_25G_NRB_INV_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003442.zip`

 - `E810_SFP_25G_NRB_SD.bin`
   Taken from `E810_SFP_25G_NRB_SD_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_80003450.zip`

 - `E810_XXVDA2_OCP_O.bin`
   Taken from `E810_XXVDA2_OCP_O_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003443.zip`

 - `E810_XXVDA2_SD_OCP_O.bin`
   Taken from `E810_XXVDA2_SD_OCP_O_SEC_FW_1p3p2p0_NVM_0p90_NCSIwPLDMoMCTP_80003451.zip`

 - `E810_XXVDA2_SD_O.bin`
   Taken from `E810_XXVDA2_SD_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_80003452.zip`

 - `E810_XXVDA4_FH_O.bin`
   Taken from `E810_XXVDA4_FH_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_80003453.zip`

 - `E810_XXVDA4_LP_O.bin`
   Taken from `E810_XXVDA4_LP_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_8000344D.zip`

The following image files have not been modified, and include both the PLDM
header and the entire firmware contents. Primarily intended for testing the
complete update flow.

 - `complete_E810_CQDA2_O.bin`
   Taken from `E810_CQDA2_O_SEC_FW_1p3p2p0_NVM_0p90_PLDMoMCTP_8000344E.zip`

The following image files have been modified so that they are invalid, and
are used to ensure that various forms of invalid input are caught by the
parser.

 - `invalid_uuid.bin`
   Copied from `E810_BACKPLANE_25G_NRB.bin`, except the UUID has been
   randomized so that it will not be recognized.

 - `revision_2_not_supported.bin`
   Copied from `E810_CQDA1_OCP2_O.bin` but with the revision field in the
   header set to 0x2.

 - `bitmap_len_not_multiple_of_8.bin`
   Copied from `E810_XXVDA2_OCP_O.bin` but with a bitmap length of 3 bits,
   rather than a multiple of 8.

 - `bitmap_len_too_large.bin`
   Copied from `E810_QSFP_100G_NRB_INV.bin` but with a bitmap length of 2
   bytes, which does not match the size used in each record.

 - `header_size_too_small.bin`
   Copied from `E810_CQDA2_OCP_O.bin` but with a package header size that is
   too small, and does not match the actual size based on the record and
   component areas.

 - `header_size_too_large.bin`
   Copied from `E810_XXVDA4_LP_O.bin` but with a package header size that is
   too large, and does not match the actual size based on the record and
   component areas.

 - `invalid_record_length.bin`
   Copied from `E810_LDA2_O.bin` but with the record length of the first
   record modified to be incorrect.

 - `invalid_record_version_length.bin`
   Copied from `E810_SFP_10G_NRB.bin` but with the version string length in
   the first record incorrect.

 - `invalid_record_package_length.bin`
   Copied from `E810_BACKPLANE_100G_NRB.bin` but with the record package
   data length modified.

 - `invalid_record_desc_count.bin`
   Copied from `E810_XXVDA4_FH_O.bin` but with the record descriptor count
   modified to not match.

 - `invalid_descriptor_length.bin`
   Copied from `E810_XXVDA2_OCP_O.bin` but with the first descriptor TLV
   modified to have an invalid length.

 - `invalid_component_version_length.bin`
   Copied from `E810_CQDA1_O.bin` but with the component version string size
   being invalid.

 - `invalid_crc.bin`
   Copied from `E810_SFP_25G_NRB_SD.bin` but with the CRC modified to be
   invalid.

 - `invalid_crc2.bin`
   Copied from `E810_BACKPLANE_10G_NRB.bin` but with one of the component
   version strings modified so that the CRC32 is bad.
