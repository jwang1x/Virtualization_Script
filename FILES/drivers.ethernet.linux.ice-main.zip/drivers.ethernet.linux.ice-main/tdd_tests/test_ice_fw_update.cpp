#ifdef DEVLINK_SUPPORT
/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"
#include "math.h"
#include <stdint.h>
#include <cstdio>
#include <algorithm>
#include <linux/types.h>
#include <sys/mman.h>
#include "CppUTest/TestHarness.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_fw_update {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "linux/log2.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/compiler.h>
#include <linux/bitmap.h>
#include <linux/kobject.h>

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"

#include "KERNEL_LIBS/crc32.c"

#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/stdmock_ice_fw_update.cpp"

#include "../src/COMPAT/kcompat_pldmfw.c"
#include "../src/CORE/ice_fw_update.c"
}
/////////////////////////////////////////////////
using namespace ns_fw_update;

#include "tdd_fw_object.h"

static const size_t devlink_alloc_size = sizeof(struct devlink) + \
					 sizeof(struct ice_pf);

TEST_GROUP_BASE(setup_pf_structs, load_fw_object)
{
	u8 __aligned(__alignof__(struct devlink)) alloc_data[devlink_alloc_size] = {};
	struct netlink_ext_ack *extack;
	struct devlink *devlink;
	struct pci_dev *pdev;
	struct device *dev;
	struct ice_pf *pf;
	struct ice_hw *hw;

	TEST_SETUP()
	{
		load_fw_object::setup();

		extack = (struct netlink_ext_ack *)calloc(1, sizeof(*extack));

		memset(alloc_data, 0, sizeof(alloc_data));

		devlink = (struct devlink *)alloc_data;
		pf = (struct ice_pf *)devlink_priv(devlink);

		pdev = (struct pci_dev *)calloc(1, sizeof(*pdev));
		pdev->vendor = 0x8086;
		pdev->subsystem_vendor = 0x8086;

		pf->pdev = pdev;

		hw = &pf->hw;
		dev = &pdev->dev;

		/* Firmware update tests produce a lot of debug print
		 * statements which clutter the test output when run in
		 * verbose mode. They aren't very useful for these specific
		 * tests, so we disable printing them for all ice_fw_update.c
		 * tests.
		 */
		mock().setData("disable_dbg_prints", true);
	}

	TEST_TEARDOWN()
	{
		free(pdev);
		free(extack);

		load_fw_object::teardown();
	}
};

TEST_GROUP_BASE(setup_ice_fwu, TGN(setup_pf_structs))
{
	struct ice_fwu_priv priv;
	struct pldmfw *context;

	TEST_SETUP()
	{
		TGN(setup_pf_structs)::setup();

		memset(&priv, 0, sizeof(priv));

		context = &priv.context;
		priv.pf = pf;
		context->dev = dev;
		context->ops = &ice_fwu_ops_e810;
	}

	TEST_TEARDOWN()
	{
		TGN(setup_pf_structs)::teardown();
	}
};

TEST_GROUP_BASE(setup_pldmfw_priv, TGN(setup_ice_fwu))
{
	struct pldmfw_priv data;

	TEST_SETUP()
	{
		TGN(setup_ice_fwu)::setup();

		memset(&data, 0, sizeof(data));

		data.fw = &fw;
		data.context = context;

		INIT_LIST_HEAD(&data.records);
		INIT_LIST_HEAD(&data.components);
	}

	TEST_TEARDOWN()
	{
		pldmfw_free_priv(&data);

		TGN(setup_ice_fwu)::teardown();
	}
};

TEST_GROUP_BASE(send_pkg_data, TGN(setup_pldmfw_priv))
{
	TEST_SETUP()
	{
		TGN(setup_pldmfw_priv)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(setup_pldmfw_priv)::teardown();
	}
};

TEST(send_pkg_data, fake_package_data)
{
	static const u8 expected[] = { 0xDE, 0xAD, 0xBE, 0xEF };
	int err;

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected, sizeof(expected))
		.withParameter("length", sizeof(expected))
		.withParameter("cd", (void *)NULL);

	err = ice_send_package_data(context, expected, sizeof(expected));
	CHECK_EQUAL(0, err);
}

TEST(send_pkg_data, set_package_data_fails)
{
	static const u8 expected[] = { 0xDE, 0xAD, 0xBE, 0xEF };
	int err;

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected, sizeof(expected))
		.withParameter("length", sizeof(expected))
		.withParameter("cd", (void *)NULL)
		.andReturnValue(ICE_ERR_OUT_OF_RANGE);

	mock().expectOneCall("ice_aq_str");

	err = ice_send_package_data(context, expected, sizeof(expected));
	CHECK_EQUAL(-EIO, err);
}

static const u8 expected_E810_LDA2_O_pkg_data[] = {
	0x02, 0x00, 0x01, 0x00, 0x24, 0x00, 0x57, 0x01, 0x90, 0x15,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x57, 0x01, 0x90, 0x15, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00,
	0x13, 0x00, 0x27, 0x01, 0x00, 0x00, 0x10, 0x00, 0x4e, 0x3a,
	0x30, 0x31, 0x36, 0x38, 0x33, 0x34, 0x34, 0x37, 0x4f, 0x3a,
	0x30, 0x31, 0x30, 0x41, 0x36, 0x33, 0x30, 0x30, 0x54, 0x3a,
	0x30, 0x30, 0x30, 0x31, 0x30, 0x30, 0x30, 0x31, 0x00, 0x00
};

TEST(send_pkg_data, pkg_data_E810_LDA2_O)
{
	int err;

	tdd_load_fw("pldm_fw_files/E810_LDA2_O.bin");

	pdev->device = 0x1592;

	err = pldm_parse_image(&data);
	CHECK_EQUAL(0, err);

	err = pldm_find_matching_record(&data);
	CHECK_EQUAL(0, err);

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_LDA2_O_pkg_data,
			       sizeof(expected_E810_LDA2_O_pkg_data))
		.withParameter("length", sizeof(expected_E810_LDA2_O_pkg_data))
		.withParameter("cd", (void *)NULL);

	err = pldm_send_package_data(&data);
	CHECK_EQUAL(0, err);
}

TEST_GROUP_BASE(component_tables, TGN(send_pkg_data))
{
	TEST_SETUP()
	{
		TGN(send_pkg_data)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(send_pkg_data)::teardown();
	}
};

static const u8 expected_E810_QSFP_100G_NRB_INV_pkg_data[] = {
	0x02, 0x00, 0x01, 0x00, 0x24, 0x00, 0x57, 0x01, 0x90, 0x15,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x57, 0x01, 0x90, 0x15, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00,
	0x13, 0x00, 0x27, 0x01, 0x00, 0x00, 0x10, 0x00, 0x4e, 0x3a,
	0x30, 0x31, 0x36, 0x38, 0x33, 0x34, 0x35, 0x37, 0x4f, 0x3a,
	0x30, 0x31, 0x30, 0x41, 0x36, 0x33, 0x30, 0x30, 0x54, 0x3a,
	0x30, 0x30, 0x30, 0x31, 0x30, 0x30, 0x30, 0x31, 0x00, 0x00
};

static const u8 expected_E810_QSFP_100G_NRB_INV_nvm_tbl[] = {
	0x0A, 0x00, 0x06, 0x00, 0x00, 0x57, 0x34, 0x68, 0x01, 0x01,
	0x12, 0x30, 0x31, 0x36, 0x38, 0x33, 0x34, 0x35, 0x37, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x00
};

static const u8 expected_E810_QSFP_100G_NRB_INV_orom_tbl[] = {
	0x0A, 0x00, 0x05, 0x00, 0x00, 0x00, 0x63, 0x0A, 0x01, 0x01,
	0x12, 0x30, 0x31, 0x30, 0x41, 0x36, 0x33, 0x30, 0x30, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x00
};

static const u8 expected_E810_QSFP_100G_NRB_INV_netlist_tbl[] = {
	0x0A, 0x00, 0x08, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
	0x2A, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x2E, 0x32,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x33, 0x2E, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x31, 0x35, 0x37, 0x2E, 0x30, 0x30, 0x30,
	0x30, 0x00, 0x00,
};

TEST(component_tables, tables_E810_QSFP_100G_NRB_INV)
{
	u8 response = 0, response_code = 0;
	int err;

	tdd_load_fw("pldm_fw_files/E810_QSFP_100G_NRB_INV.bin");

	pdev->device = 0x1592;

	err = pldm_parse_image(&data);
	CHECK_EQUAL(0, err);

	err = pldm_find_matching_record(&data);
	CHECK_EQUAL(0, err);

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_QSFP_100G_NRB_INV_pkg_data,
			       sizeof(expected_E810_QSFP_100G_NRB_INV_pkg_data))
		.withParameter("length", sizeof(expected_E810_QSFP_100G_NRB_INV_pkg_data))
		.withParameter("cd", (void *)NULL);

	err = pldm_send_package_data(&data);
	CHECK_EQUAL(0, err);

	mock().checkExpectations();

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_START)
		.withParameter("data", expected_E810_QSFP_100G_NRB_INV_nvm_tbl,
			       sizeof(expected_E810_QSFP_100G_NRB_INV_nvm_tbl))
		.withParameter("length", sizeof(expected_E810_QSFP_100G_NRB_INV_nvm_tbl))
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_QSFP_100G_NRB_INV_orom_tbl,
			       sizeof(expected_E810_QSFP_100G_NRB_INV_orom_tbl))
		.withParameter("length", sizeof(expected_E810_QSFP_100G_NRB_INV_orom_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_MIDDLE)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_QSFP_100G_NRB_INV_netlist_tbl,
			       sizeof(expected_E810_QSFP_100G_NRB_INV_netlist_tbl))
		.withParameter("length", sizeof(expected_E810_QSFP_100G_NRB_INV_netlist_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_END)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	err = pldm_send_component_tables(&data);
	CHECK_EQUAL(0, err);
}

/**
 * fake_ice_aq_update_nvm - fake implementation for updating NVM contents
 * @hw: pointer to the HW struct
 * @module_typeid: module pointer location in words from the NVM beginning
 * @offset: byte offset from the module beginning
 * @length: length of the section to be read (in bytes from the offset)
 * @data: command buffer (size [bytes] = length)
 * @last_command: tells if this is the last command in a series
 * @command_flags: command parameters
 * @cd: pointer to command details structure or NULL
 *
 * Writes to the fake NVM contents by accessing them from the fake() data
 *
 * The "nvm_contents" and "nvm_size" refer to the module specified by
 * ICE_SR_1ST_NVM_BANK_PTR, the "orom_contents" and "orom_size" refer to
 * the module specified by ICE_SR_1ST_OROM_BANK_PTR, and finally
 * "netlist_contents" and "netlist_size" refer to the module specified by
 * ICE_SR_NETLIST_BANK_PTR.
 *
 * On success, sets "last_nvm_command", "last_nvm_module" and
 * "last_nvm_offset" appropriately.
 *
 * Sets "nvm_ready" to false, in order to force code to check the completion
 * status as required.
 */
static enum ice_status
fake_ice_aq_update_nvm(struct ice_hw *hw, u16 module_typeid, u32 offset,
		       u16 length, void *data, bool last_command,
		       u8 command_flags, struct ice_sq_cd *cd)
{
	u32 total_length;
	u8 *contents;

	/* In offset the highest byte must be zeroed. */
	if (offset & 0xFF000000)
		return ICE_ERR_PARAM;

	/* The real function on real hardware will return ICE_ERR_PARAM if the
	 * length requested is zero.
	 */
	if (!length)
		return ICE_ERR_PARAM;

	switch (module_typeid) {
	case ICE_SR_1ST_OROM_BANK_PTR:
		contents = (u8 *)mock().getData("orom_contents").getObjectPointer();
		total_length = mock().getData("orom_size").getUnsignedIntValue();
		break;
	case ICE_SR_1ST_NVM_BANK_PTR:
		contents = (u8 *)mock().getData("nvm_contents").getObjectPointer();
		total_length = mock().getData("nvm_size").getUnsignedIntValue();
		break;
	case ICE_SR_NETLIST_BANK_PTR:
		contents = (u8 *)mock().getData("netlist_contents").getObjectPointer();
		total_length = mock().getData("netlist_size").getUnsignedIntValue();
		break;
	default:
		FAIL("Unexpected module_typeid");
		return ICE_ERR_PARAM;
	}

	if (!mock().getData("nvm_ready").getBoolValue()) {
		hw->adminq.sq_last_status = ICE_AQ_RC_EBUSY;
		return ICE_ERR_AQ_ERROR;
	}

	if (offset + length > total_length)
		/* Requested contents are outside of NVM space */
		return ICE_ERR_AQ_ERROR;

	memcpy(contents + offset, data, length);

	mock().setData("last_nvm_command", ice_aqc_opc_nvm_write);
	mock().setData("last_nvm_offset", offset);
	mock().setData("last_nvm_module", module_typeid);
	mock().setData("nvm_ready", false);

	return ICE_SUCCESS;
}

/**
 * fake_ice_aq_update_nvm - fake implementation for erasing an NVM module
 * @hw: pointer to the HW struct
 * @module_typeid: module pointer location in words from the NVM beginning
 * @cd: pointer to command details structure or NULL
 *
 * Sets "last_nvm_command", "last_nvm_module" and "last_nvm_offset"
 * appropriately.
 *
 * Sets "nvm_ready" to false, in order to force code to check the completion
 * status as required.
 */
static enum ice_status
fake_ice_aq_erase_nvm(struct ice_hw *hw, u16 module_typeid,
		      struct ice_sq_cd *cd)
{
	switch (module_typeid) {
	case ICE_SR_1ST_NVM_BANK_PTR:
	case ICE_SR_1ST_OROM_BANK_PTR:
	case ICE_SR_NETLIST_BANK_PTR:
		break;
	default:
		FAIL("Unexpected module_typeid");
		return ICE_ERR_PARAM;
	}

	if (!mock().getData("nvm_ready").getBoolValue()) {
		hw->adminq.sq_last_status = ICE_AQ_RC_EBUSY;
		return ICE_ERR_AQ_ERROR;
	}

	mock().setData("last_nvm_command", ice_aqc_opc_nvm_erase);
	mock().setData("last_nvm_offset", 0);
	mock().setData("last_nvm_module", module_typeid);
	mock().setData("nvm_ready", false);

	return ICE_SUCCESS;
}

/**
 * fake_ice_nvm_write_activate - fake implementation for activating NVM
 * @hw: pointer to the HW struct
 * @cmd`_flags: flags to send with the command
 *
 * Sets "last_nvm_command", "last_nvm_module" and "last_nvm_offset"
 * appropriately.
 *
 * Sets "nvm_ready" to false, in order to force code to check the completion
 * status as required.
 *
 * Still uses mock().actualCall() since we do not expect many calls to this
 * function.
 */
static enum ice_status
fake_ice_nvm_write_activate(struct ice_hw *hw, u16 cmd_flags, u8 *response_flags)
{
	if (!mock().getData("nvm_ready").getBoolValue()) {
		hw->adminq.sq_last_status = ICE_AQ_RC_EBUSY;
		return ICE_ERR_AQ_ERROR;
	}

	mock().setData("last_nvm_command", ice_aqc_opc_nvm_write_activate);
	mock().setData("last_nvm_offset", 0);
	mock().setData("last_nvm_module", 0);
	mock().setData("nvm_ready", false);

	mock().actualCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameter("response_flags", response_flags);

	return (enum ice_status)mock().returnIntValueOrDefault(0);
}

/**
 * fake_ice_aq_wait_for_event - fake implementation returning last fw event
 * @pf: pointer to the PF data structure
 * @opcode: the opcode being waited for
 * @timeout: how long to wait (unused)
 * @event: storage for the event
 *
 * Read "last_nvm_command", "last_nvm_module", and "last_nvm_offset" to
 * determine the previous firmware command that was executed.
 *
 * Update the event indicator and then mark the "nvm_ready" as true, allowing
 * future commands to succeed.
 */
static int
fake_ice_aq_wait_for_event(struct ice_pf *pf, u16 opcode, unsigned long timeout,
			   struct ice_rq_event_info *event)
{
	u32 offset;
	u16 module;

	if (!mock().hasData("last_nvm_command") ||
	    !mock().hasData("last_nvm_offset") ||
	    !mock().hasData("last_nvm_module"))
		return -ETIMEDOUT;

	if (mock().getData("last_nvm_command").getUnsignedIntValue() != opcode)
		return -ETIMEDOUT;

	module = mock().getData("last_nvm_module").getUnsignedIntValue();
	offset = mock().getData("last_nvm_offset").getUnsignedIntValue();

	event->desc.retval = CPU_TO_LE16(0);
	event->desc.params.nvm.module_typeid = module;
	event->desc.params.nvm.offset_low = CPU_TO_LE16(offset & 0xFFFFFFFF);
	event->desc.params.nvm.offset_high = (offset >> 16) & 0xFF;

	mock().setData("nvm_ready", true);

	return 0;
}

static void
fake_devlink_flash_update_status_notify(struct devlink *devlink,
					const char *status_msg,
					const char *component,
					unsigned long done,
					unsigned long total)
{
#if 0
	/* this might be useful for debugging, but otherwise is just clutter */
	fprintf(stderr, "%s: %s (%lu/%lu)\n", component, status_msg, done,
		total);
#endif
}

static void
fake_devlink_flash_update_timeout_notify(struct devlink *devlink,
					 const char *status_msg,
					 const char *component,
					 unsigned long timeout)
{
#if 0
	/* this might be useful for debugging, but otherwise is just clutter */
	fprintf(stderr, "%s: %s (timeout %lu)\n", component, status_msg, timeout);
#endif
}

static enum ice_fw_modes fake_ice_get_fw_mode(struct ice_hw *hw)
{
	if (mock().hasData("fw_mode"))
		return (enum ice_fw_modes)mock().getData("fw_mode").getIntValue();
	else
		return ICE_FW_MODE_NORMAL;
}

TEST_GROUP_BASE(flash_image, TGN(setup_pf_structs))
{
	struct devlink_flash_update_params params = {};
	detour_function *get_fw_mode;

	TEST_SETUP()
	{
		TGN(setup_pf_structs)::setup();

		params.fw = &fw;

		hw->dev_caps.common_cap.nvm_unified_update = true;

		ALLOC_NEW_MOCK(get_fw_mode, ice_get_fw_mode, fake_ice_get_fw_mode);
	}

	TEST_TEARDOWN()
	{
		DELETE_MOCK(get_fw_mode);

		TGN(setup_pf_structs)::teardown();
	}
};

TEST(flash_image, recovery_mode_not_supported)
{
	int err;

	mock().setData("fw_mode", ICE_FW_MODE_REC);

	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(-EOPNOTSUPP, err);
}

TEST(flash_image, no_unified_support)
{
	int err;

	hw->dev_caps.common_cap.nvm_unified_update = false;

	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(-EOPNOTSUPP, err);
}

TEST_GROUP_BASE(write_flash, TGN(flash_image))
{
	u32 nvm_offset, orom_offset, netlist_offset;
	u32 nvm_len, orom_len, netlist_len;
	u8 *nvm, *orom, *netlist;

	TEST_SETUP()
	{
		TGN(flash_image)::setup();

		nvm_offset = 135574;
		nvm_len = 4300800;
		nvm = (u8 *)calloc(nvm_len, sizeof(char));
		if (!nvm)
			FAIL("Unable to allocate space for NVM contents");

		mock().setDataObject("nvm_contents", "u8[]", nvm);
		mock().setData("nvm_size", nvm_len);

		orom_offset = 8737174;
		orom_len = 512000;
		orom = (u8 *)calloc(orom_len, sizeof(char));
		if (!orom)
			FAIL("Unable to allocate space for OROM contents");

		mock().setDataObject("orom_contents", "u8[]", orom);
		mock().setData("orom_size", orom_len);

		netlist_offset = 9761174;
		netlist_len = 28672;
		netlist = (u8 *)calloc(orom_len, sizeof(char));
		if (!netlist)
			FAIL("Unable to allocate space for NetList contents");

		mock().setDataObject("netlist_contents", "u8[]", netlist);
		mock().setData("netlist_size", netlist_len);

		mock().setData("nvm_ready", true);

		pdev->device = 0x1592;
	}

	TEST_TEARDOWN()
	{
		free(nvm);
		free(orom);
		free(netlist);

		TGN(flash_image)::teardown();
	}
};

static const u8 expected_E810_CQDA2_O_pkg_data[] = {
	0x02, 0x00, 0x01, 0x00, 0x24, 0x00, 0x57, 0x01, 0x90, 0x15,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x57, 0x01, 0x90, 0x15, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00,
	0x13, 0x00, 0x27, 0x01, 0x00, 0x00, 0x10, 0x00, 0x4E, 0x3A,
	0x30, 0x31, 0x36, 0x38, 0x33, 0x34, 0x34, 0x45, 0x4F, 0x3A,
	0x30, 0x31, 0x30, 0x41, 0x36, 0x33, 0x30, 0x30, 0x54, 0x3A,
	0x30, 0x30, 0x30, 0x31, 0x30, 0x30, 0x30, 0x31, 0x00, 0x00,
};

static const u8 expected_E810_CQDA2_O_nvm_tbl[] = {
	0x0A, 0x00, 0x06, 0x00, 0x00, 0x4E, 0x34, 0x68, 0x01, 0x01,
	0x12, 0x30, 0x31, 0x36, 0x38, 0x33, 0x34, 0x34, 0x45, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x00,
};

static const u8 expected_E810_CQDA2_O_orom_tbl[] = {
	0x0A, 0x00, 0x05, 0x00, 0x00, 0x00, 0x63, 0x0A, 0x01, 0x01,
	0x12, 0x30, 0x31, 0x30, 0x41, 0x36, 0x33, 0x30, 0x30, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x00
};

static const u8 expected_E810_CQDA2_O_netlist_tbl[] = {
	0x0A, 0x00, 0x08, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01,
	0x2A, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x2E,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x2E, 0x32,
	0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x33, 0x2E, 0x30, 0x30,
	0x30, 0x30, 0x30, 0x31, 0x35, 0x37, 0x2E, 0x30, 0x30, 0x30,
	0x30, 0x00, 0x00,
};

TEST(write_flash, write_complete_E810_CQDA2_O)
{
	u8 response = 0, response_code = 0;
	u8 cmd_flags;
	int err;

	USE_STD_MOCK(ice_cancel_pending_update);
	USE_MOCK(ice_aq_update_nvm, fake_ice_aq_update_nvm);
	USE_MOCK(ice_aq_erase_nvm, fake_ice_aq_erase_nvm);
	USE_MOCK(ice_aq_wait_for_event, fake_ice_aq_wait_for_event);
	USE_MOCK(ice_nvm_write_activate, fake_ice_nvm_write_activate);
	USE_MOCK(devlink_flash_update_status_notify,
		 fake_devlink_flash_update_status_notify);
	USE_MOCK(devlink_flash_update_timeout_notify,
		 fake_devlink_flash_update_timeout_notify);

	tdd_load_fw("pldm_fw_files/complete_E810_CQDA2_O.bin", false);

	cmd_flags = (ICE_AQC_NVM_PRESERVE_ALL |
		     ICE_AQC_NVM_ACTIV_SEL_OROM |
		     ICE_AQC_NVM_ACTIV_SEL_NVM |
		     ICE_AQC_NVM_ACTIV_SEL_NETLIST);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_cancel_pending_update")
		.withParameter("pf", pf)
		.withParameter("component", (const char *)NULL)
		.withParameter("extack", extack);

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_CQDA2_O_pkg_data,
			       sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_START)
		.withParameter("data", expected_E810_CQDA2_O_nvm_tbl,
			       sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_orom_tbl,
			       sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_MIDDLE)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_netlist_tbl,
			       sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_END)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(fw.data + nvm_offset, nvm, nvm_len);
	MEMCMP_EQUAL(fw.data + orom_offset, orom, orom_len);
	MEMCMP_EQUAL(fw.data + netlist_offset, netlist, netlist_len);
}

TEST(write_flash, write_complete_E810_CQDA2_O_allow_downgrade)
{
	u8 response = 0, response_code = 0, nvm_response, nvm_response_code;
	u8 cmd_flags;
	int err;

	/* Indicate that the NVM component would be a downgrade */
	nvm_response = ICE_AQ_NVM_PASS_COMP_CAN_MAY_BE_UPDATEABLE;
	nvm_response_code = ICE_AQ_NVM_PASS_COMP_STAMP_LOWER;

	USE_STD_MOCK(ice_cancel_pending_update);
	USE_MOCK(ice_aq_update_nvm, fake_ice_aq_update_nvm);
	USE_MOCK(ice_aq_erase_nvm, fake_ice_aq_erase_nvm);
	USE_MOCK(ice_aq_wait_for_event, fake_ice_aq_wait_for_event);
	USE_MOCK(ice_nvm_write_activate, fake_ice_nvm_write_activate);
	USE_MOCK(devlink_flash_update_status_notify,
		 fake_devlink_flash_update_status_notify);
	USE_MOCK(devlink_flash_update_timeout_notify,
		 fake_devlink_flash_update_timeout_notify);

	tdd_load_fw("pldm_fw_files/complete_E810_CQDA2_O.bin", false);

	cmd_flags = (ICE_AQC_NVM_PRESERVE_ALL |
		     ICE_AQC_NVM_ACTIV_SEL_OROM |
		     ICE_AQC_NVM_ACTIV_SEL_NVM |
		     ICE_AQC_NVM_ACTIV_SEL_NETLIST);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_cancel_pending_update")
		.withParameter("pf", pf)
		.withParameter("component", (const char *)NULL)
		.withParameter("extack", extack);

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_CQDA2_O_pkg_data,
			       sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_START)
		.withParameter("data", expected_E810_CQDA2_O_nvm_tbl,
			       sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withOutputParameterReturning("comp_response", &nvm_response, sizeof(nvm_response))
		.withOutputParameterReturning("comp_response_code", &nvm_response_code, sizeof(nvm_response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_orom_tbl,
			       sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_MIDDLE)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_netlist_tbl,
			       sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_END)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(fw.data + nvm_offset, nvm, nvm_len);
	MEMCMP_EQUAL(fw.data + orom_offset, orom, orom_len);
	MEMCMP_EQUAL(fw.data + netlist_offset, netlist, netlist_len);
}

TEST(write_flash, write_complete_E810_CQDA2_O_preserve_selected)
{
	u8 response = 0, response_code = 0;
	u8 cmd_flags;
	int err;

	USE_STD_MOCK(ice_cancel_pending_update);
	USE_MOCK(ice_aq_update_nvm, fake_ice_aq_update_nvm);
	USE_MOCK(ice_aq_erase_nvm, fake_ice_aq_erase_nvm);
	USE_MOCK(ice_aq_wait_for_event, fake_ice_aq_wait_for_event);
	USE_MOCK(ice_nvm_write_activate, fake_ice_nvm_write_activate);
	USE_MOCK(devlink_flash_update_status_notify,
		 fake_devlink_flash_update_status_notify);
	USE_MOCK(devlink_flash_update_timeout_notify,
		 fake_devlink_flash_update_timeout_notify);

	tdd_load_fw("pldm_fw_files/complete_E810_CQDA2_O.bin", false);

	cmd_flags = (ICE_AQC_NVM_PRESERVE_SELECTED |
		     ICE_AQC_NVM_ACTIV_SEL_OROM |
		     ICE_AQC_NVM_ACTIV_SEL_NVM |
		     ICE_AQC_NVM_ACTIV_SEL_NETLIST);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_cancel_pending_update")
		.withParameter("pf", pf)
		.withParameter("component", (const char *)NULL)
		.withParameter("extack", extack);

	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_CQDA2_O_pkg_data,
			       sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_START)
		.withParameter("data", expected_E810_CQDA2_O_nvm_tbl,
			       sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_orom_tbl,
			       sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_MIDDLE)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_netlist_tbl,
			       sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_END)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameterReturning("response_flags", NULL, 0);

	/* PRESERVE_LIMITED will not trigger an EMP reset */

	mock().expectOneCall("ice_release_nvm");

	params.overwrite_mask = DEVLINK_FLASH_OVERWRITE_SETTINGS;
	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(fw.data + nvm_offset, nvm, nvm_len);
	MEMCMP_EQUAL(fw.data + orom_offset, orom, orom_len);
	MEMCMP_EQUAL(fw.data + netlist_offset, netlist, netlist_len);
}

TEST(write_flash, write_complete_E810_CQDA2_O_no_preservation)
{
	u8 response = 0, response_code = 0;
	u8 cmd_flags;
	int err;

	USE_STD_MOCK(ice_cancel_pending_update);
	USE_MOCK(ice_aq_update_nvm, fake_ice_aq_update_nvm);
	USE_MOCK(ice_aq_erase_nvm, fake_ice_aq_erase_nvm);
	USE_MOCK(ice_aq_wait_for_event, fake_ice_aq_wait_for_event);
	USE_MOCK(ice_nvm_write_activate, fake_ice_nvm_write_activate);
	USE_MOCK(devlink_flash_update_status_notify,
		 fake_devlink_flash_update_status_notify);
	USE_MOCK(devlink_flash_update_timeout_notify,
		 fake_devlink_flash_update_timeout_notify);

	tdd_load_fw("pldm_fw_files/complete_E810_CQDA2_O.bin");

	cmd_flags = (ICE_AQC_NVM_NO_PRESERVATION |
		     ICE_AQC_NVM_ACTIV_SEL_OROM |
		     ICE_AQC_NVM_ACTIV_SEL_NVM |
		     ICE_AQC_NVM_ACTIV_SEL_NETLIST);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_cancel_pending_update")
		.withParameter("pf", pf)
		.withParameter("component", (const char *)NULL)
		.withParameter("extack", extack);


	mock().expectOneCall("ice_nvm_set_pkg_data")
		.withParameter("hw", hw)
		.withParameter("del_pkg_data_flag", false)
		.withParameter("data", expected_E810_CQDA2_O_pkg_data,
			       sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_pkg_data))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_START)
		.withParameter("data", expected_E810_CQDA2_O_nvm_tbl,
			       sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_nvm_tbl))
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_orom_tbl,
			       sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_orom_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_MIDDLE)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_pass_component_tbl")
		.withParameter("hw", hw)
		.withParameter("data", expected_E810_CQDA2_O_netlist_tbl,
			       sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("length", sizeof(expected_E810_CQDA2_O_netlist_tbl))
		.withParameter("transfer_flag", ICE_AQ_NVM_PASS_COMP_TBL_END)
		.withOutputParameterReturning("comp_response", &response, sizeof(response))
		.withOutputParameterReturning("comp_response_code", &response_code, sizeof(response_code))
		.withParameter("cd", (void *)NULL);

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", cmd_flags)
		.withOutputParameterReturning("response_flags", NULL, 0);

	/* PRESERVE_NONE will not perform a reset */

	mock().expectOneCall("ice_release_nvm");

	params.overwrite_mask = (DEVLINK_FLASH_OVERWRITE_SETTINGS |
				 DEVLINK_FLASH_OVERWRITE_IDENTIFIERS);
	err = ice_flash_pldm_image(devlink, &params, extack);
	CHECK_EQUAL(0, err);

	MEMCMP_EQUAL(fw.data + nvm_offset, nvm, nvm_len);
	MEMCMP_EQUAL(fw.data + orom_offset, orom, orom_len);
	MEMCMP_EQUAL(fw.data + netlist_offset, netlist, netlist_len);
}

TEST_GROUP_BASE(cancel_pending_update, TGN(setup_pf_structs))
{
	struct ice_hw_dev_caps *dev_caps;

	TEST_SETUP()
	{
		TGN(setup_pf_structs)::setup();

		dev_caps = (struct ice_hw_dev_caps *)calloc(1, sizeof(*dev_caps));

	}

	TEST_TEARDOWN()
	{
		free(dev_caps);

		TGN(setup_pf_structs)::teardown();
	}
};

TEST(cancel_pending_update, nothing_pending)
{
	int err;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}


TEST(cancel_pending_update, pending_update_nvm)
{
	u16 retval = 0;
	int err;

	dev_caps->common_cap.nvm_update_pending_nvm = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_NVM | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_aq_wait_for_event")
		.withParameter("pf", pf)
		.withParameter("opcode", ice_aqc_opc_nvm_write_activate)
		.withParameter("timeout", 30*HZ)
		.withOutputParameterReturning("event->desc.retval", &retval, sizeof(retval))
		.withOutputParameterReturning("event->desc.params", (void *)NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, pending_update_orom)
{
	u16 retval = 0;
	int err;

	dev_caps->common_cap.nvm_update_pending_orom = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_OROM | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_aq_wait_for_event")
		.withParameter("pf", pf)
		.withParameter("opcode", ice_aqc_opc_nvm_write_activate)
		.withParameter("timeout", 30*HZ)
		.withOutputParameterReturning("event->desc.retval", &retval, sizeof(retval))
		.withOutputParameterReturning("event->desc.params", (void *)NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, pending_update_netlist)
{
	u16 retval = 0;
	int err;

	dev_caps->common_cap.nvm_update_pending_netlist = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_NETLIST | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_aq_wait_for_event")
		.withParameter("pf", pf)
		.withParameter("opcode", ice_aqc_opc_nvm_write_activate)
		.withParameter("timeout", 30*HZ)
		.withOutputParameterReturning("event->desc.retval", &retval, sizeof(retval))
		.withOutputParameterReturning("event->desc.params", (void *)NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, pending_update_orom_specific_component)
{
	u16 retval = 0;
	int err;

	dev_caps->common_cap.nvm_update_pending_orom = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_OROM | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_aq_wait_for_event")
		.withParameter("pf", pf)
		.withParameter("opcode", ice_aqc_opc_nvm_write_activate)
		.withParameter("timeout", 30*HZ)
		.withOutputParameterReturning("event->desc.retval", &retval, sizeof(retval))
		.withOutputParameterReturning("event->desc.params", (void *)NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, ignore_pending_update_on_other_component)
{
	int err;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	dev_caps->common_cap.nvm_update_pending_netlist = true;

	err = ice_cancel_pending_update(pf, "fw.mgmt", extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, revert_previous_pending_nvm_update)
{
	u16 retval = 0;
	int err;

	/* indicate that there is a pending NVM update already */
	dev_caps->common_cap.nvm_update_pending_nvm = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_NVM | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0);

	mock().expectOneCall("ice_aq_wait_for_event")
		.withParameter("pf", pf)
		.withParameter("opcode", ice_aqc_opc_nvm_write_activate)
		.withParameter("timeout", 30*HZ)
		.withOutputParameterReturning("event->desc.retval", &retval, sizeof(retval))
		.withOutputParameterReturning("event->desc.params", (void *)NULL, 0);

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(0, err);
}

TEST(cancel_pending_update, revert_previous_pending_nvm_update_fails)
{
	int err;

	/* indicate that there is a pending NVM update already */
	dev_caps->common_cap.nvm_update_pending_nvm = true;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	mock().expectOneCall("devlink_flash_update_status_notify")
		.withParameter("devlink", devlink)
		.withParameter("status_msg", "Canceling previous pending update")
		.withParameter("component", (const char *)NULL)
		.withParameter("done", 0)
		.withParameter("total", 0);

	mock().expectOneCall("ice_acquire_nvm");

	mock().expectOneCall("ice_nvm_write_activate")
		.withParameter("hw", hw)
		.withParameter("cmd_flags", ICE_AQC_NVM_ACTIV_SEL_NVM | ICE_AQC_NVM_REVERT_LAST_ACTIV)
		.withOutputParameterReturning("response_flags", NULL, 0)
		.andReturnValue(ICE_ERR_PARAM);

	mock().expectOneCall("ice_aq_str");

	mock().expectOneCall("ice_release_nvm");

	err = ice_cancel_pending_update(pf, NULL, extack);
	CHECK_EQUAL(-EIO, err);
}

TEST(cancel_pending_update, get_pending_update)
{
	u8 pending;
	int err;

	mock().expectOneCall("ice_discover_dev_caps")
		.withParameter("hw", hw)
		.withOutputParameterReturning("dev_caps", dev_caps, sizeof(*dev_caps));

	err = ice_get_pending_updates(pf, &pending, extack);
	CHECK_EQUAL(0, err);

	CHECK_EQUAL(0, pending);
}
#endif /* DEVLINK_SUPPORT */
