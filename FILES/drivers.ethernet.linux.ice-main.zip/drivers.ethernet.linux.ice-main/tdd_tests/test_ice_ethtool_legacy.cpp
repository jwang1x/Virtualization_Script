#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_legacy_ethtool {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/compiler.h>
#include <linux/pm_wakeup.h>
#include <linux/bitmap.h>

#include "../src/CORE/ice.h"

/* move into legacy mode */
#ifdef ETHTOOL_GLINKSETTINGS
#undef ETHTOOL_GLINKSETTINGS
#endif

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"

#include "CORE_MOCKS/stdmock_ice_header.cpp"

#include "../src/CORE/ice_ethtool.c"
}
/////////////////////////////////////////////////
using namespace ns_legacy_ethtool;

class PhyCapsDataCopier : public MockNamedValueCopier
{
	public:
		virtual void copy(void *out, const void *in)
		{
			*(struct ice_aqc_get_phy_caps_data *)out =
				*(const struct ice_aqc_get_phy_caps_data *)in;
		}
};

class PhyCfgDataComparator : public MockNamedValueComparator
{
	public:
		virtual bool isEqual(const void *obj1, const void *obj2)
		{
			struct ice_aqc_set_phy_cfg_data *d1 =
				(struct ice_aqc_set_phy_cfg_data *)obj1;
			struct ice_aqc_set_phy_cfg_data *d2 =
				(struct ice_aqc_set_phy_cfg_data *)obj2;

			bool result = true;

			if (d1->phy_type_low != d2->phy_type_low) {
				printf("expected phy_type_low = 0x%llx\n"
				       "actual phy_type_low   = 0x%llx\n",
				       d1->phy_type_low, d2->phy_type_low);
				result = false;
			}
			if (d1->phy_type_high != d2->phy_type_high) {
				printf("expected phy_type_high = 0x%llx\n"
				       "actual phy_type_high   = 0x%llx\n",
				       d1->phy_type_high, d2->phy_type_high);
				result = false;
			}
			if (d1->caps != d2->caps) {
				printf("expected caps = 0x%02x\n"
				       "actual caps   = 0x%02x\n",
				       d1->caps, d2->caps);
				result = false;
			}
			if (d1->low_power_ctrl_an != d2->low_power_ctrl_an) {
				printf("expected low_power_ctrl_an = 0x%02x\n"
				       "actual low_power_ctrl_an   = 0x%02x\n",
				       d1->low_power_ctrl_an,
				       d2->low_power_ctrl_an);
				result = false;
			}
			if (d1->eee_cap != d2->eee_cap) {
				printf("expected eee_cap = 0x%04x\n"
				       "actual eee_cap   = 0x%04x\n",
				       d1->eee_cap, d2->eee_cap);
				result = false;
			}
			if (d1->eeer_value != d2->eeer_value) {
				printf("expected eeer_value = 0x%04x\n"
				       "actual eeer_value   = 0x%04x\n",
				       d1->eeer_value, d2->eeer_value);
				result = false;
			}
			if (d1->link_fec_opt != d2->link_fec_opt) {
				printf("expected link_fec_opt = 0x%02x\n"
				       "actual link_fec_opt   = 0x%02x\n",
				       d1->link_fec_opt, d2->link_fec_opt);
				result = false;
			}
			if (!result)
				printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n"
				       "Error, actual/expected ice_aqc_set_phy_cfg_data"
				       " does not match!\n");

			return result;
		}

		virtual SimpleString valueToString(const void *obj)
		{
			return StringFrom(obj);
		}
};

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

/* tests begin */
TEST_GROUP(ice_nic_legacy_ethtool)
{
	/* these stick around for the life of the test */
	PhyCfgDataComparator phyCfgDataComparator;
	PhyCapsDataCopier phyCapsDataCopier;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 5, 5);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		np->vsi = vsi;
		np->vsi->back = pf;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
		vsi->alloc_txq = 5;
		vsi->alloc_rxq = 5;
		vsi->num_txq = 1;
		vsi->num_rxq = 1;
		vsi->rx_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		vsi->tx_rings = (struct ice_ring **)calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT
		vsi->num_xdp_txq = 5;
		vsi->xdp_rings = (struct ice_ring **)calloc(vsi->num_xdp_txq, sizeof(struct ice_ring *));
		for (int i = 0; i < vsi->num_xdp_txq; i++)
			vsi->xdp_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */
		for (int i = 0; i < vsi->alloc_txq; i++)
			vsi->tx_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		for (int i = 0; i < vsi->alloc_rxq; i++)
			vsi->rx_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		vsi->port_info->lport = 0;
		hw = (struct ice_hw *)calloc(1, sizeof(struct ice_hw));
		hw->back = pf;
		vsi->port_info->hw = hw;
		hw->hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(struct ice_vsi*));
		pf->vsi[0] = vsi;

		pf->hw.func_caps.common_cap.num_txq = 128;
		pf->hw.func_caps.common_cap.num_rxq = 256;

		mock().installCopier("struct ice_aqc_get_phy_caps_data *",
				     phyCapsDataCopier);
		mock().installComparator("struct ice_aqc_set_phy_cfg_data *",
					 phyCfgDataComparator);
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		mock().removeAllComparatorsAndCopiers();

		for (int i = 0; i < vsi->alloc_txq; i++)
			free(vsi->tx_rings[i]);
		for (int i = 0; i < vsi->alloc_rxq; i++)
			free(vsi->rx_rings[i]);
		free(vsi->rx_rings);
		free(vsi->tx_rings);
#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT
		for (int i = 0; i < vsi->num_xdp_txq; i++) {
			free(vsi->xdp_rings[i]->tx_buf);
			free(vsi->xdp_rings[i]);
		}
		free(vsi->xdp_rings);
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */
		free(vsi->port_info);
		free(vsi);
		free_netdev(netdev);
		free(pf->vsi);
		free(pf->pdev);
		free(pf);
		free(hw->hw_addr);
		free(hw);

		netdev = NULL;
		vsi = NULL;
		np = NULL;
		pf = NULL;
	}
};

static void
set_default_phy_type_and_speed(struct ethtool_link_ksettings *ks_expected,
			       struct ice_port_info *pi)
{
	memset(ks_expected, 0, sizeof(struct ethtool_link_ksettings));

	pi->phy.phy_type_low =
		(ICE_PHY_TYPE_LOW_100BASE_TX | ICE_PHY_TYPE_LOW_1000BASE_T |
		 ICE_PHY_TYPE_LOW_1000BASE_SX | ICE_PHY_TYPE_LOW_1000BASE_KX |
		 ICE_PHY_TYPE_LOW_2500BASE_T | ICE_PHY_TYPE_LOW_2500BASE_X |
		 ICE_PHY_TYPE_LOW_10GBASE_T | ICE_PHY_TYPE_LOW_10GBASE_KR_CR1 |
		 ICE_PHY_TYPE_LOW_10GBASE_SR | ICE_PHY_TYPE_LOW_40GBASE_KR4 |
		 ICE_PHY_TYPE_LOW_40GBASE_CR4 | ICE_PHY_TYPE_LOW_40GBASE_SR4 |
		 ICE_PHY_TYPE_LOW_40GBASE_LR4);
	pi->phy.link_info.req_speeds =
		(ICE_AQ_LINK_SPEED_100MB | ICE_AQ_LINK_SPEED_1000MB |
		 ICE_AQ_LINK_SPEED_2500MB | ICE_AQ_LINK_SPEED_5GB |
		 ICE_AQ_LINK_SPEED_10GB | ICE_AQ_LINK_SPEED_25GB |
		 ICE_AQ_LINK_SPEED_40GB);
#ifdef HAVE_ETHTOOL_5G_BITS
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_5GBASE_T;
#endif /* HAVE_ETHTOOL_5G_BITS */
#ifdef HAVE_ETHTOOL_25G_BITS
	pi->phy.phy_type_low |=
		(ICE_PHY_TYPE_LOW_25GBASE_T | ICE_PHY_TYPE_LOW_25GBASE_SR |
		 ICE_PHY_TYPE_LOW_25GBASE_KR);
#endif /* HAVE_ETHTOOL_25G_BITS */
#ifdef HAVE_ETHTOOL_50G_BITS
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_50GB;
	pi->phy.phy_type_low |=
		(ICE_PHY_TYPE_LOW_50GBASE_CR2 | ICE_PHY_TYPE_LOW_50GBASE_KR2);
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_50GB;
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_50GBASE_SR2;
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
#warning never!
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_100GBASE_SR4;
	pi->phy.phy_type_high = ICE_PHY_TYPE_HIGH_100G_CAUI2_AOC_ACC;
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_100GB;
#endif /* HAVE_ETHTOOL_100G_BITS */

	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100baseT_Full);
#ifdef HAVE_ETHTOOL_NEW_1G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseX_Full);
#endif /* HAVE_ETHTOOL_NEW_1G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseKX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseKX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     2500baseX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     2500baseX_Full);
#ifdef HAVE_ETHTOOL_NEW_2500MB_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     2500baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     2500baseT_Full);
#endif  /* HAVE_ETHTOOL_NEW_2500MB_BITS */
#ifdef HAVE_ETHTOOL_5G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     5000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     5000baseT_Full);
#endif /* HAVE_ETHTOOL_5G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseKR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseKR_Full);
#ifdef HAVE_ETHTOOL_NEW_10G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseSR_Full);
#endif /* HAVE_ETHTOOL_NEW_10G_BITS */
#ifdef HAVE_ETHTOOL_25G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseCR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseCR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseKR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseKR_Full);
#endif /* HAVE_ETHTOOL_25G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseKR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseKR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseLR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseLR4_Full);
#ifdef HAVE_ETHTOOL_50G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseCR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseCR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseKR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseKR2_Full);
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseSR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseSR2_Full);
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100000baseSR4_Full);
#endif /* HAVE_ETHTOOL_100G_BITS */
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_phy_type_caps_to_ethtool)
{
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;
	unsigned int idx = 0;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));

	set_default_phy_type_and_speed(&ks_expected, pi);

	ice_phy_type_to_ethtool(netdev, &ks);

	for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
		CHECK_EQUAL(ks_expected.link_modes.supported[idx],
			    ks.link_modes.supported[idx]);
		CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
			    ks.link_modes.advertising[idx]);
	}
}

#ifndef BMSM_MODE
TEST(ice_nic_legacy_ethtool,  legacy_ice_set_pauseparam)
{
	struct ethtool_pauseparam *pp = (struct ethtool_pauseparam *)calloc(1, sizeof(ethtool_pauseparam));
	u8 out;
	int status;
	struct ice_port_info *pi=np->vsi->port_info;
#ifndef NO_DCB_SUPPORT
	struct ice_dcbx_cfg *dcbx_cfg = &pi->qos_cfg.local_dcbx_cfg;
#endif /* !NO_DCB_SUPPORT */

	/* If VSI type is not PF, return error */
	pp->autoneg = pi->phy.link_info.an_info & ICE_AQ_AN_COMPLETED;
	vsi->type = ICE_VSI_VF;
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* If trying to change autoneg with ethtool -A, return error */
	vsi->type = ICE_VSI_PF;
	pp->autoneg = 1;
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* If pfc is enabled, return error */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 1;
#endif
	pp->autoneg = 0;
	mock().ignoreOtherCalls();
	status = ice_set_pauseparam(netdev, pp);

	/* If set_fc function returns error, return error */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	pp->rx_pause = 1;
	out = ICE_SET_FC_AQ_FAIL_GET;
	set_bit(ICE_DOWN, vsi->back->state);
	mock().expectOneCall("ice_aq_str");
	mock().expectOneCall("ice_set_fc")
		.withOutputParameterReturning("aq_failures", &out, sizeof(out))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EAGAIN, status);

	/* Successful setting pauseparam */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	pp->rx_pause = 1;
	pp->autoneg = 1;
	pi->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	out = 0;
	clear_bit(ICE_DOWN, vsi->back->state);
	mock().expectOneCall("ice_set_fc")
		.withOutputParameterReturning("aq_failures", &out, sizeof(out))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(0, status);

	free(pp);

}
#endif /* !BMSM_MODE */

#ifdef ETHTOOL_GFECPARAM

#else /* ETHTOOL_GFECPARAM */
TEST(ice_nic_legacy_ethtool,  legacy_ice_get_pauseparam)
{
	struct ethtool_pauseparam *pp = (struct ethtool_pauseparam *)calloc(1, sizeof(ethtool_pauseparam));
	struct ice_port_info *pi=np->vsi->port_info;
#ifndef NO_DCB_SUPPORT
	struct ice_dcbx_cfg *dcbx_cfg = &pi->qos_cfg.local_dcbx_cfg;
#endif

	pp->autoneg = pi->phy.link_info.an_info & ICE_AQ_AN_COMPLETED;

	/* PFC enabled so report LFC as off */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 1;
#endif
	ice_get_pauseparam(netdev, pp);
	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(0, pp->rx_pause);
	CHECK_EQUAL(0, pp->tx_pause);

#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	/* Report RX on, the legacy test works like FVL did in i40e
	 * and reports the value of runtime in the legacy way
	 */
	pi->phy.link_info.an_info = 0;
	pi->fc.current_mode = ICE_FC_RX_PAUSE;

	ice_get_pauseparam(netdev, pp);

	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(1, pp->rx_pause);
	CHECK_EQUAL(0, pp->tx_pause);

	/* Report TX on */
	pi->phy.link_info.an_info = 0;
	pi->fc.current_mode = ICE_FC_TX_PAUSE;

	ice_get_pauseparam(netdev, pp);

	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(0, pp->rx_pause);
	CHECK_EQUAL(1, pp->tx_pause);

	/* Report TX on, RX on */
	pi->phy.link_info.an_info = 0;
	pi->fc.current_mode = ICE_FC_FULL;

	ice_get_pauseparam(netdev, pp);

	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(1, pp->rx_pause);
	CHECK_EQUAL(1, pp->tx_pause);

	free(pp);
}
#endif /* ETHTOOL_GFECPARAM */

TEST_GROUP_BASE(ice_legacy_set_ringparam, TGN(ice_nic_legacy_ethtool))
{
	struct ethtool_ringparam *rp;
#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
	struct bpf_prog *xdp_prog;
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

	TEST_SETUP()
	{
		TGN(ice_nic_legacy_ethtool)::setup();

		rp = (struct ethtool_ringparam *)calloc(1, sizeof(ethtool_ringparam));
#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
		xdp_prog = (struct bpf_prog*)calloc(1, sizeof(struct bpf_prog));
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */
	}

	TEST_TEARDOWN()
	{
		free(rp);
		rp = NULL;

#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
		free(xdp_prog);
		xdp_prog = NULL;
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

		TGN(ice_nic_legacy_ethtool)::teardown();
	}
};

TEST(ice_legacy_set_ringparam,  legacy_tx_below_minimum)
{
	int status;

	/* Tx descriptor minimum boundary case */
	rp->tx_pending = 7;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-EINVAL, status);
}

TEST(ice_legacy_set_ringparam,  legacy_rx_below_minimum)
{
	int status;

	/* Rx descriptor maximum boundary case */
	rp->rx_pending = 8166;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-EINVAL, status);
}

TEST(ice_legacy_set_ringparam,  legacy_no_change_in_tx_or_rx)
{
	int status, i;

	/* No change in descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[i]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
}

TEST(ice_legacy_set_ringparam,  legacy_change_tx_count)
{
	int status, i;

	/* Change in Tx descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 128;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	mock().expectNCalls(vsi->num_txq, "ice_setup_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_txq, "ice_free_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	ice_for_each_txq(vsi, i)
		CHECK_EQUAL(rp->tx_pending, vsi->tx_rings[i]->count);
}

#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
TEST(ice_legacy_set_ringparam,  legacy_change_xdp_count)
{
	int status, i;

	/* Change in Xdp descriptor count */
	clear_bit(ICE_VSI_DOWN, vsi->state);
	clear_bit(ICE_CFG_BUSY, np->vsi->back->state);
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	for (int i = 0; i < vsi->num_xdp_txq; i++)
		vsi->xdp_rings[i]->count = 128;
	rp->tx_pending =  64;
	vsi->xdp_prog = xdp_prog;
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	USE_STD_MOCK(ice_set_ring_xdp);
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
	mock().expectNCalls(vsi->num_txq + vsi->num_xdp_txq, "ice_setup_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_xdp_txq, "ice_set_ring_xdp")
		.ignoreOtherParameters();
	mock().expectNCalls(vsi->num_txq + vsi->num_xdp_txq, "ice_free_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	for (int i = 0; i < vsi->num_xdp_txq; i++)
		CHECK_EQUAL(rp->tx_pending, vsi->xdp_rings[i]->count);
}
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

TEST(ice_legacy_set_ringparam,  legacy_alloc_rx_bufs_fails)
{
	int status, i;

	/* Test ice_alloc_rx_bufs() fail case */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 128;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	mock().expectOneCall("ice_setup_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_alloc_rx_bufs")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	mock().expectOneCall("netif_running");

	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-ENOMEM, status);
	ice_for_each_rxq(vsi, i)
		CHECK_EQUAL(128, vsi->rx_rings[i]->count);
}

TEST(ice_legacy_set_ringparam,  legacy_change_rx_count)
{
	int status, i;

	/* Change in Rx descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 128;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	mock().expectNCalls(vsi->num_rxq, "ice_alloc_rx_bufs")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(vsi->num_rxq, "ice_setup_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_rxq, "ice_free_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	for (int i = 0; i < vsi->num_rxq; i++)
		CHECK_EQUAL(rp->rx_pending, vsi->rx_rings[i]->count);
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_get_drvinfo)
{
	struct ethtool_drvinfo *di = (struct ethtool_drvinfo *)calloc(1, sizeof(ethtool_drvinfo));
	struct ice_pf *pf = np->vsi->back;
	struct ice_hw *hw = &(pf->hw);

	hw->flash.nvm.eetrack = 0;
	hw->flash.nvm.major = 1;
	hw->flash.nvm.minor = 5;
	hw->flash.orom.major = 3;
	hw->flash.orom.build = 27;
	hw->flash.orom.patch = 9;

	ice_get_drvinfo(netdev, di);

	STRCMP_EQUAL(di->driver, KBUILD_MODNAME);
	STRCMP_EQUAL(di->version, ::ice_drv_ver);
	STRCMP_EQUAL(di->fw_version, "1.05 0x0 3.27.9");
	STRCMP_EQUAL(di->bus_info, pci_name(vsi->back->pdev));

	free(di);
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_set_get_msglevel)
{
	struct ice_pf *pf = np->vsi->back;
	u32 mask = 1;

	for (int i = 0; i < 31; i++) {
		mask |= (1 << i);
		ice_set_msglevel(netdev, mask);
		CHECK_EQUAL(mask, ice_get_msglevel(netdev));
		CHECK_EQUAL(mask, pf->msg_enable);
	}
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_get_regs_len)
{
	CHECK_EQUAL(sizeof(ice_regs_dump_list), ice_get_regs_len(netdev));
}

/* This allows TEST(ice_nic_legacy_ethtool,  legacy_ice_get_regs) to be able to determine how big
 * of a fake register address space it needs to allocate to test ice_get_regs.  This
 * allows further registers to be added to ice_regs_dump_list without having to change
 * this test.
 */
static u32 ice_regs_dump_list_largest_addr()
{
	u32 largest_addr;

	largest_addr = ice_regs_dump_list[0];
	for (unsigned int i = 1; i < ARRAY_SIZE(ice_regs_dump_list); ++i) {
		if (largest_addr < ice_regs_dump_list[i])
			largest_addr = ice_regs_dump_list[i];
	}

	return largest_addr;
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_get_regs)
{
	struct ice_pf *pf = np->vsi->back;
	struct ice_hw *hw = &(pf->hw);
	struct ethtool_regs regs;
	u32 *regs_buf;
	unsigned int num_regs;

	num_regs = ARRAY_SIZE(ice_regs_dump_list);
	/* Allocate memory to fake out hw registers */
	hw->hw_addr = (u8*) calloc(ice_regs_dump_list_largest_addr(), sizeof(u32));
	regs_buf = (u32 *)calloc(num_regs, sizeof(u32));

	for (u32 i = 0; i < num_regs; ++i)
		wr32(hw, ice_regs_dump_list[i], i);

	ice_get_regs(netdev, &regs, (void *)regs_buf);

	for (u32 i = 0; i < num_regs; ++i)
		CHECK_EQUAL(i, regs_buf[i]);

	free(regs_buf);
	free(hw->hw_addr);
}

#ifndef BMSM_MODE
TEST(ice_nic_legacy_ethtool,  legacy_ice_nway_reset)
{
	int status;

	/* Successful restart */
	mock().expectOneCall("ice_set_link")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_nway_reset(netdev);
	CHECK_EQUAL(0, status);

	/* Unsuccessful restart */
	mock().expectOneCall("ice_set_link")
		.ignoreOtherParameters()
		.andReturnValue(-EINVAL);
	status = ice_nway_reset(netdev);
	CHECK_EQUAL(-EINVAL, status);
}
#endif /* !BMSM_MODE */

#ifndef SWITCH_MODE
TEST(ice_nic_legacy_ethtool,  legacy_ice_get_ts_info)
{
	struct ice_pf *pf = np->vsi->back;
	struct ethtool_ts_info info;
	int status;

	set_bit(ICE_FLAG_PTP, pf->flags);
	ice_get_ts_info(netdev, &info);
	status = info.tx_types & BIT(HWTSTAMP_TX_OFF);
	CHECK_EQUAL(1, status);
}
#endif

TEST_GROUP(ice_legacy_ethtool_eeprom_ops)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_hw *hw;
	struct ice_pf *pf;
	struct ethtool_eeprom *eeprom;

	#define EXPECTED_MAGIC hw->vendor_id | (hw->device_id << 16)

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf = np->vsi->back;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		hw = &pf->hw;
		eeprom = (struct ethtool_eeprom *)calloc(1, sizeof(struct ethtool_eeprom));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(pf->pdev);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		free(eeprom);
	}
};

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_write_nvm_nomagic)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the "normal" set_nvm fails */
	eeprom->magic = EXPECTED_MAGIC;
	eeprom->len = 13;
	eeprom->offset = 0;

	expected_buf[0] = 0xFF;
	expected_buf[13] = 0xEE;

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(-EOPNOTSUPP, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_write_nvm_ok)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the set_eeprom works with the new way */
	eeprom->magic = hw->device_id << 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(0, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_write_nvm_nvmup)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;
	union ice_nvm_access_data *data;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the set_eeprom works with the new way */
	eeprom->cmd = ETHTOOL_SEEPROM; /* READ_NVM */
	data = (union ice_nvm_access_data *)buf;

	eeprom->magic = (u32)hw->device_id << 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(0, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_read_nvm_with_4k_page_size)
{
	int result;
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;
	hw->flash.sr_words = 32768;
	eeprom->magic = 0; /* magic is not set for normal ethtool reads */
	eeprom->len = 13;
	eeprom->offset = 0;

	expected_buf[0] = 0xFF;
	expected_buf[13] = 0xEE;

	mock().expectOneCall("ice_acquire_nvm")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_read_flat_nvm")
		.withParameter("offset", eeprom->offset)
		.withParameter("length", eeprom->len)
		.withOutputParameterReturning("length", NULL, 0)
		.withOutputParameterReturning("data", expected_buf, eeprom->len)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_release_nvm")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_get_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(0, result);
	CHECK_EQUAL((u32)EXPECTED_MAGIC, eeprom->magic);
	MEMCMP_EQUAL(expected_buf, buf, eeprom->len);

	free(expected_buf);
	free(buf);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_get_eeprom_len)
{
	int result;

	hw->flash.flash_size = 12 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);
	CHECK_EQUAL(12 * 1024 * 1024, result);
 }

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_get_eeprom_len_10MB_minimum)
{
	int result;

	hw->flash.flash_size = 4 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);
	CHECK_EQUAL(10 * 1024 * 1024, result);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_get_eeprom_len_nvm_access_regs)
{
	int result;

	/* Report a really small flash size */
	hw->flash.flash_size = 1 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);

	/* Make sure that the reported length is always larger than each of
	 * the registers that could be accessed using the QV Tools interface
	 */

	CHECK_TRUE(GL_HICR + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HICR_EN + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_FWSTS + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_MNG_FWSM + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLGEN_CSR_DEBUG_C + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLGEN_RSTAT + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLPCI_LBARCTRL + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLNVM_GENS + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLNVM_FLA + sizeof(u32) < (u32)result);
	CHECK_TRUE(PF_FUNC_RID + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HIDA(GL_HIDA_MAX_INDEX) + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HIBA(GL_HIBA_MAX_INDEX) + sizeof(u32) < (u32)result);
}

TEST(ice_legacy_ethtool_eeprom_ops,  legacy_ice_set_eeprom_nvmup)
{
	int result;
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	struct ice_nvm_access_cmd *cmd;
	union ice_nvm_access_data *data;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;
	hw->flash.sr_words = 4096;
	cmd = (struct ice_nvm_access_cmd *)eeprom;
	cmd->command = 0xB; /* do a read */
	cmd->config =
		0xEULL | /* module */
		0xFULL << ICE_NVM_CFG_FLAGS_S | /* flags */
		0x0ULL << ICE_NVM_CFG_EXT_FLAGS_S | /* ext flags */
		0x0ULL << ICE_NVM_CFG_ADAPTER_INFO_S | /* info */
		hw->device_id << 16;
	cmd->offset = 0;
	cmd->data_size = 16;

	data = (union ice_nvm_access_data *)expected_buf;
	data->drv_features.features[0] = BIT_ULL(1);
	data->drv_features.major = 0;
	data->drv_features.minor = 5;
	data->drv_features.size = 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(0, result);
	MEMCMP_EQUAL(expected_buf, buf, data->drv_features.size);

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_NO_MEMORY);

	result = ice_set_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(ICE_ERR_NO_MEMORY, result);

	free(expected_buf);
	free(buf);
}

TEST_GROUP(ice_legacy_linux_no_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		np->vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		mock().disable();
	}

	void teardown(void)
	{
		free(np->vsi->back->pdev);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_legacy_linux_no_test,  legacy_no_test)
{
	ice_get_sset_count(netdev, 0);
	ice_get_sset_count(netdev, 1);
	ice_set_ethtool_ops(netdev);
}

#ifndef BMSM_MODE
TEST(ice_nic_legacy_ethtool,  legacy_ice_get_wake_on_LAN)
{
	struct ethtool_wolinfo *wol;
	struct ice_pf *pf;

	pf = np->vsi->back;
	wol = (struct ethtool_wolinfo *)calloc(1, sizeof(ethtool_wolinfo));

	/* Test getting WoL not_supported/disabled scenario */
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(false);

	ice_get_wol(netdev, wol);
	CHECK_EQUAL(0, wol->supported);
	CHECK_EQUAL(0, wol->wolopts);

	/* Test getting WoL supported/enabled scenario */
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(true);
	pf->wol_ena = true;
	ice_get_wol(netdev, wol);
	CHECK_EQUAL(WAKE_MAGIC, wol->supported);
	CHECK_EQUAL(WAKE_MAGIC, wol->wolopts);

	free(wol);
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_set_wake_on_LAN)
{
	struct ethtool_wolinfo *wol;
	struct ice_pf *pf;
	int status;

	pf = np->vsi->back;
	wol = (struct ethtool_wolinfo *)calloc(1, sizeof(ethtool_wolinfo));

	/* Setting WoL on non PF VSI type - WoL supported on only PF VSI */
	vsi->type = ICE_VSI_VMDQ2;
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* Test setting unsupported WoL type, instead of magic packet */
	wol->wolopts = WAKE_ARP;
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* Test successful setting WoL with magic packet */
	vsi->type = ICE_VSI_PF;
	wol->wolopts = WAKE_MAGIC;
	pf->wol_ena = true;
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(true);
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(0, status);
	free(wol);
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_reg_test)
{
	int status;

	status = ice_reg_test(netdev);
	CHECK_EQUAL(0, status);
}
#endif /* !BMSM_MODE */

#ifndef SWITCH_MODE
TEST(ice_nic_legacy_ethtool,  legacy_ice_parse_hdrs)
{
	u32 hdrs;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	nfc->flow_type = TCP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_TCP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = UDP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_UDP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = SCTP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_SCTP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = TCP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_TCP | ICE_FLOW_SEG_HDR_IPV6);

	nfc->flow_type = UDP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_UDP | ICE_FLOW_SEG_HDR_IPV6);

	nfc->flow_type = SCTP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_SCTP | ICE_FLOW_SEG_HDR_IPV6);

	free(nfc);
}
TEST(ice_nic_legacy_ethtool,  legacy_ice_parse_hash_flds)
{
	u64 hash_flds;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	hash_flds = ice_parse_hash_flds(nfc);
	CHECK_EQUAL(hash_flds, ICE_FLOW_HASH_FLD_IPV4_SA);

	nfc->flow_type = UDP_V4_FLOW;
	nfc->data = RXH_IP_SRC | RXH_L4_B_2_3;
	hash_flds = ice_parse_hash_flds(nfc);
	CHECK_EQUAL(hash_flds, ICE_FLOW_HASH_FLD_IPV4_SA |
		      ICE_FLOW_HASH_FLD_UDP_DST_PORT);
	free(nfc);
}
TEST(ice_nic_legacy_ethtool,  legacy_ice_set_rss_hash_opt)
{
	struct ice_vsi *vsi = np->vsi;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	mock().ignoreOtherCalls();

	/* Invalid input, currently only supported flow types are: UDP, TCP, SCTP */
	nfc->flow_type = AH_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	CHECK_EQUAL(-EINVAL,ice_set_rss_hash_opt(vsi, nfc));

	/* Successful call of ice_add_rss_cfg function */
	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	mock().expectOneCall("ice_add_rss_cfg").andReturnValue(ICE_SUCCESS);
	CHECK_EQUAL(ICE_SUCCESS,ice_set_rss_hash_opt(vsi, nfc));

	/* ice_add_rss_cfg function returns error */
	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_DST;
	mock().expectOneCall("ice_add_rss_cfg")
		.andReturnValue(ICE_ERR_PARAM);
	CHECK_EQUAL(-EINVAL,ice_set_rss_hash_opt(vsi, nfc));

	free(nfc);
}
TEST(ice_nic_legacy_ethtool,  legacy_ice_get_rss_hash_opt)
{
	struct ice_vsi *vsi = np->vsi;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	set_bit(ICE_FLAG_ADV_FEATURES, pf->flags);
	mock().expectOneCall("ice_get_rss_cfg").andReturnValue(0);
	mock().expectOneCall("ice_is_safe_mode").andReturnValue(false);

	nfc->flow_type = TCP_V4_FLOW;
	ice_get_rss_hash_opt(vsi, nfc);
	CHECK_EQUAL(nfc->data, 0);
	free(nfc);
}

#endif /* SWITCH_MODE */
#ifdef FDIR_SUPPORT
TEST_GROUP(ice_legacy_fdir_ethtool_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(np->vsi->back);
		free(vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_legacy_fdir_ethtool_test,  legacy_ice_get_rxnfc_count)
{
#ifndef SWITCH_MODE
	struct ice_hw *hw = &(vsi->back->hw);
#endif /* !SWITCH_MODE */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRLCNT;
	cmd.rule_cnt = 0;
	cmd.data = 0;

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_get_fdir_fltr_ids_per_port")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	hw->fdir_active_fltr = 11;

	mock().expectOneCall("ice_ntuple_get_max_fltr_cnt")
		.ignoreOtherParameters()
		.andReturnValue(12);
#endif /* SWITCH_MODE */

	ice_get_rxnfc(netdev, &cmd, &not_used);

#ifndef SWITCH_MODE
	CHECK_EQUAL(11, cmd.rule_cnt);
	CHECK_EQUAL(12, cmd.data);
#endif /* !SWITCH_MODE */
}

TEST(ice_legacy_fdir_ethtool_test,  legacy_ice_get_rxnfc_rule)
{
	/* This is just testing that the function ice_get_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRULE;

	mock().expectOneCall("ice_get_ethtool_fdir_entry")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_get_rxnfc(netdev, &cmd, &not_used);

}

TEST(ice_legacy_fdir_ethtool_test,  legacy_ice_get_rxnfc_ids)
{
	/* This is just testing that the function ice_get_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRLALL;
#ifdef SWITCH_MODE
	mock().expectOneCall("ice_get_fdir_fltr_ids_per_port")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	mock().expectOneCall("ice_get_fdir_fltr_ids")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* SWITCH_MODE */

	ice_get_rxnfc(netdev, &cmd, &not_used);
}

TEST(ice_legacy_fdir_ethtool_test,  legacy_ice_set_rxnfc_add)
{
	/* This is just testing that the function ice_set_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;

	cmd.cmd = ETHTOOL_SRXCLSRLINS;

	mock().expectOneCall("ice_add_ntuple_ethtool")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_rxnfc(netdev, &cmd);
}

TEST(ice_legacy_fdir_ethtool_test,  legacy_ice_set_rxnfc_del)
{
	/* This is just testing that the function ice_set_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;

	cmd.cmd = ETHTOOL_SRXCLSRLDEL;

	mock().expectOneCall("ice_del_ntuple_ethtool")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_rxnfc(netdev, &cmd);
}

TEST(ice_nic_legacy_ethtool,  legacy_ice_get_channels)
{
	struct ethtool_channels ch;
	u32 num_online_cpus = 8;

	pf->num_lan_msix = 8;
	pf->hw.func_caps.common_cap.num_rxq = 1024;
	pf->hw.func_caps.common_cap.num_txq = 1024;
	pf->max_qps = num_online_cpus;
	ice_get_channels(netdev, &ch);

	CHECK_EQUAL(ch.rx_count, vsi->num_rxq);
	CHECK_EQUAL(ch.max_rx, num_online_cpus);
	CHECK_EQUAL(ch.tx_count, vsi->num_txq);
	CHECK_EQUAL(ch.max_tx, num_online_cpus);
	CHECK_EQUAL(ch.other_count, 0);
	CHECK_EQUAL(ch.max_other, 0);
}

#endif /* FDIR_SUPPORT */

TEST_GROUP(ice_ethtool_legacy_set_phys_id)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		np->vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(np->vsi->port_info);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_ethtool_legacy_set_phys_id,  legacy_ice_set_phys_id)
{
	int status;

	mock().expectOneCall("ice_aq_set_port_id_led")
		.withParameter("is_orig_mode", false)
		.ignoreOtherParameters()
		.andReturnValue(0);

	status = ice_set_phys_id(netdev, ETHTOOL_ID_ACTIVE);
	CHECK_EQUAL(status, 0);

	mock().expectOneCall("ice_aq_set_port_id_led")
		.withParameter("is_orig_mode", true)
		.ignoreOtherParameters()
		.andReturnValue(0);

	status = ice_set_phys_id(netdev, ETHTOOL_ID_INACTIVE);
	CHECK_EQUAL(status, 0);
}

TEST_GROUP(ice_legacy_coalesce)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void init_qs_and_vectors(int alloc_txq, int alloc_rxq, int num_txq,
				 int num_rxq, int num_q_vectors)
	{
		int i;

		vsi->num_q_vectors = num_q_vectors;
		vsi->q_vectors = (struct ice_q_vector **)calloc
			(vsi->num_q_vectors, sizeof(struct ice_q_vector *));
		ice_for_each_q_vector(vsi, i)
			vsi->q_vectors[i] = (struct ice_q_vector *)
				calloc(1, sizeof(struct ice_q_vector));

		vsi->alloc_txq = alloc_txq;
		vsi->alloc_rxq = alloc_rxq;
		vsi->num_txq = num_txq;
		vsi->num_rxq = num_rxq;

		vsi->rx_rings = (struct ice_ring **)
			calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_rxq; ++i) {
			vsi->rx_rings[i] = NULL;
			if (i >= vsi->num_rxq)
				break;
			vsi->rx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->rx_rings[i]->next = NULL;
		}

		vsi->tx_rings = (struct ice_ring **)
			calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_txq; ++i) {
			vsi->tx_rings[i] = NULL;
			if (i >= vsi->num_txq)
				break;
			vsi->tx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->tx_rings[i]->next = NULL;
		}

		ice_for_each_q_vector(vsi, i) {
			struct ice_q_vector *q_vector = vsi->q_vectors[i];

			q_vector->vsi = vsi;

			q_vector->rx.ring = vsi->rx_rings[i];
			if (q_vector->rx.ring) {
				q_vector->rx.ring->q_vector = q_vector;
				q_vector->rx.ring->vsi = vsi;
			}

			q_vector->tx.ring = vsi->tx_rings[i];
			if (q_vector->tx.ring) {
				q_vector->tx.ring->q_vector = q_vector;
				q_vector->tx.ring->vsi = vsi;
			}
		}
	}

	void free_qs_and_vectors(int num_txq, int num_rxq, int num_q_vectors)
	{
		int i;

		for (i = 0; i < vsi->num_txq; ++i)
			free(vsi->tx_rings[i]);
		free(vsi->tx_rings);
		for (i = 0; i < vsi->num_rxq; ++i)
			free(vsi->rx_rings[i]);
		free(vsi->rx_rings);
		for (i = 0; i < vsi->num_q_vectors; ++i)
			free(vsi->q_vectors[i]);
		free(vsi->q_vectors);
	}

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		vsi->back = pf;
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(u8) * 0x10000000);
		hw = &pf->hw;
		hw->itr_gran = 2;

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv),
					    vsi->num_txq, vsi->num_rxq);
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
	}

	void teardown()
	{
		free(pf->hw.hw_addr);
		free(pf);
		free(vsi);
		free_netdev(netdev);

		pf = NULL;
		vsi = NULL;
		np = NULL;
		netdev = NULL;
	}
};


TEST(ice_legacy_coalesce,  legacy_clear_adaptive_after_set)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;

	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	/* now clear it, this tests the user case of disabling adaptive */
	memset(&ec, 0, sizeof(struct ethtool_coalesce));

	/* usually the user will clear adaptive and set some moderation */
	ec.use_adaptive_tx_coalesce = 0;
	ec.use_adaptive_rx_coalesce = 0;
	ec.tx_coalesce_usecs = 10;
	ec.rx_coalesce_usecs = 20;

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_FALSE(get_ec.use_adaptive_rx_coalesce);
	CHECK_FALSE(get_ec.use_adaptive_tx_coalesce);
	CHECK_EQUAL(0, get_ec.rx_coalesce_usecs_high);
	CHECK_EQUAL(10, get_ec.tx_coalesce_usecs);
	CHECK_EQUAL(20, get_ec.rx_coalesce_usecs);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy_set_adaptive_fail_adjust)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;
	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 124;

	/* when adaptive is enabled, adjusting coalesce must fail */
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(-22, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	/* when adaptive is enabled, adjusting rate must fail too */
	memset(&ec, 0, sizeof(struct ethtool_coalesce));
	ec.rx_coalesce_usecs_high = 20;
	ec.use_adaptive_rx_coalesce = 1;

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(-22, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_FALSE(get_ec.use_adaptive_rx_coalesce);
	CHECK_FALSE(get_ec.use_adaptive_tx_coalesce);
	CHECK_EQUAL(0, get_ec.rx_coalesce_usecs_high);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy_set_and_get_adaptive_all_queues)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;

	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_TRUE(get_ec.use_adaptive_rx_coalesce);
	CHECK_TRUE(get_ec.use_adaptive_tx_coalesce);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy_set_and_get_coalesce_all_rx_and_tx_queues)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 124;

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(48, get_ec.tx_coalesce_usecs);
	CHECK_EQUAL(124, get_ec.rx_coalesce_usecs);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy___ice_set_coalesce_with_4_q_vectors_but_only_2_queue_pairs)
{
	struct ethtool_coalesce ec = { };
	int result;

	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 100;

	/* In some cases if DCB is configured the num_[rx|tx]q and
	 * alloc_[rx|tx]q/num_q_vectors can be different. This test verifies
	 * that __ice_set_coalesce doesn't fail due to this.
	 */
	init_qs_and_vectors(4, 4, 2, 2, 4);
	mock().expectNCalls(4, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");
	result = __ice_set_coalesce(netdev, &ec, -1);
	CHECK_EQUAL(0, result);
	free_qs_and_vectors(vsi->alloc_txq, vsi->alloc_rxq, vsi->num_q_vectors);
}

static void
test_set_q_coalesce(struct ice_vsi *vsi, u32 tx_usecs, u32 rx_usecs,
		    u32 tx_frames_irq, u32 rx_frames_irq, u32 q_num,
		    int expected_result)
{
	struct ethtool_coalesce ec = { };
	struct ice_q_vector *q_vector;
	int actual_result;

	ec.tx_coalesce_usecs = tx_usecs;
	ec.rx_coalesce_usecs = rx_usecs;

	actual_result = ice_set_per_q_coalesce(vsi->netdev, q_num, &ec);
	/* Make sure Rx/Tx queues(s) on q_vector[1] got updated */
	CHECK_EQUAL(expected_result, actual_result);

	if (q_num < vsi->num_txq) {
		q_vector = vsi->q_vectors[q_num];
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->tx));
	}
	if (q_num < vsi->num_rxq) {
		q_vector = vsi->q_vectors[q_num];
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->rx));
	}
}

static void
test_get_q_coalesce(struct ice_vsi *vsi, u32 tx_usecs, u32 rx_usecs,
		    u32 tx_frames_irq, u32 rx_frames_irq, u32 q_num,
		    int expected_result)
{
	struct ethtool_coalesce ec = { };
	int actual_result;

	actual_result = ice_get_per_q_coalesce(vsi->netdev, q_num, &ec);
	CHECK_EQUAL(expected_result, actual_result);
	if (q_num < vsi->num_txq) {
		CHECK_EQUAL(tx_usecs, ec.tx_coalesce_usecs);
	}
	if (q_num < vsi->num_rxq) {
		CHECK_EQUAL(rx_usecs, ec.rx_coalesce_usecs);
	}
}

#ifdef ETHTOOL_PERQUEUE
TEST(ice_legacy_coalesce,  legacy_set_get_per_queue_coalesce_even_q_distribution)
{
	init_qs_and_vectors(4, 4, 4, 4, 4);

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 40, 80, 200, 400, 1, 0);
	test_get_q_coalesce(vsi, 40, 80, 200, 400, 1, 0);

	test_set_q_coalesce(vsi, 60, 120, 220, 40, 2, 0);
	test_get_q_coalesce(vsi, 60, 120, 220, 40, 2, 0);

	test_set_q_coalesce(vsi, 80, 140, 240, 60, 3, 0);
	test_get_q_coalesce(vsi, 80, 140, 240, 60, 3, 0);

	/* Both queues are invalid so nothing is returned */
	test_set_q_coalesce(vsi, 0, 0, 0, 0, 4, -EINVAL);
	test_get_q_coalesce(vsi, 0, 0, 0, 0, 4, -EINVAL);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy_set_get_per_queue_coalesce_more_txqs)
{
	init_qs_and_vectors(4, 4, 4, 3, 4);

	mock().expectNCalls(3, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 40, 80, 160, 180, 3, 0);
	test_get_q_coalesce(vsi, 40, 0, 180, 0, 3, 0);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_legacy_coalesce,  legacy_set_get_per_queue_coalesce_more_rxqs)
{
	init_qs_and_vectors(4, 4, 3, 4, 4);

	mock().expectNCalls(3, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 10, 100, 120, 230, 3, 0);
	test_get_q_coalesce(vsi, 0, 100, 0, 230, 3, 0);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}
#endif /* ETHTOOL_PERQUEUE */

#ifndef SWITCH_MODE
TEST_GROUP(ice_legacy_ethtool_self_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(np->vsi->back);
		free(vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_legacy_ethtool_self_test,  legacy_ice_lbtest_sent_frame)
{
	struct ice_hw hw;
	struct ice_port_info port_info;
	struct ice_pf pf;
	struct pci_dev pdev;
	struct device dev;
	u8 *data;
	unsigned char buf[ICE_LB_FRAME_SIZE];
	int status;

	data = buf;
	hw.port_info = &port_info;

	dev = { 0 };
	pdev.dev = dev;
	pf.pdev = &pdev;
	pf.hw = hw;

	status = ice_lbtest_create_frame(&pf, &data, ICE_LB_FRAME_SIZE);
	CHECK_EQUAL(0, status);

	CHECK_EQUAL(0xDE, data[32]);
	CHECK_EQUAL(0xAD, data[42]);
	CHECK_EQUAL(0xBE, data[44]);
	CHECK_EQUAL(0xEF, data[46]);
	CHECK_EQUAL(0xFF, data[48]);

	free(data);
}
#endif /* !SWITCH_MODE */
