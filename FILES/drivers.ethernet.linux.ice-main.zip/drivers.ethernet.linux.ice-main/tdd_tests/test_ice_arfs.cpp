#if defined(ARFS_SUPPORT) && defined(FDIR_SUPPORT)
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_arfs {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <net/flow_dissector.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <linux/pkt_sched.h>
#include <linux/compiler.h>
#include <linux/udp.h>
#include <linux/tcp.h>

#include "../src/CORE/ice.h"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_irq.cpp"
#include "../src/CORE/ice_arfs.c"
}
/////////////////////////////////////////////////
using namespace ns_arfs;

TEST_GROUP(ice_arfs)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw hw;
	struct sk_buff *skb;
	struct skb_shared_info *skb_shinfo;
	struct flow_keys *flow_keys;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)
			calloc(1, sizeof(struct ice_vsi *));
		pf->msix_entries = (struct msix_entry *)
			calloc(1, sizeof(struct msix_entry));

		hw.back = pf;
		pf->hw = hw;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		set_bit(ICE_FLTR_PTYPE_NONF_IPV4_TCP,
			(unsigned long *)pf->hw.fdir_perfect_fltr);
		set_bit(ICE_FLTR_PTYPE_NONF_IPV6_TCP,
			(unsigned long *)pf->hw.fdir_perfect_fltr);
		set_bit(ICE_FLTR_PTYPE_NONF_IPV4_UDP,
			(unsigned long *)pf->hw.fdir_perfect_fltr);
		set_bit(ICE_FLTR_PTYPE_NONF_IPV6_UDP,
			(unsigned long *)pf->hw.fdir_perfect_fltr);
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->num_rxq = 56;
		pf->vsi[0] = vsi;
		vsi->base_vector = 0;
		vsi->type = ICE_VSI_PF;
		vsi->back = pf;
		vsi->idx = 0;
		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1,
					    1);
		netdev->reg_state = NETREG_REGISTERED;
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		flow_keys = (struct flow_keys *)calloc(1, sizeof(*flow_keys));
		skb = (struct sk_buff *)calloc(1, sizeof(*skb));
	}

	void teardown()
	{
		mock().checkExpectations();
		mock().clear();

		free(skb);
		free(pf->vsi);
		free(pf->msix_entries);
		free(pf->pdev);
		free(pf);
		free(vsi);
		free_netdev(netdev);
		free(flow_keys);
	}
};

static struct ice_arfs_entry *
build_ipv4_arfs_entry(struct ice_vsi *vsi, __be32 src_ip, __be32 dest_ip,
		      __be16 src_port, __be16 dest_port, int flow_id,
		      int rxq_idx)
{
	struct ice_fdir_fltr *fltr_info;
	struct ice_arfs_entry *e;

	e = (struct ice_arfs_entry *)calloc(1, sizeof(*e));
	if (!e)
		return NULL;

	fltr_info = &e->fltr_info;
	fltr_info->q_index = rxq_idx;
	fltr_info->dest_ctl = ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX;
	fltr_info->dest_vsi = vsi->idx;
	e->flow_id = flow_id;
	fltr_info->ip.v4.proto = IPPROTO_TCP;
	fltr_info->flow_type = ICE_FLTR_PTYPE_NONF_IPV4_TCP;
	fltr_info->ip.v4.src_ip = dest_ip;
	fltr_info->ip.v4.dst_ip = src_ip;
	fltr_info->ip.v4.src_port = dest_port;
	fltr_info->ip.v4.dst_port = src_port;
	fltr_info->fltr_id = atomic_inc_return(vsi->arfs_last_fltr_id);

	return e;
}

static void add_arfs_entry(struct ice_vsi *vsi, struct ice_arfs_entry *e,
			   int hlist_idx, enum ice_arfs_fltr_state fltr_state)
{
	INIT_HLIST_NODE(&e->list_entry);
	hlist_add_head(&e->list_entry, &vsi->arfs_fltr_list[hlist_idx]);
	e->fltr_state = fltr_state;
}

TEST(ice_arfs, ice_init_arfs)
{
	ice_init_arfs(vsi);
	CHECK_EQUAL(0, atomic_read(vsi->arfs_last_fltr_id));
	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_init_arfs_cntrs)
{
	ice_init_arfs_cntrs(vsi);
	CHECK_EQUAL(0, atomic_read(vsi->arfs_last_fltr_id));
	CHECK_EQUAL(0, atomic_read(&vsi->arfs_fltr_cntrs->active_tcpv4_cnt));
	CHECK_EQUAL(0, atomic_read(&vsi->arfs_fltr_cntrs->active_tcpv6_cnt));
	CHECK_EQUAL(0, atomic_read(&vsi->arfs_fltr_cntrs->active_udpv4_cnt));
	CHECK_EQUAL(0, atomic_read(&vsi->arfs_fltr_cntrs->active_udpv6_cnt));
	kfree(vsi->arfs_fltr_cntrs);
	kfree(vsi->arfs_last_fltr_id);
}

TEST(ice_arfs, ice_clear_arfs_hash_table_2_active_filters)
{
	int hlist_idx, rxq_idx, flow_id;
	__be16 src_port, dest_port;
	struct ice_arfs_entry *e;
	__be32 src_ip, dest_ip;

	ice_init_arfs(vsi);
	src_port = 0xDEAD;
	dest_port = 0xBEEF;
	src_ip = 0xAABBCCDD;
	dest_ip = 0xEEFF1100;
	rxq_idx = 0;
	flow_id = 1;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	hlist_idx = 0;
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);

	src_port = 0xEF1D;
	dest_port = 0xFEAF;
	src_ip = 0xFFEE11DD;
	dest_ip = 0x22EE11AA;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	hlist_idx = 1;
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);

	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_clear_cpu_rx_rmap)
{
	netdev->rx_cpu_rmap =
		(struct cpu_rmap *)calloc(1, sizeof(*netdev->rx_cpu_rmap));

	ice_init_arfs(vsi);

	mock().expectOneCall("free_irq_cpu_rmap");
	ice_free_cpu_rx_rmap(vsi);
	CHECK_TRUE(NULL == netdev->rx_cpu_rmap);

	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_set_cpu_rx_rmap_null_vsi)
{
	CHECK_TRUE(0 == ice_set_cpu_rx_rmap(NULL));
}

TEST(ice_arfs, ice_set_cpu_rx_rmap_no_qvectors)
{
	vsi->num_q_vectors = 0;
	CHECK_TRUE(-EINVAL == ice_set_cpu_rx_rmap(vsi));
}

TEST(ice_arfs, ice_set_cpu_rx_rmap_netdev_unregistered)
{
	netdev->reg_state = NETREG_UNREGISTERED;
	CHECK_TRUE(-EINVAL == ice_set_cpu_rx_rmap(vsi));
}

TEST(ice_arfs, ice_set_cpu_rx_rmap_null_rx_cpu_rmap)
{
	vsi->num_q_vectors = 1;

	vsi->arfs_fltr_list = (struct hlist_head *)
		kzalloc(sizeof(*vsi->arfs_fltr_list) * ICE_MAX_ARFS_LIST,
			GFP_KERNEL);
	mock().expectOneCall("alloc_irq_cpu_rmap").andReturnValue((void *)NULL);
	CHECK_TRUE(-EINVAL == ice_set_cpu_rx_rmap(vsi));
	kfree(vsi->arfs_fltr_list);
}

TEST(ice_arfs, ice_set_cpu_rx_rmap_irq_cpu_rmap_add_fail)
{
	vsi->num_q_vectors = 1;
	netdev->rx_cpu_rmap =
		(struct cpu_rmap *)calloc(1, sizeof(*netdev->rx_cpu_rmap));

	ice_init_arfs(vsi);
	mock().expectOneCall("alloc_irq_cpu_rmap")
		.andReturnValue((struct cpu_rmap *)netdev->rx_cpu_rmap);
	mock().expectOneCall("ice_get_irq_num")
		.withParameter("idx", vsi->base_vector)
		.andReturnValue(0);
	mock().expectOneCall("irq_cpu_rmap_add")
		.andReturnValue(-EINVAL);
	mock().expectOneCall("free_irq_cpu_rmap");

	CHECK_TRUE(-EINVAL == ice_set_cpu_rx_rmap(vsi));
	CHECK_TRUE(NULL == netdev->rx_cpu_rmap);
	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_remove_arfs_hash_table_empty)
{
	int hlist_idx, rxq_idx, flow_id;
	__be16 src_port, dest_port;
	struct ice_arfs_entry *e;
	__be32 src_ip, dest_ip;
	netdev->rx_cpu_rmap =
		(struct cpu_rmap *)calloc(1, sizeof(*netdev->rx_cpu_rmap));
	ice_init_arfs(vsi);
	/* TODO: Actually add filters to the list, for now fake number of
	 * filters that have been added
	 */
	src_port = 0xDEAD;
	dest_port = 0xBEEF;
	src_ip = 0xAABBCCDD;
	dest_ip = 0xEEFF1100;
	rxq_idx = 0;
	flow_id = 1;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	hlist_idx = 0;
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);

	src_port = 0xEF1D;
	dest_port = 0xFEAF;
	src_ip = 0xFFEE11DD;
	dest_ip = 0x22EE11AA;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	hlist_idx = 1;
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);

	mock().expectOneCall("free_irq_cpu_rmap");
	ice_free_cpu_rx_rmap(vsi);
	ice_remove_arfs(pf);

	CHECK_TRUE(NULL == netdev->rx_cpu_rmap);
}

TEST(ice_arfs, ice_rx_flow_steer_skb_encapsulation_set)
{
	skb->encapsulation = 1;

	vsi->arfs_fltr_list = (struct hlist_head *)
		kzalloc(sizeof(*vsi->arfs_fltr_list) * ICE_MAX_ARFS_LIST,
			GFP_KERNEL);
	CHECK_EQUAL(-EPROTONOSUPPORT, ice_rx_flow_steer(netdev, skb, 0, 0));
	free(vsi->arfs_fltr_list);
}

TEST(ice_arfs, ice_arfs_flow_steer_skb_flow_dissect_flow_keys_failed)
{
	vsi->arfs_fltr_list = (struct hlist_head *)
		calloc(ICE_MAX_ARFS_LIST, sizeof(*vsi->arfs_fltr_list));
	mock().expectOneCall("skb_flow_dissect_flow_keys")
		.ignoreOtherParameters()
		.andReturnValue(false);
	CHECK_EQUAL(-EPROTONOSUPPORT, ice_rx_flow_steer(netdev, skb, 0, 0));
	free(vsi->arfs_fltr_list);
}

TEST(ice_arfs, ice_arfs_sync_fltrs_add_2_new_rules)
{
	int hlist_idx, rxq_idx, flow_id;
	__be16 src_port, dest_port;
	struct ice_arfs_entry *e;
	__be32 src_ip, dest_ip;

	ice_init_arfs(vsi);
	hlist_idx = 1;

	src_port = 0xEF1D;
	dest_port = 0xFEAF;
	src_ip = 0xFFEE11DD;
	dest_ip = 0x22EE11AA;
	flow_id = 1;
	rxq_idx = 13;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_INACTIVE);

	src_port = 0xFFED;
	dest_port = 0xA1DF;
	src_ip = 0xABCE31DD;
	dest_ip = 0xF1BE31AD;
	flow_id = 2;
	rxq_idx = 18;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_INACTIVE);

	mock().expectNCalls(2, "ice_fdir_write_fltr")
		.andReturnValue(0);
	ice_sync_arfs_fltrs(pf);

	hlist_for_each_entry(e, &vsi->arfs_fltr_list[hlist_idx], list_entry)
		CHECK_EQUAL(ICE_ARFS_ACTIVE, e->fltr_state);

	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_arfs_sync_fltrs_delete_2_rules_from_expiration)
{
	int hlist_idx, rxq_idx, flow_id;
	__be16 src_port, dest_port;
	struct ice_arfs_entry *e;
	__be32 src_ip, dest_ip;

	ice_init_arfs(vsi);
	hlist_idx = 1;

	src_port = 0xEF1D;
	dest_port = 0xFEAF;
	src_ip = 0xFFEE11DD;
	dest_ip = 0x22EE11AA;
	flow_id = 1;
	rxq_idx = 13;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);

	src_port = 0xEF1A;
	dest_port = 0xFEA3;
	src_ip = 0xFFEE22DD;
	dest_ip = 0x22E311AA;
	flow_id = 2;
	rxq_idx = 15;
	e = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port, dest_port,
				  flow_id, rxq_idx);
	CHECK_FALSE(NULL == e);
	add_arfs_entry(vsi, e, hlist_idx, ICE_ARFS_ACTIVE);


	mock().expectNCalls(2, "rps_may_expire_flow")
		.andReturnValue(true);
	mock().expectNCalls(2, "ice_fdir_write_fltr")
		.andReturnValue(0);
	ice_sync_arfs_fltrs(pf);
	CHECK_TRUE(hlist_empty(&vsi->arfs_fltr_list[hlist_idx]));
	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_arfs_del_flow_rules_delete_one_rule)
{
	struct ice_arfs_entry *arfs_entry;
	int  rxq_idx, flow_id;
	__be16 src_port, dest_port;
	__be32 src_ip, dest_ip;
	HLIST_HEAD(del_list);

	ice_init_arfs(vsi);
	src_port = 0xEF1D;
	dest_port = 0xFEAF;
	src_ip = 0xFFEE11DD;
	dest_ip = 0x22EE11AA;
	flow_id = 1;
	rxq_idx = 13;
	arfs_entry = build_ipv4_arfs_entry(vsi, src_ip, dest_ip, src_port,
					   dest_port, flow_id, rxq_idx);
	hlist_add_head(&arfs_entry->list_entry, &del_list);
	mock().expectOneCall("ice_fdir_write_fltr")
		.andReturnValue(0);
	ice_arfs_del_flow_rules(vsi, &del_list);
	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_rx_flow_steer_add_ipv4_tcp_flow)
{
	int rxq_index = 13, flow_id = 2;
	unsigned int fltr_id = 1;
	struct ice_fdir_fltr *fltr_info;
	struct ice_arfs_entry *e;
	unsigned int ret;

	skb->encapsulation = 0;

	ice_init_arfs(vsi);

	flow_keys->basic.n_proto = htons(ETH_P_IP);
	flow_keys->basic.ip_proto = IPPROTO_TCP;
	flow_keys->ports.src = 0xDEAD;
	flow_keys->ports.dst = 0xBEEF;
	flow_keys->addrs.v4addrs.src = 0xAABBCCDD;
	flow_keys->addrs.v4addrs.dst = 0xEEFF1122;
	skb->hash = 0x1FBCD03E;

	mock().expectOneCall("ip_is_fragment")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("skb_flow_dissect_flow_keys")
		.withOutputParameterReturning("flow_keys", flow_keys, sizeof(*flow_keys))
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_service_task_schedule");
	ret = ice_rx_flow_steer(netdev, skb, rxq_index, flow_id);
	CHECK_EQUAL(fltr_id, ret);

	e = hlist_entry(vsi->arfs_fltr_list[skb->hash & ICE_ARFS_LST_MASK].first,
			struct ice_arfs_entry, list_entry);
	fltr_info = &e->fltr_info;
	CHECK_EQUAL(flow_keys->ports.src, fltr_info->ip.v4.src_port);
	CHECK_EQUAL(flow_keys->ports.dst, fltr_info->ip.v4.dst_port);
	CHECK_EQUAL(flow_keys->addrs.v4addrs.src, fltr_info->ip.v4.src_ip);
	CHECK_EQUAL(flow_keys->addrs.v4addrs.dst, fltr_info->ip.v4.dst_ip);
	CHECK_EQUAL(flow_keys->basic.ip_proto, fltr_info->ip.v4.proto);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV4_TCP, fltr_info->flow_type);
	CHECK_EQUAL(fltr_id, fltr_info->fltr_id);
	CHECK_EQUAL(flow_id, flow_id);
	CHECK_EQUAL(vsi->idx, fltr_info->dest_vsi);
	CHECK_EQUAL(ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX,
		    fltr_info->dest_ctl);

	/* have to clean up hash table so we don't leak memory for TDD test */
	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_rx_flow_steer_add_ipv4_udp_flow)
{
	unsigned int rxq_index = 13, flow_id = 2, fltr_id = 1;
	struct ice_fdir_fltr *fltr_info;
	struct ice_arfs_entry *e;
	int ret;

	ice_init_arfs(vsi);

	flow_keys->basic.n_proto = htons(ETH_P_IP);
	flow_keys->basic.ip_proto = IPPROTO_UDP;
	flow_keys->ports.src = 0xDEAD;
	flow_keys->ports.dst = 0xBEEF;
	flow_keys->addrs.v4addrs.src = 0xAABBCCDD;
	flow_keys->addrs.v4addrs.dst = 0xEEFF1122;
	skb->hash = 0x1FBCD03E;

	mock().expectOneCall("ip_is_fragment")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("skb_flow_dissect_flow_keys")
		.withOutputParameterReturning("flow_keys", flow_keys, sizeof(*flow_keys))
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_service_task_schedule");
	ret = ice_rx_flow_steer(netdev, skb, rxq_index, flow_id);
	// return can be negative if there was an error
	CHECK(ret >= 0);
	// cast the value here to avoid unsigned vs signed warning
	CHECK_EQUAL(fltr_id, (unsigned int)ret);

	e = hlist_entry(vsi->arfs_fltr_list[skb->hash & ICE_ARFS_LST_MASK].first,
			struct ice_arfs_entry, list_entry);
	fltr_info = &e->fltr_info;
	CHECK_EQUAL(flow_keys->ports.src, fltr_info->ip.v4.src_port);
	CHECK_EQUAL(flow_keys->ports.dst, fltr_info->ip.v4.dst_port);
	CHECK_EQUAL(flow_keys->addrs.v4addrs.src, fltr_info->ip.v4.src_ip);
	CHECK_EQUAL(flow_keys->addrs.v4addrs.dst, fltr_info->ip.v4.dst_ip);
	CHECK_EQUAL(flow_keys->basic.ip_proto, fltr_info->ip.v4.proto);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV4_UDP, fltr_info->flow_type);
	CHECK_EQUAL(fltr_id, fltr_info->fltr_id);
	CHECK_EQUAL(flow_id, flow_id);
	CHECK_EQUAL(vsi->idx, fltr_info->dest_vsi);
	CHECK_EQUAL(ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX,
		    fltr_info->dest_ctl);

	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_rx_flow_steer_add_ipv6_tcp_flow)
{
	unsigned int rxq_index = 3, flow_id = 5, fltr_id = 1;
	struct ice_fdir_fltr *fltr_info;
	struct ice_arfs_entry *e;
	int ret;

	ice_init_arfs(vsi);
	flow_keys->basic.n_proto = htons(ETH_P_IPV6);
	flow_keys->basic.ip_proto = IPPROTO_TCP;
	flow_keys->ports.src = 0xDEAD;
	flow_keys->ports.dst = 0xBEEF;
	for (__u8 i = 0; i < 16; ++i) {
		flow_keys->addrs.v6addrs.dst.in6_u.u6_addr8[i] = i;
		flow_keys->addrs.v6addrs.src.in6_u.u6_addr8[i] = i * 2;
	}

	skb->hash = 0;

	mock().expectOneCall("skb_flow_dissect_flow_keys")
		.withOutputParameterReturning("flow_keys", flow_keys, sizeof(*flow_keys))
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_service_task_schedule");
	ret = ice_rx_flow_steer(netdev, skb, rxq_index, flow_id);
	// return can be negative if there was an error
	CHECK(ret >= 0);
	// cast the value here to avoid unsigned vs signed warning
	CHECK_EQUAL(fltr_id, (unsigned int)ret);

	e = hlist_entry(vsi->arfs_fltr_list[skb->hash % ICE_ARFS_LST_MASK].first,
			struct ice_arfs_entry, list_entry);
	fltr_info = &e->fltr_info;
	CHECK_EQUAL(flow_keys->ports.src, fltr_info->ip.v6.src_port);
	CHECK_EQUAL(flow_keys->ports.dst, fltr_info->ip.v6.dst_port);
	MEMCMP_EQUAL(&flow_keys->addrs.v6addrs.src, fltr_info->ip.v6.src_ip, sizeof(fltr_info->ip.v6.src_ip));
	MEMCMP_EQUAL(&flow_keys->addrs.v6addrs.dst, fltr_info->ip.v6.dst_ip, sizeof(fltr_info->ip.v6.dst_ip));
	CHECK_EQUAL(flow_keys->basic.ip_proto, fltr_info->ip.v6.proto);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV6_TCP, fltr_info->flow_type);
	CHECK_EQUAL(fltr_id, fltr_info->fltr_id);
	CHECK_EQUAL(flow_id, flow_id);
	CHECK_EQUAL(vsi->idx, fltr_info->dest_vsi);
	CHECK_EQUAL(ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX,
		    fltr_info->dest_ctl);

	ice_clear_arfs(vsi);
}

TEST(ice_arfs, ice_rx_flow_steer_add_ipv6_udp_flow)
{
	unsigned int rxq_index = 54, flow_id = 9, fltr_id = 1;
	struct ice_fdir_fltr *fltr_info;
	struct ice_arfs_entry *e;
	int ret;

	ice_init_arfs(vsi);
	flow_keys->basic.n_proto = htons(ETH_P_IPV6);
	flow_keys->basic.ip_proto = IPPROTO_UDP;
	flow_keys->ports.src = 0xDEAD;
	flow_keys->ports.dst = 0xBEEF;
	for (__u8 i = 0; i < 16; ++i) {
		flow_keys->addrs.v6addrs.dst.in6_u.u6_addr8[i] = i + 3;
		flow_keys->addrs.v6addrs.src.in6_u.u6_addr8[i] = i * 3;
	}

	skb->hash = 0;

	mock().expectOneCall("skb_flow_dissect_flow_keys")
		.withOutputParameterReturning("flow_keys", flow_keys, sizeof(*flow_keys))
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_service_task_schedule");
	ret = ice_rx_flow_steer(netdev, skb, rxq_index, flow_id);
	// return can be negative if there was an error
	CHECK(ret >= 0);
	// cast the value here to avoid unsigned vs signed warning
	CHECK_EQUAL(fltr_id, (unsigned int)ret);

	e = hlist_entry(vsi->arfs_fltr_list[skb->hash % ICE_ARFS_LST_MASK].first,
			struct ice_arfs_entry, list_entry);
	fltr_info = &e->fltr_info;
	CHECK_EQUAL(flow_keys->ports.src, fltr_info->ip.v6.src_port);
	CHECK_EQUAL(flow_keys->ports.dst, fltr_info->ip.v6.dst_port);
	MEMCMP_EQUAL(&flow_keys->addrs.v6addrs.src, fltr_info->ip.v6.src_ip, sizeof(fltr_info->ip.v6.src_ip));
	MEMCMP_EQUAL(&flow_keys->addrs.v6addrs.dst, fltr_info->ip.v6.dst_ip, sizeof(fltr_info->ip.v6.dst_ip));
	CHECK_EQUAL(flow_keys->basic.ip_proto, fltr_info->ip.v6.proto);
	CHECK_EQUAL(ICE_FLTR_PTYPE_NONF_IPV6_UDP, fltr_info->flow_type);
	CHECK_EQUAL(fltr_id, fltr_info->fltr_id);
	CHECK_EQUAL(flow_id, flow_id);
	CHECK_EQUAL(vsi->idx, fltr_info->dest_vsi);
	CHECK_EQUAL(ICE_FLTR_PRGM_DESC_DEST_DIRECT_PKT_QINDEX,
		    fltr_info->dest_ctl);


	ice_clear_arfs(vsi);
}

TEST_GROUP(ice_is_arfs_using_perfect_flow)
{
	struct ice_hw *hw;
	struct ice_vsi *vsi;
	struct ice_pf *pf;

	void setup()
	{
		hw = (struct ice_hw *)calloc(1, sizeof(*hw));
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(struct ice_vsi *));
		hw->back = pf;
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->type = ICE_VSI_PF;
		pf->vsi[0] = vsi;
		ns_arfs::ice_init_arfs_cntrs(vsi);
	}

	void teardown()
	{
		free(vsi->arfs_last_fltr_id);
		vsi->arfs_last_fltr_id = NULL;
		free(vsi->arfs_fltr_cntrs);
		vsi->arfs_fltr_cntrs = NULL;
		free(vsi);
		vsi = NULL;
		free(pf->vsi);
		pf->vsi = NULL;
		free(pf);
		pf = NULL;
		free(hw);
		hw = NULL;
	}
};

TEST(ice_is_arfs_using_perfect_flow, using_udpv4_true)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv4_cnt, 1);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV4_UDP);
	CHECK_EQUAL(true, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_udpv4_false)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv4_cnt, 0);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV4_UDP);
	CHECK_EQUAL(false, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_udpv6_true)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv6_cnt, 1);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV6_UDP);
	CHECK_EQUAL(true, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_udpv6_false)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv6_cnt, 0);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV6_UDP);
	CHECK_EQUAL(false, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_tcpv4_true)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_tcpv4_cnt, 1);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV4_TCP);
	CHECK_EQUAL(true, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_tcpv4_false)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv4_cnt, 0);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV4_UDP);
	CHECK_EQUAL(false, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_tcpv6_true)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv6_cnt, 1);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV6_UDP);
	CHECK_EQUAL(true, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, using_tcpv6_false)
{
	bool is_using;

	atomic_set(&vsi->arfs_fltr_cntrs->active_udpv6_cnt, 0);

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV6_UDP);
	CHECK_EQUAL(false, is_using);
}

TEST(ice_is_arfs_using_perfect_flow, invalid_ice_fltr_ptype)
{
	bool is_using;

	is_using = ice_is_arfs_using_perfect_flow(hw,
						  ICE_FLTR_PTYPE_NONF_IPV4_SCTP);
	CHECK_EQUAL(false, is_using);
}

TEST_GROUP(ice_arfs_is_perfect_flow_set)
{
	struct ice_hw *hw;
	int actual;

	void setup()
	{
		hw = (struct ice_hw *)calloc(1, sizeof(*hw));
	}

	void teardown()
	{
		free(hw);
		hw = NULL;
	}
};

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_udpv4_perfect_flow_is_set)
{
	set_bit(ICE_FLTR_PTYPE_NONF_IPV4_UDP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, htons(ETH_P_IP), IPPROTO_UDP);
	CHECK_EQUAL(true, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_udpv4_perfect_flow_is_cleared)
{
	clear_bit(ICE_FLTR_PTYPE_NONF_IPV4_UDP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, ETH_P_IP, IPPROTO_UDP);
	CHECK_EQUAL(false, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_tcpv4_perfect_flow_is_set)
{
	set_bit(ICE_FLTR_PTYPE_NONF_IPV4_TCP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, htons(ETH_P_IP), IPPROTO_TCP);
	CHECK_EQUAL(true, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_tcpv4_perfect_flow_is_cleared)
{
	clear_bit(ICE_FLTR_PTYPE_NONF_IPV4_TCP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, ETH_P_IP, IPPROTO_TCP);
	CHECK_EQUAL(false, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_udpv6_perfect_flow_is_set)
{
	set_bit(ICE_FLTR_PTYPE_NONF_IPV6_UDP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, htons(ETH_P_IPV6), IPPROTO_UDP);
	CHECK_EQUAL(true, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_udpv6_perfect_flow_is_cleared)
{
	clear_bit(ICE_FLTR_PTYPE_NONF_IPV6_UDP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, ETH_P_IPV6, IPPROTO_UDP);
	CHECK_EQUAL(false, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_tcpv6_perfect_flow_is_set)
{
	set_bit(ICE_FLTR_PTYPE_NONF_IPV6_TCP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, htons(ETH_P_IPV6), IPPROTO_TCP);
	CHECK_EQUAL(true, actual);
}

TEST(ice_arfs_is_perfect_flow_set, ice_is_perfect_flow_set_tcpv6_perfect_flow_is_cleared)
{
	clear_bit(ICE_FLTR_PTYPE_NONF_IPV6_TCP, (unsigned long *)hw->fdir_perfect_fltr);
	actual = ice_arfs_is_perfect_flow_set(hw, ETH_P_IPV6, IPPROTO_TCP);
	CHECK_EQUAL(false, actual);
}

TEST_GROUP(ice_arfs_is_flow_expired)
{
	struct ice_arfs_entry *arfs_entry;
	struct ice_vsi *vsi;

	void setup()
	{
		arfs_entry = (struct ice_arfs_entry *)
			calloc(1,sizeof(*arfs_entry));
		vsi = (struct ice_vsi*)calloc(1, sizeof(*vsi));
	}

	void teardown()
	{
		free(arfs_entry);
		arfs_entry = NULL;
		free(vsi);
		vsi = NULL;
	}
};

TEST(ice_arfs_is_flow_expired, udpv4_filter_expired_jiffies_less_than_time_activated_jiffies_wrapped)
{
	arfs_entry->fltr_info.flow_type = ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	arfs_entry->time_activated = GENMASK(63, 0) -
		msecs_to_jiffies(ICE_ARFS_TIME_DELTA_EXPIRATION);

	mock().expectOneCall("rps_may_expire_flow")
		.andReturnValue(false);
	mock().expectOneCall("get_jiffies_64")
		.andReturnValue(0);
	mock().expectOneCall("time_in_range64")
		.andReturnValue(true);

	CHECK_TRUE(ice_arfs_is_flow_expired(vsi, arfs_entry));
}

TEST(ice_arfs_is_flow_expired, udpv4_filter_not_expired_jiffies_less_than_time_activated_jiffies_wrapped)
{
	arfs_entry->fltr_info.flow_type = ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	arfs_entry->time_activated = GENMASK(63, 0) -
		msecs_to_jiffies(ICE_ARFS_TIME_DELTA_EXPIRATION) + 1;

	mock().expectOneCall("rps_may_expire_flow")
		.andReturnValue(false);
	mock().expectOneCall("get_jiffies_64")
		.andReturnValue(0);
	mock().expectOneCall("time_in_range64")
		.andReturnValue(false);

	CHECK_FALSE(ice_arfs_is_flow_expired(vsi, arfs_entry));
}

TEST(ice_arfs_is_flow_expired, udpv4_filter_expired_jiffies_greater_than_time_activated)
{
	arfs_entry->fltr_info.flow_type = ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	arfs_entry->time_activated = msecs_to_jiffies(30000000);

	mock().expectOneCall("rps_may_expire_flow")
		.andReturnValue(false);
	mock().expectOneCall("get_jiffies_64")
		.andReturnValue(arfs_entry->time_activated + ICE_ARFS_TIME_DELTA_EXPIRATION);
	mock().expectOneCall("time_in_range64")
		.andReturnValue(true);

	CHECK_TRUE(ice_arfs_is_flow_expired(vsi, arfs_entry));
}

TEST(ice_arfs_is_flow_expired, udpv4_filter_not_expired_jiffies_greater_than_time_activated)
{
	arfs_entry->fltr_info.flow_type = ICE_FLTR_PTYPE_NONF_IPV4_UDP;
	arfs_entry->time_activated = msecs_to_jiffies(30000000);

	mock().expectOneCall("rps_may_expire_flow")
		.andReturnValue(false);
	mock().expectOneCall("get_jiffies_64")
		.andReturnValue(arfs_entry->time_activated + ICE_ARFS_TIME_DELTA_EXPIRATION - 1);
	mock().expectOneCall("time_in_range64")
		.andReturnValue(false);

	CHECK_FALSE(ice_arfs_is_flow_expired(vsi, arfs_entry));
}

#endif /* ARFS_SUPPORT && FDIR_SUPPORT */
