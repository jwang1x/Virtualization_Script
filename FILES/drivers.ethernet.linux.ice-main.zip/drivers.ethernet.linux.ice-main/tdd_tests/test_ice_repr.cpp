#ifdef ESWITCH_SUPPORT
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_repr {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"

#include "../src/CORE/ice.h"
#include "../src/CORE/ice_repr.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_flow.cpp"
#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_devlink.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"

/* Include standard mocks of ice_repr.c functions */
#include "CORE_MOCKS/stdmock_ice_repr.cpp"

#include "../src/CORE/ice_repr.c"
}
/////////////////////////////////////////////////
using namespace ns_repr;

TEST_GROUP(repr_grp)
{
	static const u16 num_vfs = 8;
	struct ice_vfs *vfs;
	struct ice_pf *pf;
	struct pci_dev pdev = {0};

	void test_del_vfs() {
		struct hlist_node *tmp;
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each_safe(pf->vfs.table, bkt, tmp, vf, entry) {
			hash_del(&vf->entry);
			mutex_destroy(&vf->cfg_lock);
			kfree(vf);
		}
	}

	struct ice_vf *test_add_one_vf(int i) {
		struct ice_vf *vf;

		vf = (struct ice_vf *)kzalloc(sizeof(*vf), GFP_KERNEL);

		vf->pf = pf;
		vf->vf_id = i;
		vf->lan_vsi_idx = i;
		// vf->vf_ops = &ice_sriov_vf_ops;
		mutex_init(&vf->cfg_lock);
		kref_init(&vf->refcnt);

		hash_add(vfs->table, &vf->entry, i);
		return vf;
	}

	struct ice_vf *test_get_vf(int i) {
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each(pf->vfs.table, bkt, vf, entry) {
			if (vf->vf_id == i)
				return vf;
		}

		FAIL(StringFromFormat("Unable to locate VF with ID %d", i).asCharString());
		return NULL;
	}

	void test_add_vfs(int num_vfs) {
		for (int i = 0; i < num_vfs; i++)
			test_add_one_vf(i);
	}

	void test_set_vfs(int num_vfs) {
		test_del_vfs();
		test_add_vfs(num_vfs);
	}

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->pdev = &pdev;
		vfs = &pf->vfs;

		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);

		test_add_vfs(num_vfs);

		pf->vsi = (struct ice_vsi **)calloc(num_vfs,
						   sizeof(struct ice_vsi *));
#if BMSM_MODE
		set_bit(ICE_FLAG_CREATE_VFPRS, pf->flags);
#endif
		for (int i = 0; i < num_vfs; i++)
			pf->vsi[i] = (struct ice_vsi *)
				calloc(1, sizeof(struct ice_vsi));
	}

	void teardown(void)
	{
		test_del_vfs();
		mutex_destroy(&vfs->table_lock);

		for (int i = 0; i < num_vfs; i++)
			free(pf->vsi[i]);
		free(pf->vsi);
		free(pf);
	}
};

TEST(repr_grp, repr_add_for_all_vfs_expected_success)
{
	USE_STD_MOCK(ice_repr_add);

	mock().expectNCalls(num_vfs, "ice_repr_add")
		.ignoreOtherParameters();

	mutex_lock(&pf->vfs.table_lock);
	int err = ice_repr_add_for_all_vfs(pf);
	mutex_unlock(&pf->vfs.table_lock);
	CHECK_EQUAL(err, 0);
}

TEST(repr_grp, repr_add_for_all_vfs_expected_fail)
{
	USE_STD_MOCK(ice_repr_add);

	mock().expectOneCall("ice_repr_add")
		.ignoreOtherParameters()
		.andReturnValue(-1);

	mutex_lock(&pf->vfs.table_lock);
	int err = ice_repr_add_for_all_vfs(pf);
	mutex_unlock(&pf->vfs.table_lock);
	CHECK_EQUAL(err, -1);
}

TEST(repr_grp, repr_rem_from_all_vfs)
{
	using namespace ns_repr;
	USE_STD_MOCK(ice_repr_rem);

	mock().expectNCalls(num_vfs, "ice_repr_rem")
		.ignoreOtherParameters();

	mutex_lock(&pf->vfs.table_lock);
	ice_repr_rem_from_all_vfs(pf);
	mutex_unlock(&pf->vfs.table_lock);
}

TEST(repr_grp, repr_rem)
{
	/* free netedev and kfree will free this memory */
	test_get_vf(0)->repr = (struct ice_repr *)calloc(1, sizeof(struct ice_repr));
	test_get_vf(0)->repr->netdev = (struct net_device *)
		calloc(1, sizeof(struct net_device));
	mock().expectOneCall("unregister_netdev");
#ifdef ESWITCH_SUPPORT
#if IS_ENABLED(CONFIG_NET_DEVLINK)
	mock().expectOneCall("ice_devlink_destroy_vf_port")
		.ignoreOtherParameters();
#endif /* CONFIG_NET_DEVLINK */
#endif /* ESWITCH_SUPPORT */
	mock().expectOneCall("ice_virtchnl_set_dflt_ops")
		.ignoreOtherParameters();

	ice_repr_rem(test_get_vf(0));
}

TEST(repr_grp, repr_add_expected_success)
{
	pf->vsi[0]->netdev = (struct net_device *)
		calloc(1, sizeof(struct net_device));

	USE_STD_MOCK(ice_repr_reg_netdev);

	mock().expectOneCall("ice_repr_reg_netdev")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", test_get_vf(0))
		.andReturnValue(pf->vsi[0]);

#ifdef ESWITCH_SUPPORT
#if IS_ENABLED(CONFIG_NET_DEVLINK)
	mock().expectOneCall("ice_devlink_create_vf_port")
		.ignoreOtherParameters();
	mock().expectOneCall("devlink_port_type_eth_set")
		.ignoreOtherParameters();
#endif /* CONFIG_NET_DEVLINK */
#endif /* ESWITCH_SUPPORT */
	mock().expectOneCall("ice_virtchnl_set_repr_ops")
		.ignoreOtherParameters();

	int err = ice_repr_add(test_get_vf(0));
	CHECK_EQUAL(0, err);

	mock().expectOneCall("unregister_netdev");
#ifdef ESWITCH_SUPPORT
#if IS_ENABLED(CONFIG_NET_DEVLINK)
	mock().expectOneCall("ice_devlink_destroy_vf_port")
		.ignoreOtherParameters();
#endif /* CONFIG_NET_DEVLINK */
#endif /* ESWITCH_SUPPORT */
	mock().expectOneCall("ice_virtchnl_set_dflt_ops")
		.ignoreOtherParameters();

	ice_repr_rem(test_get_vf(0));
	free(pf->vsi[0]->netdev);
}

TEST(repr_grp, repr_add_expected_fail_from_reg_netdev)
{
	pf->vsi[0]->netdev = (struct net_device *)
		calloc(1, sizeof(struct net_device));

	USE_STD_MOCK(ice_repr_reg_netdev);

	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", test_get_vf(0))
		.andReturnValue(pf->vsi[0]);
	mock().expectOneCall("ice_repr_reg_netdev")
		.ignoreOtherParameters()
		.andReturnValue(-1);

#ifdef ESWITCH_SUPPORT
#if IS_ENABLED(CONFIG_NET_DEVLINK)
	mock().expectOneCall("ice_devlink_destroy_vf_port")
		.ignoreOtherParameters();
	mock().expectOneCall("ice_devlink_create_vf_port")
		.ignoreOtherParameters();
#endif /* CONFIG_NET_DEVLINK */
#endif /* ESWITCH_SUPPORT */

	int err = ice_repr_add(test_get_vf(0));
	CHECK_EQUAL(-1, err);

	free(pf->vsi[0]->netdev);
}

TEST(repr_grp, repr_reg_netdev)
{
	struct net_device *netdev = (struct net_device *)
		calloc(1, sizeof(struct net_device));
	netdev->dev_addr = (u8 *)calloc(1, ETH_ALEN);

	mock().expectOneCall("register_netdev");
	mock().expectOneCall("ice_set_ethtool_repr_ops")
		.ignoreOtherParameters();
	int err = ice_repr_reg_netdev(netdev);
	CHECK_EQUAL(0, err);

	free(netdev->dev_addr);
	free(netdev);
}
#endif
