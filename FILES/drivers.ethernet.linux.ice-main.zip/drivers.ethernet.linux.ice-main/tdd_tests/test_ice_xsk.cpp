/*
 * Copyright(c) 2018 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#ifdef XDP_SUPPORT
#ifdef CONFIG_XDP_SOCKETS
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_xsk {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "linux/device.h"
#include "linux/netdevice.h"
#include "linux/log2.h"
#include "net/xdp_sock.h"
#include "linux/dma-mapping.h"
#include "linux/skbuff.h"
#include "../src/CORE/ice.h"
#include "../src/CORE/ice_xsk.h"
#include "../src/CORE/ice_txrx.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_net_core.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_irq.cpp"

#include "CORE_MOCKS/stdmock_ice_xsk.cpp"

#include "../src/CORE/ice_txrx_lib.c"
#include "../src/CORE/ice_xsk.c"
};
/////////////////////////////////////////////////
using namespace ns_xsk;

#define QID 2

#ifndef HAVE_AF_XDP_NETDEV_UMEM
static void ice_xsk_remove_umem_mock(struct ice_vsi *vsi, u16 qid)
{
	vsi->xsk_umems[qid] = NULL;
	vsi->num_xsk_umems_used--;

	vsi->xsk_umems = NULL;
	vsi->num_xsk_umems = 0;
}
#endif

static u16 callback_u16_invalid(struct ice_vsi *vsi)
{
	return 0;
}

static u16 callback_u16(struct ice_vsi *vsi)
{
	return QID + 1;
}

static bool callback_bool_f(struct ice_vsi *vsi)
{
	return false;
}
static bool callback_bool_t(struct ice_vsi *vsi)
{
	return true;
}

TEST_GROUP(xsk_grp)
{
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct xsk_buff_pool *pool;
	u16 qid;
	int numq = 4;

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), numq, numq);
		netdev->real_num_rx_queues = numq;
		netdev->real_num_tx_queues = numq;
		vsi  = (struct ice_vsi *) calloc(1, sizeof(*vsi));
		pf   = (struct ice_pf *)  calloc(1, sizeof(*pf));

		vsi->rx_rings = (struct ice_ring **)calloc(1, sizeof(struct ice_ring *));
		vsi->rx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->rx_rings[0]->count = 4;
		vsi->num_rxq = vsi->num_txq = numq;
		vsi->netdev = netdev;
		vsi->back = pf;
		vsi->type = ICE_VSI_PF;
		vsi->af_xdp_zc_qps = bitmap_zalloc(numq, GFP_KERNEL);
		pool = (struct xsk_buff_pool*)calloc(numq, sizeof(struct xsk_buff_pool));
		qid = QID;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
	}

	void teardown(void)
	{
		free_netdev(netdev);
		free(pf->pdev);
		free(pf);
		pf = NULL;
		free(pool);
		pool = NULL;
		free(vsi->rx_rings[0]);
		free(vsi->rx_rings);
		bitmap_free(vsi->af_xdp_zc_qps);
		free(vsi);
		vsi = NULL;
	}
};

TEST(xsk_grp, umem_disable)
{
	int qid = 0, ret;
	struct xsk_buff_pool pooldisable;

	mock().expectOneCall("netif_running");
	mock().expectOneCall("xsk_pool_dma_map");

	/* Setup a umem */
	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(0, ret);


	mock().expectOneCall("netif_running");
	mock().expectOneCall("xsk_get_pool_from_qid").andReturnValue(&pooldisable);

	/* Try to remove it */
	ret = ice_xsk_pool_setup(vsi, NULL, qid);
	CHECK_EQUAL(0, ret);

}

TEST(xsk_grp, xsk_enable)
{
	int ret;

	vsi->type = ICE_VSI_VF;
	ret = ice_xsk_pool_enable(vsi, pool, qid);
	CHECK_EQUAL(-EINVAL, ret);

	vsi->type = ICE_VSI_PF;
	qid = numq + 1;
	ret = ice_xsk_pool_enable(vsi, pool, qid);
	CHECK_EQUAL(-EINVAL, ret);

}

#ifndef HAVE_MEM_TYPE_XSK_BUFF_POOL
TEST(xsk_grp, xsk_dma_map)
{
	dma_addr_t dma;
	int ret;

	umem->npgs = 4;
	umem->pages = (struct xdp_umem_page *)calloc(umem->npgs, sizeof(struct xdp_umem_page));
	umem->pgs = (struct page **)calloc(umem->npgs, sizeof(struct page));

	ret = ice_xsk_umem_dma_map(vsi, umem);
	CHECK_EQUAL(0, ret);
	dma = dma_map_page_attrs(&pf->pdev->dev, umem->pgs[0], 0, PAGE_SIZE,
				 DMA_BIDIRECTIONAL, ICE_RX_DMA_ATTR);
	CHECK_EQUAL(umem->pages[0].dma, dma);

	free(umem->pages);
	free(umem->pgs);
}
#endif

TEST(xsk_grp, umem_setup)
{
	int qid, ret;

	qid = 10;
	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(-EINVAL, ret);

	mock().expectOneCall("netif_running");
	mock().expectOneCall("xsk_pool_dma_map");

	qid = 0;
	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(0, ret);

}

TEST(xsk_grp, pool_setup_non_balanced_queues)
{
	int qid, ret;

	/* force non balanced queues */
	qid = 2;
	vsi->num_rxq = 1;
	vsi->num_txq = 3;

	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(-EINVAL, ret);

	vsi->num_rxq = 3;
	vsi->num_txq = 1;
	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(-EINVAL, ret);

	vsi->num_rxq = 3;
	vsi->num_txq = 4;

	mock().expectOneCall("netif_running");
	mock().expectOneCall("xsk_pool_dma_map");

	ret = ice_xsk_pool_setup(vsi, pool, qid);
	CHECK_EQUAL(0, ret);
}

#endif /* CONFIG_XDP_SOCKETS */
#endif /* XDP_SUPPORT */
