#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

#define HAVE_ETHTOOL_NEW_1G_BITS
#define HAVE_ETHTOOL_NEW_2500MB_BITS
#define HAVE_ETHTOOL_5G_BITS
#define HAVE_ETHTOOL_NEW_10G_BITS
#define HAVE_ETHTOOL_25G_BITS
#define HAVE_ETHTOOL_50G_BITS
#define HAVE_ETHTOOL_NEW_50G_BITS
#define HAVE_ETHTOOL_100G_BITS

/////////////////////////////////////////////////
namespace ns_ethtool {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_sched.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/compiler.h>
#include <linux/pm_wakeup.h>
#include <linux/bitmap.h>

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"

#include "CORE_MOCKS/stdmock_ice_header.cpp"

#include "../src/CORE/ice_ethtool.c"
}
/////////////////////////////////////////////////
using namespace ns_ethtool;

class PhyCapsDataCopier : public MockNamedValueCopier
{
	public:
		virtual void copy(void *out, const void *in)
		{
			*(struct ice_aqc_get_phy_caps_data *)out =
				*(const struct ice_aqc_get_phy_caps_data *)in;
		}
};

class PhyCfgDataComparator : public MockNamedValueComparator
{
	public:
		virtual bool isEqual(const void *obj1, const void *obj2)
		{
			struct ice_aqc_set_phy_cfg_data *d1 =
				(struct ice_aqc_set_phy_cfg_data *)obj1;
			struct ice_aqc_set_phy_cfg_data *d2 =
				(struct ice_aqc_set_phy_cfg_data *)obj2;

			bool result = true;

			if (d1->phy_type_low != d2->phy_type_low) {
				printf("expected phy_type_low = 0x%llx\n"
				       "actual phy_type_low   = 0x%llx\n",
				       d1->phy_type_low, d2->phy_type_low);
				result = false;
			}
			if (d1->phy_type_high != d2->phy_type_high) {
				printf("expected phy_type_high = 0x%llx\n"
				       "actual phy_type_high   = 0x%llx\n",
				       d1->phy_type_high, d2->phy_type_high);
				result = false;
			}
			if (d1->caps != d2->caps) {
				printf("expected caps = 0x%02x\n"
				       "actual caps   = 0x%02x\n",
				       d1->caps, d2->caps);
				result = false;
			}
			if (d1->low_power_ctrl_an != d2->low_power_ctrl_an) {
				printf("expected low_power_ctrl_an = 0x%02x\n"
				       "actual low_power_ctrl_an   = 0x%02x\n",
				       d1->low_power_ctrl_an,
				       d2->low_power_ctrl_an);
				result = false;
			}
			if (d1->eee_cap != d2->eee_cap) {
				printf("expected eee_cap = 0x%04x\n"
				       "actual eee_cap   = 0x%04x\n",
				       d1->eee_cap, d2->eee_cap);
				result = false;
			}
			if (d1->eeer_value != d2->eeer_value) {
				printf("expected eeer_value = 0x%04x\n"
				       "actual eeer_value   = 0x%04x\n",
				       d1->eeer_value, d2->eeer_value);
				result = false;
			}
			if (d1->link_fec_opt != d2->link_fec_opt) {
				printf("expected link_fec_opt = 0x%02x\n"
				       "actual link_fec_opt   = 0x%02x\n",
				       d1->link_fec_opt, d2->link_fec_opt);
				result = false;
			}
			if (!result)
				printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n"
				       "Error, actual/expected ice_aqc_set_phy_cfg_data"
				       " does not match!\n");

			return result;
		}

		virtual SimpleString valueToString(const void *obj)
		{
			return StringFrom(obj);
		}
};

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

/* tests begin */
TEST_GROUP(ice_nic_ethtool)
{
	/* these stick around for the life of the test */
	PhyCfgDataComparator phyCfgDataComparator;
	PhyCapsDataCopier phyCapsDataCopier;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 5, 5);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		np->vsi = vsi;
		np->vsi->back = pf;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
		vsi->alloc_txq = 5;
		vsi->alloc_rxq = 5;
		vsi->num_txq = 1;
		vsi->num_rxq = 1;
		vsi->rx_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		vsi->tx_rings = (struct ice_ring **)calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT
		vsi->num_xdp_txq = 5;
		vsi->xdp_rings = (struct ice_ring **)calloc(vsi->num_xdp_txq, sizeof(struct ice_ring *));
		for (int i = 0; i < vsi->num_xdp_txq; i++)
			vsi->xdp_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */
		for (int i = 0; i < vsi->alloc_txq; i++)
			vsi->tx_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		for (int i = 0; i < vsi->alloc_rxq; i++)
			vsi->rx_rings[i] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
		vsi->port_info->lport = 0;
		hw = (struct ice_hw *)calloc(1, sizeof(struct ice_hw));
		hw->back = pf;
		vsi->port_info->hw = hw;
		hw->hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(struct ice_vsi*));
		pf->vsi[0] = vsi;

		pf->hw.func_caps.common_cap.num_txq = 128;
		pf->hw.func_caps.common_cap.num_rxq = 256;

		mock().installCopier("struct ice_aqc_get_phy_caps_data *",
				     phyCapsDataCopier);
		mock().installComparator("struct ice_aqc_set_phy_cfg_data *",
					 phyCfgDataComparator);
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		mock().removeAllComparatorsAndCopiers();

		for (int i = 0; i < vsi->alloc_txq; i++)
			free(vsi->tx_rings[i]);
		for (int i = 0; i < vsi->alloc_rxq; i++)
			free(vsi->rx_rings[i]);
		free(vsi->rx_rings);
		free(vsi->tx_rings);
#ifdef XDP_SUPPORT
#ifdef HAVE_XDP_SUPPORT
		for (int i = 0; i < vsi->num_xdp_txq; i++) {
			free(vsi->xdp_rings[i]->tx_buf);
			free(vsi->xdp_rings[i]);
		}
		free(vsi->xdp_rings);
#endif /* HAVE_XDP_SUPPORT */
#endif /* XDP_SUPPORT */
		free(vsi->port_info);
		free(vsi);
		free_netdev(netdev);
		free(pf->vsi);
		free(pf->pdev);
		free(pf);
		free(hw->hw_addr);
		free(hw);

		netdev = NULL;
		vsi = NULL;
		np = NULL;
		pf = NULL;
	}
};

TEST(ice_nic_ethtool, ice_get_sset_count)
{
	int initial, count;

	/* get initial stat count */
	initial = ice_get_sset_count(netdev, ETH_SS_STATS);

	/* use a few more rings */
	vsi->num_txq = vsi->alloc_txq;
	vsi->num_rxq = vsi->alloc_rxq;

	/* get stats count again */
	count = ice_get_sset_count(netdev, ETH_SS_STATS);

	/* if private flags ever get added, it would be worth verifying that
	 * changing these do not impact the number of stats either, as this is
	 * a common mistake.
	 */

	/* make sure it didn't change */
	CHECK_EQUAL(initial, count);
}

#if defined(ESWITCH_SUPPORT) || defined(BMSM_MODE)
TEST(ice_nic_ethtool, ice_repr_get_sset_count)
{
	int size;

	size = ice_repr_get_sset_count(netdev, ETH_SS_STATS);
	CHECK_EQUAL((int)ICE_VSI_STATS_LEN, size);
}
#endif /* ESWITCH_SUPPORT || BMSM_MODE */

static void
set_default_phy_type_and_speed(struct ethtool_link_ksettings *ks_expected,
			       struct ice_port_info *pi)
{
	memset(ks_expected, 0, sizeof(struct ethtool_link_ksettings));

	pi->phy.phy_type_low =
		(ICE_PHY_TYPE_LOW_100BASE_TX | ICE_PHY_TYPE_LOW_1000BASE_T |
		 ICE_PHY_TYPE_LOW_1000BASE_SX | ICE_PHY_TYPE_LOW_1000BASE_KX |
		 ICE_PHY_TYPE_LOW_2500BASE_T | ICE_PHY_TYPE_LOW_2500BASE_X |
		 ICE_PHY_TYPE_LOW_10GBASE_T | ICE_PHY_TYPE_LOW_10GBASE_KR_CR1 |
		 ICE_PHY_TYPE_LOW_10GBASE_SR | ICE_PHY_TYPE_LOW_40GBASE_KR4 |
		 ICE_PHY_TYPE_LOW_40GBASE_CR4 | ICE_PHY_TYPE_LOW_40GBASE_SR4 |
		 ICE_PHY_TYPE_LOW_40GBASE_LR4);
	pi->phy.link_info.req_speeds =
		(ICE_AQ_LINK_SPEED_100MB | ICE_AQ_LINK_SPEED_1000MB |
		 ICE_AQ_LINK_SPEED_2500MB | ICE_AQ_LINK_SPEED_5GB |
		 ICE_AQ_LINK_SPEED_10GB | ICE_AQ_LINK_SPEED_25GB |
		 ICE_AQ_LINK_SPEED_40GB);
#ifdef HAVE_ETHTOOL_5G_BITS
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_5GBASE_T;
#endif /* HAVE_ETHTOOL_5G_BITS */
#ifdef HAVE_ETHTOOL_25G_BITS
	pi->phy.phy_type_low |=
		(ICE_PHY_TYPE_LOW_25GBASE_T | ICE_PHY_TYPE_LOW_25GBASE_SR |
		 ICE_PHY_TYPE_LOW_25GBASE_KR);
#endif /* HAVE_ETHTOOL_25G_BITS */
#ifdef HAVE_ETHTOOL_50G_BITS
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_50GB;
	pi->phy.phy_type_low |=
		(ICE_PHY_TYPE_LOW_50GBASE_CR2 | ICE_PHY_TYPE_LOW_50GBASE_KR2);
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_50GB;
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_50GBASE_SR2;
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
	pi->phy.phy_type_low |= ICE_PHY_TYPE_LOW_100GBASE_SR4;
	pi->phy.phy_type_high = ICE_PHY_TYPE_HIGH_100G_CAUI2_AOC_ACC;
	pi->phy.link_info.req_speeds |= ICE_AQ_LINK_SPEED_100GB;
#endif /* HAVE_ETHTOOL_100G_BITS */

	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100baseT_Full);
#ifdef HAVE_ETHTOOL_NEW_1G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseX_Full);
#endif /* HAVE_ETHTOOL_NEW_1G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseKX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseKX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     2500baseX_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     2500baseX_Full);
#ifdef HAVE_ETHTOOL_NEW_2500MB_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     2500baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     2500baseT_Full);
#endif  /* HAVE_ETHTOOL_NEW_2500MB_BITS */
#ifdef HAVE_ETHTOOL_5G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     5000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     5000baseT_Full);
#endif /* HAVE_ETHTOOL_5G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseT_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseKR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseKR_Full);
#ifdef HAVE_ETHTOOL_NEW_10G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     10000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     10000baseSR_Full);
#endif /* HAVE_ETHTOOL_NEW_10G_BITS */
#ifdef HAVE_ETHTOOL_25G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseCR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseCR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseSR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     25000baseKR_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     25000baseKR_Full);
#endif /* HAVE_ETHTOOL_25G_BITS */
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseKR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseKR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     40000baseLR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     40000baseLR4_Full);
#ifdef HAVE_ETHTOOL_50G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseCR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseCR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseKR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseKR2_Full);
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     50000baseSR2_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     50000baseSR2_Full);
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100000baseCR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, supported,
					     100000baseSR4_Full);
	ethtool_link_ksettings_add_link_mode(ks_expected, advertising,
					     100000baseSR4_Full);
#endif /* HAVE_ETHTOOL_100G_BITS */
}

TEST(ice_nic_ethtool, ice_phy_type_caps_to_ethtool)
{
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;
	unsigned int idx = 0;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));

	set_default_phy_type_and_speed(&ks_expected, pi);

	ice_phy_type_to_ethtool(netdev, &ks);

	for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
		CHECK_EQUAL(ks_expected.link_modes.supported[idx],
			    ks.link_modes.supported[idx]);
		CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
			    ks.link_modes.advertising[idx]);
	}
}

TEST(ice_nic_ethtool, ice_phy_type_caps_ethtool_lkup)
{
#define ICE_PHY_TYPE_LOW_SIZE (ICE_PHY_TYPE_LOW_MAX_INDEX + 1)

	/* Lookup table mapping PHY type low to link speed and ethtool link modes */
	struct ice_phy_type_to_ethtool phy_type_low_lkup[ICE_PHY_TYPE_LOW_SIZE] = {
		/* ICE_PHY_TYPE_LOW_100BASE_TX */
		ICE_PHY_TYPE(0, 100MB, 100baseT_Full),
		/* ICE_PHY_TYPE_LOW_100M_SGMII */
		ICE_PHY_TYPE(1, 100MB, 100baseT_Full),
		/* ICE_PHY_TYPE_LOW_1000BASE_T */
		ICE_PHY_TYPE(2, 1000MB, 1000baseT_Full),
#ifdef HAVE_ETHTOOL_NEW_1G_BITS
		/* ICE_PHY_TYPE_LOW_1000BASE_SX */
		ICE_PHY_TYPE(3, 1000MB, 1000baseX_Full),
		/* ICE_PHY_TYPE_LOW_1000BASE_LX */
		ICE_PHY_TYPE(4, 1000MB, 1000baseX_Full),
#else
		/* ICE_PHY_TYPE_LOW_1000BASE_SX */
		ICE_PHY_TYPE(3, 1000MB, 1000baseT_Full),
		/* ICE_PHY_TYPE_LOW_1000BASE_LX */
		ICE_PHY_TYPE(4, 1000MB, 1000baseT_Full),
#endif /* HAVE_ETHTOOL_NEW_1G_BITS */
		/* ICE_PHY_TYPE_LOW_1000BASE_KX */
		ICE_PHY_TYPE(5, 1000MB, 1000baseKX_Full),
		/* ICE_PHY_TYPE_LOW_1G_SGMII */
		ICE_PHY_TYPE(6, 1000MB, 1000baseT_Full),
#ifdef HAVE_ETHTOOL_NEW_2500MB_BITS
		/* ICE_PHY_TYPE_LOW_2500BASE_T */
		ICE_PHY_TYPE(7, 2500MB, 2500baseT_Full),
#else
		/* ICE_PHY_TYPE_LOW_2500BASE_T */
		ICE_PHY_TYPE(7, 2500MB, 2500baseX_Full),
#endif /* HAVE_ETHTOOL_NEW_2500MB_BITS */
		/* ICE_PHY_TYPE_LOW_2500BASE_X */
		ICE_PHY_TYPE(8, 2500MB, 2500baseX_Full),
		/* ICE_PHY_TYPE_LOW_2500BASE_KX */
		ICE_PHY_TYPE(9, 2500MB, 2500baseX_Full),
#ifdef HAVE_ETHTOOL_5G_BITS
		/* ICE_PHY_TYPE_LOW_5GBASE_T */
		ICE_PHY_TYPE(10, 5GB, 5000baseT_Full),
		/* ICE_PHY_TYPE_LOW_5GBASE_KR */
		ICE_PHY_TYPE(11, 5GB, 5000baseT_Full),
#else /* HAVE_ETHTOOL_5G_BITS */
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(10),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(11),
#endif /* HAVE_ETHTOOL_5G_BITS */
		/* ICE_PHY_TYPE_LOW_10GBASE_T */
		ICE_PHY_TYPE(12, 10GB, 10000baseT_Full),
#ifdef HAVE_ETHTOOL_NEW_10G_BITS
		/* ICE_PHY_TYPE_LOW_10G_SFI_DA */
		ICE_PHY_TYPE(13, 10GB, 10000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_10GBASE_SR */
		ICE_PHY_TYPE(14, 10GB, 10000baseSR_Full),
		/* ICE_PHY_TYPE_LOW_10GBASE_LR */
		ICE_PHY_TYPE(15, 10GB, 10000baseLR_Full),
#else
		/* ICE_PHY_TYPE_LOW_10G_SFI_DA */
		ICE_PHY_TYPE(13, 10GB, 10000baseT_Full),
		/* ICE_PHY_TYPE_LOW_10GBASE_SR */
		ICE_PHY_TYPE(14, 10GB, 10000baseT_Full),
		/* ICE_PHY_TYPE_LOW_10GBASE_LR */
		ICE_PHY_TYPE(15, 10GB, 10000baseT_Full),
#endif /* HAVE_ETHTOOL_NEW_10G_BITS */
		/* ICE_PHY_TYPE_LOW_10GBASE_KR_CR1 */
		ICE_PHY_TYPE(16, 10GB, 10000baseKR_Full),
#ifdef HAVE_ETHTOOL_NEW_10G_BITS
		/* ICE_PHY_TYPE_LOW_10G_SFI_AOC_ACC */
		ICE_PHY_TYPE(17, 10GB, 10000baseCR_Full),
#else
		/* ICE_PHY_TYPE_LOW_10G_SFI_AOC_ACC */
		ICE_PHY_TYPE(17, 10GB, 10000baseT_Full),
#endif
		/* ICE_PHY_TYPE_LOW_10G_SFI_C2C */
		ICE_PHY_TYPE(18, 10GB, 10000baseKR_Full),
#ifdef HAVE_ETHTOOL_25G_BITS
		/* ICE_PHY_TYPE_LOW_25GBASE_T */
		ICE_PHY_TYPE(19, 25GB, 25000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_CR */
		ICE_PHY_TYPE(20, 25GB, 25000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_CR_S */
		ICE_PHY_TYPE(21, 25GB, 25000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_CR1 */
		ICE_PHY_TYPE(22, 25GB, 25000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_SR */
		ICE_PHY_TYPE(23, 25GB, 25000baseSR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_LR */
		ICE_PHY_TYPE(24, 25GB, 25000baseSR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_KR */
		ICE_PHY_TYPE(25, 25GB, 25000baseKR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_KR_S */
		ICE_PHY_TYPE(26, 25GB, 25000baseKR_Full),
		/* ICE_PHY_TYPE_LOW_25GBASE_KR1 */
		ICE_PHY_TYPE(27, 25GB, 25000baseKR_Full),
		/* ICE_PHY_TYPE_LOW_25G_AUI_AOC_ACC */
		ICE_PHY_TYPE(28, 25GB, 25000baseSR_Full),
		/* ICE_PHY_TYPE_LOW_25G_AUI_C2C */
		ICE_PHY_TYPE(29, 25GB, 25000baseCR_Full),
#else /* HAVE_ETHTOOL_25G_BITS */
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(19),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(20),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(21),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(22),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(23),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(24),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(25),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(26),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(27),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(28),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(29),
#endif /* HAVE_ETHTOOL_25G_BITS */
		/* ICE_PHY_TYPE_LOW_40GBASE_CR4 */
		ICE_PHY_TYPE(30, 40GB, 40000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_40GBASE_SR4 */
		ICE_PHY_TYPE(31, 40GB, 40000baseSR4_Full),
		/* ICE_PHY_TYPE_LOW_40GBASE_LR4 */
		ICE_PHY_TYPE(32, 40GB, 40000baseLR4_Full),
		/* ICE_PHY_TYPE_LOW_40GBASE_KR4 */
		ICE_PHY_TYPE(33, 40GB, 40000baseKR4_Full),
		/* ICE_PHY_TYPE_LOW_40G_XLAUI_AOC_ACC */
		ICE_PHY_TYPE(34, 40GB, 40000baseSR4_Full),
		/* ICE_PHY_TYPE_LOW_40G_XLAUI */
		ICE_PHY_TYPE(35, 40GB, 40000baseCR4_Full),
#ifdef HAVE_ETHTOOL_50G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_CR2 */
		ICE_PHY_TYPE(36, 50GB, 50000baseCR2_Full),
#else
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(36),
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_SR2 */
		ICE_PHY_TYPE(37, 50GB, 50000baseSR2_Full),
		/* ICE_PHY_TYPE_LOW_50GBASE_LR2 */
		ICE_PHY_TYPE(38, 50GB, 50000baseSR2_Full),
#else
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(37),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(38),
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_50G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_KR2 */
		ICE_PHY_TYPE(39, 50GB, 50000baseKR2_Full),
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
		/* ICE_PHY_TYPE_LOW_50G_LAUI2_AOC_ACC */
		ICE_PHY_TYPE(40, 50GB, 50000baseSR2_Full),
#else
		/* ICE_PHY_TYPE_LOW_50G_LAUI2_AOC_ACC */
		ICE_PHY_TYPE(40, 50GB, 50000baseCR2_Full),
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
		/* ICE_PHY_TYPE_LOW_50G_LAUI2 */
		ICE_PHY_TYPE(41, 50GB, 50000baseCR2_Full),
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
		/* ICE_PHY_TYPE_LOW_50G_AUI2_AOC_ACC */
		ICE_PHY_TYPE(42, 50GB, 50000baseSR2_Full),
#else
		/* ICE_PHY_TYPE_LOW_50G_AUI2_AOC_ACC */
		ICE_PHY_TYPE(42, 50GB, 50000baseCR2_Full),
#endif
		/* ICE_PHY_TYPE_LOW_50G_AUI2 */
		ICE_PHY_TYPE(43, 50GB, 50000baseCR2_Full),
#ifdef deHAVE_ETHTOOL_200G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_CP */
		ICE_PHY_TYPE(44, 50GB, 50000baseCR_Full),
		/* ICE_PHY_TYPE_LOW_50GBASE_SR */
		ICE_PHY_TYPE(45, 50GB, 50000baseSR_Full),
#else
		/* ICE_PHY_TYPE_LOW_50GBASE_CP */
		ICE_PHY_TYPE(44, 50GB, 50000baseCR2_Full),
		/* ICE_PHY_TYPE_LOW_50GBASE_SR */
		ICE_PHY_TYPE(45, 50GB, 50000baseCR2_Full),
#endif /* HAVE_ETHTOOL_200G_BITS */
#else /* HAVE_ETHTOOL_50G_BITS */
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(39),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(40),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(41),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(42),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(43),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(44),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(45),
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
#ifdef HAVE_ETHTOOL_200G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_FR */
		ICE_PHY_TYPE(46, 50GB, 50000baseLR_ER_FR_Full),
		/* ICE_PHY_TYPE_LOW_50GBASE_LR */
		ICE_PHY_TYPE(47, 50GB, 50000baseLR_ER_FR_Full),
#else
		/* ICE_PHY_TYPE_LOW_50GBASE_FR */
		ICE_PHY_TYPE(46, 50GB, 50000baseSR2_Full),
		/* ICE_PHY_TYPE_LOW_50GBASE_LR */
		ICE_PHY_TYPE(47, 50GB, 50000baseSR2_Full),
#endif /* HAVE_ETHTOOL_200G_BITS */
#else
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(46),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(47),
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_50G_BITS
#ifdef HAVE_ETHTOOL_200G_BITS
		/* ICE_PHY_TYPE_LOW_50GBASE_KR_PAM4 */
		ICE_PHY_TYPE(48, 50GB, 50000baseKR_Full),
		/* ICE_PHY_TYPE_LOW_50G_AUI1_AOC_ACC */
		ICE_PHY_TYPE(49, 50GB, 50000baseSR_Full),
		/* ICE_PHY_TYPE_LOW_50G_AUI1 */
		ICE_PHY_TYPE(50, 50GB, 50000baseCR_Full),
#else
		/* ICE_PHY_TYPE_LOW_50GBASE_KR_PAM4 */
		ICE_PHY_TYPE(48, 50GB, 50000baseKR2_Full),
		/* ICE_PHY_TYPE_LOW_50G_AUI1_AOC_ACC */
		ICE_PHY_TYPE(49, 50GB, 50000baseCR2_Full),
		/* ICE_PHY_TYPE_LOW_50G_AUI1 */
		ICE_PHY_TYPE(50, 50GB, 50000baseCR2_Full),
#endif /* HAVE_ETHTOOL_200G_BITS */
#else
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(48),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(49),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(50),
#endif /* HAVE_ETHTOOL_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
		/* ICE_PHY_TYPE_LOW_100GBASE_CR4 */
		ICE_PHY_TYPE(51, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_SR4 */
		ICE_PHY_TYPE(52, 100GB, 100000baseSR4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_LR4 */
		ICE_PHY_TYPE(53, 100GB, 100000baseLR4_ER4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_KR4 */
		ICE_PHY_TYPE(54, 100GB, 100000baseKR4_Full),
		/* ICE_PHY_TYPE_LOW_100G_CAUI4_AOC_ACC */
		ICE_PHY_TYPE(55, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100G_CAUI4 */
		ICE_PHY_TYPE(56, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100G_AUI4_AOC_ACC */
		ICE_PHY_TYPE(57, 100GB, 100000baseSR4_Full),
		/* ICE_PHY_TYPE_LOW_100G_AUI4 */
		ICE_PHY_TYPE(58, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_CR_PAM4 */
		ICE_PHY_TYPE(59, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_KR_PAM4 */
		ICE_PHY_TYPE(60, 100GB, 100000baseKR4_Full),
#ifdef HAVE_ETHTOOL_NEW_100G_BITS
		/* ICE_PHY_TYPE_LOW_100GBASE_CP2 */
		ICE_PHY_TYPE(61, 100GB, 100000baseCR2_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_SR2 */
		ICE_PHY_TYPE(62, 100GB, 100000baseSR2_Full),
#else
		/* ICE_PHY_TYPE_LOW_100GBASE_CP2 */
		ICE_PHY_TYPE(61, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_LOW_100GBASE_SR2 */
		ICE_PHY_TYPE(62, 100GB, 100000baseSR4_Full),
#endif /* HAVE_ETHTOOL_NEW_100G_BITS */
		/* ICE_PHY_TYPE_LOW_100GBASE_DR */
		ICE_PHY_TYPE(63, 100GB, 100000baseLR4_ER4_Full),
#else /* HAVE_ETHTOOL_100G_BITS */
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(51),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(52),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(53),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(54),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(55),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(56),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(57),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(58),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(59),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(60),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(61),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(62),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(63),
#endif /* HAVE_ETHTOOL_100G_BITS */
	};

#ifdef HAVE_ETHTOOL_100G_BITS
#define ICE_PHY_TYPE_HIGH_SIZE (ICE_PHY_TYPE_HIGH_MAX_INDEX + 1)

	/* Lookup table mapping PHY type high to link speed and ethtool link modes */
	struct ice_phy_type_to_ethtool phy_type_high_lkup[ICE_PHY_TYPE_HIGH_SIZE] = {
#ifdef HAVE_ETHTOOL_NEW_100G_BITS
		/* ICE_PHY_TYPE_HIGH_100GBASE_KR2_PAM4 */
		ICE_PHY_TYPE(0, 100GB, 100000baseKR2_Full),
		/* ICE_PHY_TYPE_HIGH_100G_CAUI2_AOC_ACC */
		ICE_PHY_TYPE(1, 100GB, 100000baseSR2_Full),
		/* ICE_PHY_TYPE_HIGH_100G_CAUI2 */
		ICE_PHY_TYPE(2, 100GB, 100000baseCR2_Full),
		/* ICE_PHY_TYPE_HIGH_100G_AUI2_AOC_ACC */
		ICE_PHY_TYPE(3, 100GB, 100000baseSR2_Full),
		/* ICE_PHY_TYPE_HIGH_100G_AUI2 */
		ICE_PHY_TYPE(4, 100GB, 100000baseCR2_Full),
#else
		/* ICE_PHY_TYPE_HIGH_100GBASE_KR2_PAM4 */
		ICE_PHY_TYPE(0, 100GB, 100000baseKR4_Full),
		/* ICE_PHY_TYPE_HIGH_100G_CAUI2_AOC_ACC */
		ICE_PHY_TYPE(1, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_HIGH_100G_CAUI2 */
		ICE_PHY_TYPE(2, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_HIGH_100G_AUI2_AOC_ACC */
		ICE_PHY_TYPE(3, 100GB, 100000baseCR4_Full),
		/* ICE_PHY_TYPE_HIGH_100G_AUI2 */
		ICE_PHY_TYPE(4, 100GB, 100000baseCR4_Full),
#endif /* HAVE_ETHTOOL_NEW_100G_BITS */
#ifdef E830_SUPPORT
#ifdef HAVE_ETHTOOL_200G_BITS
		/* ICE_PHY_TYPE_HIGH_200G_CR4_PAM4 */
		ICE_PHY_TYPE(5, 200GB, 200000baseCR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_SR4 */
		ICE_PHY_TYPE(6, 200GB, 200000baseSR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_FR4 */
		ICE_PHY_TYPE(7, 200GB, 200000baseLR4_ER4_FR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_LR4 */
		ICE_PHY_TYPE(8, 200GB, 200000baseLR4_ER4_FR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_DR4 */
		ICE_PHY_TYPE(9, 200GB, 200000baseDR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_KR4_PAM4 */
		ICE_PHY_TYPE(10, 200GB, 200000baseKR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_AUI4_AOC_ACC */
		ICE_PHY_TYPE(11, 200GB, 200000baseSR4_Full),
		/* ICE_PHY_TYPE_HIGH_200G_AUI4 */
		ICE_PHY_TYPE(12, 200GB, 200000baseCR4_Full),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(13),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(14),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(15),
#else /* HAVE_ETHTOOL_200G_BITS */
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(5),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(6),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(7),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(8),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(9),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(10),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(11),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(12),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(13),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(14),
		ICE_PHY_TYPE_ETHTOOL_UNSUPPORTED(15),
#endif /* HAVE_ETHTOOL_200G_BITS */
#endif /* E830_SUPPORT */
	};
#endif /* HAVE_ETHTOOL_100G_BITS */
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));

	pi->phy.phy_type_low = 0;
	pi->phy.phy_type_high = 0;

	for (int index = 0; index <= ICE_PHY_TYPE_LOW_MAX_INDEX; index++)
	{
		unsigned int idx = 0;

		pi->phy.phy_type_low = BIT_ULL(phy_type_low_lkup[index].phy_type_idx);
		ice_phy_type_to_ethtool(netdev, &ks);

		if (!phy_type_low_lkup[index].ethtool_link_mode_supported) {
			for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
				CHECK_EQUAL(0, ks.link_modes.supported[idx]);
				CHECK_EQUAL(0, ks.link_modes.advertising[idx]);
			}
			continue;
		}

		linkmode_zero(ks_expected.link_modes.supported);
		linkmode_zero(ks_expected.link_modes.advertising);

		linkmode_set_bit(phy_type_low_lkup[index].link_mode,
				 ks_expected.link_modes.supported);
		linkmode_set_bit(phy_type_low_lkup[index].link_mode,
				 ks_expected.link_modes.advertising);

		for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
			CHECK_EQUAL(ks_expected.link_modes.supported[idx],
				    ks.link_modes.supported[idx]);
			CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
				    ks.link_modes.advertising[idx]);
		}
	}

	pi->phy.phy_type_low = 0;

	for (int index = 0; index <= ICE_PHY_TYPE_HIGH_MAX_INDEX; index++)
	{
		unsigned int idx = 0;

		pi->phy.phy_type_high = BIT_ULL(phy_type_high_lkup[index].phy_type_idx);
		ice_phy_type_to_ethtool(netdev, &ks);

		if (!phy_type_high_lkup[index].ethtool_link_mode_supported) {
			for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
				CHECK_EQUAL(0, ks.link_modes.supported[idx]);
				CHECK_EQUAL(0, ks.link_modes.advertising[idx]);
			}
			continue;
		}

		linkmode_zero(ks_expected.link_modes.supported);
		linkmode_zero(ks_expected.link_modes.advertising);

		linkmode_set_bit(phy_type_high_lkup[index].link_mode,
				 ks_expected.link_modes.supported);
		linkmode_set_bit(phy_type_high_lkup[index].link_mode,
				 ks_expected.link_modes.advertising);

		for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
			CHECK_EQUAL(ks_expected.link_modes.supported[idx],
				    ks.link_modes.supported[idx]);
			CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
				    ks.link_modes.advertising[idx]);
		}
	}
}

#ifdef ETHTOOL_GLINKSETTINGS
TEST(ice_nic_ethtool, ice_get_settings_link_up)
{
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;
	unsigned int idx = 0;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));

	pi->phy.link_info.phy_type_low = ICE_PHY_TYPE_LOW_1000BASE_T;
	pi->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.link_info.req_speeds = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.phy_type_low = ICE_PHY_TYPE_LOW_1000BASE_T |
		ICE_PHY_TYPE_LOW_1000BASE_SX;

	ethtool_link_ksettings_add_link_mode(&ks_expected, supported,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, supported,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     1000baseT_Full);
	ks_expected.base.speed = SPEED_1000;

	ice_get_settings_link_up(&ks, netdev);

	CHECK_EQUAL(ks_expected.base.speed, ks.base.speed);
	for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
		CHECK_EQUAL(ks_expected.link_modes.supported[idx],
			    ks.link_modes.supported[idx]);
		CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
			    ks.link_modes.advertising[idx]);
	}
}

TEST(ice_nic_ethtool, ice_get_settings_link_down)
{
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;
	unsigned int idx = 0;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));

	set_default_phy_type_and_speed(&ks_expected, pi);
	ks_expected.base.speed = SPEED_UNKNOWN;
	ks_expected.base.duplex = DUPLEX_UNKNOWN;

	ice_get_settings_link_down(&ks, netdev);

	CHECK_EQUAL(ks_expected.base.speed, ks.base.speed);
	CHECK_EQUAL(ks_expected.base.duplex, ks.base.duplex);
	for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
		CHECK_EQUAL(ks_expected.link_modes.supported[idx],
			    ks.link_modes.supported[idx]);
		CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
			    ks.link_modes.advertising[idx]);
	}

}

#ifndef BMSM_MODE
TEST(ice_nic_ethtool, ice_ksettings_find_adv_link_speed)
{
	u16 expected_adv_speed, actual_adv_speed;
	struct ethtool_link_ksettings ks;

	expected_adv_speed = ICE_AQ_LINK_SPEED_100MB |
		ICE_AQ_LINK_SPEED_1000MB | ICE_AQ_LINK_SPEED_2500MB |
		ICE_AQ_LINK_SPEED_10GB | ICE_AQ_LINK_SPEED_40GB;
	ethtool_link_ksettings_add_link_mode(&ks, advertising, 100baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks, advertising, 1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks, advertising, 2500baseX_Full);
	ethtool_link_ksettings_add_link_mode(&ks, advertising,
					     10000baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks, advertising,
					     40000baseCR4_Full);

#ifdef HAVE_ETHTOOL_5G_BITS
	expected_adv_speed |= ICE_AQ_LINK_SPEED_5GB;
	ethtool_link_ksettings_add_link_mode(&ks, advertising, 5000baseT_Full);
#endif /* HAVE_ETHTOOL_5G_BITS */
#ifdef HAVE_ETHTOOL_25G_BITS
	expected_adv_speed |= ICE_AQ_LINK_SPEED_25GB;
	ethtool_link_ksettings_add_link_mode(&ks, advertising,
					     25000baseCR_Full);
#endif /* HAVE_ETHTOOL_5G_BITS */
#ifdef HAVE_ETHTOOL_NEW_50G_BITS
	expected_adv_speed |= ICE_AQ_LINK_SPEED_50GB;
	ethtool_link_ksettings_add_link_mode(&ks, advertising,
					     50000baseSR2_Full);
#endif /* HAVE_ETHTOOL_NEW_50G_BITS */
#ifdef HAVE_ETHTOOL_100G_BITS
		expected_adv_speed |= ICE_AQ_LINK_SPEED_100GB;
	ethtool_link_ksettings_add_link_mode(&ks, advertising,
					     100000baseKR4_Full);
#endif /* HAVE_ETHTOOL_100G_BITS */

	actual_adv_speed = ice_ksettings_find_adv_link_speed(&ks);
	CHECK_EQUAL(actual_adv_speed, expected_adv_speed);
}

TEST(ice_nic_ethtool, ice_setup_autoneg)
{
	struct ice_port_info *p = vsi->port_info;
	struct ethtool_link_ksettings ks;
	struct ice_aqc_set_phy_cfg_data config = {0};
	u8 autoneg_enabled = 0, autoneg_changed = 0;
	int err;

	// Test case 1 : Autoneg change from disable to enable
	autoneg_enabled = AUTONEG_ENABLE;
	ethtool_link_ksettings_add_link_mode(&ks, supported, Autoneg);
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(ICE_AQ_PHY_ENA_AUTO_LINK_UPDT, config.caps);
	CHECK_EQUAL(1, autoneg_changed);

	// Test case 2 : No change on Autoneg which is already enabled
	p->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	autoneg_enabled = AUTONEG_ENABLE;
	config.caps = 0;
	memset(&config, 0, sizeof(config));
	memset(&ks, 0, sizeof(ks));
	ethtool_link_ksettings_add_link_mode(&ks, supported, Autoneg);
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, config.caps);
	CHECK_EQUAL(0, autoneg_changed);

	// Test case 3 : Autoneg change from enable to disable
	p->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	autoneg_enabled = 0;
	memset(&ks, 0, sizeof(ks));
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, config.caps);
	CHECK_EQUAL(1, autoneg_changed);

	// Test case 4 : No change on Autoneg which is already disabled
	p->phy.link_info.an_info = 0;
	memset(&ks, 0, sizeof(ks));
	autoneg_enabled = 0;
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(0, config.caps);
	CHECK_EQUAL(0, autoneg_changed);

	// Test case 5 : Autoneg not supported on this phy
	autoneg_enabled = AUTONEG_ENABLE;
	p->phy.link_info.an_info = 0;
	memset(&ks, 0, sizeof(ks));
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(-EINVAL, err);
	CHECK_EQUAL(0, config.caps);
	CHECK_EQUAL(0, autoneg_changed);

	// Test case 6 : Autoneg cannot be disabled on this phy
	autoneg_enabled = 0;
	p->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	memset(&ks, 0, sizeof(ks));
	ethtool_link_ksettings_add_link_mode(&ks, supported, Autoneg);
	err = ice_setup_autoneg(p, &ks, &config, autoneg_enabled,
				&autoneg_changed, netdev);
	CHECK_EQUAL(-EINVAL, err);
	CHECK_EQUAL(0, config.caps);
	CHECK_EQUAL(0, autoneg_changed);
}
#endif /* !BMSM_MODE */

TEST(ice_nic_ethtool, ice_get_link_ksettings)
{
	struct ice_aqc_get_phy_caps_data pcaps = { };
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks_expected;
	struct ethtool_link_ksettings ks;
	unsigned int idx = 0;

	memset(&ks_expected, 0, sizeof(struct ethtool_link_ksettings));
	memset(&ks, 0, sizeof(struct ethtool_link_ksettings));
	pi->phy.link_info.link_info = ICE_AQ_LINK_UP;
	pi->phy.link_info.phy_type_low = ICE_PHY_TYPE_LOW_1000BASE_T;
	pi->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	pi->phy.media_type = ICE_MEDIA_BACKPLANE;
	pi->fc.req_mode = ICE_FC_FULL;
	pi->phy.link_info.req_speeds = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.phy_type_low = ICE_PHY_TYPE_LOW_1000BASE_T |
		ICE_PHY_TYPE_LOW_1000BASE_SX;

	ethtool_link_ksettings_add_link_mode(&ks_expected, supported, Autoneg);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     Autoneg);
	ethtool_link_ksettings_add_link_mode(&ks_expected, supported,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     1000baseX_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, supported,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     1000baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks_expected, supported,
					     Backplane);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     Backplane);
	ethtool_link_ksettings_add_link_mode(&ks_expected, supported, Pause);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising, Pause);
	ethtool_link_ksettings_add_link_mode(&ks_expected, advertising,
					     Asym_Pause);
	ks_expected.base.port = PORT_NONE;
	ks_expected.base.speed = SPEED_1000;
	ks_expected.base.autoneg = AUTONEG_ENABLE;
	ks_expected.base.duplex = DUPLEX_FULL;

	pcaps.caps = ICE_AQC_PHY_EN_RX_LINK_PAUSE |
		     ICE_AQC_PHY_EN_TX_LINK_PAUSE;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_is_phy_caps_an_enabled")
			.ignoreOtherParameters()
			.andReturnValue(true);

	ice_get_link_ksettings(netdev, &ks);

	CHECK_EQUAL(ks_expected.base.port, ks.base.port);
	CHECK_EQUAL(ks_expected.base.speed, ks.base.speed);
	CHECK_EQUAL(ks_expected.base.autoneg, ks.base.autoneg);
	CHECK_EQUAL(ks_expected.base.duplex, ks.base.duplex);
	for (; idx < ETHTOOL_LINK_MASK_SIZE; idx++) {
		CHECK_EQUAL(ks_expected.link_modes.supported[idx],
			    ks.link_modes.supported[idx]);
		CHECK_EQUAL(ks_expected.link_modes.advertising[idx],
			    ks.link_modes.advertising[idx]);
	}
}

#ifndef BMSM_MODE
TEST(ice_nic_ethtool, ice_set_link_ksettings)
{
	struct ice_aqc_set_phy_cfg_data expected_cfg = { };
	struct ice_aqc_get_phy_caps_data pcaps = { };
	struct ice_port_info *pi = vsi->port_info;
	struct ethtool_link_ksettings ks = { };
	u64 phy_type_high;
	u64 phy_type_low;

	ethtool_link_ksettings_add_link_mode(&ks, supported, 100baseT_Full);
	ethtool_link_ksettings_add_link_mode(&ks, advertising, 100baseT_Full);
	ks.base.autoneg = AUTONEG_ENABLE;
	ks.base.duplex = DUPLEX_FULL;
	ks.base.speed = SPEED_100;
	ks.base.port = PORT_TP;

	pi->phy.phy_type_low = ICE_PHY_TYPE_LOW_100BASE_TX |
		ICE_PHY_TYPE_LOW_1000BASE_T;
	pi->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	pi->phy.link_info.phy_type_low = ICE_PHY_TYPE_LOW_1000BASE_T;
	pi->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.link_info.req_speeds = ICE_AQ_LINK_SPEED_1000MB;
	pi->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	pi->phy.link_info.link_info = ICE_AQ_LINK_UP;
	pi->phy.media_type = ICE_MEDIA_BASET;
	pi->fc.req_mode = ICE_FC_FULL;
	clear_bit(ICE_CFG_BUSY, pf->state);

	pcaps.phy_type_low = ICE_PHY_TYPE_LOW_100BASE_TX | ICE_PHY_TYPE_LOW_1000BASE_T;
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_get_link_status")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_is_phy_caps_an_enabled")
			.ignoreOtherParameters()
			.andReturnValue(true);

	phy_type_low = ICE_PHY_TYPE_LOW_100BASE_TX;
	phy_type_high = 0;
	mock().expectOneCall("ice_update_phy_type")
		.withOutputParameterReturning("phy_type_low", &phy_type_low, sizeof(u64 *))
		.withOutputParameterReturning("phy_type_high", &phy_type_high, sizeof(u64 *))
		.withParameter("link_speeds_bitmap", ICE_AQ_LINK_SPEED_100MB)
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_print_link_msg");
	mock().expectOneCall("ice_fw_supports_report_dflt_cfg").andReturnValue(true);

	expected_cfg.phy_type_low = ICE_PHY_TYPE_LOW_100BASE_TX;
	expected_cfg.caps = ICE_AQ_PHY_ENA_LINK | ICE_AQ_PHY_ENA_AUTO_LINK_UPDT;
	mock().expectOneCall("ice_aq_set_phy_cfg")
		.withParameterOfType("struct ice_aqc_set_phy_cfg_data *", "cfg",
				     &expected_cfg)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	ice_set_link_ksettings(netdev, &ks);
}
#endif /* !BMSM_MODE */
#endif /* ETHTOOL_GLINKSETTINGS */

#ifndef BMSM_MODE
TEST(ice_nic_ethtool, ice_set_pauseparam)
{
	struct ethtool_pauseparam *pp = (struct ethtool_pauseparam *)calloc(1, sizeof(ethtool_pauseparam));
	u8 out;
	int status;
	struct ice_port_info *pi=np->vsi->port_info;
#ifndef NO_DCB_SUPPORT
	struct ice_dcbx_cfg *dcbx_cfg = &pi->qos_cfg.local_dcbx_cfg;
#endif /* !NO_DCB_SUPPORT */
#ifdef ETHTOOL_GLINKSETTINGS
	struct ice_aqc_get_phy_caps_data pcaps_output = {};
#endif

	/* If VSI type is not PF, return error */
	pp->autoneg = pi->phy.link_info.an_info & ICE_AQ_AN_COMPLETED;
	vsi->type = ICE_VSI_VF;
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* If trying to change autoneg with ethtool -A, return error */
	vsi->type = ICE_VSI_PF;
#ifdef ETHTOOL_GLINKSETTINGS
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
#endif /* ETHTOOL_GLINKSETTINGS */
	pp->autoneg = 1;
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* If pfc is enabled, return error */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 1;
#endif
	pp->autoneg = 0;
#ifdef ETHTOOL_GLINKSETTINGS
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
#endif /* ETHTOOL_GLINKSETTINGS */
	mock().ignoreOtherCalls();
	status = ice_set_pauseparam(netdev, pp);

	/* If set_fc function returns error, return error */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	pp->rx_pause = 1;
	out = ICE_SET_FC_AQ_FAIL_GET;
	set_bit(ICE_DOWN, vsi->back->state);
#ifdef ETHTOOL_GLINKSETTINGS
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
#endif /* ETHTOOL_GLINKSETTINGS */
	mock().expectOneCall("ice_aq_str");
	mock().expectOneCall("ice_set_fc")
		.withOutputParameterReturning("aq_failures", &out, sizeof(out))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(-EAGAIN, status);

	/* Successful setting pauseparam */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	pp->rx_pause = 1;
	pp->autoneg = 1;
	pi->phy.link_info.an_info = ICE_AQ_AN_COMPLETED;
	out = 0;
	clear_bit(ICE_DOWN, vsi->back->state);
#ifdef ETHTOOL_GLINKSETTINGS
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(true);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
#endif /* ETHTOOL_GLINKSETTINGS */
	mock().expectOneCall("ice_set_fc")
		.withOutputParameterReturning("aq_failures", &out, sizeof(out))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	status = ice_set_pauseparam(netdev, pp);
	CHECK_EQUAL(0, status);

	free(pp);

}
#endif /* !BMSM_MODE */

#ifdef ETHTOOL_GFECPARAM

#else /* ETHTOOL_GFECPARAM */
TEST(ice_nic_ethtool, ice_get_pauseparam)
{
	struct ethtool_pauseparam *pp = (struct ethtool_pauseparam *)calloc(1, sizeof(ethtool_pauseparam));
	struct ice_port_info *pi=np->vsi->port_info;
#ifndef NO_DCB_SUPPORT
	struct ice_dcbx_cfg *dcbx_cfg = &pi->qos_cfg.local_dcbx_cfg;
#endif
	struct ice_aqc_get_phy_caps_data pcaps_output = {};

	pp->autoneg = pi->phy.link_info.an_info & ICE_AQ_AN_COMPLETED;

	/* PFC enabled so report LFC as off */
#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 1;
#endif
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
	ice_get_pauseparam(netdev, pp);
	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(0, pp->rx_pause);
	CHECK_EQUAL(0, pp->tx_pause);

#ifndef NO_DCB_SUPPORT
	dcbx_cfg->pfc.pfcena = 0;
#endif
	/* Report RX on */
	pcaps_output.caps |= ICE_AQC_PHY_EN_RX_LINK_PAUSE;
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
	ice_get_pauseparam(netdev, pp);
	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(1, pp->rx_pause);
	CHECK_EQUAL(0, pp->tx_pause);

	/* Report TX on */
	pcaps_output.caps = 0;
	pcaps_output.caps |= ICE_AQC_PHY_EN_TX_LINK_PAUSE;
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
	ice_get_pauseparam(netdev, pp);
	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(0, pp->rx_pause);
	CHECK_EQUAL(1, pp->tx_pause);

	/* Report TX on, RX on */
	pcaps_output.caps |= ICE_AQC_PHY_EN_RX_LINK_PAUSE;
	pcaps_output.caps |= ICE_AQC_PHY_EN_TX_LINK_PAUSE;
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters();
	ice_get_pauseparam(netdev, pp);
	CHECK_EQUAL(0, pp->autoneg);
	CHECK_EQUAL(1, pp->rx_pause);
	CHECK_EQUAL(1, pp->tx_pause);

	free(pp);
}
#endif /* ETHTOOL_GFECPARAM */

TEST_GROUP_BASE(ice_set_ringparam, TGN(ice_nic_ethtool))
{
	struct ethtool_ringparam *rp;
#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
	struct bpf_prog *xdp_prog;
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

	TEST_SETUP()
	{
		TGN(ice_nic_ethtool)::setup();

		rp = (struct ethtool_ringparam *)calloc(1, sizeof(ethtool_ringparam));
#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
		xdp_prog = (struct bpf_prog*)calloc(1, sizeof(struct bpf_prog));
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */
	}

	TEST_TEARDOWN()
	{
		free(rp);
		rp = NULL;

#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
		free(xdp_prog);
		xdp_prog = NULL;
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

		TGN(ice_nic_ethtool)::teardown();
	}
};

TEST(ice_set_ringparam, tx_below_minimum)
{
	int status;

	/* Tx descriptor minimum boundary case */
	rp->tx_pending = 7;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-EINVAL, status);
}

TEST(ice_set_ringparam, rx_below_minimum)
{
	int status;

	/* Rx descriptor maximum boundary case */
	rp->rx_pending = 8166;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-EINVAL, status);
}

TEST(ice_set_ringparam, no_change_in_tx_or_rx)
{
	int status, i;

	/* No change in descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[i]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
}

TEST(ice_set_ringparam, change_tx_count)
{
	int status, i;

	/* Change in Tx descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 128;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	mock().expectNCalls(vsi->num_txq, "ice_setup_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_txq, "ice_free_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	ice_for_each_txq(vsi, i)
		CHECK_EQUAL(rp->tx_pending, vsi->tx_rings[i]->count);
}

#if defined(XDP_SUPPORT) && defined(HAVE_XDP_SUPPORT)
TEST(ice_set_ringparam, change_xdp_count)
{
	int status, i;

	/* Change in Xdp descriptor count */
	clear_bit(ICE_VSI_DOWN, vsi->state);
	clear_bit(ICE_CFG_BUSY, np->vsi->back->state);
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 256;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	for (int i = 0; i < vsi->num_xdp_txq; i++)
		vsi->xdp_rings[i]->count = 128;
	rp->tx_pending =  64;
	vsi->xdp_prog = xdp_prog;
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	USE_STD_MOCK(ice_set_ring_xdp);
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
	mock().expectNCalls(vsi->num_txq + vsi->num_xdp_txq, "ice_setup_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_xdp_txq, "ice_set_ring_xdp")
		.ignoreOtherParameters();
	mock().expectNCalls(vsi->num_txq + vsi->num_xdp_txq, "ice_free_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	for (int i = 0; i < vsi->num_xdp_txq; i++)
		CHECK_EQUAL(rp->tx_pending, vsi->xdp_rings[i]->count);
}
#endif /* XDP_SUPPORT && HAVE_XDP_SUPPORT */

TEST(ice_set_ringparam, alloc_rx_bufs_fails)
{
	int status, i;

	/* Test ice_alloc_rx_bufs() fail case */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 128;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	mock().expectOneCall("ice_setup_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_alloc_rx_bufs")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	mock().expectOneCall("netif_running");

	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(-ENOMEM, status);
	ice_for_each_rxq(vsi, i)
		CHECK_EQUAL(128, vsi->rx_rings[i]->count);
}

TEST(ice_set_ringparam, change_rx_count)
{
	int status, i;

	/* Change in Rx descriptor count */
	ice_for_each_txq(vsi, i)
		vsi->tx_rings[0]->count = 256;
	ice_for_each_rxq(vsi, i)
		vsi->rx_rings[i]->count = 128;
	rp->tx_pending =  256;
	rp->rx_pending =  256;
	mock().expectNCalls(vsi->num_rxq, "ice_alloc_rx_bufs")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(vsi->num_rxq, "ice_setup_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectNCalls(vsi->num_rxq, "ice_free_rx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("netif_running");
	mock().expectOneCall("ice_down")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_up")
		.ignoreOtherParameters()
		.andReturnValue(0);
#ifdef XDP_SUPPORT
#ifdef HAVE_AF_XDP_ZC_SUPPORT
	mock().expectOneCall("ice_xsk_any_rx_ring_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* HAVE_AF_XDP_ZC_SUPPORT */
#endif /* XDP_SUPPORT */
	status = ice_set_ringparam(netdev, rp);
	CHECK_EQUAL(0, status);
	for (int i = 0; i < vsi->num_rxq; i++)
		CHECK_EQUAL(rp->rx_pending, vsi->rx_rings[i]->count);
}

TEST(ice_nic_ethtool, ice_get_drvinfo)
{
	struct ethtool_drvinfo *di = (struct ethtool_drvinfo *)calloc(1, sizeof(ethtool_drvinfo));
	struct ice_pf *pf = np->vsi->back;
	struct ice_hw *hw = &(pf->hw);

	hw->flash.nvm.eetrack = 0;
	hw->flash.nvm.major = 1;
	hw->flash.nvm.minor = 5;
	hw->flash.orom.major = 3;
	hw->flash.orom.build = 27;
	hw->flash.orom.patch = 9;

	ice_get_drvinfo(netdev, di);

	STRCMP_EQUAL(di->driver, KBUILD_MODNAME);
	STRCMP_EQUAL(di->version, ::ice_drv_ver);
	STRCMP_EQUAL(di->fw_version, "1.05 0x0 3.27.9");
	STRCMP_EQUAL(di->bus_info, pci_name(vsi->back->pdev));

	free(di);
}

TEST(ice_nic_ethtool, ice_set_get_msglevel)
{
	struct ice_pf *pf = np->vsi->back;
	u32 mask = 1;

	for (int i = 0; i < 31; i++) {
		mask |= (1 << i);
		ice_set_msglevel(netdev, mask);
		CHECK_EQUAL(mask, ice_get_msglevel(netdev));
		CHECK_EQUAL(mask, pf->msg_enable);
	}
}

TEST(ice_nic_ethtool, ice_get_regs_len)
{
	CHECK_EQUAL(sizeof(ice_regs_dump_list), ice_get_regs_len(netdev));
}

/* This allows TEST(ice_nic_ethtool, ice_get_regs) to be able to determine how big
 * of a fake register address space it needs to allocate to test ice_get_regs.  This
 * allows further registers to be added to ice_regs_dump_list without having to change
 * this test.
 */
static u32 ice_regs_dump_list_largest_addr()
{
	u32 largest_addr;

	largest_addr = ice_regs_dump_list[0];
	for (unsigned int i = 1; i < ARRAY_SIZE(ice_regs_dump_list); ++i) {
		if (largest_addr < ice_regs_dump_list[i])
			largest_addr = ice_regs_dump_list[i];
	}

	return largest_addr;
}

TEST(ice_nic_ethtool, ice_get_regs)
{
	struct ice_pf *pf = np->vsi->back;
	struct ice_hw *hw = &(pf->hw);
	struct ethtool_regs regs;
	u32 *regs_buf;
	unsigned int num_regs;

	num_regs = ARRAY_SIZE(ice_regs_dump_list);
	/* Allocate memory to fake out hw registers */
	hw->hw_addr = (u8*) calloc(ice_regs_dump_list_largest_addr(), sizeof(u32));
	regs_buf = (u32 *)calloc(num_regs, sizeof(u32));

	for (u32 i = 0; i < num_regs; ++i)
		wr32(hw, ice_regs_dump_list[i], i);

	ice_get_regs(netdev, &regs, (void *)regs_buf);

	for (u32 i = 0; i < num_regs; ++i)
		CHECK_EQUAL(i, regs_buf[i]);

	free(regs_buf);
	free(hw->hw_addr);
}

#ifndef BMSM_MODE
TEST(ice_nic_ethtool, ice_nway_reset)
{
	int status;

	/* Successful restart */
	mock().expectOneCall("ice_set_link")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_nway_reset(netdev);
	CHECK_EQUAL(0, status);

	/* Unsuccessful restart */
	mock().expectOneCall("ice_set_link")
		.ignoreOtherParameters()
		.andReturnValue(-EINVAL);
	status = ice_nway_reset(netdev);
	CHECK_EQUAL(-EINVAL, status);
}
#endif /* !BMSM_MODE */

#ifndef SWITCH_MODE
TEST(ice_nic_ethtool, ice_get_ts_info)
{
	struct ice_pf *pf = np->vsi->back;
	struct ethtool_ts_info info;
	int status;

	set_bit(ICE_FLAG_PTP, pf->flags);
	ice_get_ts_info(netdev, &info);
	status = info.tx_types & BIT(HWTSTAMP_TX_OFF);
	CHECK_EQUAL(1, status);
}
#endif

TEST_GROUP(ice_ethtool_eeprom_ops)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_hw *hw;
	struct ice_pf *pf;
	struct ethtool_eeprom *eeprom;

	#define EXPECTED_MAGIC hw->vendor_id | (hw->device_id << 16)

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf = np->vsi->back;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		hw = &pf->hw;
		eeprom = (struct ethtool_eeprom *)calloc(1, sizeof(struct ethtool_eeprom));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(pf->pdev);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		free(eeprom);
	}
};

TEST(ice_ethtool_eeprom_ops, ice_write_nvm_nomagic)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the "normal" set_nvm fails */
	eeprom->magic = EXPECTED_MAGIC;
	eeprom->len = 13;
	eeprom->offset = 0;

	expected_buf[0] = 0xFF;
	expected_buf[13] = 0xEE;

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(-EOPNOTSUPP, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_ethtool_eeprom_ops, ice_write_nvm_ok)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the set_eeprom works with the new way */
	eeprom->magic = hw->device_id << 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(0, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_ethtool_eeprom_ops, ice_write_nvm_nvmup)
{
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	int result;
	union ice_nvm_access_data *data;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;

	/* this tests that the set_eeprom works with the new way */
	eeprom->cmd = ETHTOOL_SEEPROM; /* READ_NVM */
	data = (union ice_nvm_access_data *)buf;

	eeprom->magic = (u32)hw->device_id << 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);
	CHECK_EQUAL(0, result);

	free(buf);
	free(expected_buf);
}

TEST(ice_ethtool_eeprom_ops, ice_read_nvm_with_4k_page_size)
{
	int result;
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;
	hw->flash.sr_words = 32768;
	eeprom->magic = 0; /* magic is not set for normal ethtool reads */
	eeprom->len = 13;
	eeprom->offset = 0;

	expected_buf[0] = 0xFF;
	expected_buf[13] = 0xEE;

	mock().expectOneCall("ice_acquire_nvm")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_read_flat_nvm")
		.withParameter("offset", eeprom->offset)
		.withParameter("length", eeprom->len)
		.withOutputParameterReturning("length", NULL, 0)
		.withOutputParameterReturning("data", expected_buf, eeprom->len)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_release_nvm")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_get_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(0, result);
	CHECK_EQUAL((u32)EXPECTED_MAGIC, eeprom->magic);
	MEMCMP_EQUAL(expected_buf, buf, eeprom->len);

	free(expected_buf);
	free(buf);
}

TEST(ice_ethtool_eeprom_ops, ice_get_eeprom_len)
{
	int result;

	hw->flash.flash_size = 12 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);
	CHECK_EQUAL(12 * 1024 * 1024, result);
 }

TEST(ice_ethtool_eeprom_ops, ice_get_eeprom_len_10MB_minimum)
{
	int result;

	hw->flash.flash_size = 4 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);
	CHECK_EQUAL(10 * 1024 * 1024, result);
}

TEST(ice_ethtool_eeprom_ops, ice_get_eeprom_len_nvm_access_regs)
{
	int result;

	/* Report a really small flash size */
	hw->flash.flash_size = 1 * 1024 * 1024;

	result = ice_get_eeprom_len(netdev);

	/* Make sure that the reported length is always larger than each of
	 * the registers that could be accessed using the QV Tools interface
	 */

	CHECK_TRUE(GL_HICR + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HICR_EN + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_FWSTS + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_MNG_FWSM + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLGEN_CSR_DEBUG_C + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLGEN_RSTAT + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLPCI_LBARCTRL + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLNVM_GENS + sizeof(u32) < (u32)result);
	CHECK_TRUE(GLNVM_FLA + sizeof(u32) < (u32)result);
	CHECK_TRUE(PF_FUNC_RID + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HIDA(GL_HIDA_MAX_INDEX) + sizeof(u32) < (u32)result);
	CHECK_TRUE(GL_HIBA(GL_HIBA_MAX_INDEX) + sizeof(u32) < (u32)result);
}

TEST(ice_ethtool_eeprom_ops, ice_set_eeprom_nvmup)
{
	int result;
	u8 *expected_buf = (u8 *)calloc(4096, sizeof(u8));
	u8 *buf = (u8 *)calloc(4096, sizeof(u8));
	struct ice_nvm_access_cmd *cmd;
	union ice_nvm_access_data *data;

	hw->vendor_id = 0x8086;
	hw->device_id = ICE_MAC_GENERIC;
	hw->flash.sr_words = 4096;
	cmd = (struct ice_nvm_access_cmd *)eeprom;
	cmd->command = 0xB; /* do a read */
	cmd->config =
		0xEULL | /* module */
		0xFULL << ICE_NVM_CFG_FLAGS_S | /* flags */
		0x0ULL << ICE_NVM_CFG_EXT_FLAGS_S | /* ext flags */
		0x0ULL << ICE_NVM_CFG_ADAPTER_INFO_S | /* info */
		hw->device_id << 16;
	cmd->offset = 0;
	cmd->data_size = 16;

	data = (union ice_nvm_access_data *)expected_buf;
	data->drv_features.features[0] = BIT_ULL(1);
	data->drv_features.major = 0;
	data->drv_features.minor = 5;
	data->drv_features.size = 16;

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_set_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(0, result);
	MEMCMP_EQUAL(expected_buf, buf, data->drv_features.size);

	mock().expectOneCall("ice_is_reset_in_progress")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_handle_nvm_access")
		.withOutputParameterReturning("data", data, sizeof(*data))
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_NO_MEMORY);

	result = ice_set_eeprom(netdev, eeprom, buf);

	CHECK_EQUAL(ICE_ERR_NO_MEMORY, result);

	free(expected_buf);
	free(buf);
}

TEST_GROUP(ice_linux_no_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		np->vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		mock().disable();
	}

	void teardown(void)
	{
		free(np->vsi->back->pdev);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_linux_no_test, no_test)
{
	ice_get_sset_count(netdev, 0);
	ice_get_sset_count(netdev, 1);
	ice_set_ethtool_ops(netdev);
}

#ifndef BMSM_MODE
TEST(ice_nic_ethtool, ice_get_wake_on_LAN)
{
	struct ethtool_wolinfo *wol;
	struct ice_pf *pf;

	pf = np->vsi->back;
	wol = (struct ethtool_wolinfo *)calloc(1, sizeof(ethtool_wolinfo));

	/* Test getting WoL not_supported/disabled scenario */
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(false);

	ice_get_wol(netdev, wol);
	CHECK_EQUAL(0, wol->supported);
	CHECK_EQUAL(0, wol->wolopts);

	/* Test getting WoL supported/enabled scenario */
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(true);
	pf->wol_ena = true;
	ice_get_wol(netdev, wol);
	CHECK_EQUAL(WAKE_MAGIC, wol->supported);
	CHECK_EQUAL(WAKE_MAGIC, wol->wolopts);

	free(wol);
}

TEST(ice_nic_ethtool, ice_set_wake_on_LAN)
{
	struct ethtool_wolinfo *wol;
	struct ice_pf *pf;
	int status;

	pf = np->vsi->back;
	wol = (struct ethtool_wolinfo *)calloc(1, sizeof(ethtool_wolinfo));

	/* Setting WoL on non PF VSI type - WoL supported on only PF VSI */
	vsi->type = ICE_VSI_VMDQ2;
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* Test setting unsupported WoL type, instead of magic packet */
	wol->wolopts = WAKE_ARP;
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(-EOPNOTSUPP, status);

	/* Test successful setting WoL with magic packet */
	vsi->type = ICE_VSI_PF;
	wol->wolopts = WAKE_MAGIC;
	pf->wol_ena = true;
	mock().expectOneCall("ice_is_wol_supported")
		.andReturnValue(true);
	status = ice_set_wol(netdev, wol);
	CHECK_EQUAL(0, status);
	free(wol);
}

TEST(ice_nic_ethtool, ice_reg_test)
{
	int status;

	status = ice_reg_test(netdev);
	CHECK_EQUAL(0, status);
}
#endif /* !BMSM_MODE */

#ifndef SWITCH_MODE
TEST(ice_nic_ethtool, ice_parse_hdrs)
{
	u32 hdrs;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	nfc->flow_type = TCP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_TCP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = UDP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_UDP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = SCTP_V4_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_SCTP | ICE_FLOW_SEG_HDR_IPV4);

	nfc->flow_type = TCP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_TCP | ICE_FLOW_SEG_HDR_IPV6);

	nfc->flow_type = UDP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_UDP | ICE_FLOW_SEG_HDR_IPV6);

	nfc->flow_type = SCTP_V6_FLOW;
	hdrs = ice_parse_hdrs(nfc);
	CHECK_EQUAL(hdrs, ICE_FLOW_SEG_HDR_SCTP | ICE_FLOW_SEG_HDR_IPV6);

	free(nfc);
}
TEST(ice_nic_ethtool, ice_parse_hash_flds)
{
	u64 hash_flds;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	hash_flds = ice_parse_hash_flds(nfc);
	CHECK_EQUAL(hash_flds, ICE_FLOW_HASH_FLD_IPV4_SA);

	nfc->flow_type = UDP_V4_FLOW;
	nfc->data = RXH_IP_SRC | RXH_L4_B_2_3;
	hash_flds = ice_parse_hash_flds(nfc);
	CHECK_EQUAL(hash_flds, ICE_FLOW_HASH_FLD_IPV4_SA |
		      ICE_FLOW_HASH_FLD_UDP_DST_PORT);
	free(nfc);
}
TEST(ice_nic_ethtool, ice_set_rss_hash_opt)
{
	struct ice_vsi *vsi = np->vsi;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	mock().ignoreOtherCalls();

	/* Invalid input, currently only supported flow types are: UDP, TCP, SCTP */
	nfc->flow_type = AH_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	CHECK_EQUAL(-EINVAL,ice_set_rss_hash_opt(vsi, nfc));

	/* Successful call of ice_add_rss_cfg function */
	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_SRC;
	mock().expectOneCall("ice_add_rss_cfg").andReturnValue(ICE_SUCCESS);
	CHECK_EQUAL(ICE_SUCCESS,ice_set_rss_hash_opt(vsi, nfc));

	/* ice_add_rss_cfg function returns error */
	nfc->flow_type = TCP_V4_FLOW;
	nfc->data = RXH_IP_DST;
	mock().expectOneCall("ice_add_rss_cfg")
		.andReturnValue(ICE_ERR_PARAM);
	CHECK_EQUAL(-EINVAL,ice_set_rss_hash_opt(vsi, nfc));

	free(nfc);
}
TEST(ice_nic_ethtool, ice_get_rss_hash_opt)
{
	struct ice_vsi *vsi = np->vsi;
	struct ethtool_rxnfc *nfc = (struct ethtool_rxnfc *)
				      calloc(1, sizeof(ethtool_rxnfc));

	set_bit(ICE_FLAG_ADV_FEATURES, pf->flags);
	mock().expectOneCall("ice_get_rss_cfg").andReturnValue(0);
	mock().expectOneCall("ice_is_safe_mode").andReturnValue(false);

	nfc->flow_type = TCP_V4_FLOW;
	ice_get_rss_hash_opt(vsi, nfc);
	CHECK_EQUAL(nfc->data, 0);
	free(nfc);
}

#endif /* SWITCH_MODE */
#ifdef FDIR_SUPPORT
TEST_GROUP(ice_fdir_ethtool_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(np->vsi->back);
		free(vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_fdir_ethtool_test, ice_get_rxnfc_count)
{
#ifndef SWITCH_MODE
	struct ice_hw *hw = &(vsi->back->hw);
#endif /* !SWITCH_MODE */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRLCNT;
	cmd.rule_cnt = 0;
	cmd.data = 0;

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_get_fdir_fltr_ids_per_port")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	hw->fdir_active_fltr = 11;

	mock().expectOneCall("ice_ntuple_get_max_fltr_cnt")
		.ignoreOtherParameters()
		.andReturnValue(12);
#endif /* SWITCH_MODE */

	ice_get_rxnfc(netdev, &cmd, &not_used);

#ifndef SWITCH_MODE
	CHECK_EQUAL(11, cmd.rule_cnt);
	CHECK_EQUAL(12, cmd.data);
#endif /* !SWITCH_MODE */
}

TEST(ice_fdir_ethtool_test, ice_get_rxnfc_rule)
{
	/* This is just testing that the function ice_get_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRULE;

	mock().expectOneCall("ice_get_ethtool_fdir_entry")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_get_rxnfc(netdev, &cmd, &not_used);

}

TEST(ice_fdir_ethtool_test, ice_get_rxnfc_ids)
{
	/* This is just testing that the function ice_get_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;
	u32 not_used;

	cmd.cmd = ETHTOOL_GRXCLSRLALL;

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_get_fdir_fltr_ids_per_port")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	mock().expectOneCall("ice_get_fdir_fltr_ids")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* SWITCH_MODE */

	ice_get_rxnfc(netdev, &cmd, &not_used);
}

TEST(ice_fdir_ethtool_test, ice_set_rxnfc_add)
{
	/* This is just testing that the function ice_set_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;

	cmd.cmd = ETHTOOL_SRXCLSRLINS;

	mock().expectOneCall("ice_add_ntuple_ethtool")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_rxnfc(netdev, &cmd);
}

TEST(ice_fdir_ethtool_test, ice_set_rxnfc_del)
{
	/* This is just testing that the function ice_set_rxnfc() calls
	 * the next layer. There is not much to test.
	 */
	struct ethtool_rxnfc cmd;

	cmd.cmd = ETHTOOL_SRXCLSRLDEL;

	mock().expectOneCall("ice_del_ntuple_ethtool")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_rxnfc(netdev, &cmd);
}

TEST(ice_nic_ethtool, ice_get_channels)
{
	struct ethtool_channels ch;
	u32 num_online_cpus = 8;

	pf->num_lan_msix = 8;
	pf->hw.func_caps.common_cap.num_rxq = 1024;
	pf->hw.func_caps.common_cap.num_txq = 1024;
	pf->max_qps = num_online_cpus;
	ice_get_channels(netdev, &ch);

	CHECK_EQUAL(ch.rx_count, vsi->num_rxq);
	CHECK_EQUAL(ch.max_rx, num_online_cpus);
	CHECK_EQUAL(ch.tx_count, vsi->num_txq);
	CHECK_EQUAL(ch.max_tx, num_online_cpus);
	CHECK_EQUAL(ch.other_count, 0);
	CHECK_EQUAL(ch.max_other, 0);
}

#endif /* FDIR_SUPPORT */

TEST_GROUP(ice_ethtool_set_phys_id)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		np->vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(struct ice_port_info));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(np->vsi->port_info);
		free(np->vsi->back);
		free(np->vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_ethtool_set_phys_id, ice_set_phys_id)
{
	int status;

	mock().expectOneCall("ice_aq_set_port_id_led")
		.withParameter("is_orig_mode", false)
		.ignoreOtherParameters()
		.andReturnValue(0);

	status = ice_set_phys_id(netdev, ETHTOOL_ID_ACTIVE);
	CHECK_EQUAL(status, 0);

	mock().expectOneCall("ice_aq_set_port_id_led")
		.withParameter("is_orig_mode", true)
		.ignoreOtherParameters()
		.andReturnValue(0);

	status = ice_set_phys_id(netdev, ETHTOOL_ID_INACTIVE);
	CHECK_EQUAL(status, 0);
}

TEST_GROUP(ice_coalesce)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void init_qs_and_vectors(int alloc_txq, int alloc_rxq, int num_txq,
				 int num_rxq, int num_q_vectors)
	{
		int i;

		vsi->num_q_vectors = num_q_vectors;
		vsi->q_vectors = (struct ice_q_vector **)calloc
			(vsi->num_q_vectors, sizeof(struct ice_q_vector *));
		ice_for_each_q_vector(vsi, i)
			vsi->q_vectors[i] = (struct ice_q_vector *)
				calloc(1, sizeof(struct ice_q_vector));

		vsi->alloc_txq = alloc_txq;
		vsi->alloc_rxq = alloc_rxq;
		vsi->num_txq = num_txq;
		vsi->num_rxq = num_rxq;

		vsi->rx_rings = (struct ice_ring **)
			calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_rxq; ++i) {
			vsi->rx_rings[i] = NULL;
			if (i >= vsi->num_rxq)
				break;
			vsi->rx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->rx_rings[i]->next = NULL;
		}

		vsi->tx_rings = (struct ice_ring **)
			calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_txq; ++i) {
			vsi->tx_rings[i] = NULL;
			if (i >= vsi->num_txq)
				break;
			vsi->tx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->tx_rings[i]->next = NULL;
		}

		ice_for_each_q_vector(vsi, i) {
			struct ice_q_vector *q_vector = vsi->q_vectors[i];

			q_vector->vsi = vsi;

			q_vector->rx.ring = vsi->rx_rings[i];
			if (q_vector->rx.ring) {
				q_vector->rx.ring->q_vector = q_vector;
				q_vector->rx.ring->vsi = vsi;
			}

			q_vector->tx.ring = vsi->tx_rings[i];
			if (q_vector->tx.ring) {
				q_vector->tx.ring->q_vector = q_vector;
				q_vector->tx.ring->vsi = vsi;
			}
		}
	}

	void free_qs_and_vectors(int num_txq, int num_rxq, int num_q_vectors)
	{
		int i;

		for (i = 0; i < vsi->num_txq; ++i)
			free(vsi->tx_rings[i]);
		free(vsi->tx_rings);
		for (i = 0; i < vsi->num_rxq; ++i)
			free(vsi->rx_rings[i]);
		free(vsi->rx_rings);
		for (i = 0; i < vsi->num_q_vectors; ++i)
			free(vsi->q_vectors[i]);
		free(vsi->q_vectors);
	}

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		vsi->back = pf;
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(u8) * 0x10000000);
		hw = &pf->hw;
		hw->itr_gran = 2;

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv),
					    vsi->num_txq, vsi->num_rxq);
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
	}

	void teardown()
	{
		free(pf->hw.hw_addr);
		free(pf);
		free(vsi);
		free_netdev(netdev);

		pf = NULL;
		vsi = NULL;
		np = NULL;
		netdev = NULL;
	}
};


TEST(ice_coalesce, clear_adaptive_after_set)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;

	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	/* now clear it, this tests the user case of disabling adaptive */
	memset(&ec, 0, sizeof(struct ethtool_coalesce));

	/* usually the user will clear adaptive and set some moderation */
	ec.use_adaptive_tx_coalesce = 0;
	ec.use_adaptive_rx_coalesce = 0;
	ec.tx_coalesce_usecs = 10;
	ec.rx_coalesce_usecs = 20;

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_FALSE(get_ec.use_adaptive_rx_coalesce);
	CHECK_FALSE(get_ec.use_adaptive_tx_coalesce);
	CHECK_EQUAL(0, get_ec.rx_coalesce_usecs_high);
	CHECK_EQUAL(10, get_ec.tx_coalesce_usecs);
	CHECK_EQUAL(20, get_ec.rx_coalesce_usecs);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, set_adaptive_fail_adjust)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;
	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 124;

	/* when adaptive is enabled, adjusting coalesce must fail */
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(-22, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	/* when adaptive is enabled, adjusting rate must fail too */
	memset(&ec, 0, sizeof(struct ethtool_coalesce));
	ec.rx_coalesce_usecs_high = 20;
	ec.use_adaptive_rx_coalesce = 1;

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(-22, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_FALSE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_FALSE(get_ec.use_adaptive_rx_coalesce);
	CHECK_FALSE(get_ec.use_adaptive_tx_coalesce);
	CHECK_EQUAL(0, get_ec.rx_coalesce_usecs_high);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, set_and_get_adaptive_all_queues)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.use_adaptive_rx_coalesce = 1;
	ec.use_adaptive_tx_coalesce = 1;

	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_TRUE(ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_TRUE(get_ec.use_adaptive_rx_coalesce);
	CHECK_TRUE(get_ec.use_adaptive_tx_coalesce);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, set_and_get_coalesce_all_rx_and_tx_queues)
{
	struct ethtool_coalesce get_ec = { };
	struct ethtool_coalesce ec = { };
	int result, i;

	init_qs_and_vectors(4, 4, 4, 4, 4);

	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 124;

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");
	result = ice_set_coalesce(netdev, &ec);
	CHECK_EQUAL(0, result);
	ice_for_each_q_vector(vsi, i) {
		struct ice_q_vector *q_vector = vsi->q_vectors[i];

		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->tx));
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->rx));
	}

	result = ice_get_coalesce(netdev, &get_ec);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(48, get_ec.tx_coalesce_usecs);
	CHECK_EQUAL(124, get_ec.rx_coalesce_usecs);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, __ice_set_coalesce_with_4_q_vectors_but_only_2_queue_pairs)
{
	struct ethtool_coalesce ec = { };
	int result;

	ec.tx_coalesce_usecs = 48;
	ec.rx_coalesce_usecs = 100;

	/* In some cases if DCB is configured the num_[rx|tx]q and
	 * alloc_[rx|tx]q/num_q_vectors can be different. This test verifies
	 * that __ice_set_coalesce doesn't fail due to this.
	 */
	init_qs_and_vectors(4, 4, 2, 2, 4);
	mock().expectNCalls(4, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");
	result = __ice_set_coalesce(netdev, &ec, -1);
	CHECK_EQUAL(0, result);
	free_qs_and_vectors(vsi->alloc_txq, vsi->alloc_rxq, vsi->num_q_vectors);
}

static void
test_set_q_coalesce(struct ice_vsi *vsi, u32 tx_usecs, u32 rx_usecs,
		    u32 tx_frames_irq, u32 rx_frames_irq, u32 q_num,
		    int expected_result)
{
	struct ethtool_coalesce ec = { };
	struct ice_q_vector *q_vector;
	int actual_result;

	ec.tx_coalesce_usecs = tx_usecs;
	ec.rx_coalesce_usecs = rx_usecs;

	actual_result = ice_set_per_q_coalesce(vsi->netdev, q_num, &ec);
	/* Make sure Rx/Tx queues(s) on q_vector[1] got updated */
	CHECK_EQUAL(expected_result, actual_result);

	if (q_num < vsi->num_txq) {
		q_vector = vsi->q_vectors[q_num];
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->tx));
	}
	if (q_num < vsi->num_rxq) {
		q_vector = vsi->q_vectors[q_num];
		CHECK_EQUAL(false, ITR_IS_DYNAMIC(&q_vector->rx));
	}
}

static void
test_get_q_coalesce(struct ice_vsi *vsi, u32 tx_usecs, u32 rx_usecs,
		    u32 tx_frames_irq, u32 rx_frames_irq, u32 q_num,
		    int expected_result)
{
	struct ethtool_coalesce ec = { };
	int actual_result;

	actual_result = ice_get_per_q_coalesce(vsi->netdev, q_num, &ec);
	CHECK_EQUAL(expected_result, actual_result);
	if (q_num < vsi->num_txq) {
		CHECK_EQUAL(tx_usecs, ec.tx_coalesce_usecs);
	}
	if (q_num < vsi->num_rxq) {
		CHECK_EQUAL(rx_usecs, ec.rx_coalesce_usecs);
	}
}

#ifdef ETHTOOL_PERQUEUE
TEST(ice_coalesce, set_get_per_queue_coalesce_even_q_distribution)
{
	init_qs_and_vectors(4, 4, 4, 4, 4);

	mock().expectNCalls(8, "ice_write_itr");
	mock().expectNCalls(4, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 40, 80, 200, 400, 1, 0);
	test_get_q_coalesce(vsi, 40, 80, 200, 400, 1, 0);

	test_set_q_coalesce(vsi, 60, 120, 220, 40, 2, 0);
	test_get_q_coalesce(vsi, 60, 120, 220, 40, 2, 0);

	test_set_q_coalesce(vsi, 80, 140, 240, 60, 3, 0);
	test_get_q_coalesce(vsi, 80, 140, 240, 60, 3, 0);

	/* Both queues are invalid so nothing is returned */
	test_set_q_coalesce(vsi, 0, 0, 0, 0, 4, -EINVAL);
	test_get_q_coalesce(vsi, 0, 0, 0, 0, 4, -EINVAL);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, set_get_per_queue_coalesce_more_txqs)
{
	init_qs_and_vectors(4, 4, 4, 3, 4);

	mock().expectNCalls(3, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 40, 80, 160, 180, 3, 0);
	test_get_q_coalesce(vsi, 40, 0, 180, 0, 3, 0);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, set_get_per_queue_coalesce_more_rxqs)
{
	init_qs_and_vectors(4, 4, 3, 4, 4);

	mock().expectNCalls(3, "ice_write_itr");
	mock().expectNCalls(2, "ice_set_q_vector_intrl");

	test_set_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);
	test_get_q_coalesce(vsi, 20, 40, 128, 200, 0, 0);

	test_set_q_coalesce(vsi, 10, 100, 120, 230, 3, 0);
	test_get_q_coalesce(vsi, 0, 100, 0, 230, 3, 0);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}
#endif /* ETHTOOL_PERQUEUE */

#ifdef ESWITCH_SUPPORT
#ifndef ETHTOOL_COALESCE_USECS
TEST(ice_coalesce, pr_validate_coalesce_param)
{
	struct ethtool_coalesce ec = { };
	bool result;

	/* Nothing is set */
	result = ice_repr_is_coalesce_param_invalid(&ec);
	CHECK_EQUAL(false, result);

	/* Set only rx_coalesce_usec_high, so it's ok */
	ec.rx_coalesce_usecs_high = 20;
	result = ice_repr_is_coalesce_param_invalid(&ec);
	CHECK_EQUAL(false, result);

	/* Add additional parameter */
	ec.pkt_rate_high = 10;
	result = ice_repr_is_coalesce_param_invalid(&ec);
	CHECK_EQUAL(true, result);

	/* Add one more additional parameter */
	ec.rate_sample_interval = 100;
	result = ice_repr_is_coalesce_param_invalid(&ec);
	CHECK_EQUAL(true, result);

	/* Reset rx_coalesce_usecs_high */
	ec.rx_coalesce_usecs_high = 0;
	result = ice_repr_is_coalesce_param_invalid(&ec);
	CHECK_EQUAL(true, result);
}

TEST(ice_coalesce, pr_set_coalesce_invalid_param)
{
	struct ethtool_coalesce ec = { };
	int result;

	/* Set invalid ethtool_coalesce parameter */
	ec.rx_max_coalesced_frames = 10;
	result = ice_repr_set_coalesce(netdev, &ec);
	CHECK_EQUAL(-EOPNOTSUPP, result);
}

TEST(ice_coalesce, pr_set_coalesce_successfull)
{
	struct ethtool_coalesce ec = { };
	int i, result;

	init_qs_and_vectors(4, 4, 4, 4, 4);
	ec.rx_coalesce_usecs_high = 100;

	ice_for_each_q_vector(vsi, i) {
		mock().expectOneCall("ice_write_intrl")
			.withParameter("q_vector", vsi->rx_rings[i]->q_vector)
			.withParameter("intrl", ec.rx_coalesce_usecs_high);
	}

	result = ice_repr_set_coalesce(netdev, &ec);

	CHECK_EQUAL(0, result);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, pr_set_coalesce_param_too_high)
{
	struct ethtool_coalesce ec = { };
	int result;

	init_qs_and_vectors(4, 4, 4, 4, 4);
	ec.rx_coalesce_usecs_high = ICE_MAX_INTRL + 100;

	result = ice_repr_set_coalesce(netdev, &ec);

	CHECK_EQUAL(-EINVAL, result);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, pr_set_coalesce_param_too_low)
{
	struct ethtool_coalesce ec = { };
	int result;

	init_qs_and_vectors(4, 4, 4, 4, 4);
	pf->hw.intrl_gran = ICE_INTRL_GRAN_MAX_25;
	ec.rx_coalesce_usecs_high = pf->hw.intrl_gran - 1;

	result = ice_repr_set_coalesce(netdev, &ec);

	CHECK_EQUAL(-EINVAL, result);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}
#endif /* !ETHTOOL_COALESCE_USECS */

TEST(ice_coalesce, pr_get_coalesce_successful)
{
	struct ethtool_coalesce ec = { };
	int result;

	init_qs_and_vectors(4, 4, 4, 4, 4);
	vsi->rx_rings[0]->q_vector->intrl = 100;

	result = ice_repr_get_coalesce(netdev, &ec);

	CHECK_EQUAL(0, result);
	CHECK_EQUAL(100, ec.rx_coalesce_usecs_high);

	free_qs_and_vectors(vsi->num_txq, vsi->num_rxq, vsi->num_q_vectors);
}

TEST(ice_coalesce, pr_get_coalesce_param_uninitialized_queues)
{
	struct ethtool_coalesce ec = { };
	int result;

	/* No queues and vectors initialization */

	result = ice_repr_get_coalesce(netdev, &ec);

	CHECK_EQUAL(-EINVAL, result);
}
#endif /* ESWITCH_SUPPORT */

#ifndef SWITCH_MODE
TEST_GROUP(ice_ethtool_self_test)
{
	/* these stick around for the life of the test */
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;

	void setup(void)
	{
		/* must use alloc_etherdev* to get data past the end of the
		 * net_device struct, where the priv structure lives
		 */
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		np->vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(np->vsi->back);
		free(vsi);
		free_netdev(netdev);
		netdev = NULL;
		np = NULL;
	}
};

TEST(ice_ethtool_self_test, ice_lbtest_sent_frame)
{
	struct ice_hw hw;
	struct ice_port_info port_info;
	struct ice_pf pf;
	struct pci_dev pdev;
	struct device dev;
	u8 *data;
	unsigned char buf[ICE_LB_FRAME_SIZE];
	int status;

	data = buf;
	hw.port_info = &port_info;

	dev = { 0 };
	pdev.dev = dev;
	pf.pdev = &pdev;
	pf.hw = hw;

	status = ice_lbtest_create_frame(&pf, &data, ICE_LB_FRAME_SIZE);
	CHECK_EQUAL(0, status);

	CHECK_EQUAL(0xDE, data[32]);
	CHECK_EQUAL(0xAD, data[42]);
	CHECK_EQUAL(0xBE, data[44]);
	CHECK_EQUAL(0xEF, data[46]);
	CHECK_EQUAL(0xFF, data[48]);

	free(data);
}
#endif /* !SWITCH_MODE */
