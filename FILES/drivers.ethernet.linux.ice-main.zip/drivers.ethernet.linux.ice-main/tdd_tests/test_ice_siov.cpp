#ifdef SIOV_SUPPORT
/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_siov {
struct ice_adi_priv;

#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_status.h"
#include "../src/SHARED/virtchnl/siov_regs.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "asm-generic/page.h"
#include "asm-generic/pfn.h"
#include <linux/compiler.h>

#include "../src/CORE/ice.h"
#include "../src/CORE/ice_sriov.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_workqueue.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"

#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_vdcm.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_virtchnl_allowlist.cpp"
#include "CORE_MOCKS/mock_ice_dcf.cpp"
#include "CORE_MOCKS/mock_ice_irq.cpp"
#include "CORE_MOCKS/mock_ice_vf_lib.cpp"
#include "CORE_MOCKS/stdmock_ice_siov.cpp"

struct workqueue_struct *ice_wq;

#include "../src/CORE/ice_siov.c"
}
/////////////////////////////////////////////////
using namespace ns_siov;

struct test_hw {
/* 128MB of 32 bits each */
	uint32_t reg[32 * 1024 * 1024];
};

TEST_GROUP(ice_siov)
{
	struct ice_port_info *port_info;
	struct ice_vsi **all_vsi;
	struct test_hw *test_hw;
	struct pci_dev *pdev;
	struct ice_vfs *vfs;
	struct device *dev;
	struct ice_pf *pf;
	struct ice_vf *vf;
	int status;

	TEST_SETUP()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		test_hw = (struct test_hw *)calloc(1, sizeof(*test_hw));
		port_info = (__typeof(port_info))calloc(1, sizeof(*port_info));
		pf->pdev = pdev;
		dev = &pdev->dev;
		pdev->dev.driver_data = pf;
		vfs = &pf->vfs;
		hash_init(vfs->table);
		mutex_init(&vfs->table_lock);
		pf->hw.hw_addr = (u8 *)test_hw;
		pf->hw.port_info = port_info;

		pf->num_alloc_vsi = 10;
		all_vsi = (struct ice_vsi **)calloc(10, sizeof(ice_vsi *));
		pf->vsi = all_vsi;
	}

	void test_init_vf(struct ice_vf *vf, int vf_id) {

		vf->pf = pf;
		vf->vf_id = vf_id;
		vf->vf_ops = &ice_siov_vf_ops;
		mutex_init(&vf->cfg_lock);
		kref_init(&vf->refcnt);

		hash_add(vfs->table, &vf->entry, vf_id);
	}

	void test_del_vfs()
	{
		struct hlist_node *tmp;
		struct ice_vf *vf;
		unsigned int bkt;

		hash_for_each_safe(vfs->table, bkt, tmp, vf, entry) {
			hash_del(&vf->entry);
			mutex_destroy(&vf->cfg_lock);
		}
	}

	TEST_TEARDOWN()
	{
		mutex_destroy(&vfs->table_lock);
		free(pdev);
		free(pf);
		free(all_vsi);
		free(test_hw);
		free(port_info);
	}
};

TEST_GROUP_BASE(ice_setup_adi, TGN(ice_siov))
{
	struct ice_adi_priv *priv;
	struct ice_adi *adi;
	struct ice_vsi *vsi;
	const u16 test_vf_id = 324;

	TEST_SETUP()
	{
		TGN(ice_siov)::setup();
		priv = (struct ice_adi_priv *)calloc(1, sizeof(*priv));
		adi = &priv->adi;
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vf = &priv->vf;
		test_init_vf(vf, test_vf_id);
		vsi->back = pf;
		pf->vsi[3] = vsi;
		adi->cfg_pasid = ice_adi_cfg_pasid;
		vsi->vsi_num = test_vf_id;
		vsi->vf = vf;
		vsi->txq_map = (u16 *)calloc(ICE_DFLT_QS_PER_SIOV_VF, sizeof(u16));
		vsi->rxq_map = (u16 *)calloc(ICE_DFLT_QS_PER_SIOV_VF, sizeof(u16));
	}

	TEST_TEARDOWN()
	{
		free(vsi->txq_map);
		free(vsi->rxq_map);
		test_del_vfs();
		free(vsi);
		kfree(priv);
		TGN(ice_siov)::teardown();
	}
};

TEST(ice_siov, ice_initialize_siov_res_fail)
{
	mock().expectOneCall("ice_vdcm_init")
		.ignoreOtherParameters()
		.andReturnValue(-1);

	ice_initialize_siov_res(pf);
	CHECK_EQUAL(false, test_bit(ICE_FLAG_SIOV_ENA, pf->flags));
}

TEST(ice_siov, ice_restore_pasid_config_success)
{
	u32 regval;

	ice_restore_pasid_config(pf, ICE_RESET_CORER);
	regval = rd32(&pf->hw, GL_MBX_PASID);
	CHECK_EQUAL(1, (regval & GL_MBX_PASID_PASID_MODE_M >>
			GL_MBX_PASID_PASID_MODE_S));
}

TEST(ice_setup_adi, ice_vsi_configure_pasid_success)
{
	u32 pasid = 24;

	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", vf)
		.andReturnValue(vsi);
	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(ICE_SUCCESS);
	status = ice_vsi_configure_pasid(vf, pasid, true);
	CHECK_EQUAL(ICE_SUCCESS, status);
}

TEST(ice_setup_adi, ice_adi_cfg_success)
{
	u32 pasid = 24;

	USE_STD_MOCK(ice_vsi_configure_pasid);
	mock().expectOneCall("ice_vsi_configure_pasid")
		.ignoreOtherParameters()
		.andReturnValue(0);
	status = ice_vsi_configure_pasid(vf, pasid, true);

	CHECK_EQUAL(0, status);
}

TEST(ice_setup_adi, adi_vsi_setup_fail)
{
	struct ice_vsi *test_vsi;

	mock().expectOneCall("ice_vsi_setup")
		.withParameter("pf", pf)
		.withParameter("pi", port_info)
		.withParameter("type", ICE_VSI_ADI)
		.withParameter("vf", vf)
		.withParameter("ch", (void *)NULL)
		.withParameter("tc", 0)
		.andReturnValue((void *)NULL);

	mock().expectOneCall("ice_vf_invalidate_vsi")
		.withParameter("vf", vf);

	test_vsi = ice_adi_vsi_setup(vf);

	CHECK_EQUAL(test_vsi, (void *)NULL);
}

TEST(ice_setup_adi, adi_vsi_setup_host_cfg_fail)
{
	struct ice_vsi adi_vsi = {};
	struct ice_vsi *test_vsi;

	mock().expectOneCall("ice_vsi_setup")
		.withParameter("pf", pf)
		.withParameter("pi", port_info)
		.withParameter("type", ICE_VSI_ADI)
		.withParameter("vf", vf)
		.withParameter("ch", (void *)NULL)
		.withParameter("tc", 0)
		.andReturnValue(&adi_vsi);

	mock().expectOneCall("ice_vf_init_host_cfg")
		.withParameter("vf", vf)
		.withParameter("vsi", &adi_vsi)
		.andReturnValue(-EEXIST);

	mock().expectOneCall("ice_vsi_release")
		.withParameter("vsi", &adi_vsi);

	mock().expectOneCall("ice_vf_invalidate_vsi")
		.withParameter("vf", vf);

	test_vsi = ice_adi_vsi_setup(vf);
	CHECK_EQUAL(test_vsi, (void *)NULL);
}

TEST(ice_setup_adi, initialize_vf_entry_fail)
{
	struct ice_adi_priv *test_adi;

	USE_STD_MOCK(ice_ena_siov_vf_mapping);
	mock().expectOneCall("ice_get_avail_txq_count")
		.andReturnValue(100);
	mock().expectOneCall("ice_get_avail_rxq_count")
		.andReturnValue(100);

	mock().expectOneCall("ice_initialize_vf_entry")
		.ignoreOtherParameters()
		.andReturnValue(-1);

	test_adi = ice_create_adi(pf);
	CHECK_EQUAL(test_adi, (void *)NULL);
}

TEST(ice_setup_adi, create_adi_fail)
{
	struct ice_adi_priv *test_adi;

	USE_STD_MOCK(ice_ena_siov_vf_mapping);
	mock().expectOneCall("ice_get_avail_txq_count")
		.andReturnValue(100);
	mock().expectOneCall("ice_get_avail_rxq_count")
		.andReturnValue(100);

	mock().expectOneCall("ice_initialize_vf_entry")
		.ignoreOtherParameters()
		.andReturnValue(0);
	USE_STD_MOCK(ice_adi_vsi_setup);
	mock().expectOneCall("ice_adi_vsi_setup")
		.ignoreOtherParameters()
		.andReturnValue((void *)NULL);

	test_adi = ice_create_adi(pf);
	CHECK_EQUAL(test_adi, (void *)NULL);
}

TEST(ice_setup_adi, fail_alloc_adi)
{
	struct ice_adi *test_adi;

	USE_STD_MOCK(ice_create_adi);
	mock().expectOneCall("ice_create_adi")
		.withParameter("pf", pf)
		.andReturnValue((void *)NULL);

	test_adi = ice_vdcm_alloc_adi(dev, NULL);
	CHECK_EQUAL(test_adi, (void *)NULL);
}

TEST(ice_setup_adi, ice_adi_read_reg32)
{
	u32 ret;

	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", vf)
		.andReturnValue(vsi);

	ret = ice_adi_read_reg32(adi, 0);
	CHECK_EQUAL(0xdeadbeef, ret);
}

TEST(ice_setup_adi, ice_adi_write_reg32)
{
	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", vf)
		.andReturnValue(vsi);

	ice_adi_write_reg32(adi, 0, 0);
}

TEST(ice_setup_adi, ice_adi_reset_fail)
{
	int ret;

	mock().expectOneCall("ice_reset_vf")
		.withParameter("vf", vf)
		.withParameter("flags", ICE_VF_RESET_NOTIFY | ICE_VF_RESET_LOCK)
		.andReturnValue(-EFAULT);

	ret = ice_adi_reset(adi);
	CHECK_EQUAL(-EFAULT, ret);
}

TEST_GROUP_BASE(ice_setup_adi_free, TGN(ice_siov))
{
	struct ice_adi_priv *priv;
	struct ice_adi *adi;
	struct ice_vsi *vsi;
	const u16 test_vf_id = 324;

	TEST_SETUP()
	{
		TGN(ice_siov)::setup();
		priv = (struct ice_adi_priv *)calloc(1, sizeof(*priv));
		adi = &priv->adi;
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vf = &priv->vf;
		test_init_vf(vf, test_vf_id);
		pf->vsi[5] = vsi;
		vsi->back = pf;
		vsi->vsi_num = test_vf_id;
		vsi->vf = vf;
	}

	TEST_TEARDOWN()
	{
		free(vsi);
		// test cases are expected to free priv
		TGN(ice_siov)::teardown();
	}
};

TEST(ice_setup_adi_free, ice_siov_free_vf)
{
	USE_STD_MOCK(ice_dis_siov_vf_mapping);
	mock().expectOneCall("ice_dis_siov_vf_mapping")
		.withParameter("vf", vf)
		.andReturnValue(0);
	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", vf)
		.andReturnValue(vsi);
	mock().expectOneCall("ice_vsi_release")
		.withParameter("vsi", vsi);
	hash_del(&priv->vf.entry);
	ice_siov_free_vf(&priv->vf);
}

TEST(ice_setup_adi_free, ice_free_adi)
{
	USE_STD_MOCK(ice_dis_siov_vf_mapping);
	mock().expectOneCall("ice_dis_siov_vf_mapping")
		.withParameter("vf", vf)
		.andReturnValue(0);
	mock().expectOneCall("ice_get_vf_vsi")
		.withParameter("vf", vf)
		.andReturnValue(vsi);
	mock().expectOneCall("ice_vsi_release")
		.withParameter("vsi", vsi);
	ice_free_adi(priv);
	CHECK_TRUE(hash_empty(vfs->table));
}

TEST(ice_setup_adi_free, ice_vdcm_free_adi)
{
	USE_STD_MOCK(ice_free_adi);
	mock().expectOneCall("ice_free_adi")
		.withParameter("priv", priv);

	ice_vdcm_free_adi(adi);

	/* destroy the resource */
	hash_del(&vf->entry);
	mutex_destroy(&vf->cfg_lock);
	kfree(priv);
}

#if 0
/* TDD WORK IN PROGRESS */

TEST_GROUP_BASE(vsi_rebuild, TGN(ice_setup_adi_free))
{
	int token_data;
	void *token;

	TEST_SETUP()
	{
		TGN(ice_setup_adi_free)::setup();

		token_data = 27;
		token = &token_data;

		priv->token = token;
	}

	TEST_TEARDOWN()
	{
		TGN(ice_setup_adi_free)::teardown();
	}
};

TEST(vsi_rebuild, post_vsi_rebuild)
{
	mock().expectOneCall("ice_vdcm_free_irq")
		.withParameter("token", token);

	mock().expectOneCall("ice_vdcm_zap")
		.withParameter("token", token);

	ice_siov_post_vsi_rebuild(vf);
}
#endif

#endif /* SIOV_SUPPORT */
