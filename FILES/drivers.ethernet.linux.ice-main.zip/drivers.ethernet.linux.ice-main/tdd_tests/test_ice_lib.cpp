#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_lib {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "ice_flex_pipe.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/kernel.h>
#include <linux/cpumask.h>
#include <linux/pm_wakeup.h>
#include <linux/rtnetlink.h>
#include <net/act_api.h>
#include <net/pkt_cls.h>
#include <net/tc_act/tc_gact.h>
#include <linux/netdevice.h>
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_adminq_cmd.h"
#include "../src/SHARED/ice_sched.h"
#ifdef LAG_SUPPORT
#include "CORE_MOCKS/mock_ice_lag.cpp"
#endif /* LAG_SUPPORT */
#include "../src/CORE/ice.h"
#include "../src/CORE/ice_txrx.h"
#include "../src/CORE/ice_vsi_vlan_ops.h"

#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_dcb.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_dcb_nl.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_devlink.cpp"
#include "CORE_MOCKS/mock_ice_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_pf_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_irq.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "local_ice_common.cpp"
#include "../src/CORE/ice_lib.c"
}
/////////////////////////////////////////////////
using namespace ns_lib;

TEST_GROUP(ice_vsi_setup_q_map)
{
	struct ice_vsi vsi = { };
	struct ice_pf pf = { };
	struct ice_port_info pi;

	void setup()
	{
		vsi.rxq_map = (u16*) calloc(8, sizeof(u16));
		vsi.port_info = &pi;
		vsi.back = &pf;
		pf.pdev = (struct pci_dev *) calloc(1, sizeof(struct pci_dev));
	}

	void teardown()
	{
		free(pf.pdev);
		free(vsi.rxq_map);
	}
};

TEST(ice_vsi_setup_q_map, check_rx_qmap_with_8_queue_pairs)
{
	struct ice_vsi_ctx ctxt;
	int ret;

	vsi.alloc_txq = 1;
	vsi.alloc_rxq = 8;
	vsi.tc_cfg.ena_tc = 1;
	ret = ice_vsi_setup_q_map(&vsi, &ctxt);
	CHECK_EQUAL(order_base_2(vsi.alloc_rxq) << ICE_AQ_VSI_TC_Q_NUM_S, ctxt.info.tc_mapping[0]);
	CHECK_EQUAL(vsi.alloc_rxq, vsi.num_rxq);
	CHECK_EQUAL(0, ret);
}


TEST_GROUP(ice_rss)
{
	struct ice_vsi vsi = { };
	struct ice_pf pf = { };

	void setup(void)
	{
		pf.pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		vsi.back = &pf;
		vsi.type = ICE_VSI_PF;
		/* sensible defaults */
		vsi.rss_table_size = 128;
		vsi.rss_size = 16;
		vsi.num_rxq = 16;
		vsi.rxq_map = (u16*) calloc(4, sizeof(u16));
#ifdef ADK_SUPPORT
		vsi.is_rss_lut_ena = true;
#endif /* ADK_SUPPORT */
	}
	void teardown(void)
	{
		free(pf.pdev);
		free(vsi.rxq_map);
		memset(&pf, 0, sizeof(struct ice_pf));
		memset(&vsi, 0, sizeof(struct ice_vsi));

		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_rss, order_base_2_matches_ilog2)
{
	int i;

	/* ilog2 is undefined for 0... */
	for (i = 1; i < 1000; i++) {
		int expected, actual;

		expected = ilog2(i);
		if (!is_power_of_2(i))
			expected++;

		actual = order_base_2(i);

		CHECK_EQUAL(expected, actual);
	}
}

TEST(ice_rss, rss_entry_width_check)
{
	pf.max_qps = 8;
	ice_vsi_set_rss_params(&vsi);
	CHECK_EQUAL(1,vsi.rss_size);
	set_bit(ICE_FLAG_RSS_ENA, pf.flags);
	pf.hw.func_caps.common_cap.rss_table_entry_width = 2;
	ice_vsi_set_rss_params(&vsi);
	CHECK_EQUAL(4,vsi.rss_size);
}

TEST(ice_rss, set_rss_key_failed_expect_errror)
{
	mock().expectOneCall("ice_fill_rss_lut");
	mock().expectOneCall("ice_set_rss_lut").andReturnValue(0);
	mock().expectOneCall("ice_set_rss_key")
		.ignoreOtherParameters()
		.andReturnValue(-1);
	// no ignoreOtherCalls here because we
	// just want to see the one

	int ret = ice_vsi_cfg_rss_lut_key(&vsi);
	//the error code expected always is the kernel error code -EIO
	CHECK_EQUAL(-1, ret);
}

TEST(ice_rss, set_rss_lut_failed_expect_error)
{
	mock().expectOneCall("ice_fill_rss_lut");
	mock().expectOneCall("ice_set_rss_lut")
		.ignoreOtherParameters()
		.andReturnValue(-1);
	// no ignoreOtherCalls here because we
	// just want to see the one

	int ret = ice_vsi_cfg_rss_lut_key(&vsi);

	//the error code expected always is the kernel error code -EIO
	CHECK_EQUAL(-1, ret);
}

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_vsi_set_q_vectors_reg_idx)
{
	struct ice_vsi *vsi;
	int result;
#define Q_VECTOR_CNT 3
#define LAST_Q_VECTOR_IDX (Q_VECTOR_CNT - 1)

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->base_vector = 13;
		vsi->q_vectors = (struct ice_q_vector **)
			calloc(Q_VECTOR_CNT, sizeof(*vsi->q_vectors));
		for (int i = 0; i <= LAST_Q_VECTOR_IDX; ++i) {
			vsi->q_vectors[i] = (struct ice_q_vector *)
				calloc(1, sizeof(**vsi->q_vectors));
			vsi->q_vectors[i]->v_idx = i;
		}
		vsi->num_q_vectors = Q_VECTOR_CNT;
	}

	void teardown()
	{
		for (int i = 0; i <= LAST_Q_VECTOR_IDX; ++i) {
			free(vsi->q_vectors[i]);
			vsi->q_vectors[i] = NULL;
		}

		free(vsi->q_vectors);
		vsi->q_vectors = NULL;
		free(vsi);
		vsi = NULL;
	}
};

TEST(ice_vsi_set_q_vectors_reg_idx, null_vsi)
{
	result = ice_vsi_set_q_vectors_reg_idx(NULL, 0);
	CHECK_EQUAL(-EINVAL, result);
}

TEST(ice_vsi_set_q_vectors_reg_idx, null_q_vector_array)
{
	struct ice_q_vector **q_vectors_holder = vsi->q_vectors;

	vsi->q_vectors = NULL;
	result = ice_vsi_set_q_vectors_reg_idx(NULL, 0);
	CHECK_EQUAL(-EINVAL, result);

	vsi->q_vectors = q_vectors_holder;
}

TEST(ice_vsi_set_q_vectors_reg_idx, null_q_vector_entry_test_unroll)
{
	struct ice_q_vector *q_vector_holder = vsi->q_vectors[LAST_Q_VECTOR_IDX];

	vsi->q_vectors[LAST_Q_VECTOR_IDX] = NULL;
	result = ice_vsi_set_q_vectors_reg_idx(NULL, 0);
	CHECK_EQUAL(-EINVAL, result);

	vsi->q_vectors[LAST_Q_VECTOR_IDX] = q_vector_holder;

	for (int i = 0; i <= LAST_Q_VECTOR_IDX; ++i)
		CHECK_EQUAL(0, vsi->q_vectors[i]->reg_idx);
}

TEST(ice_vsi_set_q_vectors_reg_idx, success)
{
	result = ice_vsi_set_q_vectors_reg_idx(vsi, 0);
	CHECK_EQUAL(0, result);

	for (int i = 0; i <= LAST_Q_VECTOR_IDX; ++i)
		CHECK_EQUAL(vsi->base_vector + vsi->q_vectors[i]->v_idx,
			    vsi->q_vectors[i]->reg_idx);
}

TEST_GROUP(ice_get_free_res)
{
	struct ice_res_tracker *res;
	struct pci_dev pdev;
	struct ice_pf pf;
	int vectors = 64;

	void setup(void)
	{
		using namespace ns_lib;
#define RES(x) 0x00A##x
		memset(&pdev, 0, sizeof(struct pci_dev));
		pf.pdev = &pdev;
		int size;

		size = (sizeof(struct ice_res_tracker) + (sizeof(u16) * vectors));
		res = (struct ice_res_tracker *) malloc(size);
		memset(res, 0, size);
		res->num_entries = vectors;
		res->end = res->num_entries;
		pf.irq_tracker = res;
	}

	void teardown(void)
	{
		free(pf.irq_tracker);
		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_get_free_res, get_free1)
{
	int base;

	base = ice_get_res(&pf, res, 32, RES(0));
	CHECK(base >= 0);
	ice_free_res(res, base, RES(0));
	base = ice_get_res(&pf, res, 32, RES(0));
	CHECK(base >= 0);
	ice_free_res(res, base, RES(0));
}

TEST(ice_get_free_res, get_free2)
{
	int base[10];

	memset(base, 0, sizeof(base));

	base[0] = ice_get_res(&pf, res, 16, RES(0));
	CHECK(base[0] >= 0);

	base[1] = ice_get_res(&pf, res, 16, RES(1));
	CHECK(base[1] >= 0);

	base[2] = ice_get_res(&pf, res, 8, RES(2));
	CHECK(base[2] >= 0);

	base[3] = ice_get_res(&pf, res, 4, RES(3));
	CHECK(base[3] >= 0);

	base[4] = ice_get_res(&pf, res, 4, RES(4));
	CHECK(base[4] >= 0);

	base[5] = ice_get_res(&pf, res, 16, RES(5));
	CHECK(base[5] >= 0);

	/* all 64 entries used. this should fail now */
	base[6] = ice_get_res(&pf, res, 16, RES(6));
	CHECK(base[6] < 0);

	ice_free_res(res, base[0], RES(0));
	ice_free_res(res, base[1], RES(1));
	ice_free_res(res, base[2], RES(2));
	ice_free_res(res, base[3], RES(3));
	ice_free_res(res, base[4], RES(4));
	ice_free_res(res, base[5], RES(5));
}

TEST(ice_get_free_res, get_free3)
{
	int base[10];

	memset(base, 0, sizeof(base));

	base[0] = ice_get_res(&pf, res, 16, RES(0));
	CHECK(base[0] >= 0);

	base[1] = ice_get_res(&pf, res, 16, RES(1));
	CHECK(base[1] >= 0);

	base[2] = ice_get_res(&pf, res, 16, RES(2));
	CHECK(base[2] >= 0);

	base[6] = ice_get_res(&pf, res, 16, RES(6));
	CHECK(base[3] >= 0);

	/* create a hole */
	ice_free_res(res, base[2], RES(2));

	/* allocate again */
	base[2] = ice_get_res(&pf, res, 4, RES(2));
	CHECK(base[2] >= 0);
	base[3] = ice_get_res(&pf, res, 4, RES(3));
	CHECK(base[3] >= 0);
	base[4] = ice_get_res(&pf, res, 4, RES(4));
	CHECK(base[4] >= 0);
	base[5] = ice_get_res(&pf, res, 4, RES(5));
	CHECK(base[5] >= 0);

	ice_free_res(res, base[0], RES(0));
	ice_free_res(res, base[1], RES(1));
	ice_free_res(res, base[2], RES(2));
	ice_free_res(res, base[3], RES(3));
	ice_free_res(res, base[4], RES(4));
	ice_free_res(res, base[5], RES(5));
	ice_free_res(res, base[6], RES(6));
}

TEST(ice_get_free_res, get_free_with_sriov)
{
	u16 sriov_base_vector;
	int base[10];

	memset(base, 0, sizeof(base));

	base[0] = ice_get_res(&pf, res, 16, RES(0));
	CHECK_EQUAL(0, base[0]);

	base[1] = ice_get_res(&pf, res, 16, RES(1));
	CHECK_EQUAL(16, base[1]);

	base[2] = ice_get_res(&pf, res, 8, RES(2));
	CHECK_EQUAL(32, base[2]);

	base[3] = ice_get_res(&pf, res, 4, RES(3));
	CHECK_EQUAL(40, base[3]);

	base[4] = ice_get_res(&pf, res, 4, RES(4));
	CHECK_EQUAL(44, base[4]);

	/* SRIOV needs 2 of the irq_tracker entries */
	sriov_base_vector = res->num_entries - 2;
	res->end = sriov_base_vector;

	/* only 14 entries left this should fail */
	base[5] = ice_get_res(&pf, res, 16, RES(5));
	CHECK_EQUAL(-ENOMEM, base[5]);

	/* should be no resources to free here */
	CHECK_EQUAL(-EINVAL, ice_free_res(res, base[5], RES(5)));

	/* SRIOV freed its resources and moved res->end */
	sriov_base_vector = 0;
	res->end = res->num_entries;

	/* try again after SRIOV has left */
	base[5] = ice_get_res(&pf, res, 16, RES(5));
	CHECK_EQUAL(48, base[5]);

	CHECK_EQUAL(16, ice_free_res(res, base[0], RES(0)));
	CHECK_EQUAL(16, ice_free_res(res, base[1], RES(1)));
	CHECK_EQUAL(8, ice_free_res(res, base[2], RES(2)));
	CHECK_EQUAL(4, ice_free_res(res, base[3], RES(3)));
	CHECK_EQUAL(4, ice_free_res(res, base[4], RES(4)));
	CHECK_EQUAL(16, ice_free_res(res, base[5], RES(5)));
}

TEST(ice_get_free_res, ice_get_free_res_count)
{
	u16 expected_free_entries = 10;
	u16 used_entries = res->num_entries - expected_free_entries;
	u16 block_index;

	block_index = ice_get_res(&pf, res, used_entries, RES(0));
	CHECK_EQUAL(expected_free_entries,
		    ice_get_free_res_count(res));
	ice_free_res(res, block_index, RES(0));
	CHECK_EQUAL(res->num_entries,
		    ice_get_free_res_count(res));
}

TEST_GROUP(ice_vsi_init)
{
	struct ice_vsi_ctx ctxt;
	struct ice_port_info pi;
	struct pci_dev pdev;
	struct ice_vsi vsi;
	struct ice_sw sw;
	struct ice_pf pf;
	u16 rxq_map[16];

	TEST_SETUP()
	{
		memset(&ctxt, 0, sizeof(ctxt));
		memset(&pdev, 0, sizeof(pdev));
		memset(&pi, 0, sizeof(pi));
		memset(&vsi, 0, sizeof(vsi));
		memset(&sw, 0, sizeof(sw));
		memset(&pf, 0, sizeof(pf));
		memset(rxq_map, 0, sizeof(rxq_map));

		vsi.back = &pf;
		vsi.vsw = &sw;
		vsi.port_info = &pi;

		pf.pdev = &pdev;

		/* sensible defaults */
		vsi.type = ICE_VSI_PF;
		vsi.rss_table_size = 128;
		vsi.rss_size = 16;
		vsi.alloc_rxq = 16;
		vsi.alloc_txq = 16;
		vsi.num_rxq = 16;
		vsi.num_txq = 16;
		vsi.rxq_map = rxq_map;
	}

	TEST_TEARDOWN()
	{
	}
};

TEST(ice_vsi_init, ice_set_dflt_vsi_ctx_clears_info)
{
	/* setup some random data in the info field */
	ctxt.info.valid_sections = 0xF3;
	ctxt.info.sw_flags = 0xF;
	ctxt.info.sw_flags2 = 0xA;
	ctxt.info.inner_vlan_reserved[0] = 0xE;
	ctxt.info.inner_vlan_reserved[1] = 0xE;

	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(false);
	ice_set_dflt_vsi_ctx(&pf.hw, &ctxt);

	CHECK_EQUAL(0, ctxt.info.valid_sections);
	CHECK_EQUAL(ICE_AQ_VSI_SW_FLAG_SRC_PRUNE, ctxt.info.sw_flags);
	CHECK_EQUAL(ICE_AQ_VSI_SW_FLAG_LAN_ENA, ctxt.info.sw_flags2);
	CHECK_EQUAL(0, ctxt.info.inner_vlan_reserved[0]);
	CHECK_EQUAL(0, ctxt.info.inner_vlan_reserved[1]);
}

TEST(ice_vsi_init, ice_vsi_init_clears_previous_vsi_info)
{
	int err;

	/* We could probably make a more robust suite of tests to really
	 * verify that settings get cleared...
	 */
	vsi.info.inner_vlan_reserved[0] = 0x3;
	vsi.info.inner_vlan_reserved[1] = 0xF;

	mock().expectOneCall("ice_add_vsi");
	mock().expectOneCall("ice_is_dvm_ena")
		.andReturnValue(false);
	err = ice_vsi_init(&vsi, true);
	CHECK_EQUAL(0, err);

	CHECK_EQUAL(0, vsi.info.inner_vlan_reserved[0]);
	CHECK_EQUAL(0, vsi.info.inner_vlan_reserved[1]);
}

TEST_GROUP(dflt_vsi)
{
	struct ice_vsi *vf0_vsi;
	struct ice_vsi *vf1_vsi;
	struct ice_pf *pf;
	int i;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(*pf->pdev));
		pf->first_sw = (struct ice_sw *)calloc(1, sizeof(*pf->first_sw));
		pf->first_sw->pf = pf;
		pf->num_alloc_vsi = 3;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi,
						    sizeof(struct ice_vsi *));
		ice_for_each_vsi(pf, i) {
			pf->vsi[i] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
			pf->vsi[i]->back = pf;
		}

		vf0_vsi = pf->vsi[1];
		vf1_vsi = pf->vsi[2];
	}

	void teardown()
	{

		ice_for_each_vsi(pf, i) {
			free(pf->vsi[i]);
			pf->vsi[i] = NULL;
		}
		free(pf->vsi);
		pf->vsi = NULL;
		free(pf->first_sw);
		pf->first_sw = NULL;
		free(pf->pdev);
		pf->pdev = NULL;
		free(pf);
		pf = NULL;

	}
};

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
TEST(dflt_vsi, call_ice_is_dflt_vsi_in_use_when_not_in_use_return_false)
{
	bool exists = false;
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.withOutputParameterReturning("rule_exists", &exists, sizeof(exists));
	
	
	CHECK_EQUAL(false, ice_is_dflt_vsi_in_use(vf0_vsi->port_info));
}

TEST(dflt_vsi, call_ice_is_dflt_vsi_in_use_when_being_used_return_true)
{
	bool exists = true;
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.withOutputParameterReturning("rule_exists", &exists, sizeof(exists));
	CHECK_EQUAL(true, ice_is_dflt_vsi_in_use(vf0_vsi->port_info));
}
#endif /* SWITCH_MODE && !BMSM_MODE */

TEST(dflt_vsi, ice_set_dflt_vsi_when_the_vsi_is_already_the_dflt_vsi)
{
	mock().expectNCalls(2, "ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(true);

	ice_set_dflt_vsi(vf0_vsi);
	CHECK_EQUAL(0, ice_set_dflt_vsi(vf0_vsi));

}

TEST(dflt_vsi, ice_set_dflt_vsi_fails)
{
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_cfg_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);
	CHECK_EQUAL(-EIO, ice_set_dflt_vsi(vf0_vsi));
}

TEST(dflt_vsi, ice_set_dflt_vsi_succeeds)
{
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(false);

	mock().expectOneCall("ice_cfg_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	CHECK_EQUAL(0, ice_set_dflt_vsi(vf0_vsi));
}

TEST(dflt_vsi, ice_clear_dflt_vsi_fails)
{
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_cfg_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);
	CHECK_EQUAL(-EIO, ice_clear_dflt_vsi(vf1_vsi));
}

TEST(dflt_vsi, ice_clear_dflt_vsi_success)
{
	mock().expectOneCall("ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_cfg_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	CHECK_EQUAL(0, ice_clear_dflt_vsi(vf1_vsi));
}

TEST(dflt_vsi, ice_clear_dflt_vsi_when_the_vsi_is_not_the_dflt_vsi)
{
	mock().expectNCalls(2, "ice_check_if_dflt_vsi")
		.ignoreOtherParameters()
		.andReturnValue(false);

	ice_clear_dflt_vsi(vf1_vsi);
	CHECK_EQUAL(0, ice_clear_dflt_vsi(vf1_vsi));

}

TEST_GROUP(ice_change_num_queues)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

#define ITR_DEFAULT_VAL 1234

	void init_qs_and_vectors(int alloc_txq, int alloc_rxq, int num_txq,
				 int num_rxq, int num_q_vectors)
	{
		int i;

		vsi->num_q_vectors = num_q_vectors;
		vsi->q_vectors = (struct ice_q_vector **)calloc
			(vsi->num_q_vectors, sizeof(struct ice_q_vector *));
		ice_for_each_q_vector(vsi, i)
			vsi->q_vectors[i] = (struct ice_q_vector *)
				calloc(1, sizeof(struct ice_q_vector));

		vsi->alloc_txq = alloc_txq;
		vsi->alloc_rxq = alloc_rxq;
		vsi->num_txq = num_txq;
		vsi->num_rxq = num_rxq;

		vsi->rx_rings = (struct ice_ring **)
			calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_rxq; ++i) {
			vsi->rx_rings[i] = NULL;
			if (i >= vsi->num_rxq)
				break;
			vsi->rx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->rx_rings[i]->next = NULL;
		}

		vsi->tx_rings = (struct ice_ring **)
			calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
		for (i = 0; i < vsi->alloc_txq; ++i) {
			vsi->tx_rings[i] = NULL;
			if (i >= vsi->num_txq)
				break;
			vsi->tx_rings[i] = (struct ice_ring *)
				calloc(1, sizeof(struct ice_ring));
			vsi->tx_rings[i]->next = NULL;
		}

		ice_for_each_q_vector(vsi, i) {
			struct ice_q_vector *q_vector = vsi->q_vectors[i];

			q_vector->vsi = vsi;
			q_vector->intrl = 10;
			q_vector->reg_idx = i;

			if (i < vsi->alloc_rxq) {
				q_vector->rx.ring = vsi->rx_rings[i];
				if (q_vector->rx.ring) {
					q_vector->rx.ring->q_vector = q_vector;
					q_vector->rx.ring->vsi = vsi;
					q_vector->rx.itr_setting = ITR_DEFAULT_VAL;
				}
			}

			if (i < vsi->alloc_txq) {
				q_vector->tx.ring = vsi->tx_rings[i];
				if (q_vector->tx.ring) {
					q_vector->tx.ring->q_vector = q_vector;
					q_vector->tx.ring->vsi = vsi;
					q_vector->tx.itr_setting = ITR_DEFAULT_VAL;
				}
			}
		}
	}

	void free_qs_and_vectors(int num_txq, int num_rxq, int num_q_vectors)
	{
		int i;

		for (i = 0; i < vsi->num_txq; ++i)
			free(vsi->tx_rings[i]);
		free(vsi->tx_rings);
		for (i = 0; i < vsi->num_rxq; ++i)
			free(vsi->rx_rings[i]);
		free(vsi->rx_rings);
		for (i = 0; i < vsi->num_q_vectors; ++i)
			free(vsi->q_vectors[i]);
		free(vsi->q_vectors);
	}

	enum test_ring_type {
		TEST_RING_TYPE_TX = 1,
		TEST_RING_TYPE_RX
	};

	void change_itr_val(enum test_ring_type type, u16 itr_val)
	{
		int i;
		ice_for_each_q_vector(vsi, i) {
			struct ice_q_vector *q_vector = vsi->q_vectors[i];

			if ((type == TEST_RING_TYPE_TX) && (i < vsi->alloc_txq))
					q_vector->tx.itr_setting = itr_val;
			else if (i < vsi->alloc_rxq)
					q_vector->rx.itr_setting = itr_val;
		}
	}

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		vsi->back = pf;
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(u8) * 0x10000000);
		hw = &pf->hw;
		hw->itr_gran = 2;
		hw->intrl_gran = 4;

		pf->hw.func_caps.common_cap.num_txq = 64;
		pf->hw.func_caps.common_cap.num_rxq = 64;

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv),
					    vsi->num_txq, vsi->num_rxq);
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
	}

	void teardown()
	{
		free(pf->hw.hw_addr);
		free(pf);
		free(vsi);
		free_netdev(netdev);

		pf = NULL;
		vsi = NULL;
		np = NULL;
		netdev = NULL;
	}
};

/* test the case where we have go from a smaller number of rings to a larger
 * number of queues. the coalesce values should get set for the small number
 * of rings, then when the number of rings increase the new rings should
 * get set with the coalesce settings from the small number of rings. this
 * was a bug found using the following set of ethtool commands:
 *   ethtool -C adaptive-rx off
 *   ethtool -L rx 1 tx 4
 *   ethtool -C rx-usecs 100
 *   ethtool -C adaptive-rx on
 *   ethtool -C adaptive-tx off
 *   ethtool -L rx 4 tx 1
 *   ethtool -C tx-usecs 10
 */
TEST(ice_change_num_queues, coalesce_rx_more_q_less_q_more_q)
{
	struct ice_coalesce_stored *st;
	int prev_num_q_vectors, tx_rings, rx_rings, num_q_vectors;
	int i;

	/* for the purposes of this test, number of rings matches number of qs */
	tx_rings = 4;
	rx_rings = 1;
	num_q_vectors = 4;

	/* set the number of queues, the itr value will get set to a default */
	init_qs_and_vectors(tx_rings, rx_rings, tx_rings, rx_rings, num_q_vectors);

	/* change the rx-usecs for the small number of queues */
	change_itr_val(TEST_RING_TYPE_RX, 50);
	CHECK_EQUAL(50, vsi->q_vectors[0]->rx.itr_setting);

	st = (struct ice_coalesce_stored *)calloc
			(vsi->num_q_vectors, sizeof(struct ice_coalesce_stored));
	prev_num_q_vectors = ice_vsi_rebuild_get_coalesce(vsi, st);
	CHECK_EQUAL(num_q_vectors, prev_num_q_vectors);

	free_qs_and_vectors(vsi->alloc_txq, vsi->alloc_rxq, vsi->num_q_vectors);
	/* change the number of rx (more than before) and tx rings (less
	 * than before)
	 */
	tx_rings = 1;
	rx_rings = 4;
	init_qs_and_vectors(tx_rings, rx_rings, tx_rings, rx_rings, num_q_vectors);
	ice_vsi_rebuild_set_coalesce(vsi, st, prev_num_q_vectors);

        ice_for_each_q_vector(vsi, i) {
		if (i < vsi->alloc_rxq)
			/* all the vectors should have the same value as the
			 * zero-th vector since we added RX rings.
			 */
			CHECK_EQUAL(50, vsi->q_vectors[i]->rx.itr_setting);
		if (i < vsi->alloc_txq)
			CHECK_EQUAL(ITR_DEFAULT_VAL, vsi->q_vectors[i]->tx.itr_setting);
        }

	free(st);
	free_qs_and_vectors(vsi->alloc_txq, vsi->alloc_rxq, vsi->num_q_vectors);
}

TEST_GROUP(ice_vsi_set_dflt_rss_lut)
{
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		vsi->type = ICE_VSI_PF;
		vsi->rss_table_size = ICE_AQC_GSET_RSS_LUT_TABLE_SIZE_128;
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		vsi->back = pf;
		set_bit(ICE_FLAG_RSS_ENA, pf->flags);
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(*vsi));
		pf->vsi[0] = vsi;
		pf->hw.func_caps.common_cap.rss_table_entry_width = 8;
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
#ifdef ADK_SUPPORT
		vsi->is_rss_lut_ena = true;
#endif /* ADK_SUPPORT */
	}

	void teardown()
	{
		free(vsi);
		vsi = NULL;
		free(pf->vsi);
		pf->vsi = NULL;
		free(pf->pdev);
		free(pf);
		pf = NULL;
	}
};

TEST(ice_vsi_set_dflt_rss_lut, fail_to_set_lut_with_req_rss_size_0)
{
	CHECK_EQUAL(-EINVAL, ice_vsi_set_dflt_rss_lut(vsi, 0));
}

TEST(ice_vsi_set_dflt_rss_lut, set_rss_lut_failed_rss_lut_user_still_cleared)
{
	int result;

	mock().expectOneCall("ice_set_rss_lut")
		.andReturnValue(-EIO);
	mock().expectOneCall("ice_fill_rss_lut");
	mock().expectOneCall("ice_aq_str")
		.andReturnValue("ICE_AQ_RC_EIO");
	result = ice_vsi_set_dflt_rss_lut(vsi, 16);
	CHECK_EQUAL(-EIO, result);
}

TEST(ice_vsi_set_dflt_rss_lut, success)
{
	int result;

	mock().expectOneCall("ice_set_rss_lut")
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_fill_rss_lut");
	result = ice_vsi_set_dflt_rss_lut(vsi, 16);
	CHECK_EQUAL(0, result);
	CHECK_EQUAL(16, vsi->rss_size);
}
