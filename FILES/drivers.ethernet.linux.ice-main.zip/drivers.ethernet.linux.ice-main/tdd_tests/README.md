ice-linux TDD Unit Tests
========================

This directory contains unit tests for the nd_linux-cpk Linux ice device
driver. Tests are implemented using the CppUTest C++ testing framework.

# Running the tests

The tests require an installation of CppUTest on your machine. For
information about CppUTest refer to the
[webpage](https://cpputest.github.io/)

## Installing CppUTest

CppUTest can be obtained from
[GitHub](https://github.com/cpputest/cpputest.git).

The CI server uses the latest upstream version of CppUtest from Github, so
it is recommended that you install this version when running the tests
locally.

If you've installed CppUTest globally in either /usr or /usr/local, the
Makefile should automatically detect the installation. Alternatively, if you
installed CppUTest in another location you may set CPPUTEST_HOME in your
environment or on the Make command line.

## Running the tests

### To compile and run all tests

```
make test
```

### To compile only a single test binary (better compilation failure!)

```
make ice-linux-test
# OR
make ice-linux-test-switch
# OR
make ice-linux-test-swx
```

### To run a single test

```
./run-ice-linux-test.sh -n test_name
```

### To run all tests in a single group

```
./run-ice-linux-test.sh -g group_name
```

### See the help output for detailed explanation of all test options

```
./run-ice-linux-test.sh -h
```

### To run a test binary through gdb

```
gdb ice-linux-test
(gdb) source setgdbenv
```

### To debug a single test (very useful!)

```
gdb ice-linux-test-swx
(gdb) source setgdbenv
# set break points, etc if necessary
(gdb) r -n test_name
```

## Creating new test files

The unit tests are separated by each file under test. For example, to add a
new test for a function in `ice_lib.c`, the test function should be placed
in `test_ice_lib.cpp`

Code under test is separated from dependent code by using C++ namespaces. We
use "mocks" to implement most functionality that comes from other files.
This generally lives in the mock files in MOCK folders.

* `CORE_MOCKS` containing mock implementations of functions from other core
  driver files.
* `SHARED_MOCKS` containing mock implementations of functions from SHARED
  code files.
* `KERNEL_MOCKS` containing mock implementations of functions from the
  kernel.

To implement kernel functionality, portions of the Linux kernel headers have
been copied to files in the `include` directory.

To add a new test file, use the following guidelines

1. Create a test file named `test_<file_under_test>.cpp`
2. Include the `ice_utest.h` header file first.
3. Create a namespace with a unigue name, such as `ns_main`, `ns_txrx`, etc.
4. Inside this namespace block include all first all of the relevant
   `KERNEL_MOCK`, `SHARED_MOCK` and `CORE_MOCK` files that your test file
   will depend on. Also include the `CORE_MOCK/stdmock_<file>.cpp` for this
   file if it exists.
5. Include the file under test following this, still inside the namespace
6. Follow the namespace definition with a `using namespace <name>` where
   `<name>` matches the namespace just defined.
7. Create a `TEST_GROUP` and `TEST` functions.

**AVOID** the following

* Avoid including headers outside of the namespace, with the exception of
  `ice_utest.h`. Doing so can lead to compilation conflicts caused by having
  function prototypes defined in the wrong namespace
* Avoid using global variables. Because global variables are shared across the
  tests this can lead tests being dependent on test order. Instead, use
  `mock().setData()` and `mock().getData()` so that "global" values are reset
  each test.
* Avoid testing multiple things in a single function. This can make it
  difficult to debug test failures, especially mock expectations. If you
  find yourself doing `mock().checkExpectations()` you may want to try and
  split the test into multiple unit tests.
* Avoid defining non-detour mock functions in test files. These should be
  defined in the relevant MOCK file instead. It is ok to define
  test-specific detour functions near the code under test. However, see the
  section on `USE_STD_MOCK` for implementing mock functions as standard
  implementations of other functions within the same file.

## Writing unit tests

Writing unit tests is helpful when developing any form of code. When fixing
a bug, creating a new test can help ensure that the bug does not regress in
the future. When writing new features, unit tests can provide assurance that
code behaves as you expect without needing to boot up the full hardware.

Generally it is preferred to create `TEST_GROUP`s for each function or family
of functions being tested. Then, each `TEST` can be written to test a
specific behavior.

If possible, it is preferred that a single `TEST` test for a single
behavior. The test name should suitably describe the behavior under test.

To share test setup code, you can create `TEST_BASE` classes that contain
setup, and then use `TEST_GROUP_BASE` to extend the `TEST_BASE`. The `TGN`
macro can also be used to extend a regular `TEST_GROUP` too:

```
TEST_GROUP(my_group)
{
	int a_test_variable;

	TEST_SETUP()
	{
		/* Code to execute before each test is run */
	}

	TEST_TEARDOWN()
	{
		/* Code to execute after each test is finished, regardless
		 * of success or failure */
	}
};

TEST_GROUP_BASE(my_extended_group, TGN(my_group))
{
	TEST_SETUP()
	{
		TGN(my_group)::setup();

		/* Code to execute after the my_group setup function */
	}
}
```

By using the `TGN` macro, you can extend and re-use setup functionality even
from another pre-existing `TEST_GROUP` without refactoring.

## Writing mock functions

Most of the current unit tests rely on "mock" functions to simplify tests,
so that you test only the behavior of a single function.

In most cases, mock implementations should be provided in the relevant mock
file, and then included in the test files.

We use the ``mock().actualCall()`` and ``mock().expectOneCall()`` mock
functionality of CppUTest.

```
int a_driver_function(struct pf *pf, int flags, char *name)
{
	mock().actualCall(__func__)
		.withParameter("pf", pf)
		.withParameter("flags", flags)
		.withParameter("name", name);

	return mock().returnIntValueOrDefault(0);
}
```

The following guidelines should be used.

* use `__func__` where possible, to avoid typos in mock expectation name.
* use default return values, via `returnTypeValueOrDefault()`
* mock all parameters where possible. Callers can either provide expected
  inputs or use `.ignoreOtherParameters()` where they don't care
* Usually `.withParameter()` is fine, as it is overloaded with most of the
  common types.
* Use `.withParameter("param", param, sizeof(*param))` for parameters which
  are memory buffers.

### mock functions within the same file

In order to mock a function that is resolved within the file under test, we
provide the `USE_STD_MOCK` macro.

"standard" mocks live in `CORE_MOCKS/stdmock_file.cpp`, and are defined
within the 'stdmock' namespace. `USE_STD_MOCK(name)` will detour the
function `name` to `stdmock::name`. By using namespaces, the mock functions
can be implemented with `__func__`. Additionally, a `stdmock_file.cpp` can
directly include the `mock_file.cpp` in order to re-use mock function
implementations that are normally used by tests for other files.

```
/* stdmock_my_file.cpp */
namespace stdmock {
int file_func(int arg)
{
	mock().actualCall(__func__)
		.withParameter("arg", arg);

	return mock().returnIntValueOrDefault(0);
}
}

/* test_my_file.cpp */
int file_func(int arg)
{
	if (arg == 3)
		return 5;
	else
		return arg * 3;
}

#include "stdmock_my_file.cpp"

TEST(group, file_func)
{
	int result;

	USE_STD_MOCK(file_func);

	mock().expectOneCall("file_func")
		.withParameter("arg", 5)
		.andReturnValue(20);


	result = file_func(5);
	CHECK_EQUAL(20, result);
}
```

By using the stdmock namespace and the convention that public functions are
mocked in `mock_file.cpp` while static functions are mocked in
`stdmock_file.cpp` it becomes easy to detour out complex subfunction calls
to the mock implementation.

### Complex mock function examples

Sometimes mock functions may benefit from more advanced techniques. Some
examples follow.

#### deference an input parameter

You can dereference an input parameter if most tests care about testing for
a given value, rather than a given pointer address. To make it obvious in
the test expectation, prefixing the name with the `*` dereference operator
is preferred.

```
void my_func(int *param_by_ref)
{
	mock().actualCall(__func__)
		.withParameter("*param_by_ref", *param_by_ref);
}

TEST(group, my_test)
{
	int val = 5;

	mock().expectOneCall("my_func")
		.withParameter("*param_by_ref", 5);

	my_func(&val);
}
```

#### specify structure members

You can specify members of a structure instead of requiring use of a memory
buffer parameter. This can ease producing expectations in some cases.

```
struct data {
	int field;
};

void my_func(struct *data param)
{
	mock().actualCall(__func__)
		.withParameter("param->field", param->field);
}

TEST(group, my_test)
{
	struct data my_data = { .field = 6 };

	mock().expectOneCall("my_func")
		.withParameter("param->field", 6);

	my_func(&my_data);
}
```

#### output parameters

Sometimes, a function modifies parameters during execution. This is modeled
by using `.withOutputParameter()` Note how you can provide the same name for
both an input and an output parameter.

```
void my_func(int *output_param)
{
	mock().actualCall(__func__)
		.withParameter("output_param", output_param,
			       sizeof(*output_param));
		.withOutputParameter("output_param", output_param);
}

TEST(group, my_test)
{
	int return = 6;
	int input = 5;
	int val = 5;

	mock().expectOneCall("my_func")
		.withParameter("output_param", &input, sizeof(input));
		.withOutputParameterReturning("output_param", &return,
					      sizeof(return));

	my_func(&val);
	CHECK_EQUAL(6, val);
}
```

### detour to fake implementation

In some cases the mock interface does not work well for a given function.
This can occur if the number of calls of a function grows large, or if the
details of the implementation are too difficult to mock, even using the
above tips. Specifically, the expectOneCall interface does not guarantee
ordering.

In such cases, it may be useful to create a 'fake' implementation instead of
a 'mock'. Generally, a mock implementation just records "i was called with
these parameters", while a fake implementation attempts to behave in a
manner consistent with the real function. Often, fake implementations can
use shortcuts or make other assumptions to simplify their implementation.

In general, it is preferred for detoured implementations to live along side
the test code that calls them. This is because they are often crafted
specifically for a given test group. However, some kernel or shared code
functions are implemented as fakes in the MOCK files.

```
int my_func(int n)
{
	mock().actualCall(__func__)
		.withParameter("n", n);

	return mock().returnIntValueOrDefault(0);
}

int fake_my_func(int n)
{
	return n*5;
}

TEST(group, my_test)
{
	int result;

	USE_MOCK(my_func, fake_my_func);

	result = my_func(5);
	CHECK_EQUAL(25, result);
}
```
