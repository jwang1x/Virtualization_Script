#include "ice_utest.h"

#define WQ_MEM_RECLAIM 0
#define KBUILD_MODNAME "ice_test"
#define CEE_DCBX_MAX_PRIO 8
#define IEEE_8021QAZ_MAX_TCS 8
#define DCB_CAP_DCBX_HOST 0x01
#define DCB_CAP_DCBX_VER_IEEE 0x08
#define DCB_CAP_DCBX_LLD_MANAGED 0x02

/////////////////////////////////////////////////
namespace ns_main {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "../src/SHARED/ice_type.h"
#include "../src/SHARED/ice_adminq_cmd.h"
#include "ice_osdep.h"
#include "ice_flex_pipe.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/kernel.h>
#include <linux/cpumask.h>
#include <linux/pm_wakeup.h>
#include <sys/stat.h>
#include <linux/rtnetlink.h>
#include <net/act_api.h>
#include <net/pkt_cls.h>
#include <net/flow_dissector.h>
#include <net/flow_offload.h>
#include <net/tc_act/tc_gact.h>
#include <linux/pci_regs.h>
#include <linux/net.h>
#include <linux/netdevice.h>
#include <linux/jiffies.h>

#include "../src/IDC/iidc.h"
#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_devlink.cpp"
#include "KERNEL_MOCKS/mock_workqueue.cpp"
#include "KERNEL_MOCKS/mock_pci.cpp"
#include "KERNEL_MOCKS/mock_netlink.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_kthread.cpp"
#include "KERNEL_MOCKS/mock_pkt_sched.cpp"

#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "SHARED_MOCKS/mock_ice_nvm.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_dcb.cpp"
#include "SHARED_MOCKS/mock_ice_ddp.cpp"
#include "SHARED_MOCKS/mock_ice_fdir.cpp"
#include "SHARED_MOCKS/mock_ice_sched.cpp"
#include "SHARED_MOCKS/mock_ice_flow.cpp"
#include "SHARED_MOCKS/mock_ice_acl.cpp"
#include "SHARED_MOCKS/mock_ice_vlan_mode.cpp"
#include "SHARED_MOCKS/mock_ice_fwlog.cpp"
#include "SHARED_MOCKS/mock_ice_ptp_hw.c"
#include "CORE_MOCKS/mock_ice_txrx.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_idc.cpp"
#include "CORE_MOCKS/mock_ice_dcb_nl.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_ethtool_fdir.cpp"
#include "CORE_MOCKS/mock_ice_arfs.cpp"
#include "CORE_MOCKS/mock_ice_fltr.cpp"
#include "CORE_MOCKS/mock_ice_xsk.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/mock_ice_devlink.cpp"
#include "CORE_MOCKS/mock_ice_repr.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_dcf.cpp"
#include "CORE_MOCKS/mock_ice_vsi_vlan_ops.cpp"
#include "CORE_MOCKS/mock_ice_irq.cpp"
#ifdef BMSM_MODE
#include "CORE_MOCKS/mock_ice_hw_lag.cpp"
#include "CORE_MOCKS/mock_ice_idc_int.cpp"
#endif /* BMSM_MODE */
#ifdef SIOV_SUPPORT
#include "CORE_MOCKS/mock_ice_siov.cpp"
#endif /* SIOV_SUPPORT */
#include "local_ice_common.cpp"

#include "CORE_MOCKS/stdmock_ice_header.cpp"
#include "CORE_MOCKS/stdmock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_vdcm.cpp"

#include "../src/CORE/ice_main.c"
}
/////////////////////////////////////////////////
using namespace ns_main;

static void *devm_kzalloc_detour_fail(struct device *dev,
					     size_t size,
					     gfp_t gfp)
{
	mock().actualCall(__func__);
	return (void *)mock().returnPointerValueOrDefault(NULL);
}

static void *devm_kcalloc_detour_fail(struct device *dev,
					     size_t nmemb,
					     size_t size,
					     gfp_t gfp)
{
	mock().actualCall(__func__);
	return (void *)mock().returnPointerValueOrDefault(NULL);
}

static void *kzalloc_mock(size_t size, gfp_t flags)
{
	mock().actualCall("kzalloc");
	return (void *)mock().returnPointerValueOrDefault(NULL);
}

TEST_GROUP(ice_nic_probe)
{
	/* these stick around for the life of the test */
	struct pci_device_id ent;
	struct pci_dev pdev;
	struct ice_pf pf;

	void setup(void)
	{
		memset(&ent, 0, sizeof(struct pci_device_id));
		memset(&pdev, 0, sizeof(struct pci_dev));
		memset(&pf, 0, sizeof(struct ice_pf));
		global_vector_count = 129;
	}

	void teardown(void)
	{
		global_vector_count = 0;

		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_nic_probe, check_probe_ena_err)
{
#ifndef SWITCH_MODE
	mock().expectOneCall("pci_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(-19);
#else
	mock().expectOneCall("pcim_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(-19);
#endif /* !SWITCH_MODE */
	// no ignoreOtherCalls here because we
	// just want to see the one

	int ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(-19, ret);
}

#ifdef ADQ_SUPPORT
struct ice_vsi *
fake_ice_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi,
		   enum ice_vsi_type type, struct ice_vf *vf,
		   struct ice_channel *ch, u8 tc)
#else
struct ice_vsi *
fake_ice_vsi_setup(struct ice_pf *pf, struct ice_port_info *pi,
		   enum ice_vsi_type type, struct ice_vf *vf)
#endif /* ADQ_SUPPORT */
{
	/* NOTE: Several of the probe tests rely on the side effects of this
	 * particular implementation. It was moved to a detour in order to
	 * make the regular mock implementation use the standard approach with
	 * out side effects.
	 */
	mock().actualCall("ice_vsi_setup");
	struct ice_vsi *vsi = (struct ice_vsi *)mock().returnPointerValueOrDefault(NULL);
	if (!vsi)
		return NULL;

	vsi->back = pf;
	vsi->port_info = pi;
	vsi->port_info->hw = &pf->hw;
	vsi->port_info->hw->back = pf;

#ifdef FDIR_SUPPORT
	if (vsi->type != ICE_VSI_CTRL) {
		vsi->idx = pf->next_vsi;
		pf->vsi[vsi->idx] = vsi;
		pf->next_vsi++;
	} else {
		vsi->idx = pf->num_alloc_vsi - 1;
		pf->vsi[vsi->idx] = vsi;
	}
#else
	vsi->idx = pf->next_vsi;
	pf->vsi[vsi->idx] = vsi;
	pf->next_vsi++;
#endif /* FDIR_SUPPORT */

	return vsi;
}

#ifdef SWITCH_MODE
TEST(ice_nic_probe, check_probe_success_switch)
{
#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif

	mock().expectNCalls(2, "ice_init_hw")
		.ignoreOtherParameters()
		.andReturnValue(0);

	/* switch mode needs at least 96 vectors */
#ifdef BMSM_MODE
	int num_ports =8;
	int localvec = 81;
#else
	int num_ports =21;
	int localvec = 96;
#endif

	USE_MOCK(ice_vsi_setup, fake_ice_vsi_setup);

	/* this controls the mock's num_msix_vectors return value */
	global_vector_count = localvec;

	mock().expectOneCall("ice_init_interrupt_scheme")
		.andReturnValue(0);

	struct ice_vsi *all_pf_vsi = (struct ice_vsi *)calloc(num_ports, sizeof(struct ice_vsi));
	for (int i = 0; i < num_ports; i++) {
		mock().expectOneCall("ice_vsi_setup")
			.andReturnValue(&all_pf_vsi[i]);
	}

#ifdef FDIR_SUPPORT
	struct ice_vsi *ctrl_vsi =
		(struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
	mock().expectOneCall("ice_vsi_setup")
		.andReturnValue(ctrl_vsi);
#endif /* FDIR_SUPPORT */

	mock().ignoreOtherCalls();

	int ret = ice_probe(&pdev, &ent);
	CHECK_EQUAL(0, ret);

	/* call clean up */
	ice_remove(&pdev);

	for (int i = 0; i < num_ports; i++) {
		free_netdev(all_pf_vsi[i].netdev);
	}

	free(all_pf_vsi);
#ifdef FDIR_SUPPORT
	free(ctrl_vsi);
#endif /* FDIR_SUPPORT */
}

#else
TEST(ice_nic_probe, check_probe_success)
{
#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif

	mock().expectNCalls(2, "ice_init_hw")
		.ignoreOtherParameters()
		.andReturnValue(0);

	USE_MOCK(ice_vsi_setup, fake_ice_vsi_setup);

	/* this controls the mock's num_msix_vectors return value */
	global_vector_count = 20;

	mock().expectOneCall("request_firmware");

	/* test we can call probe, and that it calls enable interrupt */
	mock().expectOneCall("ice_init_interrupt_scheme")
		.andReturnValue(0);

	struct ice_vsi main_vsi = { };
	mock().expectOneCall("ice_vsi_setup")
		.andReturnValue(&main_vsi);

#ifdef FDIR_SUPPORT
	struct ice_vsi fd_vsi = { };
	mock().expectOneCall("ice_vsi_setup")
		.andReturnValue(&fd_vsi);
#endif /* FDIR_SUPPORT */

	mock().ignoreOtherCalls();

	int ret = ice_probe(&pdev, &ent);
	CHECK_EQUAL(0, ret);

	/* call clean up */
	ice_remove(&pdev);
	free_netdev(main_vsi.netdev);
}
#endif /* SWITCH_MODE */

TEST_GROUP(ice_nic_probe_fail)
{
	/* these stick around for the life of the test */
	struct pci_device_id ent;
	struct pci_dev pdev;
	struct ice_pf pf;

	void setup(void)
	{
		memset(&ent, 0, sizeof(struct pci_device_id));
		memset(&pdev, 0, sizeof(struct pci_dev));
		memset(&pf, 0, sizeof(struct ice_pf));
		global_vector_count = 129;
	}

	void teardown(void)
	{
		global_vector_count = 0;
		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_nic_probe_fail, check_hw_init_fail)
{
	USE_STD_MOCK(ice_pf_fwlog_init);

#ifndef SWITCH_MODE
	mock().expectOneCall("pci_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_request_mem_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_release_mem_regions")
		.ignoreOtherParameters();
#else
	mock().expectOneCall("pcim_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pcim_iomap_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* !SWITCH_MODE */
#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
	mock().expectOneCall("alloc_workqueue")
		.withParameter("fmt", "%s_fp")
		.withParameter("flags", 0)
		.withParameter("max_active", 0)
		.withParameter("name", "ice_test_fp");
#endif /* SWITCH_MODE && !BMSM_MODE */
	mock().expectOneCall("dma_set_mask_and_coherent")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_read_config_byte")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_set_master");
	mock().expectOneCall("pci_save_state");

#ifndef NO_RECOVERY_MODE_SUPPORT
	mock().expectOneCall("ice_get_fw_mode")
		.andReturnValue(ICE_FW_MODE_NORMAL);
#endif
#ifdef FWLOG_SUPPORT_V2
	mock().expectOneCall("ice_pf_fwlog_init")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif

	/* now fail the call to ice_init_hw */
	mock().expectOneCall("ice_init_hw")
		.ignoreOtherParameters()
		.andReturnValue(-1);

	int ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(-EIO, ret);
}

#ifndef NO_RECOVERY_MODE_SUPPORT
TEST(ice_nic_probe_fail, enter_recovery_mode)
{
#ifndef SWITCH_MODE
	mock().expectOneCall("pci_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_request_mem_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	mock().expectOneCall("pcim_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pcim_iomap_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* !SWITCH_MODE */
#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif
#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
	mock().expectOneCall("alloc_workqueue")
		.withParameter("fmt", "%s_fp")
		.withParameter("flags", 0)
		.withParameter("max_active", 0)
		.withParameter("name", "ice_test_fp");
#endif
	mock().expectOneCall("dma_set_mask_and_coherent")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_read_config_byte")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_set_master");
	mock().expectOneCall("pci_save_state");
	mock().expectOneCall("ice_get_fw_mode")
		.andReturnValue(ICE_FW_MODE_REC);
	mock().expectOneCall("register_netdev");
	mock().expectOneCall("ice_set_ethtool_recovery_ops");

	int ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(0, ret);
	mock().ignoreOtherCalls();

	/* undo things */
	struct ice_pf *pf = pci_get_drvdata(&pdev);
	ice_remove_recovery_mode(pf);
}
#endif

#ifdef DEVLINK_SUPPORT
TEST(ice_nic_probe_fail, pf_alloc_fail)
{
#ifndef SWITCH_MODE
	mock().expectOneCall("pci_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_request_mem_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
#else
	mock().expectOneCall("pcim_enable_device")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pcim_iomap_regions")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* !SWITCH_MODE */
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue((void *)NULL);

	int ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(-ENOMEM, ret);
}
#endif

TEST(ice_nic_probe_fail, vsi_list_alloc_fail)
{
	USE_MOCK(devm_kcalloc, devm_kcalloc_detour_fail);

#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif

	mock().expectOneCall("devm_kcalloc_detour_fail")
		.andReturnValue((void *)NULL)
		.ignoreOtherParameters();

	mock().ignoreOtherCalls();

	int ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(-ENOMEM, ret);
}

#ifndef SWITCH_MODE
TEST(ice_nic_probe_fail, register_netdev_fail)
{
	struct ice_vsi main_vsi = { };
	int ret;

	USE_MOCK(ice_vsi_setup, fake_ice_vsi_setup);

	/* this controls the mock's num_msix_vectors return value */
	global_vector_count = 20;

#ifdef DEVLINK_SUPPORT
	mock().expectOneCall("ice_allocate_pf")
		.withParameter("dev", &pdev.dev)
		.andReturnValue(&pf);
#endif

	mock().expectOneCall("ice_init_interrupt_scheme")
		.andReturnValue(0);

	mock().expectOneCall("ice_vsi_setup")
		.andReturnValue(&main_vsi);

	mock().expectOneCall("ice_vsi_setup");

	mock().expectOneCall("register_netdev")
		.andReturnValue(-EINVAL);

	mock().ignoreOtherCalls();

	ret = ice_probe(&pdev, &ent);

	CHECK_EQUAL(-EINVAL, ret);
}
#endif /* !SWITCH_MODE */

#ifndef SWITCH_MODE
TEST_GROUP(ice_init_ddp_config)
{
	struct pci_dev *pdev;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup()
	{
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));

		hw = (struct ice_hw *)calloc(1, sizeof(struct ice_hw));
		
		hw->back = pf;
		pf->pdev = pdev;
	}

	void teardown()
	{
		free(pdev);
		free(pf);
		free(hw);

		pdev = NULL;
		pf = NULL;
		hw = NULL;
	}
};

TEST(ice_init_ddp_config, basic_ice_init_ddp_config)
{
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pdev)
		.andReturnValue(0);

	mock().expectOneCall("request_firmware");

	mock().expectOneCall("ice_cfg_tx_topo");

	mock().expectNCalls(2, "ice_deinit_hw");

	mock().expectOneCall("ice_init_hw");

	mock().expectOneCall("ice_copy_and_init_pkg");

	mock().expectOneCall("ice_is_init_pkg_successful");

	ice_init_ddp_config(hw, pf);


	/* prevent leak due to ice_init_hw mock function allocation */
	ice_deinit_hw(hw);
}

TEST(ice_init_ddp_config, basic_ice_init_ddp_config_fails)
{
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pdev)
		.andReturnValue(0);

	mock().expectOneCall("request_firmware")
		.andReturnValue(EBUSY);

	ice_init_ddp_config(hw, pf);
}

TEST(ice_init_ddp_config, optional_ice_init_ddp_config)
{
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pdev)
		.andReturnValue(0x0102030405060708);

	mock().expectOneCall("firmware_request_nowarn")
		.withParameter("name", "intel/tdd/ddp/@DRIVER@-0102030405060708.pkg")
		.withParameter("device", &pdev->dev);

	mock().expectOneCall("ice_cfg_tx_topo");

	mock().expectNCalls(2, "ice_deinit_hw");

	mock().expectOneCall("ice_init_hw");
	mock().expectOneCall("ice_copy_and_init_pkg");

	mock().expectOneCall("ice_is_init_pkg_successful");

	ice_init_ddp_config(hw, pf);

	/* prevent leak due to ice_init_hw mock function allocation */
	ice_deinit_hw(hw);
}

TEST(ice_init_ddp_config, optional_ice_request_fw_does_not_exist)
{
	mock().expectOneCall("pci_get_dsn")
		.withParameter("dev", pdev)
		.andReturnValue(0x0102030405060708);

	mock().expectOneCall("firmware_request_nowarn")
		.withParameter("name", "intel/tdd/ddp/@DRIVER@-0102030405060708.pkg")
		.withParameter("device", &pdev->dev)
		.andReturnValue(ENODATA);

	mock().expectOneCall("request_firmware");

	mock().expectOneCall("ice_cfg_tx_topo");

	mock().expectNCalls(2, "ice_deinit_hw");

	mock().expectOneCall("ice_init_hw");
	mock().expectOneCall("ice_copy_and_init_pkg");

	mock().expectOneCall("ice_is_init_pkg_successful");

	ice_init_ddp_config(hw, pf);

	/* prevent leak due to ice_init_hw mock function allocation */
	ice_deinit_hw(hw);
}

TEST(ice_init_ddp_config, ice_cfg_tx_topology_succeeds)
{
	const struct firmware *firmware;
	int err;
	mock().expectOneCall("request_firmware");

	mock().expectOneCall("ice_cfg_tx_topo")
		.andReturnValue(ICE_SUCCESS);

	mock().expectNCalls(2, "ice_deinit_hw");
	mock().expectOneCall("ice_init_hw");

	request_firmware(&firmware, NULL, NULL);


	err = ice_init_tx_topology(hw, firmware);

	CHECK_EQUAL(err, 0);
	release_firmware(firmware);

	/* prevent leak due to ice_init_hw mock function allocation */
	ice_deinit_hw(hw);
}

TEST(ice_init_ddp_config, ice_cfg_tx_topology_fails)
{
	const struct firmware *firmware;
	int err;
	mock().expectOneCall("request_firmware");

	mock().expectOneCall("ice_cfg_tx_topo")
		.andReturnValue(ICE_ERR_CFG);

	request_firmware(&firmware, NULL, NULL);

	err = ice_init_tx_topology(hw, firmware);

	/* This feature is opt-in so we return 0 */
	CHECK_EQUAL(err, 0);

	release_firmware(firmware);
}
#endif /* !SWITCH_MODE */

TEST_GROUP(ice_reset)
{
	struct workqueue_struct *wq;
	struct ice_pf *pf;
	struct ice_hw hw;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));

		wq = (struct workqueue_struct *)calloc(1, sizeof(*wq));
		ice_wq = wq;
	}

	void teardown()
	{
		free(pf->pdev);
		free(pf);
		pf = NULL;

		ice_wq = NULL;
		free(wq);

		mock().checkExpectations();
		mock().clear();
	}
};

#ifndef SWITCH_MODE
TEST(ice_reset, ice_pf_reset)
{
	ice_status ret;

	mock().disable();

	ret = ice_pf_reset(&hw);
	CHECK_EQUAL(ICE_SUCCESS, ret);

	mock().enable();
}

TEST(ice_reset, ice_schedule_pfr_success1)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(false);

	mock().expectOneCall("queue_work")
		.withParameter("wq", wq)
		.withParameter("work", &pf->serv_task);

	ret = ice_schedule_reset(pf, ICE_RESET_PFR);
	CHECK_EQUAL(0, ret);
	CHECK_EQUAL(1, test_bit(ICE_PFR_REQ, pf->state));
}

TEST(ice_reset, ice_schedule_pfr_success2)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(true);
	ret = ice_schedule_reset(pf, ICE_RESET_PFR);
	CHECK_EQUAL(-EBUSY, ret);
}

TEST(ice_reset, ice_schedule_bogus_reset_success3)
{
	enum ice_reset_req bogus_reset = (enum ice_reset_req) 0xf;
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(false);

	ret = ice_schedule_reset(pf, bogus_reset);
	CHECK_EQUAL(-EINVAL, ret);
}
#endif

TEST(ice_reset, ice_schedule_corer_success1)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(false);

	mock().expectOneCall("queue_work")
		.withParameter("wq", wq)
		.withParameter("work", &pf->serv_task);

	ret = ice_schedule_reset(pf, ICE_RESET_CORER);
	CHECK_EQUAL(0, ret);
	CHECK_EQUAL(1, test_bit(ICE_CORER_REQ, pf->state));
}

TEST(ice_reset, ice_schedule_corer_success2)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(true);
	ret = ice_schedule_reset(pf, ICE_RESET_CORER);
	CHECK_EQUAL(-EBUSY, ret);
}

TEST(ice_reset, ice_schedule_globr_success1)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(false);

	mock().expectOneCall("queue_work")
		.withParameter("wq", wq)
		.withParameter("work", &pf->serv_task);

	ret = ice_schedule_reset(pf, ICE_RESET_GLOBR);
	CHECK_EQUAL(0, ret);
	CHECK_EQUAL(1, test_bit(ICE_GLOBR_REQ, pf->state));
}

TEST(ice_reset, ice_schedule_globr_success2)
{
	int ret;

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(true);
	ret = ice_schedule_reset(pf, ICE_RESET_GLOBR);
	CHECK_EQUAL(-EBUSY, ret);
}

TEST_GROUP(ice_err_str)
{
	const char *err;
};

TEST(ice_err_str, ice_aq_str)
{
	enum ice_aq_err test_err;
	test_err = ICE_AQ_RC_EPERM;
	err = ice_aq_str(test_err);
	STRCMP_EQUAL(err, "ICE_AQ_RC_EPERM");

	test_err = ICE_AQ_RC_ESBCOMP;
	err = ice_aq_str(test_err);
	STRCMP_EQUAL(err, "ICE_AQ_RC_ESBCOMP");
}

struct test_hw {
/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_handle_link_event)
{
	struct ice_rq_event_info *event;
	struct ice_pf *pf;
	struct pci_dev *pdev;
	int result;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pdev = (__typeof(pdev))calloc(1, sizeof(*pdev));
		pf->pdev = pdev;
		pf->hw.port_info = (struct ice_port_info *)
			calloc(1, sizeof(struct ice_port_info));
		event = (struct ice_rq_event_info *)calloc(1, sizeof(*event));
		event->msg_buf = (u8 *)
			calloc(1, sizeof(struct ice_aqc_get_link_status_data));
	}

	void teardown(void)
	{
		free(event->msg_buf);
		event->msg_buf = NULL;
		free(event);
		event = NULL;
		free(pf->hw.port_info);
		pf->hw.port_info = NULL;
		free(pf);
		free(pdev);
		pf = NULL;
	}
};

TEST(ice_handle_link_event, null_port_info)
{
	struct ice_port_info *pi_holder = pf->hw.port_info;

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_find_port_info")
		.ignoreOtherParameters()
		.andReturnValue((struct ice_port_info *)NULL);
#else
	pf->hw.port_info = NULL;
#endif /* SWITCH_MODE */
	result = ice_handle_link_event(pf, event);
	CHECK_EQUAL(-EINVAL, result);

	pf->hw.port_info = pi_holder;
}

TEST(ice_handle_link_event, ice_link_event_failed)
{
	USE_STD_MOCK(ice_link_event);

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_find_port_info")
		.ignoreOtherParameters()
		.andReturnValue((struct ice_port_info *)pf->hw.port_info);
#endif /* SWITCH_MODE */

	mock().expectOneCall("ice_link_event")
		.ignoreOtherParameters()
		.andReturnValue(-EINVAL);

	result = ice_handle_link_event(pf, event);
	CHECK_EQUAL(-EINVAL, result);
}

TEST(ice_handle_link_event, success)
{
	USE_STD_MOCK(ice_link_event);

#ifdef SWITCH_MODE
	mock().expectOneCall("ice_find_port_info")
		.ignoreOtherParameters()
		.andReturnValue((struct ice_port_info *)pf->hw.port_info);
#endif /* SWITCH_MODE */

	mock().expectOneCall("ice_link_event")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_handle_link_event(pf, event);
	CHECK_EQUAL(0, result);
}

TEST_GROUP(ice_init_link_events)
{
	struct ice_pf *pf;
	struct ice_hw *hw;
	struct pci_dev *pdev;
	int status;

	void setup()
	{
		pf = (ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (__typeof(pdev))calloc(1, sizeof(*pdev));
		pf->pdev = pdev;
		hw = &pf->hw;
		hw->back = pf;
		hw->port_info = (struct ice_port_info *)calloc(1,
							sizeof(struct ice_port_info));
		hw->port_info->hw = hw;
	}

	void teardown()
	{
		free(hw->port_info);
		free(pf);
		free(pdev);
	}
};

TEST(ice_init_link_events, failure_to_set_link_event_mask)
{
	mock().expectOneCall("ice_aq_set_event_mask")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_AQ_ERROR);

	status = ice_init_link_events(pf->hw.port_info);
	CHECK_EQUAL(-EIO, status);
}

TEST(ice_init_link_events, failure_to_enable_link_events)
{
	mock().expectOneCall("ice_aq_set_event_mask")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_get_link_info")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_AQ_ERROR);

	status = ice_init_link_events(pf->hw.port_info);
	CHECK_EQUAL(-EIO, status);
}

TEST(ice_init_link_events, return_success)
{
	mock().expectOneCall("ice_aq_set_event_mask")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_get_link_info")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	status = ice_init_link_events(pf->hw.port_info);
	CHECK_EQUAL(0, status);
}

TEST_GROUP(ice_vsi_link_event)
{
	struct ice_vsi *vsi;
	struct net_device *netdev;
	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		vsi->netdev = netdev;
#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
		set_bit(ICE_FLAG_ND_VIS_ENA, vsi->back->flags);
#endif /* SWITCH_MODE && ADK_SUPPORT */
		vsi->type = ICE_VSI_PF;
	}

	void teardown()
	{
		free(vsi->back->pdev);
		free(vsi->back);
		free(vsi);
		free_netdev(netdev);
	}
};

TEST(ice_vsi_link_event, trivial_cases)
{
	struct net_device *netdev_holder;

	/* Return early due to null vsi */
	struct ice_vsi *null_vsi = NULL;
	ice_vsi_link_event(null_vsi, false);
	/* Return early due to vsi state being down */
	set_bit(ICE_VSI_DOWN, vsi->state);
	ice_vsi_link_event(vsi, false);
	/* Return early due to uninitialized netdev */
	netdev_holder = vsi->netdev;
	vsi->netdev = NULL;
	ice_vsi_link_event(vsi, false);
	vsi->netdev = netdev_holder;
}

#if defined(SWITCH_MODE) && defined(ADK_SUPPORT)
TEST(ice_vsi_link_event, ICE_FLAG_ND_VSI_ENA_cleared)
{
	/* netdev is not NULL for the test case so if we do end up
	 * calling a netdev function this test will fail
	 */
	clear_bit(ICE_FLAG_ND_VIS_ENA, vsi->back->flags);
	ice_vsi_link_event(vsi, true);
}
#endif /* SWITCH_MODE && ADK_SUPPORT */

TEST(ice_vsi_link_event, vsi_is_pf_and_link_is_up)
{
	set_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state);
	vsi->type = ICE_VSI_PF;

	mock().expectOneCall("netif_carrier_ok")
		.andReturnValue(false);
	ice_vsi_link_event(vsi, true);
	CHECK_EQUAL(0, test_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state));
}

TEST(ice_vsi_link_event, vsi_is_pf_and_link_is_down)
{
	vsi->type = ICE_VSI_PF;

	mock().expectOneCall("netif_carrier_ok")
		.andReturnValue(true);
	ice_vsi_link_event(vsi, false);
	CHECK_EQUAL(1, test_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state));
}

TEST(ice_vsi_link_event, vf_vsi)
{
	netif_carrier_off(vsi->netdev);

	// no unexpected calls to netif_carrier_ok means yay!
	vsi->type = ICE_VSI_VF;
	ice_vsi_link_event(vsi, false);
}

TEST(ice_vsi_link_event, vmdq2_vsi)
{
	netif_carrier_off(vsi->netdev);

	// no unexpected calls to netif_carrier_ok means yay!
	vsi->type = ICE_VSI_VMDQ2;
	ice_vsi_link_event(vsi, false);
}

#ifndef SWITCH_MODE
TEST(ice_vsi_link_event, lb_vsi)
{
	netif_carrier_off(vsi->netdev);

	// this one is not handled by this function
	// no unexpected calls to netif_carrier_ok means yay!
	vsi->type = ICE_VSI_LB;
	ice_vsi_link_event(vsi, false);
}
#endif

TEST_GROUP(ice_link_event_trivial)
{
	struct ice_pf *pf;
	struct ice_port_info *port_info;
	struct ice_vsi **vsi;
	int status;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		port_info = (struct ice_port_info *)calloc(1, sizeof(ice_port_info));
		vsi = (struct ice_vsi **)calloc(10, sizeof(ice_vsi *));
		pf->vsi = vsi;
		for (int i = 0; i < 10; ++i)
			pf->vsi[i] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf->vsi[0]->port_info = port_info;
		port_info->lport = 13;
	}

	void teardown()
	{
		for (int i = 0; i < 10; ++i)
			free(pf->vsi[i]);
		free(vsi);
		vsi = NULL;
		free(port_info);
		port_info = NULL;
		free(pf->pdev);
		free(pf);
		pf = NULL;
	}
};

TEST(ice_link_event_trivial, null_vsi)
{
	struct ice_vsi *vsi_holder;
	int result;

	port_info->phy.link_info.link_speed = 0;
	port_info->phy.link_info.link_info = 0;
	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);

	vsi_holder = pf->vsi[0];
	pf->vsi[0] = NULL;
	result = ice_link_event(pf, port_info, true, ICE_AQ_LINK_SPEED_100GB);
	CHECK_EQUAL(-EINVAL, result);

	pf->vsi[0] = vsi_holder;
}

TEST(ice_link_event_trivial, null_port_info)
{
	struct ice_port_info *pi_holder;
	int result;

	port_info->phy.link_info.link_speed = 0;
	port_info->phy.link_info.link_info = 0;
	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);

	pi_holder = pf->vsi[0]->port_info;
	pf->vsi[0]->port_info = NULL;
	result = ice_link_event(pf, port_info, true, ICE_AQ_LINK_SPEED_100GB);
	CHECK_EQUAL(-EINVAL, result);

	pf->vsi[0]->port_info = pi_holder;
}

TEST_GROUP(ice_link_event)
{
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct ice_port_info *port_info;
	struct ice_phy_info *phy_info;
	struct ice_vsi **vsilist;
	struct ice_vsi *vsi;
	int result;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));

		vsilist = (struct ice_vsi **)calloc(1, sizeof(ice_vsi *));
		pf->vsi = vsilist;
		pf->num_alloc_vsi = 1;
		vsi = (struct ice_vsi *)calloc(1, sizeof(ice_vsi));
		vsi->back = pf;
		vsi->netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);

		port_info = (struct ice_port_info *)calloc(1, sizeof(ice_port_info));
		port_info->lport = 13;
		phy_info = &port_info->phy;

		pf->vsi[0] = vsi;
		port_info->fc.current_mode = ICE_FC_NONE;
		vsi->type = ICE_VSI_PF;
		pf->vsi[0]->port_info = port_info;
		vf = (struct ice_vf *)calloc(1, sizeof(ice_vf));
		hash_add(pf->vfs.table, &vf->entry, 0);
#ifdef ADK_SUPPORT
		set_bit(ICE_FLAG_ND_VIS_ENA, pf->flags);
#endif /* ADK_SUPPORT */
	}

	void teardown()
	{
		free_netdev(vsi->netdev);
		vsi->netdev = NULL;
		free(vsi);
		vsi = NULL;
		phy_info = NULL;
		free(vsilist);
		vsilist = NULL;
		free(port_info);
		port_info = NULL;
		free(pf->pdev);
		free(vf);
		free(pf);
		pf = NULL;

		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_link_event, new_link_up_100G_same_as_old)
{
	int result;

	port_info->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_100GB;
	port_info->phy.link_info.link_info = ICE_AQ_LINK_UP;
	port_info->phy.link_info.link_info |= ICE_AQ_MEDIA_AVAILABLE;

	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);
	result = ice_link_event(pf, port_info, true, ICE_AQ_LINK_SPEED_100GB);

	CHECK_EQUAL(0, result);
}

TEST(ice_link_event, new_link_down_0G_same_as_old)
{
	int result;

	port_info->phy.link_info.link_speed = 0;
	port_info->phy.link_info.link_info = 0;
	port_info->phy.link_info.link_info |= ICE_AQ_MEDIA_AVAILABLE;

	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);
	result = ice_link_event(pf, port_info, false, 0);

	CHECK_EQUAL(0, result);
}

TEST(ice_link_event, link_up_event_100GB)
{
	port_info->phy.link_info.link_info = ICE_AQ_MEDIA_AVAILABLE;
	port_info->phy.link_info.link_speed = 0;
	vsi->current_isup = false;

	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);
#ifndef NO_PTP_SUPPORT
	mock().expectOneCall("ice_ptp_link_change");
#endif /* !NO_PTP_SUPPORT */
	mock().expectOneCall("netif_carrier_ok")
		.andReturnValue(false);
#ifndef SWITCH_MODE
	mock().expectOneCall("ice_aq_get_phy_caps")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
#endif /* !SWITCH_MODE */
#ifdef BMSM_MODE
	mock().expectOneCall("ice_recalc_each_link_speed_kbps")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* BMSM_MODE */
	mock().expectOneCall("ice_vc_notify_link_state");

	result = ice_link_event(pf, port_info, true, ICE_AQ_LINK_SPEED_100GB);
	CHECK_EQUAL(0, result);
	CHECK_FALSE(test_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state));
}

TEST(ice_link_event, link_down_event)
{
	port_info->phy.link_info.link_info = ICE_AQ_LINK_UP | ICE_AQ_MEDIA_AVAILABLE;
	port_info->phy.link_info.link_speed = ICE_AQ_LINK_SPEED_100GB;
	vsi->current_isup = true;

	mock().expectOneCall("ice_update_link_info")
		.andReturnValue(0);
#ifndef NO_PTP_SUPPORT
	mock().expectOneCall("ice_ptp_link_change");
#endif /* !NO_PTP_SUPPORT */
	mock().expectOneCall("netif_carrier_ok")
		.andReturnValue(true);
#ifdef BMSM_MODE
	mock().expectOneCall("ice_recalc_each_link_speed_kbps")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* BMSM_MODE */
	mock().expectOneCall("ice_vc_notify_link_state");

	result = ice_link_event(pf, port_info, false, 0);
	CHECK_EQUAL(0, result);
}

TEST(ice_link_event, link_up_strings)
{
	struct ice_vf vf = {};

	hash_add(pf->vfs.table, &vf.entry, 0);
	phy_info->link_info.link_info = ICE_AQ_MEDIA_AVAILABLE;
	phy_info->link_info.link_speed = 0;

	vsi->type = ICE_VSI_PF;
	set_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state);

#ifdef SWITCH_MODE
#define NUM_LINK_SPEEDS_TO_TEST 1
#else
#define NUM_LINK_SPEEDS_TO_TEST 8
#endif
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "ice_update_link_info")
		.andReturnValue(0);
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "ice_vc_notify_link_state")
		.ignoreOtherParameters();
#ifdef BMSM_MODE
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST,"ice_recalc_each_link_speed_kbps")
		.ignoreOtherParameters()
		.andReturnValue(0);
#endif /* BMSM_MODE */

#ifndef NO_PTP_SUPPORT
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "ice_ptp_link_change")
		.ignoreOtherParameters();
#endif /* NO_PTP_SUPPORT */
#ifndef SWITCH_MODE
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "ice_aq_get_phy_caps")
		.ignoreOtherParameters();
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "ice_is_phy_caps_an_enabled")
		.andReturnValue(false);
#endif /* !SWITCH_MODE */
	mock().expectNCalls(NUM_LINK_SPEEDS_TO_TEST, "netif_carrier_ok")
		.andReturnValue(false);
	/* grab stderr */
	int oldfd;
	FILE *lfd;
	fpos_t pos;

	/* get the stderr handle and save it for later */
	fflush(stderr);
	fgetpos(stderr, &pos);
	oldfd = dup(fileno(stderr));

	lfd = fopen("links.txt", "w");
	if (lfd == NULL) {
		perror("fopen biff");
		return;
	}

	dup2(fileno(lfd), fileno(stderr));

	for (unsigned int i = 2; i <= BIT(NUM_LINK_SPEEDS_TO_TEST); i <<= 1) {
		phy_info->link_info.link_speed = i;

		/* Actually printing a link message */
		vsi->current_isup = false;

		result = ice_link_event(pf, port_info, true, i);
		CHECK_EQUAL(0, result);
	}

	/* get the number of bytes written, don't forget to flush
	 * first or the size is zero
	 */
	struct stat *st = (struct stat *)calloc(1, sizeof(*st));
	fflush(stderr);
	if (stat("links.txt", st)) {
		perror("links.txt stat");
		free(st);
		return;
	}

	/* restore stderr by first duplicating ours to stderr
	 * then close "our" copy
	 * then close our file links.txt, so we don't leak it
	 * then clear stderr and reset it's pointer to where we started
	 */
	if (fclose(lfd))
		perror("close lfd failed");

	int resto = dup2(oldfd, fileno(stderr));
	if (oldfd == resto)
		perror("dup2 restore failed");
	//clearerr(stderr);
	//fsetpos(stderr, &pos);

	/* this is kinda lame right now, it just checks that the
	 * expected number of bytes was printed in total from each call to
	 * fprintf(stderr, ...)
	 */
#ifdef SWITCH_MODE
	/* Flow control is None */
	CHECK_EQUAL(150, st->st_size);
#else
	CHECK_EQUAL(1200, st->st_size);
#endif

	/* clean up our file */
	unlink("links.txt");
	free(st);
}

#ifndef SWITCH_MODE
TEST(ice_link_event, topo_string)
{
	struct ice_vf vf = {};

	hash_add(pf->vfs.table, &vf.entry, 0);

	phy_info->link_info.link_info = ICE_AQ_MEDIA_AVAILABLE;
	phy_info->link_info.link_speed = 0;

	vsi->type = ICE_VSI_PF;
	set_bit(__LINK_STATE_NOCARRIER, &vsi->netdev->state);

	/* grab stderr */
	int oldfd;
	FILE *lfd;
	fpos_t pos;

	/* get the stderr handle and save it for later */
	fflush(stderr);
	fgetpos(stderr, &pos);
	oldfd = dup(fileno(stderr));

	lfd = fopen("links.txt", "w");
	if (lfd == NULL) {
		perror("fopen biff");
		return;
	}

	dup2(fileno(lfd), fileno(stderr));

	phy_info->link_info.topo_media_conflict = ICE_AQ_LINK_TOPO_CONFLICT;
	ice_print_topo_conflict(vsi);

	phy_info->link_info.topo_media_conflict = ICE_AQ_LINK_MEDIA_CONFLICT;
	ice_print_topo_conflict(vsi);

	/* get the number of bytes written, don't forget to flush
	 * first or the size is zero
	 */
	struct stat *st = (struct stat *)calloc(1, sizeof(*st));
	fflush(stderr);
	if (stat("links.txt", st)) {
		perror("links.txt stat");
		free(st);
		return;
	}

	/* restore stderr by first duplicating ours to stderr
	 * then close "our" copy
	 * then close our file links.txt, so we don't leak it
	 * then clear stderr and reset it's pointer to where we started
	 */
	if (fclose(lfd))
		perror("close lfd failed");

	int resto = dup2(oldfd, fileno(stderr));
	if (oldfd == resto)
		perror("dup2 restore failed");
	//clearerr(stderr);
	//fsetpos(stderr, &pos);

	/* this is kinda lame right now, it just checks that the
	 * expected number of bytes was printed in total from each call to
	 * fprintf(stderr, ...)
	 */
	CHECK_EQUAL(324, st->st_size);

	/* clean up our file */
	unlink("links.txt");
	free(st);
}
#endif /* !SWITCH_MODE */

TEST_GROUP(ice_netpoll)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	struct ice_pf *pf;

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back = pf;
		/* need this for dev_dbg */
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		free(pf->pdev);
		free(pf);
		free(vsi);
		free_netdev(netdev);
	}
};

TEST(ice_netpoll, vsi_is_down)
{
	set_bit(ICE_VSI_DOWN, vsi->state);
	ice_netpoll(netdev);
	CHECK_EQUAL(1, test_bit(ICE_VSI_DOWN, vsi->state));
}

TEST_GROUP(ice_features_check)
{
	struct net_device netdev;
	struct sk_buff init_skb = {};
	struct sk_buff *skb = &init_skb;
	struct skb_shared_info *skb_shinfo;
	netdev_features_t features;

	#define MIN_VALID_GSO_SIZE 	64

	void setup(void)
	{
		u32 len = 1024;
		int size = len + sizeof(skb_shared_info);
		skb->data = (unsigned char *) malloc(size);
		skb->head = skb->data;
		skb->len = len;
		skb_reset_tail_pointer(skb);
		skb->end = skb->tail + len;
		skb_shinfo = skb_shinfo(skb);
	}

	void teardown(void)
	{
		free(skb->data);
	}
};

TEST(ice_features_check, skb_ip_summed_is_not_CHECKSUM_PARTIAL)
{
	netdev_features_t result;

	features = 10;
	skb->ip_summed = CHECKSUM_COMPLETE;

	result = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(features, result);
}

TEST(ice_features_check, skb_gso_size_less_than_64_bytes)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE - 1;

	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(NETIF_F_CSUM_MASK, features);
}

TEST(ice_features_check, odd_mac_len_remove_gso_csum_support)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;

	skb->network_header = ICE_TXD_MACLEN_MAX - 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);

	skb->network_header = ICE_TXD_MACLEN_MAX + 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, above_max_size_maclen_remove_gso_csum_support)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;

	skb->network_header = ICE_TXD_MACLEN_MAX + 2;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, odd_iplen_remove_gso_csum_support)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;

	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX - 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);

	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX + 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, above_max_iplen_remove_gso_csum_support)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;

	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX + 2;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, odd_l4tunlen_with_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;
	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;
	skb->encapsulation = 1;

	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);

	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, above_max_l4tunlen_with_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;
	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;
	skb->encapsulation = 1;

	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, odd_iplen_with_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;
	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;
	skb->encapsulation = 1;

	skb->inner_transport_header = skb->inner_network_header + ICE_TXD_IPLEN_MAX - 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);

	skb->inner_transport_header = skb->inner_network_header + ICE_TXD_IPLEN_MAX + 1;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, above_max_iplen_with_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;
	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;
	skb->encapsulation = 1;

	skb->inner_transport_header = skb->inner_network_header + ICE_TXD_IPLEN_MAX + 2;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(0, features);
}

TEST(ice_features_check, keep_features_without_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;

	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK, features);
}

TEST(ice_features_check, keep_features_with_skb_encapsulation)
{
	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb_shinfo->gso_size = MIN_VALID_GSO_SIZE;
	skb->network_header = ICE_TXD_MACLEN_MAX;
	skb->transport_header = skb->network_header + ICE_TXD_IPLEN_MAX;

	skb->inner_transport_header = skb->inner_network_header + ICE_TXD_IPLEN_MAX;
	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK, features);
}

TEST(ice_features_check, check_ip_ip_frames_offload)
{
	/* see this comment in the kernel doc
	 *
	* IPIP/SIT Tunnel::
	*              Outer                  Inner
	*   MAC        skb_mac_header
	*   Network    skb_network_header     skb_inner_network_header
	*   Transport  skb_transport_header
	*
	* actual frame offsets from stack for IP/IP/TCPv4
        *  l2_hdr       = head+0xea
        *  l3_hdr       = head+0xf8
        *  l4_hdr       = head+0x120
        *  inner_l2_hdr = head+0x10c
        *  inner_l3_hdr = head+0x10c
        *  inner_l4_hdr = head+0x120
	*/

	features = NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK;
	skb->ip_summed = CHECKSUM_PARTIAL;
	skb->encapsulation = 1;
	skb_shinfo->gso_size = 1428;
	skb_shinfo->gso_type = SKB_GSO_IPXIP4;
	skb->network_header = 14;
	/* two normal IP headers, transport points to inner,
	 * and no inner_tranport */
	skb->inner_mac_header = skb->network_header + 20;
	skb->inner_network_header = skb->network_header + 20;
	skb->transport_header = skb->network_header + 20 + 20;

	skb->inner_transport_header = skb->transport_header;

	features = ice_features_check(skb, &netdev, features);
	CHECK_EQUAL(NETIF_F_GSO_MASK | NETIF_F_CSUM_MASK, features);
}

#ifndef SWITCH_MODE
TEST_GROUP(ice_bridge)
{
	struct sk_buff *skb = &init_skb;
	struct sk_buff init_skb = {};
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_vsi *vsi;
	struct nlattr nla[2];
	struct nlattr *nlap;
	struct ice_pf *pf;
	struct ice_hw *hw;
	int status;

	void setup()
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi=vsi;
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		hw = &pf->hw;
		vsi->back = pf;
		pf->first_sw = (struct ice_sw *)calloc(1, sizeof(struct ice_sw));
		nlap = nla;
		/* nla[0].len should be 2 times NLA_HDRLEN, because it will encapsulate
		 * two nla structure
		 */
		nlap->nla_len = 2 * NLA_HDRLEN;
		nlap->nla_type = IFLA_BRIDGE_MODE;
		(nlap+1)->nla_len = NLA_HDRLEN;
		(nlap+1)->nla_type = IFLA_BRIDGE_MODE;
	}

	void teardown()
	{
		free(pf->pdev);
		free(pf->first_sw);
		free(pf);
		free(vsi);
		free_netdev(netdev);

	}
};

TEST(ice_bridge,ice_bridge_setlink_vepa)
{
	/* Initialize bridge mode to VEB */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEB;
	hw->evb_veb = true;
	/* Set VEPA mode */
	mock().expectOneCall("nlmsg_find_attr")
		.andReturnValue(nlap);
	mock().expectOneCall("nla_get_u16")
		.andReturnValue(1);
	mock().expectOneCall("ice_update_sw_rule_bridge_mode")
		.andReturnValue(ICE_SUCCESS);
	/* we are sending nlmsghdr pointer as NULL, because the function that
	 * uses nlmsghdr is being mocked
	 */
	status = ice_bridge_setlink(netdev, NULL);
	CHECK_EQUAL(status, 0);
	CHECK_EQUAL(pf->first_sw->bridge_mode, BRIDGE_MODE_VEPA);
	CHECK_EQUAL(hw->evb_veb, false);

	/* Initialize bridge mode to VEPA */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEPA;
	hw->evb_veb = false;
	/*. Set to VEPA mode. This time, ice_update_sw_rule_bridge_mode will
	 * not be invoked
	 */
	mock().expectOneCall("nlmsg_find_attr")
		.andReturnValue(nlap);
	mock().expectOneCall("nla_get_u16")
		.andReturnValue(1);
	status = ice_bridge_setlink(netdev, NULL);
	CHECK_EQUAL(status, 0);
	CHECK_EQUAL(pf->first_sw->bridge_mode, BRIDGE_MODE_VEPA);
	CHECK_EQUAL(hw->evb_veb, false);
}

TEST(ice_bridge,ice_bridge_setlink_veb)
{
	/* Initialize bridge mode to VEPA */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEPA;
	hw->evb_veb = false;
	/* Set VEPA mode */
	mock().expectOneCall("nlmsg_find_attr")
		.andReturnValue(nlap);
	mock().expectOneCall("nla_get_u16")
		.andReturnValue(0);
	mock().expectOneCall("ice_update_sw_rule_bridge_mode")
		.andReturnValue(ICE_SUCCESS);
	/* we are sending nlmsghdr pointer as NULL, because the function that
	 * uses nlmsghdr is being mocked
	 */
	status = ice_bridge_setlink(netdev, NULL);
	CHECK_EQUAL(status, 0);
	CHECK_EQUAL(pf->first_sw->bridge_mode, BRIDGE_MODE_VEB);
	CHECK_EQUAL(hw->evb_veb, true);

	/* Initialize bridge mode to VEB */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEB;
	hw->evb_veb = true;
	/*. Set to VEB mode. This time, ice_update_sw_rule_bridge_mode will
	 * not be invoked
	 */
	mock().expectOneCall("nlmsg_find_attr")
		.andReturnValue(nlap);
	mock().expectOneCall("nla_get_u16")
		.andReturnValue(0);
	status = ice_bridge_setlink(netdev, NULL);
	CHECK_EQUAL(status, 0);
	CHECK_EQUAL(pf->first_sw->bridge_mode, BRIDGE_MODE_VEB);
	CHECK_EQUAL(hw->evb_veb, true);
}

TEST(ice_bridge,ice_bridge_setlink_failure)
{
	/* Check the failure case, where ice_update_sw_rule_bridge_mode fails.
	 * Bridge mode is set to VEB, but as ice_bridge_setlink will fail, so
	 * bridge mode will not be updated.
	 */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEB;
	hw->evb_veb = true;
	mock().expectOneCall("nlmsg_find_attr")
		.andReturnValue(nlap);
	mock().expectOneCall("nla_get_u16")
		.andReturnValue(1);
	mock().expectOneCall("ice_update_sw_rule_bridge_mode")
		.andReturnValue(ICE_ERR_PARAM);
	/* we are sending nlmsghdr pointer as NULL, because the function that
	 * uses nlmsghdr is being mocked
	 */
	status = ice_bridge_setlink(netdev, NULL);
	CHECK_EQUAL(ICE_ERR_PARAM, status);
	CHECK_EQUAL(pf->first_sw->bridge_mode, BRIDGE_MODE_VEB);
	CHECK_EQUAL(hw->evb_veb, true);;
}

TEST(ice_bridge,ice_bridge_getlink)
{
	int bmode;
	/* Set bridge mode to VEB and check if ice_bridge_getlink function
	 * returns that mode
	 */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEB;
	mock().expectOneCall("ndo_dflt_bridge_getlink");
	bmode = ice_bridge_getlink(skb, 0, 0, netdev, 0);
	CHECK_EQUAL(bmode, BRIDGE_MODE_VEB);

	/* Set bridge mode to VEPA and check if ice_bridge_getlink  function
	 * returns that mode
	 */
	pf->first_sw->bridge_mode = BRIDGE_MODE_VEPA;
	mock().expectOneCall("ndo_dflt_bridge_getlink");
	bmode = ice_bridge_getlink(skb, 0, 0, netdev, 0);
	CHECK_EQUAL(bmode, BRIDGE_MODE_VEPA);

}

TEST(ice_bridge,ice_vsi_update_bridge_mode_veb)
{
	/* Check update VSI for VEB mode from VEPA mode */
	vsi->info.sw_flags = 0;
	vsi->info.sw_flags &= ~ICE_AQ_VSI_SW_FLAG_ALLOW_LB;
	u16 bmode = BRIDGE_MODE_VEB;
	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(ICE_SUCCESS);
	status = ice_vsi_update_bridge_mode(vsi, bmode);
	CHECK_EQUAL(0, status);
	CHECK_EQUAL(vsi->info.sw_flags, ICE_AQ_VSI_SW_FLAG_ALLOW_LB |
					ICE_AQ_VSI_SW_FLAG_LOCAL_LB);
}

TEST(ice_bridge,ice_vsi_update_bridge_mode_vepa)
{
	/* Check update VSI for VEPA mode from VEB mode */
	vsi->info.sw_flags = 0;
	vsi->info.sw_flags |= ICE_AQ_VSI_SW_FLAG_ALLOW_LB;
	u16 bmode = BRIDGE_MODE_VEPA;
	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(ICE_SUCCESS);
	status = ice_vsi_update_bridge_mode(vsi, bmode);
	CHECK_EQUAL(0, status);
	CHECK_EQUAL(vsi->info.sw_flags, 0);
}

TEST(ice_bridge,ice_vsi_update_bridge_mode_failure)
{
	/* Check update failure */
	vsi->info.sw_flags = 0;
	vsi->info.sw_flags |= ICE_AQ_VSI_SW_FLAG_ALLOW_LB;
	u16 bmode = BRIDGE_MODE_VEPA;
	mock().expectOneCall("ice_update_vsi")
		.andReturnValue(ICE_ERR_PARAM);
	status = ice_vsi_update_bridge_mode(vsi, bmode);
	CHECK_EQUAL(ICE_ERR_PARAM, status);
	CHECK_EQUAL(vsi->info.sw_flags, ICE_AQ_VSI_SW_FLAG_ALLOW_LB);
}

#endif /* SWITCH_MODE */
TEST_GROUP(ice_mdd)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct netdev_queue *q;
	struct test_hw *tdd_hw;
	struct ice_ring *ring;
	struct pci_dev *pdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct ice_vf *vf;
	struct ice_hw *hw;
	int status;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		tdd_hw = (struct test_hw *)calloc(1, sizeof(*tdd_hw));
		pf->pdev = pdev;
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = pf;
		vsi->tx_rings = (struct ice_ring **)calloc(1, sizeof(struct ice_ring *));
		vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		hw = &pf->hw;
		hw->hw_addr = (u8 *)tdd_hw;

		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		q = (struct netdev_queue *) calloc(1, sizeof(struct netdev_queue));

		pf->num_alloc_vsi = 1;
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
		hash_init(pf->vfs.table);
		mutex_init(&pf->vfs.table_lock);
		vf = (struct ice_vf *)calloc(1, sizeof(struct ice_vf));
		vf->pf = pf;
		vf->vf_id = 0;
		hash_add(pf->vfs.table, &vf->entry, 0);
	}

	void teardown()
	{
		free(vsi->tx_rings[0]);
		free(vsi->tx_rings);
		free(vsi);
		free_netdev(netdev);
		free(q);
		hash_del(&vf->entry);
		mutex_destroy(&pf->vfs.table_lock);
		free(vf);
		free(pdev);
		free(pf);
		free(tdd_hw);
	}
};

TEST(ice_mdd, mdd_subtask_no_event)
{
	u32 reg;

	/* GL_MDET_TX_TCLAN register
	 * 1|001 01|11 0|000 0000 0|000 0000 0000 1000
	 * Valid  = 1
	 * Mal ev type = 00101 (5)
	 * PF Num = 110 (6)
	 * VF Num = 0 (8 bits)
	 * Q Num = 8
	 */
#ifndef E830_SUPPORT
	wr32(hw, GL_MDET_TX_TCLAN, 0x97000008);
#else
	wr32(hw, GL_MDET_TX_TCLAN_BY_MAC(hw), 0x97000008);
#endif /* E830_SUPPORT */

	set_bit(ICE_MDD_EVENT_PENDING, pf->state);

	mock().expectOneCall("ice_print_vfs_mdd_events");

	/* Since ICE_MDD_EVENT_PENDING is set the MDD handler
	 * check all the related registers for find details of the
	 * event occurred.
	 */
	ice_handle_mdd_event(pf);

	/* Pending MDD event flag is cleared as soon as the event is handled */
	CHECK_EQUAL(false, test_bit(ICE_MDD_EVENT_PENDING, pf->state));

	/* After the event type and details are determined, the
	 * register is cleared by writing all 1's in the register.
	 */
#ifndef E830_SUPPORT
	reg = rd32(hw, GL_MDET_TX_TCLAN);
#else
	reg = rd32(hw, GL_MDET_TX_TCLAN_BY_MAC(hw));
#endif /* E830_SUPPORT */
	CHECK_EQUAL(0xFFFFFFFF, reg);

	/* Since events related to other registers did not occur.
	 * They are not cleared.
	 * Note: They are not set in beginning so they are initialized to 0.
	 */
	reg = rd32(hw, GL_MDET_RX);
	CHECK_EQUAL(0, reg);
};

TEST(ice_mdd, mdd_vf_tx_event)
{
	struct ice_vf vf = {};
	u32 reg;

	hash_add(pf->vfs.table, &vf.entry, 0);

	/* set VF 0 TX MDD event */
	wr32(hw, VP_MDET_TX_TDPU(0), VP_MDET_TX_TDPU_VALID_M);

	set_bit(ICE_MDD_EVENT_PENDING, pf->state);
	mock().expectOneCall("ice_print_vfs_mdd_events");

	/* Since ICE_MDD_EVENT_PENDING is set the MDD handler
	 * check all the related registers for find details of the
	 * event occurred.
	 */
	ice_handle_mdd_event(pf);

	/* Pending MDD event flag is cleared as soon as the event is handled */
	CHECK_EQUAL(false, test_bit(ICE_MDD_EVENT_PENDING, pf->state));
	CHECK_EQUAL(1,  vf.mdd_tx_events.count);

	/* After the event type and details are determined, the
	 * register is cleared by writing all 1's in the register.
	 */
	reg = rd32(hw, VP_MDET_TX_TDPU(0));
	CHECK_EQUAL(0xFFFF, reg);
};

TEST(ice_mdd, mdd_vf_rx_event)
{
	struct ice_vf vf = {};
	u32 reg;

	hash_add(pf->vfs.table, &vf.entry, 0);

	/* set VF 0 RX MDD event */
	wr32(hw, VP_MDET_RX(0), VP_MDET_RX_VALID_M);

	set_bit(ICE_MDD_EVENT_PENDING, pf->state);
	mock().expectOneCall("ice_print_vfs_mdd_events");

	/* Since ICE_MDD_EVENT_PENDING is set the MDD handler
	 * check all the related registers for find details of the
	 * event occurred.
	 */
	ice_handle_mdd_event(pf);

	/* Pending MDD event flag is cleared as soon as the event is handled */
	CHECK_EQUAL(false, test_bit(ICE_MDD_EVENT_PENDING, pf->state));
	CHECK_EQUAL(1,  vf.mdd_rx_events.count);

	/* After the event type and details are determined, the
	 * register is cleared by writing all 1's in the register.
	 */
	reg = rd32(hw, VP_MDET_RX(0));
	CHECK_EQUAL(0xFFFF, reg);
};

TEST_GROUP(ice_udp_tunnel)
{
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	struct device *dev;
	struct net_device *netdev;
	struct udp_tunnel_info ti;
	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		vsi->port_info = (struct ice_port_info *)calloc(1, sizeof(ice_port_info));
		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);

		vsi->netdev = netdev;
		pf = vsi->back;
		dev = &pf->pdev->dev;
		pf->num_alloc_vsi = 1;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
		vsi->port_info->lport = 0;
		INIT_LIST_HEAD(&pf->tnl_list);

		spin_lock_init(&pf->tnl_lock);
	}

	void teardown()
	{
		ice_tnl_entry *entry, *tmp;
		LIST_FOR_EACH_ENTRY_SAFE(entry, tmp, &pf->tnl_list, ice_tnl_entry, node) {
			LIST_DEL(&entry->node);
			devm_kfree(ice_pf_to_dev(pf), entry);
		}
		free(vsi->port_info);
		free(vsi->back->pdev);
		free(vsi->back);
		free(vsi);
		free_netdev(netdev);
		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_udp_tunnel, udp_tunnel_add)
{
	struct ice_netdev_priv *np;
	np = netdev_priv(netdev);
	np->vsi = vsi;

	vsi->type = ICE_VSI_PF;
	ti.type = UDP_TUNNEL_TYPE_VXLAN;
	ti.port = htons(5000);

	/* When tunnel type is valid, following
	 * calls should happen.
	 */
#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_dcf_is_udp_tunnel_capable")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif
	mock().expectOneCall("ice_is_create_tunnel_possible")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("ice_create_tunnel")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().ignoreOtherCalls();

	ice_udp_tunnel_add(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();

	/* When the tunnel port already exists
	 * no other call happens.
	 */
#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_dcf_is_udp_tunnel_capable")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif
	mock().expectOneCall("ice_is_create_tunnel_possible")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_ALREADY_EXISTS);
	mock().ignoreOtherCalls();

	ice_udp_tunnel_add(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();

	/* When ice_is_create_tunnel_possible returns
	 * ICE_ERR_OUT_OF_RANGE no other call happens.
	 */
#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_dcf_is_udp_tunnel_capable")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif
	mock().expectOneCall("ice_is_create_tunnel_possible")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_OUT_OF_RANGE);
	mock().ignoreOtherCalls();

	ice_udp_tunnel_add(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();

	/* When type is invalid no calls will occur
	 */
#ifdef DCF_SUPPORT
	mock().expectOneCall("ice_dcf_is_udp_tunnel_capable")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif
	ti.type = 100;  /* Invalid Tunnel type */
	ti.port = htons(5000);
	ice_udp_tunnel_add(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();
}

TEST(ice_udp_tunnel, udp_tunnel_del)
{
	struct ice_tnl_entry *tnl_entry;
	struct ice_netdev_priv *np;
	np = netdev_priv(netdev);
	np->vsi = vsi;

	tnl_entry = (struct ice_tnl_entry*)calloc(1, sizeof(struct ice_tnl_entry));

	tnl_entry->port = 7000;
	tnl_entry->type = TNL_VXLAN;
	tnl_entry->state = ICE_TNL_STATE_ACTIVE;
	tnl_entry->ref_cnt = 2;
	LIST_ADD(&tnl_entry->node, &vsi->back->tnl_list);

	vsi->type = ICE_VSI_PF;
	ti.type = UDP_TUNNEL_TYPE_VXLAN;
	ti.port = htons(7000);

	/* When tunnel port has a reference count > 1 there
	 * won't be call will to ice_destroy_tunnel
	 */
	mock().ignoreOtherCalls();

	ice_udp_tunnel_del(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();

	/* When tunnel type & port number is valid with
	 * one reference, following calls should happen.
	 */
	mock().expectOneCall("ice_destroy_tunnel")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().ignoreOtherCalls();

	ice_udp_tunnel_del(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();

	/* When tunnel port is not in use, there
	 * won't be call will to ice_destroy_tunnel
	 */
	mock().ignoreOtherCalls();

	ice_udp_tunnel_del(netdev, &ti);
	ice_handle_tunnel(vsi->back);
	mock().checkExpectations();
	mock().clear();
}

TEST_GROUP(ice_tx_timeout_recovery)
{
	struct workqueue_struct *wq;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct netdev_queue *q;
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	int status;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		vsi->tx_rings = (struct ice_ring **)calloc(1, sizeof(struct ice_ring *));
		vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		q = (struct netdev_queue *) calloc(1, sizeof(struct netdev_queue));

		wq = (struct workqueue_struct *)calloc(1, sizeof(*wq));
		ice_wq = wq;

		pf = vsi->back;
		pf->num_alloc_vsi = 1;
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
	}

	void teardown()
	{
		ice_wq = NULL;

		free(vsi->back->pdev);
		free(vsi->back);
		free(vsi->tx_rings[0]);
		free(vsi->tx_rings);
		free(vsi);
		free_netdev(netdev);
		free(wq);
		free(q);
	}
};

#ifndef SWITCH_MODE
TEST(ice_tx_timeout_recovery, tx_timeout_pfr)
{
	q->trans_start = 0;
	netdev->_tx = q;  /* netdev_get_tx_queue returns this */
	netdev->num_tx_queues = 1;
	netdev->watchdog_timeo = 5 * HZ;
	vsi->num_txq = 1;
	vsi->tx_rings[0]->q_index = 0;
	pf->tx_timeout_count = 0;

#ifndef HAVE_TX_TIMEOUT_TXQUEUE
	/* netdev_get_tx_queue returns queue defined above.
	* netif_xmit_stopped returns true always
	* Defined in tdd_tests/include/linux/netdevice.h
	*/

	mock().expectOneCall("netif_xmit_stopped");
#endif /* HAVE_TX_TIMEOUT_TXQUEUE */

	mock().expectOneCall("queue_work")
		.withParameter("wq", wq)
		.withParameter("work", &pf->serv_task);

	ice_tx_timeout(netdev);
	CHECK_EQUAL(1, pf->tx_timeout_count);
	CHECK_EQUAL(true, test_bit(ICE_PFR_REQ, pf->state));
}
#endif /* !SWITCH_MODE */

#ifdef XDP_SUPPORT
#define RX_BUF_LEN 2048
#define RX_BUF_3072 3072
TEST_GROUP(ice_xdp)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_vsi *vsi;
	struct bpf_prog_aux *aux;
	struct bpf_prog *prog;
	struct ice_ring *rx_ring;
	struct ice_ring **rx_rings;
	struct ice_pf *pf;
	struct device *dev;
	int i;

	void setup(void)
	{
		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		netdev->mtu = 2000;
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		np->vsi = vsi;
		vsi->netdev = netdev;
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->pdev = (struct pci_dev*) calloc(1, sizeof(struct pci_dev));
#ifdef SWITCH_MODE
		pf->max_pf_txqs = ICE_MAX_TXQS;
		pf->max_pf_rxqs = ICE_MAX_RXQS;
#else
		pf->max_pf_txqs = 64;
		pf->max_pf_rxqs = 64;
#endif
		pf->avail_txqs = bitmap_zalloc(pf->max_pf_txqs, GFP_KERNEL);
		pf->avail_rxqs = bitmap_zalloc(pf->max_pf_rxqs, GFP_KERNEL);
		vsi->back = pf;
		mutex_init(&vsi->back->avail_q_mutex);
		aux = (struct bpf_prog_aux*)calloc(1, sizeof(struct bpf_prog_aux));
		prog = (struct bpf_prog*)calloc(1, sizeof(struct bpf_prog));
		prog->aux = aux;
		vsi->rx_buf_len = RX_BUF_LEN;
		vsi->num_rxq = 8;
		vsi->alloc_rxq = 8;
		vsi->alloc_txq = 4;
		vsi->num_xdp_txq = vsi->alloc_rxq;
		vsi->txq_map = (u16*) calloc((vsi->alloc_txq + vsi->num_xdp_txq), sizeof(u16));
		rx_rings = (struct ice_ring**)calloc(vsi->num_rxq, sizeof(struct ice_ring*));
		vsi->rx_rings = rx_rings;
		for(i = 0; i < vsi->num_rxq; i++)
			rx_rings[i] = (struct ice_ring*)calloc(1, sizeof(struct ice_ring));
		dev = &vsi->back->pdev->dev;
		vsi->q_vectors = (struct ice_q_vector **)
				calloc(10, sizeof(*vsi->q_vectors));

	}

	void teardown(void)
	{
		mock().checkExpectations();
		for(i = 0; i < vsi->num_rxq; i++)
			free(rx_rings[i]);
		free(rx_ring);
		free(rx_rings);
		free(aux);
		free(prog);
		mutex_destroy(&vsi->back->avail_q_mutex);
		free(pf->pdev);
		bitmap_free(pf->avail_txqs);
		bitmap_free(pf->avail_rxqs);
		free(pf);
		free(vsi->q_vectors);
		free(vsi->txq_map);
		free(vsi);
		free_netdev(netdev);
	}
};

TEST(ice_xdp, xdp_query_no_prog)
{
	int xdp_res;
	netdev_bpf xdp;

	xdp.command = XDP_QUERY_PROG;
	xdp_res = ice_xdp(netdev, &xdp);
	CHECK_EQUAL(0, xdp_res);
	CHECK_EQUAL(0, xdp.prog_attached);
}

TEST(ice_xdp, xdp_query_prog_id)
{
	int xdp_res;
	unsigned int prog_id;
	netdev_bpf xdp;

	prog_id = 0x55AA55AA;
	vsi->xdp_prog = prog;
	vsi->xdp_prog->aux->id = prog_id;
	xdp.command = XDP_QUERY_PROG;

	xdp_res = ice_xdp(netdev, &xdp);

	CHECK_EQUAL(0, xdp_res);
	CHECK_EQUAL(1, xdp.prog_attached);
	CHECK_EQUAL(prog_id, xdp.prog_id);

}

TEST(ice_xdp, xdp_non_pf_vsi)
{
	int xdp_res;
	netdev_bpf xdp;

	vsi->type = ICE_VSI_VF;
	xdp_res = ice_xdp(netdev, &xdp);
	CHECK_EQUAL(-EINVAL, xdp_res);
}

TEST(ice_xdp, xdp_setup_prog_mtu_ok)
{
	int xdp_setup_res;
	mock().expectOneCall("netif_running").andReturnValue(false);
	xdp_setup_res = ice_xdp_setup_prog(vsi, NULL, NULL);
	CHECK_EQUAL(0, xdp_setup_res);
}

TEST(ice_xdp, xdp_setup_prog_max_mtu_max_buffer)
{
	int xdp_setup_res;
	mock().expectOneCall("netif_running").andReturnValue(false);
	netdev->mtu = 3046;
	vsi->rx_buf_len = RX_BUF_3072;
	xdp_setup_res = ice_xdp_setup_prog(vsi, NULL, NULL);
	CHECK_EQUAL(0, xdp_setup_res);
}

TEST(ice_xdp, xdp_setup_prog_mtu_too_large)
{
	int xdp_setup_res;

	mock().expectOneCall("netif_running").andReturnValue(false);
	netdev->mtu = 2040;
	xdp_setup_res = ice_xdp_setup_prog(vsi, NULL, NULL);
	CHECK_EQUAL(-EOPNOTSUPP, xdp_setup_res);

}

TEST(ice_xdp, xdp_setup_prog)
{
	int xdp_setup_res, i;

	USE_STD_MOCK(ice_up);
	USE_STD_MOCK(ice_down);
	USE_STD_MOCK(ice_set_ring_xdp);
	USE_STD_MOCK(ice_xsk_pool);

	mock().expectOneCall("__ice_vsi_get_qs");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_setup_tx_ring");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_set_ring_xdp");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_xsk_pool");
	mock().expectOneCall("netif_running").andReturnValue(false);
	mock().ignoreOtherCalls();

	xdp_setup_res = ice_xdp_setup_prog(vsi, prog, NULL);
	CHECK_EQUAL(0, xdp_setup_res);
	CHECK_EQUAL(prog, vsi->xdp_prog);
	for(i = 0; i < vsi->num_rxq; i++)
		CHECK_EQUAL(vsi->rx_rings[i]->xdp_prog, prog);
	ice_destroy_xdp_rings(vsi);
}

TEST(ice_xdp, xdp_setup_prog_running)
{
	int xdp_setup_res, i;

	USE_STD_MOCK(ice_up);
	USE_STD_MOCK(ice_down);
	USE_STD_MOCK(ice_set_ring_xdp);
	USE_STD_MOCK(ice_is_xdp_ena_vsi);
	USE_STD_MOCK(ice_xsk_pool);

	mock().expectOneCall("ice_is_xdp_ena_vsi");
	mock().expectOneCall("__ice_vsi_get_qs");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_xsk_pool");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_setup_tx_ring");
	mock().expectNCalls(vsi->num_xdp_txq, "ice_set_ring_xdp");
	mock().expectOneCall("netif_running").andReturnValue(true);
	mock().ignoreOtherCalls();

	xdp_setup_res = ice_xdp_setup_prog(vsi, prog, NULL);
	CHECK_EQUAL(0, xdp_setup_res);
	CHECK_EQUAL(prog, vsi->xdp_prog);
	for(i = 0; i < vsi->num_rxq; i++)
		CHECK_EQUAL(vsi->rx_rings[i]->xdp_prog, prog);
	ice_destroy_xdp_rings(vsi);
}

TEST(ice_xdp, xdp_setup_prog_again)
{
	int xdp_setup_res, i;
	struct bpf_prog prog2;

	USE_STD_MOCK(ice_up);
	USE_STD_MOCK(ice_down);
	USE_STD_MOCK(ice_set_ring_xdp);

	/* Simulate previous prog attachment */
	vsi->xdp_prog = prog;

	mock().expectOneCall("netif_running").andReturnValue(false);
	/* expect to free the old program */
	mock().expectOneCall("bpf_prog_put")
		.withParameter("prog", prog);

	/* call tested function with different program */
	xdp_setup_res = ice_xdp_setup_prog(vsi, &prog2, NULL);

	CHECK_EQUAL(0, xdp_setup_res);
	CHECK_EQUAL(&prog2, vsi->xdp_prog);
	for(i = 0; i < vsi->num_rxq; i++)
		CHECK_EQUAL(vsi->rx_rings[i]->xdp_prog, &prog2);
}

TEST(ice_xdp, prepare_xdp_rings_alloc_failed)
{
	int ret;

	USE_MOCK(devm_kcalloc, devm_kcalloc_detour_fail);

	mock().expectOneCall("devm_kcalloc_detour_fail")
		.andReturnValue((void *)NULL)
		.ignoreOtherParameters();

	mock().ignoreOtherCalls();

	ret = ice_prepare_xdp_rings(vsi, NULL);
	CHECK_EQUAL(-ENOMEM, ret);
}

TEST(ice_xdp, prepare_xdp_rings_get_qs_failed)
{
	int ret;

	mock().expectOneCall("__ice_vsi_get_qs")
		.ignoreOtherParameters()
		.andReturnValue(-ENOMEM);

	ret = ice_prepare_xdp_rings(vsi, NULL);
	CHECK_EQUAL(-ENOMEM, ret);
}

TEST(ice_xdp, prepare_xdp_rings_setup_rings_failed)
{
	int ret;

	USE_STD_MOCK(ice_xdp_alloc_setup_rings);

	mock().expectOneCall("__ice_vsi_get_qs")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_xdp_alloc_setup_rings")
		.ignoreOtherParameters()
		.andReturnValue(-ENOMEM);

	ret = ice_prepare_xdp_rings(vsi, NULL);
	CHECK_EQUAL(-ENOMEM, ret);
}

TEST(ice_xdp, prepare_xdp_rings_ok)
{
	int ret;

	USE_STD_MOCK(ice_xdp_alloc_setup_rings);

	mock().expectOneCall("__ice_vsi_get_qs")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_xdp_alloc_setup_rings")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("ice_is_reset_in_progress")
		.andReturnValue(false);

	mock().expectOneCall("ice_cfg_vsi_lan")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_prepare_xdp_rings(vsi, prog);
	CHECK_EQUAL(0, ret);
	devm_kfree(&pf->pdev->dev, vsi->xdp_rings);
}

TEST(ice_xdp, alloc_setup_rings_ok)
{
	int ret, i;
	vsi->xdp_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
	vsi->num_tx_desc = 10;

	USE_STD_MOCK(ice_set_ring_xdp);
	USE_STD_MOCK(ice_xsk_pool);

#ifdef XDP_SUPPORT
	mock().expectNCalls(vsi->num_xdp_txq, "ice_xsk_pool")
		.ignoreOtherParameters();

#endif /* XDP_SUPPORT */
	mock().expectNCalls(vsi->num_xdp_txq, "ice_set_ring_xdp")
		.ignoreOtherParameters();

	mock().expectNCalls(vsi->num_xdp_txq, "ice_setup_tx_ring")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ret = ice_xdp_alloc_setup_rings(vsi);
	CHECK_EQUAL(0, ret);
	for (i = 0; i < vsi->num_xdp_txq; i++) {
		CHECK_EQUAL(vsi->num_tx_desc, vsi->xdp_rings[i]->count);
		free(vsi->xdp_rings[i]);
	}
	free(vsi->xdp_rings);
}
#endif /* XDP_SUPPORT */

TEST_GROUP(ice_wake_on_lan)
{
	struct ice_port_info *port_info;
	struct device *dev;
	struct ice_pf *pf;
	struct ice_hw *hw;

	void setup(void)
	{
		pf = (struct ice_pf*) calloc(1, sizeof(*pf));
		pf->pdev = (struct pci_dev*) calloc(1, sizeof(struct pci_dev));
		port_info = (struct ice_port_info *)calloc(1, sizeof(ice_port_info));
		pf->hw.hw_addr = (unsigned char *) calloc(1, sizeof(unsigned char) * 0x1000000);
		pf->hw.port_info = port_info;
		pf->vsi = (struct ice_vsi **)calloc(1, sizeof(ice_vsi *));
		pf->num_alloc_vsi = 1;
		pf->wol_ena = 1;
		pf->vsi[0] = (struct ice_vsi *)calloc(1, sizeof(ice_vsi));
		pf->vsi[0]->port_info = port_info;
		pf->vsi[0]->netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);

		pf->pdev->dev.driver_data = pf;
		dev = &pf->pdev->dev;
		hw = &pf->hw;
		hw->back = pf;
	}

	void teardown(void)
	{
		free_netdev(pf->vsi[0]->netdev);
		free(pf->vsi[0]);
		free(pf->vsi);
		free(port_info);
		free(pf->hw.hw_addr);
		free(pf->pdev);
		free(pf);

		mock().checkExpectations();
		mock().clear();
	}
};

TEST(ice_wake_on_lan, is_wol_supported)
{
	bool wol_ena;
	u16 data = 0;

	/* first test enabled port 0 - aka 0x0000
	 * 					^
	 */
	mock().expectOneCall("ice_read_sr_word")
		.withOutputParameterReturning("data", &data, sizeof(data))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	wol_ena = ice_is_wol_supported(hw);
	CHECK_TRUE(wol_ena);

	/* now test disabled port 2  - aka 0x0004
	 * 					^
	 */
	data = 0x0004;
#ifdef SWITCH_MODE
	hw->pf_id = 2;
#else
	port_info->lport = 2;
#endif

	mock().expectOneCall("ice_read_sr_word")
		.withOutputParameterReturning("data", &data, sizeof(data))
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	wol_ena = ice_is_wol_supported(hw);
	CHECK_FALSE(wol_ena);

	/* check the failure case that we do the right thing, errors
	 * mean no WoL
	 */
	data = 0;
	mock().expectOneCall("ice_read_sr_word")
		.withOutputParameterReturning("data", &data, sizeof(data))
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);

	wol_ena = ice_is_wol_supported(hw);
	CHECK_FALSE(wol_ena);
}

TEST(ice_wake_on_lan, set_up_mc_magic_wake)
{
	static const u8 mac[6] = { 0x01, 0x00, 0xCC, 0xCC, 0xDD, 0xDD };
	struct ice_vsi *vsi = pf->vsi[0];

	vsi->type = ICE_VSI_PF;
	ether_addr_copy(vsi->netdev->dev_addr, mac);
	mock().expectOneCall("ice_aq_manage_mac_write")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	ice_setup_mc_magic_wake(pf);
}

class PhyCapsDataCopier : public MockNamedValueCopier
{
	public:
		virtual void copy(void *out, const void *in)
		{
			*(struct ice_aqc_get_phy_caps_data *)out =
				*(const struct ice_aqc_get_phy_caps_data *)in;
		}
};

class PhyCfgDataCopier : public MockNamedValueCopier
{
	public:
		virtual void copy(void *out, const void *in)
		{
			*(struct ice_aqc_set_phy_cfg_data *)out =
				*(const struct ice_aqc_set_phy_cfg_data *)in;
		}
};

class PhyCfgDataComparator : public MockNamedValueComparator
{
	public:
		virtual bool isEqual(const void *obj1, const void *obj2)
		{
			struct ice_aqc_set_phy_cfg_data *d1 =
				(struct ice_aqc_set_phy_cfg_data *)obj1;
			struct ice_aqc_set_phy_cfg_data *d2 =
				(struct ice_aqc_set_phy_cfg_data *)obj2;

			bool result = true;

			if (d1->phy_type_low != d2->phy_type_low) {
				printf("expected phy_type_low = 0x%08llx\n"
				       "actual phy_type_low   = 0x%08llx\n",
				       d1->phy_type_low, d2->phy_type_low);
				result = false;
			}
			if (d1->phy_type_high != d2->phy_type_high) {
				printf("expected phy_type_high = 0x%08llx\n"
				       "actual phy_type_high   = 0x%08llx\n",
				       d1->phy_type_high, d2->phy_type_high);
				result = false;
			}
			if (d1->caps != d2->caps) {
				printf("expected caps = 0x%02x\n"
				       "actual caps   = 0x%02x\n",
				       d1->caps, d2->caps);
				result = false;
			}
			if (d1->low_power_ctrl_an != d2->low_power_ctrl_an) {
				printf("expected low_power_ctrl_an = 0x%02x\n"
				       "actual low_power_ctrl_an   = 0x%02x\n",
				       d1->low_power_ctrl_an,
				       d2->low_power_ctrl_an);
				result = false;
			}
			if (d1->eee_cap != d2->eee_cap) {
				printf("expected eee_cap = 0x%04x\n"
				       "actual eee_cap   = 0x%04x\n",
				       d1->eee_cap, d2->eee_cap);
				result = false;
			}
			if (d1->eeer_value != d2->eeer_value) {
				printf("expected eeer_value = 0x%04x\n"
				       "actual eeer_value   = 0x%04x\n",
				       d1->eeer_value, d2->eeer_value);
				result = false;
			}
			if (d1->link_fec_opt != d2->link_fec_opt) {
				printf("expected link_fec_opt = 0x%02x\n"
				       "actual link_fec_opt   = 0x%02x\n",
				       d1->link_fec_opt, d2->link_fec_opt);
				result = false;
			}
			if (!result)
				printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n"
				       "Error, actual/expected ice_aqc_set_phy_cfg_data"
				       " does not match!\n");

			return result;
		}

		virtual SimpleString valueToString(const void *obj)
		{
			return StringFrom(obj);
		}
};

#ifndef SWITCH_MODE
TEST_GROUP(ice_force_phys_link_state)
{
	struct ice_vsi *vsi;
	PhyCapsDataCopier phyCapsDataCopier;
	PhyCfgDataCopier phyCfgDataCopier;
	PhyCfgDataComparator phyCfgDataComparator;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->port_info = (struct ice_port_info *)
					calloc(1, sizeof(struct ice_port_info));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back->pdev = (struct pci_dev *)
					calloc(1, sizeof(struct pci_dev));
		mock().installCopier("struct ice_aqc_get_phy_caps_data *",
				     phyCapsDataCopier);
		mock().installCopier("struct ice_aqc_set_phy_cfg_data *",
				     phyCfgDataCopier);
		mock().installComparator("struct ice_aqc_set_phy_cfg_data *",
					 phyCfgDataComparator);

		vsi->port_info->phy.curr_user_speed_req = ICE_AQ_LINK_SPEED_M;
	}

	void teardown()
	{
		free(vsi->port_info);
		free(vsi->back->pdev);
		free(vsi->back);
		free(vsi);
		mock().removeAllComparatorsAndCopiers();
	}
};

TEST(ice_force_phys_link_state, null_vsi)
{
	struct ice_vsi *null_vsi = NULL;
	int result;

	result = ice_force_phys_link_state(null_vsi, false);
	CHECK_EQUAL(-EINVAL, result);
}

TEST(ice_force_phys_link_state, null_port_info)
{
	struct ice_port_info *tmp_port_info;
	int result;

	tmp_port_info = vsi->port_info;
	vsi->port_info = NULL;

	result = ice_force_phys_link_state(vsi, false);
	CHECK_EQUAL(-EINVAL, result);

	vsi->port_info = tmp_port_info;
}

TEST(ice_force_phys_link_state, vsi_is_not_pfvsi)
{
	int result;

	vsi->type = ICE_VSI_VF;

	result = ice_force_phys_link_state(vsi, true);
	CHECK_EQUAL(0, result);
}

TEST(ice_force_phys_link_state, ice_aq_get_phy_caps_failed)
{
	int result;

	vsi->type = ICE_VSI_PF;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.ignoreOtherParameters()
		.andReturnValue(-EIO);

	result = ice_force_phys_link_state(vsi, true);
	CHECK_EQUAL(-EIO, result);
}

TEST(ice_force_phys_link_state, no_link_change)
{
	struct ice_aqc_get_phy_caps_data pcaps_output = { };
	int link_up = true;
	int result;


	pcaps_output.caps |= ICE_AQC_PHY_EN_LINK;
	vsi->port_info->phy.link_info.link_info |= ICE_AQ_LINK_UP;

	vsi->type = ICE_VSI_PF;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	result = ice_force_phys_link_state(vsi, link_up);
	CHECK_EQUAL(0, result);
}

TEST(ice_force_phys_link_state, link_up_equals_pcaps_caps_both_down)
{
	struct ice_aqc_get_phy_caps_data pcaps_output = { };
	int link_up = false;
	int result;

	vsi->type = ICE_VSI_PF;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.withOutputParameterOfTypeReturning("struct ice_aqc_get_phy_caps_data *",
						    "pcaps", &pcaps_output)
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	result = ice_force_phys_link_state(vsi, link_up);
	CHECK_EQUAL(0, result);
}

TEST(ice_force_phys_link_state, ice_aq_set_phy_cfg_failed)
{
	int link_up = true;
	int result;

	vsi->type = ICE_VSI_PF;
	vsi->port_info->lport = 0;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_set_phy_cfg")
		.ignoreOtherParameters()
		.andReturnValue(-1);

	result = ice_force_phys_link_state(vsi, link_up);
	CHECK_EQUAL(-EIO, result);
}

TEST(ice_force_phys_link_state, success)
{
	int link_up = true;
	int result;

	vsi->type = ICE_VSI_PF;
	vsi->port_info->lport = 0;

	mock().expectOneCall("ice_aq_get_phy_caps")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	mock().expectOneCall("ice_aq_set_phy_cfg")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);

	result = ice_force_phys_link_state(vsi, link_up);
	CHECK_EQUAL(0, result);
}
#endif /* !SWITCH_MODE */

TEST_GROUP(ice_stats)
{
	struct ice_vsi *vsi;
	struct ice_hw *hw;
	struct ice_pf *pf;
	void setup(void)
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->hw.hw_addr = (unsigned char *) calloc(1, sizeof(unsigned char) * 0x1000000);
		vsi->num_txq = 2;
		vsi->num_rxq = 2;
		vsi->tx_rings = (struct ice_ring **)calloc(2, sizeof(struct ice_ring *));
		vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->tx_rings[1] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		vsi->rx_rings = (struct ice_ring **)calloc(2, sizeof(struct ice_ring *));
		vsi->rx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->rx_rings[1] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->back = pf;
		vsi->vsi_num = 10;
		pf->hw.port_info = (struct ice_port_info *)calloc(1,
								  sizeof(struct ice_port_info));
		hw = &pf->hw;
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();
		free(vsi->tx_rings[0]);
		free(vsi->tx_rings[1]);
		free(vsi->tx_rings);
		free(vsi->rx_rings[0]);
		free(vsi->rx_rings[1]);
		free(vsi->rx_rings);
		free(pf->hw.hw_addr);
		free(pf->hw.port_info);
		free(pf);
		free(vsi);
	}
};

TEST(ice_stats, ice_update_pf_stats)
{
	u64 prev_stat = 0, cur_stat = 0;

	memset(&pf->stats, 0, sizeof(pf->stats));
	memset(&pf->stats_prev, 0, sizeof(pf->stats_prev));
	pf->stat_prev_loaded = false;
	pf->stats_prev.link_xon_rx = 10;

	/* rx_bytes */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_GORCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_unicast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_UPRCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_multicast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_MPRCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_broadcast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_BPRCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_discards */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", PRTRPB_RDPC)
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_bytes */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_GOTCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_unicast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_UPTCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_multicast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_MPTCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_broadcast */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_BPTCL(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_dropped_link_down */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_TDOLD(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_64 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC64L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_127 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC127L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_255 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC255L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_511 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC511L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_1023 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC1023L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_1522 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC1522L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_size_big */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PRC9522L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_64 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC64L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_127 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC127L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_255 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC255L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_511 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC511L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_1023 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC1023L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_1522 */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC1522L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* tx_size_big */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_PTC9522L(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

#ifdef FDIR_SUPPORT
	/* fd_sb_match */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLSTAT_FD_CNT0L(ICE_FD_SB_STAT_IDX(0)))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

#ifdef ADQ_SUPPORT
#ifdef ADQ_PERF_COUNTERS
	/* chnl_fd_match */
	mock().expectOneCall("ice_stat_update40")
		.withParameter("hw", hw)
		.withParameter("reg", GLSTAT_FD_CNT0L(ICE_FD_CH_STAT_IDX(0)))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));
#endif /* ADQ_PERF_COUNTERS */
#endif /* ADQ_SUPPORT */
#endif /* FDIR_SUPPORT */

	/* link_xon_rx */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_LXONRXC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* link_xoff_rx */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_LXOFFRXC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* link_xon_tx */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_LXONTXC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* link_xoff_tx */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_LXOFFTXC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

#ifndef NO_DCB_SUPPORT
	mock().expectOneCall("ice_update_dcb_stats");
#endif
	/* crc_errors */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_CRCERRS(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* illegal_bytes */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_ILLERRC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* mac_local_faults */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_MLFC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* mac_remote_faults */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_MRFC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_len_errors */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_RLEC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_undersize */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_RUC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_fragments */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_RFC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_oversize */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_ROC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* rx_jabber */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_RJC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

#ifdef INTERNAL_ONLY
	/* error_bytes */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_ERRBC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));

	/* mac_short_pkt_dropped */
	mock().expectOneCall("ice_stat_update32")
		.withParameter("hw", hw)
		.withParameter("reg", GLPRT_MSPDC(0))
		.withParameter("prev_stat_loaded", false)
		.withOutputParameterReturning("prev_stat", &prev_stat, sizeof(prev_stat))
		.withOutputParameterReturning("cur_stat", &cur_stat, sizeof(cur_stat));
#endif

	ice_update_pf_stats(pf);

	CHECK_EQUAL(pf->stats_prev.link_xon_rx, 0);
	CHECK_EQUAL(pf->stats.link_xon_rx, 0);

	mock().checkExpectations();
}

TEST(ice_stats, ice_update_vsi_stats)
{
	/* Test to calculate VSI stats including ring stats */
	clear_bit(ICE_CFG_BUSY, pf->state);
	memset(&vsi->eth_stats, 0, sizeof(vsi->eth_stats));
	memset(&vsi->eth_stats_prev, 0, sizeof(vsi->eth_stats_prev));

	vsi->tx_rings[0]->stats.pkts = 10;
	vsi->tx_rings[0]->stats.bytes = 256;
	vsi->tx_rings[0]->tx_stats.tx_busy = 5;

	vsi->tx_rings[1]->stats.pkts = 20;
	vsi->tx_rings[1]->stats.bytes = 512;

	vsi->rx_rings[0]->stats.pkts = 2;
	vsi->rx_rings[0]->stats.bytes = 32;

	vsi->rx_rings[1]->stats.pkts = 1;
	vsi->rx_rings[1]->stats.bytes = 16;
	vsi->rx_rings[1]->rx_stats.alloc_buf_failed = 10;

	mock().expectOneCall("ice_update_eth_stats");

	ice_update_vsi_stats(vsi);
	CHECK_EQUAL(vsi->net_stats.tx_packets, 30);
	CHECK_EQUAL(vsi->net_stats.tx_bytes, 768);
	CHECK_EQUAL(vsi->net_stats.rx_packets, 3);
	CHECK_EQUAL(vsi->net_stats.rx_bytes, 48);
	CHECK_EQUAL(vsi->tx_busy, 5);
	CHECK_EQUAL(vsi->rx_buf_failed, 10);

	mock().checkExpectations();

	/* Test to not calculate VSI stats when ICE_CFG_BUSY is set in PF
	 * state
	 */
	set_bit(ICE_CFG_BUSY, pf->state);
	memset(&vsi->net_stats, 0, sizeof(vsi->net_stats));

	vsi->tx_rings[0]->stats.pkts = 1;
	vsi->tx_rings[0]->stats.bytes = 16;

	vsi->rx_rings[0]->stats.pkts = 1;
	vsi->rx_rings[0]->stats.bytes = 16;

	ice_update_vsi_stats(vsi);
	CHECK_EQUAL(vsi->net_stats.tx_packets, 0);
	CHECK_EQUAL(vsi->net_stats.tx_bytes, 0);
	CHECK_EQUAL(vsi->net_stats.rx_packets, 0);
	CHECK_EQUAL(vsi->net_stats.rx_bytes, 0);
}

#ifdef DEVLINK_SUPPORT
TEST_GROUP(ice_aq_events)
{
	struct ice_hw *hw;
	struct ice_pf *pf;
	struct pci_dev *pdev;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (__typeof(pdev))calloc(1, sizeof(*pdev));
		pf->pdev = pdev;
		pf->hw.hw_addr = (unsigned char *) calloc(1, sizeof(unsigned char) * 0x1000000);
		pf->hw.port_info = (struct ice_port_info *)calloc(1,
								  sizeof(struct ice_port_info));
		hw = &pf->hw;

		INIT_HLIST_HEAD(&pf->aq_wait_list);
		spin_lock_init(&pf->aq_wait_lock);
		init_waitqueue_head(&pf->aq_wait_queue);
	}

	void tdd_insert_pending_event(u16 opcode, struct ice_rq_event_info *event)
	{
		using namespace ns_main;

		struct ice_aq_task *task;

		task = (struct ice_aq_task *)kzalloc(sizeof(*task), GFP_KERNEL);
		if (!task)
			FAIL("Failed to allocate a task, out of memory");

		INIT_HLIST_NODE(&task->entry);
		task->opcode = opcode;
		task->event = event;
		task->state = ICE_AQ_TASK_WAITING;
		hlist_add_head(&task->entry, &pf->aq_wait_list);
	}

	void teardown(void)
	{
		using namespace ns_main;
		struct ice_aq_task *task;
		struct hlist_node *n;

		/* remove all pending events */
		hlist_for_each_entry_safe(task, n, &pf->aq_wait_list, entry) {
			hlist_del(&task->entry);
			kfree(task);
		}

		mock().checkExpectations();
		mock().clear();
		free(pf->hw.hw_addr);
		free(pf->hw.port_info);
		free(pf);
		free(pdev);
	}
};

TEST(ice_aq_events, no_events_waiting)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {};

	mock().expectNoCall("wake_up");

	ice_aq_check_events(pf, ice_aqc_opc_nvm_write, &event);
}

TEST(ice_aq_events, one_nvm_write_waiting)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {}, wait_for_write = {};
	struct ice_aq_desc zero_desc = {};

	event.msg_len = 25;

	event.desc.flags = ICE_AQ_FLAG_DD;
	event.desc.opcode = cpu_to_le16(ice_aqc_opc_nvm_erase);
	event.desc.retval = cpu_to_le16(ICE_AQ_RC_EIO);

	tdd_insert_pending_event(ice_aqc_opc_nvm_write, &wait_for_write);

	mock().expectNoCall("wake_up");

	ice_aq_check_events(pf, ice_aqc_opc_nvm_erase, &event);

	CHECK_EQUAL(0, wait_for_write.msg_len);
	MEMCMP_EQUAL(&zero_desc, &wait_for_write.desc, sizeof(wait_for_write.desc));
}

TEST(ice_aq_events, one_nvm_write_completed)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {}, wait_for_write = {};

	event.msg_len = 25;

	event.desc.flags = ICE_AQ_FLAG_DD;
	event.desc.opcode = cpu_to_le16(ice_aqc_opc_nvm_write);
	event.desc.retval = cpu_to_le16(ICE_AQ_RC_EIO);

	tdd_insert_pending_event(ice_aqc_opc_nvm_write, &wait_for_write);

	mock().expectOneCall("wake_up")
		.withParameter("wq", &pf->aq_wait_queue);

	ice_aq_check_events(pf, ice_aqc_opc_nvm_write, &event);

	CHECK_EQUAL(25, wait_for_write.msg_len);
	MEMCMP_EQUAL(&event.desc, &wait_for_write.desc, sizeof(wait_for_write.desc));
}

TEST(ice_aq_events, ice_aq_wait_for_event_error)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {};
	int err;

	mock().expectOneCall("wait_event_interruptible_timeout")
		.withParameter("wq", &pf->aq_wait_queue)
		.withParameter("condition", "task->state")
		.withParameter("timeout", 5 * HZ)
		.andReturnValue(-EIO);

	err = ns_main::ice_aq_wait_for_event(pf, ice_aqc_opc_nvm_write,
					     5 * HZ, &event);
	CHECK_EQUAL(-EIO, err);
}

TEST(ice_aq_events, ice_aq_wait_for_event_timeout)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {};
	int err;

	mock().expectOneCall("wait_event_interruptible_timeout")
		.withParameter("wq", &pf->aq_wait_queue)
		.withParameter("condition", "task->state")
		.withParameter("timeout", 5 * HZ)
		.andReturnValue(0);

	err = ns_main::ice_aq_wait_for_event(pf, ice_aqc_opc_nvm_write,
					     5 * HZ, &event);
	CHECK_EQUAL(-ETIMEDOUT, err);
}

static void tdd_complete_all_aq_tasks(void *pf_ptr)
{
	using namespace ns_main;
	struct ice_pf *pf = (struct ice_pf *)pf_ptr;
	struct ice_aq_task *task;
	struct hlist_node *n;

	/* mark all tasks complete */
	hlist_for_each_entry_safe(task, n, &pf->aq_wait_list, entry)
		task->state = ICE_AQ_TASK_COMPLETE;
}

TEST(ice_aq_events, ice_aq_wait_for_event_success)
{
	using namespace ns_main;
	struct ice_rq_event_info event = {};
	int err;

	mock().expectOneCall("wait_event_interruptible_timeout")
		.withParameter("wq", &pf->aq_wait_queue)
		.withParameter("condition", "task->state")
		.withParameter("timeout", 5 * HZ)
		.andReturnValue(5 * HZ);

	tdd_set_wait_cb(tdd_complete_all_aq_tasks, (void *)pf);

	err = ns_main::ice_aq_wait_for_event(pf, ice_aqc_opc_nvm_write,
					     5 * HZ, &event);
	CHECK_EQUAL(0, err);
}
#endif /* DEVLINK_SUPPORT */

#ifdef TXPP_SUPPORT
#ifdef HAVE_TC_ETF_QOPT_OFFLOAD
TEST_GROUP(ice_offload_txtime)
{
	struct tc_etf_qopt_offload qopt_off;
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct ice_ring **tx_rings;
	struct ice_ring *tx_ring;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	static const int i = 4;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		tx_rings = (struct ice_ring **)calloc(10, sizeof(*tx_rings));
		tx_ring = (struct ice_ring *)calloc(1, sizeof(*tx_ring));
		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);

		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;

		qopt_off.queue = 3;

		vsi->back = pf;
		vsi->tx_rings = tx_rings;
		vsi->num_txq = i;
		tx_rings[i] = tx_ring;

		qopt_off.enable = 1;
	}

	void teardown(void)
	{
		free(tx_ring);
		free(tx_rings);
		free(vsi);
		free(pf);
		free_netdev(netdev);
	}
};

TEST(ice_offload_txtime, expects_success_turn_on_txtime)
{
	using namespace ns_main;
	int ret = -1;

	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(true);
	ret = ice_offload_txtime(netdev, (void *)(&qopt_off));
	CHECK_EQUAL(ret, 0);
}
#endif /* HAVE_TC_ETF_QOPT_OFFLOAD */
#endif /* TXPP_SUPPORT */

#ifdef ADQ_SUPPORT
TEST_GROUP(ice_tc)
{
	struct ice_netdev_priv *np;
	struct net_device *netdev;
	struct netdev_queue *q;
	struct ice_ring *ring;
	struct ice_vsi *vsi;
	struct ice_pf *pf;
	int status;
	struct tc_cls_flower_offload *cls_flower;
	struct flow_dissector *dissector;
	struct fl_flow_key *mkey;
	struct fl_flow_key *mask;
	struct tcf_exts *exts;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		vsi->back = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		vsi->back->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		vsi->alloc_txq = 1;
		vsi->alloc_rxq = 1;
		vsi->num_txq = 1;
		vsi->num_rxq = 1;
		vsi->tx_rings = (struct ice_ring **)calloc(vsi->alloc_txq, sizeof(struct ice_ring *));
		vsi->tx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));
		vsi->rx_rings = (struct ice_ring **)calloc(vsi->alloc_rxq, sizeof(struct ice_ring *));
		vsi->rx_rings[0] = (struct ice_ring *)calloc(1, sizeof(struct ice_ring));

		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		q = (struct netdev_queue *) calloc(1, sizeof(struct netdev_queue));

		pf = vsi->back;
		pf->num_alloc_vsi = 1;
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->type = ICE_VSI_PF;
		cls_flower = (struct tc_cls_flower_offload *)calloc(1, sizeof(struct tc_cls_flower_offload));
		dissector = (struct flow_dissector *)calloc(1, sizeof(struct flow_dissector));
		mkey = (struct fl_flow_key *)calloc(1, sizeof(struct fl_flow_key));
		mask = (struct fl_flow_key *)calloc(1, sizeof(struct fl_flow_key));
		exts = (struct tcf_exts *)calloc(1, sizeof(struct tcf_exts));
	}

	void teardown()
	{
		free(cls_flower);
		free(dissector);
		free(mkey);
		free(mask);
		free(exts);
		free(vsi->back->pdev);
		free(vsi->back);
		free(vsi->tx_rings[0]);
		free(vsi->rx_rings[0]);
		free(vsi->tx_rings);
		free(vsi->rx_rings);
		free(vsi);
		free_netdev(netdev);
		free(q);
	}
};

#if 0
TEST(ice_tc, ice_set_mac_l2_filter)
{
	struct tc_action a;
	struct tc_action_ops ops;
	int ret;
	static const u8 mac_addr[6] = { 0x10, 0x20, 0x20, 0x20, 0x20, 0x20 };

	memset(mask->eth.dst, 0xff, ETH_ALEN);
	memset(mask->eth.src, 0xff, ETH_ALEN);
	mkey->basic.n_proto = ETH_P_ALL;
	memcpy(mkey->eth.dst, mac_addr, ETH_ALEN);

	ret = fl_init_dissector(dissector, mask);
	CHECK_EQUAL(0, ret);

        cls_flower->dissector = dissector;
        cls_flower->command = TC_CLSFLOWER_REPLACE;
        cls_flower->cookie = 0xff;
        cls_flower->mask = mask;
        cls_flower->key = mkey;
        cls_flower->classid = 0;

	ret = tcf_exts_init(exts, TCA_FLOWER_ACT, 0);
	CHECK_EQUAL(0, ret);

	exts->nr_actions = 1;
	strcpy(ops.kind, "mirred");
	ops.type = TCA_ACT_MIRRED;
	a.ops = &ops;
	a.tcfa_action = TC_ACT_STOLEN;
	exts->actions[0] = &a;
        cls_flower->exts = exts;

	mock().expectOneCall("ice_add_mac")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	mock().expectOneCall("ice_remove_mac")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
	ret = ice_setup_tc_cls_flower(np, cls_flower);
	CHECK_EQUAL(ICE_SUCCESS, ret);

	ret = ice_delete_clsflower(vsi, cls_flower);
	CHECK_EQUAL(ICE_SUCCESS, ret);

	free(exts->actions);
}
#endif
#endif /* ADQ_SUPPORT */

TEST_GROUP(ice_ena_dis_queue_interrupts)
{
	struct ice_hw hw;

	void setup()
	{
		hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
	}

	void teardown()
	{
		free(hw.hw_addr);
		hw.hw_addr = NULL;
	}
};

TEST(ice_ena_dis_queue_interrupts, enable_then_disable_ctrl_queue_interrupts)
{
	u16 vector_idx = 4;
	u32 regval;

#define CAUSE_ENA_SET	1
	ice_ena_ctrlq_interrupts(&hw, vector_idx);

	regval = rd32(&hw, PFINT_OICR_CTL);
	CHECK_EQUAL(vector_idx,
		    (regval & PFINT_OICR_CTL_MSIX_INDX_M) >>
		    PFINT_OICR_CTL_MSIX_INDX_S);
	CHECK_EQUAL(CAUSE_ENA_SET,
		    (regval & PFINT_OICR_CTL_CAUSE_ENA_M) >>
		    PFINT_OICR_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_FW_CTL);
	CHECK_EQUAL(vector_idx,
		    (regval & PFINT_FW_CTL_MSIX_INDX_M) >>
		    PFINT_FW_CTL_MSIX_INDX_S);
	CHECK_EQUAL(CAUSE_ENA_SET,
		    (regval & PFINT_FW_CTL_CAUSE_ENA_M) >>
		    PFINT_FW_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_MBX_CTL);
	CHECK_EQUAL(vector_idx,
		    (regval & PFINT_MBX_CTL_MSIX_INDX_M) >>
		    PFINT_MBX_CTL_MSIX_INDX_S);
	CHECK_EQUAL(CAUSE_ENA_SET,
		    (regval & PFINT_MBX_CTL_CAUSE_ENA_M) >>
		    PFINT_MBX_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_SB_CTL);
	CHECK_EQUAL(vector_idx,
		    (regval & PFINT_SB_CTL_MSIX_INDX_M) >>
		    PFINT_SB_CTL_MSIX_INDX_S);
	CHECK_EQUAL(CAUSE_ENA_SET,
		    (regval & PFINT_SB_CTL_CAUSE_ENA_M) >>
		    PFINT_SB_CTL_CAUSE_ENA_S);

#define CAUSE_ENA_CLEAR	0
	ice_dis_ctrlq_interrupts(&hw);

	regval = rd32(&hw, PFINT_OICR_CTL);
	CHECK_EQUAL(CAUSE_ENA_CLEAR,
		    (regval & PFINT_OICR_CTL_CAUSE_ENA_M) >>
		    PFINT_OICR_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_FW_CTL);
	CHECK_EQUAL(CAUSE_ENA_CLEAR,
		    (regval & PFINT_FW_CTL_CAUSE_ENA_M) >>
		    PFINT_FW_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_MBX_CTL);
	CHECK_EQUAL(CAUSE_ENA_CLEAR,
		    (regval & PFINT_MBX_CTL_CAUSE_ENA_M) >>
		    PFINT_MBX_CTL_CAUSE_ENA_S);

	regval = rd32(&hw, PFINT_SB_CTL);
	CHECK_EQUAL(CAUSE_ENA_CLEAR,
		    (regval & PFINT_SB_CTL_CAUSE_ENA_M) >>
		    PFINT_SB_CTL_CAUSE_ENA_S);
}

TEST_GROUP(pci_error_handlers)
{
	struct ice_pf *pf;
	struct pci_dev *pdev;
	struct ice_hw *hw;

	void setup()
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pf->num_alloc_vsi = 1;
		pf->vsi = (struct ice_vsi **)calloc(pf->num_alloc_vsi, sizeof(struct ice_vsi *));
		hw = &pf->hw;

		for (int i = 0; i < pf->num_alloc_vsi; ++i) {
			pf->vsi[i] = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
			pf->vsi[i]->back = pf;
			pf->vsi[i]->type = ICE_VSI_PF;
		}

		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		pci_set_drvdata(pdev, pf);
		hw->hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
	}

	void teardown()
	{
		mock().checkExpectations();
		mock().clear();

		for (int i = 0; i < pf->num_alloc_vsi; ++i) {
			free(pf->vsi[i]);
			pf->vsi[i] = NULL;
		}

		free(hw->hw_addr);
		hw->hw_addr = NULL;
		free(pf->vsi);
		pf->vsi = NULL;
		free(pf);
		pf = NULL;
		free(pdev);
		pdev = NULL;
	}
};

TEST(pci_error_handlers, pci_err_detected_ice_suspended)
{
	pci_ers_result_t result;

	set_bit(ICE_SUSPENDED, pf->state);
	result = ice_pci_err_detected(pdev, pci_channel_io_frozen);
	CHECK_EQUAL(result, PCI_ERS_RESULT_NEED_RESET);
}

TEST(pci_error_handlers, ice_pci_err_slot_reset_pci_enable_device_mem_failed)
{
	pci_ers_result_t result;

	mock().expectOneCall("pci_enable_device_mem")
		.ignoreOtherParameters()
		.andReturnValue(-1);
	mock().expectOneCall("pci_aer_clear_nonfatal_status")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_pci_err_slot_reset(pdev);
	CHECK_EQUAL(result, PCI_ERS_RESULT_DISCONNECT);
}

TEST(pci_error_handlers, ice_pci_err_slot_reset_invalid_reg_read)
{
	pci_ers_result_t result;

	mock().expectOneCall("pci_enable_device_mem")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_set_master")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_restore_state")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_save_state")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_wake_from_d3")
		.ignoreOtherParameters();

	/* Force register read to be something other than 0 so we fail */
	wr32(&pf->hw, GLGEN_RTRIG, 0xffff);

	mock().expectOneCall("pci_aer_clear_nonfatal_status")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_pci_err_slot_reset(pdev);
	CHECK_EQUAL(result, PCI_ERS_RESULT_DISCONNECT);
}

TEST(pci_error_handlers, ice_pci_err_slot_reset_success)
{
	pci_ers_result_t result;

	mock().expectOneCall("pci_enable_device_mem")
		.ignoreOtherParameters()
		.andReturnValue(0);
	mock().expectOneCall("pci_set_master")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_restore_state")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_save_state")
		.ignoreOtherParameters();
	mock().expectOneCall("pci_wake_from_d3")
		.ignoreOtherParameters();

	/* Force register read to be 0 so we succeed */
	wr32(&pf->hw, GLGEN_RTRIG, 0x0);

	mock().expectOneCall("pci_aer_clear_nonfatal_status")
		.ignoreOtherParameters()
		.andReturnValue(0);

	result = ice_pci_err_slot_reset(pdev);
	CHECK_EQUAL(result, PCI_ERS_RESULT_RECOVERED);
}

TEST(pci_error_handlers, ice_pci_err_resume_ice_suspended)
{
	set_bit(ICE_SUSPENDED, pf->state);
	ice_pci_err_resume(pdev);
}


static bool fake_ice_is_dvm_ena_always_enabled(struct ice_hw *hw)
{
	return true;
}

TEST_GROUP(ice_vlan_features)
{
	netdev_features_t features;
	struct net_device *netdev;
	struct pci_dev *pdev;
	struct ice_vsi *vsi;
	struct ice_pf *pf;

	void setup()
	{
		struct ice_netdev_priv *np;

		netdev = alloc_etherdev_mqs((sizeof(struct ice_netdev_priv)), 1, 1);
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		np = netdev_priv(netdev);
		np->vsi = vsi;
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		np->vsi->back = pf;
		pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
		pf->pdev = pdev;

		features = 0;
	}

	void teardown()
	{
		free(pdev);
		free(pf);
		free_netdev(netdev);
		free(vsi);
	}

};

TEST_GROUP_BASE(dvm_ice_fix_features, TGN(ice_vlan_features))
{
	detour_function *fake_ice_is_dvm_ena;

	TEST_SETUP()
	{
		TGN(ice_vlan_features)::setup();
		ALLOC_NEW_MOCK(fake_ice_is_dvm_ena, ice_is_dvm_ena, fake_ice_is_dvm_ena_always_enabled);
	}

	TEST_TEARDOWN()
	{
		DELETE_MOCK(fake_ice_is_dvm_ena);
		TGN(ice_vlan_features)::teardown();
	}
};

#define NETDEV_DVM_VLAN_FILTERING_ENABLED	(NETIF_F_HW_VLAN_CTAG_FILTER | NETIF_F_HW_VLAN_STAG_FILTER)
TEST(dvm_ice_fix_features, enable_only_ctag_filter_expect_all_filtering_features_set)
{
	features = NETIF_F_HW_VLAN_CTAG_FILTER;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(NETDEV_DVM_VLAN_FILTERING_ENABLED, features);
}

TEST(dvm_ice_fix_features, enable_only_stag_filter_expect_all_filtering_features_set)
{
	features = NETIF_F_HW_VLAN_STAG_FILTER;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(NETDEV_DVM_VLAN_FILTERING_ENABLED, features);
}

TEST(dvm_ice_fix_features, disable_only_ctag_filter_expect_all_filtering_features_cleared)
{
	features = NETIF_F_HW_VLAN_STAG_FILTER;
	netdev->features = NETDEV_DVM_VLAN_FILTERING_ENABLED;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(0, features);
}

TEST(dvm_ice_fix_features, disable_only_stag_filter_expect_all_filtering_features_cleared)
{
	features = NETIF_F_HW_VLAN_CTAG_FILTER;
	netdev->features = NETDEV_DVM_VLAN_FILTERING_ENABLED;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(0, features);
}

TEST(dvm_ice_fix_features, enable_stag_and_ctag_filter_expect_both_still_set)
{
	features = NETDEV_DVM_VLAN_FILTERING_ENABLED;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(NETDEV_DVM_VLAN_FILTERING_ENABLED, features);
}

TEST(dvm_ice_fix_features, enable_STAG_and_CTAG_RX_TX_expect_only_CTAG_set)
{
	features = NETIF_F_HW_VLAN_CTAG_RX | NETIF_F_HW_VLAN_CTAG_TX |
		NETIF_F_HW_VLAN_STAG_RX | NETIF_F_HW_VLAN_STAG_TX;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(NETIF_F_HW_VLAN_CTAG_RX | NETIF_F_HW_VLAN_CTAG_TX, features);
}

TEST(dvm_ice_fix_features, disable_FCS_stripping_expect_VLAN_stripping_disabled_if_no_vlans_cfg)
{
	netdev_features_t vlan_strippings[] = {NETIF_F_HW_VLAN_CTAG_RX, NETIF_F_HW_VLAN_STAG_RX};

	for (size_t i=0; i < ARRAY_SIZE(vlan_strippings); ++i) {
		features = NETIF_F_RXFCS | vlan_strippings[i];

		mock().expectOneCall("ice_vsi_has_non_zero_vlans")
			.andReturnValue(false);

		features = ice_fix_features(netdev, features);

		CHECK_EQUAL(NETIF_F_RXFCS, features);
	}
}

static bool fake_ice_is_dvm_ena_always_disabled(struct ice_hw *hw)
{
	return false;
}

TEST_GROUP_BASE(svm_ice_fix_features, TGN(ice_vlan_features))
{
	detour_function *fake_ice_is_dvm_ena;

	TEST_SETUP()
	{
		features = 0;
		TGN(ice_vlan_features)::setup();
		ALLOC_NEW_MOCK(fake_ice_is_dvm_ena, ice_is_dvm_ena, fake_ice_is_dvm_ena_always_disabled);
	}

	TEST_TEARDOWN()
	{
		DELETE_MOCK(fake_ice_is_dvm_ena);
		TGN(ice_vlan_features)::teardown();
	}
};

TEST(svm_ice_fix_features, enable_ctag_filtering_expect_ctag_filtering_still_set)
{
	features = NETIF_F_HW_VLAN_CTAG_FILTER;

	features = ice_fix_features(netdev, features);

	CHECK_EQUAL(NETIF_F_HW_VLAN_CTAG_FILTER, features);
}

TEST_GROUP_BASE(ice_set_vlan_features, TGN(ice_vlan_features))
{
	TEST_SETUP()
	{
		TGN(ice_vlan_features)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_vlan_features)::teardown();
	}
};

TEST(ice_set_vlan_features, current_and_requested_features_0_expect_no_call_to_set_vlan_offload_and_filtering_settings)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);
	USE_STD_MOCK(ice_set_vlan_filtering_features);

	netdev->features = 0;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_CTAG_RX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_RX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_CTAG_TX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_TX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_CTAG_RX_TX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_TX | NETIF_F_HW_VLAN_CTAG_RX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_STAG_RX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_STAG_RX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_STAG_TX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_STAG_TX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_STAG_RX_TX_expect_no_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_STAG_TX | NETIF_F_HW_VLAN_STAG_RX;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_and_requested_features_CTAG_STAG_FILTER_expect_no_call_to_set_vlan_filtering_features)
{
	USE_STD_MOCK(ice_set_vlan_filtering_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_FILTER | NETIF_F_HW_VLAN_STAG_FILTER;
	features = netdev->features;

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_0_requested_CTAG_RX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = 0;
	features = NETIF_F_HW_VLAN_CTAG_RX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_0_requested_CTAG_TX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = 0;
	features = NETIF_F_HW_VLAN_CTAG_TX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_CTAG_RX_requested_CTAG_RX_TX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_RX;
	features = NETIF_F_HW_VLAN_CTAG_RX |
		NETIF_F_HW_VLAN_CTAG_TX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_0_requested_STAG_RX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = 0;
	features = NETIF_F_HW_VLAN_STAG_RX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_0_requested_STAG_TX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = 0;
	features = NETIF_F_HW_VLAN_STAG_TX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_CTAG_RX_requested_STAG_RX_TX_expect_call_to_set_vlan_offload_features)
{
	USE_STD_MOCK(ice_set_vlan_offload_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_RX;
	features = NETIF_F_HW_VLAN_STAG_RX |
		NETIF_F_HW_VLAN_STAG_TX;

	mock().expectOneCall("ice_set_vlan_offload_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_CTAG_STAG_FILTER_requested_0_expect_call_to_set_vlan_filtering_features)
{
	USE_STD_MOCK(ice_set_vlan_filtering_features);

	netdev->features = NETIF_F_HW_VLAN_CTAG_FILTER |
		NETIF_F_HW_VLAN_STAG_FILTER;
	features = 0;

	mock().expectOneCall("ice_set_vlan_filtering_features")
		.withParameter("features", features)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_features(netdev, features);
}

TEST(ice_set_vlan_features, current_0_and_requested_VLAN_and_FCS_stripping_expect_err)
{
	netdev_features_t vlan_strippings[] = {NETIF_F_HW_VLAN_CTAG_RX, NETIF_F_HW_VLAN_STAG_RX};
	int ret;

	USE_STD_MOCK(ice_set_vlan_offload_features);

	for (size_t i=0; i < ARRAY_SIZE(vlan_strippings); ++i) {
		netdev->features = 0;
		features = NETIF_F_RXFCS | vlan_strippings[i];

		ret = ice_set_vlan_features(netdev, features);
		CHECK_EQUAL(-EIO, ret);
	}
}

TEST_GROUP_BASE(ice_set_vlan_offload_features, TGN(ice_vlan_features))
{
	struct ice_vsi_vlan_ops vlan_ops;

	TEST_SETUP()
	{
		init_vlan_ops_mocks(&vlan_ops);
		TGN(ice_vlan_features)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_vlan_features)::teardown();
	}
};

TEST(ice_set_vlan_offload_features, enable_CTAG_TX_disable_CTAG_RX_expect_call_to_enable_insertion_disable_stripping)
{
	features = NETIF_F_HW_VLAN_CTAG_TX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_insertion")
		.withParameter("tpid", ETH_P_8021Q)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_dis_stripping")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, enable_CTAG_RX_disable_CTAG_TX_expect_call_to_enable_stripping_disable_insertion)
{
	features = NETIF_F_HW_VLAN_CTAG_RX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_stripping")
		.withParameter("tpid", ETH_P_8021Q)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_dis_insertion")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, enable_CTAG_RX_TX_expect_call_to_enable_stripping_enable_insertion)
{
	features = NETIF_F_HW_VLAN_CTAG_RX | NETIF_F_HW_VLAN_CTAG_TX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_stripping")
		.withParameter("tpid", ETH_P_8021Q)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_ena_insertion")
		.withParameter("tpid", ETH_P_8021Q)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, disable_insertion_stripping_expect_call_to_disable_stripping_disable_insertion)
{
	features = 0;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_dis_stripping")
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_dis_insertion")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, enable_STAG_TX_disable_STAG_RX_expect_call_to_enable_insertion_disable_stripping)
{
	features = NETIF_F_HW_VLAN_STAG_TX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_insertion")
		.withParameter("tpid", ETH_P_8021AD)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_dis_stripping")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, enable_STAG_RX_disable_STAG_TX_expect_call_to_enable_stripping_disable_insertion)
{
	features = NETIF_F_HW_VLAN_STAG_RX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_stripping")
		.withParameter("tpid", ETH_P_8021AD)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_dis_insertion")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST(ice_set_vlan_offload_features, enable_STAG_RX_TX_expect_call_to_enable_stripping_enable_insertion)
{
	features = NETIF_F_HW_VLAN_STAG_RX | NETIF_F_HW_VLAN_STAG_TX;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_stripping")
		.withParameter("tpid", ETH_P_8021AD)
		.ignoreOtherParameters()
		.andReturnValue(0);

	mock().expectOneCall("mock_ena_insertion")
		.withParameter("tpid", ETH_P_8021AD)
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_offload_features(vsi, features);
}

TEST_GROUP_BASE(ice_set_vlan_filtering_features, TGN(ice_vlan_features))
{
	struct ice_vsi_vlan_ops vlan_ops;

	TEST_SETUP()
	{
		init_vlan_ops_mocks(&vlan_ops);
		TGN(ice_vlan_features)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_vlan_features)::teardown();
	}
};

/* Single VLAN Mode == svm - Only NETIF_F_HW_VLAN_CTAG_FILTER is supported
 * so make sure this function still enables Rx filtering when that is the only
 * bit set for the netdev features input
 */
TEST(ice_set_vlan_filtering_features, svm_CTAG_filering_requested_expect_call_to_ena_rx_filtering)
{
	features = NETIF_F_HW_VLAN_CTAG_FILTER;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_filtering_features(vsi, features);
}

TEST(ice_set_vlan_filtering_features, dvm_STAG_CTAG_filtering_requested_expect_call_to_ena_rx_filtering)
{
	features = NETIF_F_HW_VLAN_CTAG_FILTER | NETIF_F_HW_VLAN_STAG_FILTER;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_ena_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_filtering_features(vsi, features);
}

TEST(ice_set_vlan_filtering_features, no_filtering_requested_expect_call_to_dis_rx_filtering)
{
	features = 0;

	mock().expectOneCall("ice_get_compat_vsi_vlan_ops")
		.ignoreOtherParameters()
		.andReturnValue(&vlan_ops);

	mock().expectOneCall("mock_dis_rx_vlan_filtering")
		.ignoreOtherParameters()
		.andReturnValue(0);

	ice_set_vlan_filtering_features(vsi, features);
}

static bool fake_ice_is_safe_mode_always_false(struct ice_pf *pf)
{
	return false;
}

TEST_GROUP_BASE(ice_set_netdev_features, TGN(ice_vlan_features))
{
	detour_function *fake_ice_is_safe_mode;

	TEST_SETUP()
	{
		TGN(ice_vlan_features)::setup();
		ALLOC_NEW_MOCK(fake_ice_is_safe_mode, ice_is_safe_mode, fake_ice_is_safe_mode_always_false);
	}

	TEST_TEARDOWN()
	{
		DELETE_MOCK(fake_ice_is_safe_mode);
		TGN(ice_vlan_features)::teardown();
	}
};

#define NETIF_F_HW_VLAN_OFFLOAD_FEATURES	(NETIF_F_HW_VLAN_CTAG_RX | \
						 NETIF_F_HW_VLAN_CTAG_TX | \
						 NETIF_F_HW_VLAN_STAG_RX | \
						 NETIF_F_HW_VLAN_STAG_TX)

#define NETIF_F_HW_VLAN_FILTER_FEATURES	(NETIF_F_HW_VLAN_CTAG_FILTER | \
					 NETIF_F_HW_VLAN_STAG_FILTER)

#define NETIF_F_HW_VLAN_FEATURES	(NETIF_F_HW_VLAN_OFFLOAD_FEATURES | \
					 NETIF_F_HW_VLAN_FILTER_FEATURES)

#define NETIF_F_HW_CTAG_VLAN_FEATURES	(NETIF_F_HW_VLAN_CTAG_RX | \
					 NETIF_F_HW_VLAN_CTAG_TX | \
					 NETIF_F_HW_VLAN_CTAG_FILTER)

TEST(ice_set_netdev_features, svm_only_ctag_offloads_enabled_in_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_HW_CTAG_VLAN_FEATURES,
		    netdev->features & NETIF_F_HW_VLAN_FEATURES);
}

TEST(ice_set_netdev_features, svm_only_ctag_offloads_available_in_hw_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(false);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_HW_CTAG_VLAN_FEATURES,
		    netdev->hw_features & NETIF_F_HW_VLAN_FEATURES);
}

TEST(ice_set_netdev_features, dvm_ctag_offloads_and_ctag_and_stag_filtering_enabled_in_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_HW_CTAG_VLAN_FEATURES | NETIF_F_HW_VLAN_FILTER_FEATURES,
		    netdev->features & NETIF_F_HW_VLAN_FEATURES);
}

TEST(ice_set_netdev_features, dvm_all_vlan_filtering_available_in_hw_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(false);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_HW_VLAN_FEATURES,
		    netdev->hw_features & NETIF_F_HW_VLAN_FEATURES);
}

#ifdef GCO_SUPPORT
TEST(ice_set_netdev_features, feature_gco_capable)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(true);
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(true);

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_HW_CSUM,
		    netdev->hw_features & NETIF_F_HW_CSUM);
}
#endif /* GCO_SUPPORT */

TEST(ice_set_netdev_features, rx_fcs_enabled_in_hw_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(true);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_EQUAL(NETIF_F_RXFCS,
		    netdev->hw_features & NETIF_F_RXFCS);
}

TEST(ice_set_netdev_features, rx_fcs_disabled_by_default_in_features)
{
	mock().expectOneCall("ice_is_dvm_ena")
		.ignoreOtherParameters()
		.andReturnValue(true);
#ifdef GCO_SUPPORT
	mock().expectOneCall("ice_is_feature_supported")
		.ignoreOtherParameters()
		.andReturnValue(true);
#endif /* GCO_SUPPORT */

	ice_set_netdev_features(netdev);

	CHECK_FALSE(netdev->features & NETIF_F_RXFCS);
}

TEST_GROUP_BASE(ice_set_features, TGN(ice_set_netdev_features))
{
	TEST_SETUP()
	{
		TGN(ice_set_netdev_features)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_set_netdev_features)::teardown();
	}
};

TEST(ice_set_features, disable_rx_fcs_error_if_vlan_stripping_is_enabled)
{
	netdev_features_t vlan_strippings[] = {NETIF_F_HW_VLAN_CTAG_RX, NETIF_F_HW_VLAN_STAG_RX};
	int ret;

	for (size_t i=0; i < ARRAY_SIZE(vlan_strippings); ++i) {
		mock().expectOneCall("ice_is_reset_in_progress")
			.ignoreOtherParameters()
			.andReturnValue(false);

		netdev->features = vlan_strippings[i];
		features = NETIF_F_RXFCS | vlan_strippings[i];

		ret = ice_set_features(netdev, features);

		CHECK_EQUAL(-EIO, ret);
	}
}

TEST_GROUP(ice_fwlog)
{
	struct ice_fwlog_user_input *user_input;
	struct ice_pf *pf;
	struct pci_dev *pdev;

	void setup()
	{
		user_input = (struct ice_fwlog_user_input *)calloc(1, sizeof(*user_input));
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pdev = (__typeof(pdev))calloc(1, sizeof(*pdev));
		pf->pdev = pdev;
	}

	void teardown()
	{
		free(user_input);
		free(pf);
		free(pdev);
	}
};

TEST_GROUP_BASE(ice_pf_fwlog_is_input_valid, TGN(ice_fwlog))
{
	TEST_SETUP()
	{
		TGN(ice_fwlog)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_fwlog)::teardown();
	}
};

TEST(ice_pf_fwlog_is_input_valid, input_invalid_log_level_expect_false)
{
	bool actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_INVALID;
	user_input->events = 0;

	actual = ice_pf_fwlog_is_input_valid(pf, user_input);

	CHECK_FALSE(actual);
}

TEST(ice_pf_fwlog_is_input_valid, input_invalid_events_expect_false)
{
	bool actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	set_bit(ICE_AQC_FW_LOG_ID_MAX, &user_input->events);
	user_input->log_level = ICE_FWLOG_LEVEL_ERROR;

	actual = ice_pf_fwlog_is_input_valid(pf, user_input);

	CHECK_FALSE(actual);
}

TEST(ice_pf_fwlog_is_input_valid, input_invalid_log_method_expect_false)
{
	bool actual;

	user_input->log_method = 100;
	user_input->log_level = ICE_FWLOG_LEVEL_VERBOSE;
	user_input->events = ICE_AQC_FW_LOG_ID_PFREG;

	actual = ice_pf_fwlog_is_input_valid(pf, user_input);

	CHECK_FALSE(actual);
}

TEST(ice_pf_fwlog_is_input_valid, input_valid_expect_true)
{
	bool actual;

	user_input->log_method = ICE_FWLOG_METHOD_UART;
	user_input->log_level = ICE_FWLOG_LEVEL_VERBOSE;
	/* set all valid events */
	user_input->events = ICE_AQC_FW_LOG_ID_MAX - 1;

	actual = ice_pf_fwlog_is_input_valid(pf, user_input);

	CHECK_TRUE(actual);
}

TEST_GROUP_BASE(ice_pf_fwlog_populate_cfg, TGN(ice_fwlog))
{
	TEST_SETUP()
	{
		TGN(ice_fwlog)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_fwlog)::teardown();
	}

};

TEST(ice_pf_fwlog_populate_cfg, expect_log_level_verbose_only_on_enabled_events)
{
	struct ice_fwlog_cfg cfg { };

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_VERBOSE;
	set_bit(ICE_AQC_FW_LOG_ID_WATCHDOG, &user_input->events);
	set_bit(ICE_AQC_FW_LOG_ID_DCB, &user_input->events);

	ice_pf_fwlog_populate_cfg(&cfg, user_input);

	for (u16 module_id = 0; module_id < ICE_AQC_FW_LOG_ID_MAX; ++module_id) {
		struct ice_fwlog_module_entry *entry = &cfg.module_entries[module_id];

		if (entry->module_id == ICE_AQC_FW_LOG_ID_WATCHDOG ||
		    entry->module_id == ICE_AQC_FW_LOG_ID_DCB)
			CHECK_EQUAL(ICE_FWLOG_LEVEL_VERBOSE, entry->log_level);
		else
			CHECK_EQUAL(ICE_FWLOG_LEVEL_NONE, entry->log_level);
	}
}

TEST(ice_pf_fwlog_populate_cfg, expect_arq_ena_option)
{
	struct ice_fwlog_cfg cfg { };

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_NONE;
	user_input->events = 0;

	ice_pf_fwlog_populate_cfg(&cfg, user_input);

	CHECK_EQUAL(ICE_FWLOG_OPTION_ARQ_ENA, cfg.options);
}

TEST(ice_pf_fwlog_populate_cfg, expect_uart_ena_option)
{
	struct ice_fwlog_cfg cfg { };

	user_input->log_method = ICE_FWLOG_METHOD_UART;
	user_input->log_level = ICE_FWLOG_LEVEL_NONE;
	user_input->events = 0;

	ice_pf_fwlog_populate_cfg(&cfg, user_input);

	CHECK_EQUAL(ICE_FWLOG_OPTION_UART_ENA, cfg.options);
}

TEST(ice_pf_fwlog_populate_cfg, expect_dflt_log_resolution)
{
	struct ice_fwlog_cfg cfg { };

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_NONE;
	user_input->events = 0;

	ice_pf_fwlog_populate_cfg(&cfg, user_input);

	CHECK_EQUAL(ICE_FWLOG_DFLT_LOG_RESOLUTION, cfg.log_resolution);
}

TEST_GROUP_BASE(ice_pf_fwlog_set, TGN(ice_fwlog))
{
	TEST_SETUP()
	{
		TGN(ice_fwlog)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_fwlog)::teardown();
	}

};

TEST(ice_pf_fwlog_set, invalid_input_expect_failure)
{
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_INVALID;
	set_bit(ICE_AQC_FW_LOG_ID_MAX, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.withMemoryBufferParameter("user_input", (u8 *)user_input, sizeof(*user_input))
		.andReturnValue(false);

	actual = ice_pf_fwlog_set(pf, user_input);

	CHECK_EQUAL(-EINVAL, actual);
}

TEST(ice_pf_fwlog_set, ice_fwlog_set_fails_expect_failure)
{
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_VERBOSE;
	set_bit(ICE_AQC_FW_LOG_ID_XLR, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_fwlog_set")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_NO_MEMORY);

	actual = ice_pf_fwlog_set(pf, user_input);

	CHECK_EQUAL(ICE_ERR_NO_MEMORY, actual);
}

TEST(ice_pf_fwlog_set, ice_pf_fwlog_set_expect_success)
{
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_WARNING;
	set_bit(ICE_AQC_FW_LOG_ID_DNL, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_fwlog_set")
		.ignoreOtherParameters()
		.andReturnValue(0);

	actual = ice_pf_fwlog_set(pf, user_input);

	CHECK_EQUAL(0, actual);
}

TEST_GROUP_BASE(ice_pf_fwlog_init, TGN(ice_fwlog))
{
	TEST_SETUP()
	{
		TGN(ice_fwlog)::setup();
	}

	TEST_TEARDOWN()
	{
		TGN(ice_fwlog)::teardown();
	}

};

TEST(ice_pf_fwlog_init, invalid_input_expect_failure)
{
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_INVALID;
	set_bit(ICE_AQC_FW_LOG_ID_MAX, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.withMemoryBufferParameter("user_input", (u8 *)user_input, sizeof(*user_input))
		.andReturnValue(false);

	actual = ice_pf_fwlog_init(pf, user_input);

	CHECK_EQUAL(-EINVAL, actual);
}

TEST(ice_pf_fwlog_init, ice_fwlog_init_fails_expect_failure)
{
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_ERROR;
	set_bit(ICE_AQC_FW_LOG_ID_SYNCE, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.ignoreOtherParameters()
		.andReturnValue(true);

	mock().expectOneCall("ice_fwlog_init")
		.ignoreOtherParameters()
		.andReturnValue(ICE_ERR_PARAM);

	actual = ice_pf_fwlog_init(pf, user_input);

	CHECK_EQUAL(ICE_ERR_PARAM, actual);
}

TEST(ice_pf_fwlog_init, ice_pf_fwlog_init_succeeds_expect_register_on_init_bit_set)
{
	u8 expected_options = ICE_FWLOG_OPTION_REGISTER_ON_INIT | ICE_FWLOG_OPTION_ARQ_ENA;
	struct ice_fwlog_cfg cfg = { .options = expected_options };
	int actual;

	user_input->log_method = ICE_FWLOG_METHOD_ARQ;
	user_input->log_level = ICE_FWLOG_LEVEL_NONE;
	set_bit(ICE_AQC_FW_LOG_ID_SYNCE, &user_input->events);

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.ignoreOtherParameters()
		.andReturnValue(true);

	USE_STD_MOCK(ice_pf_fwlog_populate_cfg);
	mock().expectOneCall("ice_pf_fwlog_populate_cfg")
		.withOutputParameterReturning("cfg", &cfg, sizeof(cfg))
		.withMemoryBufferParameter("user_input", (u8 *)user_input, sizeof(*user_input));

	mock().expectOneCall("ice_fwlog_init")
		.withParameter("options", cfg.options)
		.andReturnValue(0);

	actual = ice_pf_fwlog_init(pf, user_input);

	CHECK_EQUAL(0, actual);
}

TEST(ice_pf_fwlog_init, ice_pf_fwlog_init_succeeds_expect_register_on_init_bit_cleared)
{
	struct ice_fwlog_cfg cfg = { .options = ICE_FWLOG_OPTION_ARQ_ENA };
	int actual;

	user_input->log_level = ICE_FWLOG_LEVEL_NONE;
	user_input->events = 0;

	USE_STD_MOCK(ice_pf_fwlog_is_input_valid);
	mock().expectOneCall("ice_pf_fwlog_is_input_valid")
		.ignoreOtherParameters()
		.andReturnValue(true);

	USE_STD_MOCK(ice_pf_fwlog_populate_cfg);
	mock().expectOneCall("ice_pf_fwlog_populate_cfg")
		.withOutputParameterReturning("cfg", &cfg, sizeof(cfg))
		.withMemoryBufferParameter("user_input", (u8 *)user_input, sizeof(*user_input));

	mock().expectOneCall("ice_fwlog_init")
		.withParameter("options", cfg.options)
		.andReturnValue(0);

	actual = ice_pf_fwlog_init(pf, user_input);

	CHECK_EQUAL(0, actual);
}

TEST_GROUP(ice_check_phy_fw_load)
{
	struct pci_dev *pdev;
	struct ice_pf *pf;

	void setup(void)
	{
		pf = (__typeof(pf))calloc(1, sizeof(*pf));
		pdev = (__typeof(pdev))calloc(1, sizeof(*pdev));

		pf->pdev = pdev;
	}

	void teardown(void)
	{
		free(pf);
		free(pdev);
	}
};

TEST(ice_check_phy_fw_load, link_cfg_err_reports_phy_load_failure)
{
	ice_check_phy_fw_load(pf, ICE_AQ_LINK_EXTERNAL_PHY_LOAD_FAILURE);

	CHECK_TRUE(test_bit(ICE_FLAG_PHY_FW_LOAD_FAILED, pf->flags));
}


TEST(ice_check_phy_fw_load, link_cfg_err_doesnt_report_phy_load_failure)
{
	/* set the error on the first pass */
	ice_check_phy_fw_load(pf, ICE_AQ_LINK_EXTERNAL_PHY_LOAD_FAILURE);

	/* clear the error on the second pass (i.e. PHY FW load succeeded) */
	ice_check_phy_fw_load(pf, 0);

	CHECK_FALSE(test_bit(ICE_FLAG_PHY_FW_LOAD_FAILED, pf->flags));
}
