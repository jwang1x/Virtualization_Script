#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_txrx_lib {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"
#include "linux/netdevice.h"
#include "../src/CORE/ice.h"
#include "KERNEL_MOCKS/mock_net_core.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "CORE_MOCKS/mock_ice_ptp.cpp"
#include "CORE_MOCKS/stdmock_ice_osdep_header.cpp"
#include "CORE_MOCKS/mock_ice_eswitch.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "../src/CORE/ice_txrx_lib.c"
}
/////////////////////////////////////////////////
using namespace ns_txrx_lib;

TEST_GROUP(ice_release_rx_desc)
{
	struct ice_ring *rx_ring;
	void setup()
	{
		rx_ring = (struct ice_ring *)calloc(1, sizeof(*rx_ring));
		rx_ring->count = 2048;
		rx_ring->next_to_use = 2040;
		rx_ring->next_to_alloc = 2040;
		rx_ring->tail = (u8 *)calloc(4, sizeof(u8));
	}

	void teardown()
	{
		free(rx_ring->tail);
		rx_ring->tail = NULL;
		free(rx_ring);
		rx_ring = NULL;
	}
};

TEST(ice_release_rx_desc, rx_tail_bump_maximum_of_once_per_8_descriptors)
{
	USE_STD_MOCK(writel_relaxed);

	mock().expectOneCall("writel_relaxed")
		.withParameter("value", 0)
		.withParameter("addr", rx_ring->tail);
	ice_release_rx_desc(rx_ring, 0);
	ice_release_rx_desc(rx_ring, 1);
	ice_release_rx_desc(rx_ring, 2);
	ice_release_rx_desc(rx_ring, 3);
	ice_release_rx_desc(rx_ring, 4);
	ice_release_rx_desc(rx_ring, 5);
	ice_release_rx_desc(rx_ring, 6);
	ice_release_rx_desc(rx_ring, 7);
	mock().expectOneCall("writel_relaxed")
		.withParameter("value", 8)
		.withParameter("addr", rx_ring->tail);
	ice_release_rx_desc(rx_ring, 8);
	mock().expectOneCall("writel_relaxed")
		.withParameter("value", 24)
		.withParameter("addr", rx_ring->tail);
	ice_release_rx_desc(rx_ring, 24);
}

#ifdef XDP_SUPPORT
TEST_GROUP(finalize_xdp_rx)
{
	struct ice_ring *rx_ring;
	struct ice_ring *xdp_ring;
	struct ice_vsi *vsi;

	u8 xdp_tail = 0;

	void setup()
	{
		vsi = (struct ice_vsi *)calloc(1, sizeof(*vsi));
		xdp_ring = (struct ice_ring *) calloc(1, sizeof(*xdp_ring));
		xdp_ring->tail = &xdp_tail;

		rx_ring = (struct ice_ring *)calloc(1, sizeof(*rx_ring));

		vsi->xdp_rings = (struct ice_ring **)calloc(1, sizeof(struct ice_ring **));
		vsi->xdp_rings[0] = xdp_ring;
		rx_ring->vsi = vsi;

	}

	void teardown()
	{
		free(vsi->xdp_rings);
		free(xdp_ring);
		free(rx_ring);
		free(vsi);
	}
};

TEST(finalize_xdp_rx, tx_and_redir)
{
	xdp_ring->next_to_use = 4;
	ice_finalize_xdp_rx(rx_ring, ICE_XDP_TX | ICE_XDP_REDIR);
	CHECK_EQUAL(xdp_ring->next_to_use, *xdp_ring->tail);
}
#endif

#ifdef GCO_SUPPORT
TEST_GROUP(ice_rx_gcs)
{
	struct  ice_32b_rx_flex_desc_nic rx_desc;
	struct sk_buff skb;
	__le16 val = 5;

	void setup()
	{
		rx_desc.raw_csum = val;
		rx_desc.rxdid = 2;
	}
};

TEST(ice_rx_gcs, expects_success)
{
	__wsum	csum = (__force __wsum)~htons(le16_to_cpu(val));
	ice_rx_gcs(&skb, (ice_32b_rx_flex_desc *)&rx_desc);
	// If we successfully made it thru, we know that the
	// csum is set to the value passed in the flex descriptor.
	CHECK_EQUAL(skb.csum, csum);
}
#endif /* GCO_SUPPORT */
