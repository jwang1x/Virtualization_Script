/* This file contains a mock implementation of the ice_peer_ops table,
 * implementing each callback operation as a mock().actualCall. It can be used
 * to setup a struct ice_peer_obj structure for TDD tests.
 */

static void mock_peer_ops_event_handler(struct ice_peer_obj *peer_obj,
					struct ice_event *event)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("event", event);
}

static int mock_peer_ops_open(struct ice_peer_obj *peer_obj)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj);

	return mock().returnIntValueOrDefault(0);
}

#ifdef SWITCH_MODE
#ifdef CONFIG_PCI_IOV
static int mock_peer_ops_vf_reset(struct ice_peer_obj *peer_obj, u32 vf_id)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("vf_id", vf_id);

	return mock().returnIntValueOrDefault(0);
}

static int mock_peer_ops_vf_ena(struct ice_peer_obj *peer_obj, u32 vf_id)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("vf_id", vf_id);

	return mock().returnIntValueOrDefault(0);
}

static int mock_peer_ops_vf_capability(struct ice_peer_obj *peer_obj,
				       struct ice_vf_caps *caps)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("caps", (u8 *)caps, sizeof(caps));

	return mock().returnIntValueOrDefault(0);
}
#endif /* CONFIG_PCI_IOV */

#ifdef ADK_SUPPORT
static int mock_peer_ops_adk_ice_rx_skb(struct ice_peer_obj *peer_obj,
					struct sk_buff *skb, u16 vlan_tag, int budget,
					struct ice_nd_rx_md *rxmd,
					struct napi_struct *napi)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("skb", skb)
		.withParameter("vlan_tag", vlan_tag)
		.withParameter("budget", budget)
		.withParameter("napi", napi);

	return mock().returnIntValueOrDefault(0);
}

static void mock_peer_ops_adk_ice_sent_q(struct ice_peer_obj *peer_obj,
					 struct sk_buff *skb, unsigned int bytecount)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("skb", skb)
		.withParameter("bytecount", bytecount);
}

static int mock_peer_ops_adk_ice_test_xmit(struct ice_peer_obj *peer_obj,
					   struct sk_buff *skb)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("skb", skb);

	return mock().returnIntValueOrDefault(0);
}

static void mock_peer_ops_adk_ice_consume_skb(struct ice_peer_obj *peer_obj,
					      struct sk_buff *skb, int napi_budget,
					      unsigned int bytes, unsigned short segs)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("skb", skb)
		.withParameter("napi_budget", napi_budget)
		.withParameter("bytes", bytes)
		.withParameter("segs", segs);
}

static int mock_peer_ops_adk_ice_subq_stopped(struct ice_peer_obj *peer_obj, u8 lport,
					      struct net_device *netdev)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("lport", lport)
		.withParameter("netdev", netdev);

	return mock().returnIntValueOrDefault(0);
}

static void mock_peer_ops_adk_ice_wake_subq(struct ice_peer_obj *peer_obj, u8 lport,
					    struct net_device *netdev)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("lport", lport)
		.withParameter("netdev", netdev);
}

static void mock_peer_ops_adk_ice_stop_subq(struct net_device *lwr_netdev)
{
	mock().actualCall(__func__)
		.withParameter("lwr_netdev", lwr_netdev);
}

static void mock_peer_ops_adk_ice_start_subq(struct net_device *lwr_netdev)
{
	mock().actualCall(__func__)
		.withParameter("lwr_netdev", lwr_netdev);
}

#ifndef NO_PTP_SUPPORT
static void mock_peer_ops_adk_ice_tx_ts_intr(struct ice_peer_obj *peer_obj, int bank_id,
					     u64 ts_avail_map)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("bank_id", bank_id)
		.withParameter("ts_avail_map", ts_avail_map);
}
#endif /* !NO_PTP_SUPPORT */
#endif /* ADK_SUPPORT */
#endif /* SWITCH_MODE */

static int mock_peer_ops_vc_receive(struct ice_peer_obj *peer_obj, u32 vf_id, u8 *msg,
				    u16 len)
{
	mock().actualCall(__func__)
		.withParameter("peer_obj", peer_obj)
		.withParameter("vf_id", vf_id)
		.withParameter("msg", msg, len)
		.withParameter("len", len);

	return mock().returnIntValueOrDefault(0);
}
