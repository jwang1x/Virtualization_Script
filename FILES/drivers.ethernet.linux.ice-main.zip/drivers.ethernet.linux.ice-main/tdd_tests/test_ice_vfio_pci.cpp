#ifdef LM_SUPPORT
/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_vfio_pci {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "linux/irqbypass.h"
#include "asm-generic/page.h"
#include "asm-generic/pfn.h"
#include "linux/mm_types.h"

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_pci.cpp"
#include "KERNEL_MOCKS/mock_vfio_pci.cpp"

#include "../src/CORE/ice_vfio_pci.c"

#include "CORE_MOCKS/stdmock_ice_vfio_pci.cpp"
#include "CORE_MOCKS/mock_ice_migration.cpp"
}
/////////////////////////////////////////////////
using namespace ns_vfio_pci;

TEST_GROUP(ice_vfio_pci)
{
	struct pci_dev pdev;
	struct device *dev;
	struct ice_vfio_pci_core_device *ice_vdev;
	struct vfio_pci_core_device *vdev;

	TEST_SETUP()
	{
		memset(&pdev, 0, sizeof(pdev));
		dev = &pdev.dev;
		ice_vdev = (struct ice_vfio_pci_core_device *)malloc(sizeof(*ice_vdev));
		vdev = &ice_vdev->core_device;
		dev_set_drvdata(&pdev.dev, &ice_vdev->core_device);
	}

	TEST_TEARDOWN()
	{
		free(ice_vdev);
	}
};

TEST(ice_vfio_pci, check_init)
{
	int err;

	err = ice_vfio_pci_init();
	CHECK_EQUAL(0, err);
}

TEST(ice_vfio_pci, check_probe)
{
	int err;
	struct ice_vfio_pci_core_device *tmp_ice_vdev;

	mock().expectOneCall("vfio_pci_core_init_device")
		.withParameter("vfio_pci_ops", &ice_vfio_pci_ops)
		.ignoreOtherParameters();

	mock().expectOneCall("vfio_pci_core_register_device")
		.ignoreOtherParameters()
		.andReturnValue(0);

	err = ice_vfio_pci_probe(&pdev, NULL);
	CHECK_EQUAL(0, err);

	tmp_ice_vdev = (struct ice_vfio_pci_core_device *)dev_get_drvdata(&pdev.dev);
	free(tmp_ice_vdev);
}

TEST(ice_vfio_pci, check_remove)
{
	struct ice_vfio_pci_core_device *tmp_ice_vdev;

	tmp_ice_vdev = (struct ice_vfio_pci_core_device *)malloc(sizeof(*tmp_ice_vdev));
	dev_set_drvdata(&pdev.dev, tmp_ice_vdev);

	mock().expectOneCall("vfio_pci_core_uninit_device")
		.withParameter("vdev", &tmp_ice_vdev->core_device);

	mock().expectOneCall("vfio_pci_core_unregister_device")
		.withParameter("vdev", &tmp_ice_vdev->core_device);

	ice_vfio_pci_remove(&pdev);
}

TEST(ice_vfio_pci, check_open)
{
	int err;

	USE_STD_MOCK(ice_vfio_migration_init);

	mock().expectOneCall("ice_vfio_migration_init")
		.withParameter("ice_vdev", ice_vdev)
		.andReturnValue(0);

	mock().expectOneCall("vfio_pci_core_enable")
		.withParameter("vdev", vdev)
		.andReturnValue(0);

	mock().expectOneCall("vfio_pci_core_finish_enable")
		.withParameter("vdev", vdev);

	err = ice_vfio_pci_open_device(&vdev->vdev);
	CHECK_EQUAL(0, err);
}

TEST(ice_vfio_pci, check_close)
{
	USE_STD_MOCK(ice_vfio_migration_uninit);

	mock().expectOneCall("ice_vfio_migration_uninit")
		.withParameter("ice_vdev", ice_vdev);

	mock().expectOneCall("vfio_pci_core_close_device")
		.withParameter("core_vdev", &vdev->vdev);

	ice_vfio_pci_close_device(&vdev->vdev);
}

TEST(ice_vfio_pci, check_set_device_state_saving)
{
	u32 state = VFIO_DEVICE_STATE_SAVING;
	int err;

	USE_STD_MOCK(ice_vfio_pci_save_state);

	mock().expectOneCall("ice_vfio_pci_save_state")
		.withParameter("ice_vdev", ice_vdev)
		.andReturnValue(0);

	ice_vdev->mig_info.device_state = VFIO_DEVICE_STATE_RUNNING | VFIO_DEVICE_STATE_SAVING;

	err = ice_vfio_pci_set_device_state(ice_vdev, state);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(ice_vdev->mig_info.device_state, state);
}

TEST(ice_vfio_pci, check_set_device_state_load)
{
	u32 state = VFIO_DEVICE_STATE_RUNNING;
	int err;

	USE_STD_MOCK(ice_vfio_pci_load_state);

	mock().expectOneCall("ice_vfio_pci_load_state")
		.withParameter("ice_vdev", ice_vdev)
		.andReturnValue(0);

	ice_vdev->mig_info.device_state = VFIO_DEVICE_STATE_RESUMING;

	err = ice_vfio_pci_set_device_state(ice_vdev, state);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(ice_vdev->mig_info.device_state, state);
}

TEST(ice_vfio_pci, check_set_device_state_stop)
{
	u32 state = VFIO_DEVICE_STATE_STOP;
	int err;

	USE_STD_MOCK(ice_vfio_pci_reset_mig);

	mock().expectOneCall("ice_vfio_pci_reset_mig")
		.withParameter("ice_vdev", ice_vdev);

	ice_vdev->mig_info.device_state = VFIO_DEVICE_STATE_SAVING;

	err = ice_vfio_pci_set_device_state(ice_vdev, state);
	CHECK_EQUAL(0, err);
	CHECK_EQUAL(ice_vdev->mig_info.device_state, state);
}
#endif /* LM_SUPPORT */
