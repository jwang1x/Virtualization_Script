#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_irq {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "ice_osdep.h"

#include "../src/CORE/ice.h"
#include "../src/CORE/ice_irq.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_pci.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_sriov.cpp"
#include "CORE_MOCKS/mock_ice_devlink.cpp"
#include "CORE_MOCKS/mock_ice_ethtool.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"

#include "CORE_MOCKS/stdmock_ice_irq.cpp"

#include "../src/CORE/ice_irq.c"
}
/////////////////////////////////////////////////
using namespace ns_irq;

TEST_GROUP(irq_grp)
{
	struct ice_pf *pf;
	int result;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(*pf));
		pf->pdev = (struct pci_dev *)calloc(1, sizeof(struct pci_dev));
#ifdef FDIR_SUPPORT
		set_bit(ICE_FLAG_FD_ENA, pf->flags);
#endif /* FDIR_SUPPORT */
#if !defined(SWITCH_MODE) && !defined(BMSM_MODE)
		set_bit(ICE_FLAG_VMDQ_ENA, pf->flags);
		set_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags);
		set_bit(ICE_FLAG_IWARP_ENA, pf->flags);
#endif /* !SWITCH_MODE && !BMSM_MODE */
	}

	void teardown(void)
	{
		free(pf->msix_entries); /* allocated in ice_ena_msix_range() */
		free(pf->pdev);
		free(pf);
	}
};

#if defined(SWITCH_MODE) && !defined(BMSM_MODE)
TEST(irq_grp, fail_to_allocate_msix_no_vect_left)
{
	int num_cpus = 8;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(2, "num_online_cpus")
		.andReturnValue(num_cpus);

	CHECK_EQUAL(-ENOSPC, ice_ena_msix_range(pf));
}

TEST(irq_grp, kernel_returns_error_expect_fail)
{
	int num_cpus = 8;
	int vectors;

	pf->hw.num_lports = 8;
	pf->max_qps = 8;
	vectors = 1 + pf->hw.num_lports * num_cpus + num_cpus +
		  ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC + ICE_MAX_AE_VEC;
#ifdef FDIR_SUPPORT
	vectors += ICE_FDIR_MSIX;
#endif /* FDIR_SUPPORT */
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(2, "num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(-1);

	CHECK_EQUAL(-1, ice_ena_msix_range(pf));
}

TEST(irq_grp, kernel_returns_less_than_min_expect_fails)
{
	int num_cpus = 8;
	int vectors;

	pf->hw.num_lports = 8;
	pf->max_qps = 8;
	vectors = 1 + pf->hw.num_lports * num_cpus + num_cpus +
		  ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC + ICE_MAX_AE_VEC;
#ifdef FDIR_SUPPORT
	vectors += ICE_FDIR_MSIX;
#endif /* FDIR_SUPPORT */
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(2, "num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(vectors-1);

	CHECK_EQUAL(-ENOSPC, ice_ena_msix_range(pf));
}

TEST(irq_grp, kernel_returns_max_expect_success)
{
	int num_cpus = 8;
	int vectors;

	pf->hw.num_lports = 8;
	pf->max_qps = 8;
	vectors = 1 + pf->hw.num_lports * num_cpus + num_cpus +
		  ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC + ICE_MAX_AE_VEC;
#ifdef FDIR_SUPPORT
	vectors += ICE_FDIR_MSIX;
#endif /* FDIR_SUPPORT */
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectNCalls(2, "num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(vectors);

	CHECK_EQUAL(vectors, ice_ena_msix_range(pf));

}
#elif defined(BMSM_MODE)
TEST(irq_grp, fail_to_allocate_msix_no_vect_left)
{
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("num_online_cpus")
		.andReturnValue(num_cpus);

	CHECK_EQUAL(-ENOSPC, ice_ena_msix_range(pf));
}

TEST(irq_grp, kernel_return_less_than_min_expect_fail)
{
	int vectors, min_vec;
	int num_cpus = 256;

	pf->hw.num_total_ports = 8;
	pf->hw.num_lports = 8;
	min_vec = 1 + pf->hw.num_lports + ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC;
	vectors = 1 + num_cpus * pf->hw.num_total_ports + ICE_MAX_SWT_VEC +
		  ICE_MAX_CRYPTO_VEC;
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(min_vec-1);

	CHECK_EQUAL(-ENOSPC, ice_ena_msix_range(pf));
}

TEST(irq_grp, kernel_return_min_expect_success_with_less_lan)
{
	int vectors, min_vec;
	int num_cpus = 256;

	pf->hw.num_total_ports = 8;
	pf->hw.num_lports = 8;
	min_vec = 1 + pf->hw.num_lports + ICE_MAX_SWT_VEC + ICE_MAX_CRYPTO_VEC;
	vectors = 1 + num_cpus * pf->hw.num_total_ports + ICE_MAX_SWT_VEC +
		  ICE_MAX_CRYPTO_VEC;
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(min_vec);

	CHECK_EQUAL(min_vec, ice_ena_msix_range(pf));
	CHECK_EQUAL(pf->num_lan_msix, pf->hw.num_lports);
}

TEST(irq_grp, kernel_return_max_expect_success)
{
	int num_cpus = 256;
	int vectors;

	pf->hw.num_total_ports = 8;
	pf->hw.num_lports = 8;
	vectors = 1 + num_cpus * pf->hw.num_total_ports + ICE_MAX_SWT_VEC +
		  ICE_MAX_CRYPTO_VEC;
	pf->hw.func_caps.common_cap.num_msix_vectors = vectors;

	mock().expectOneCall("ice_is_safe_mode")
		.ignoreOtherParameters()
		.andReturnValue(false);
	mock().expectOneCall("num_online_cpus")
		.andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", vectors)
		.ignoreOtherParameters()
		.andReturnValue(vectors);

	CHECK_EQUAL(vectors, ice_ena_msix_range(pf));
	CHECK_EQUAL(pf->num_lan_msix, num_cpus * pf->hw.num_total_ports);
}
#else
TEST(irq_grp, fail_to_allocate_msix_entries_expect_fail)
{
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	USE_STD_MOCK(ice_alloc_msix_entries);

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);

	mock().expectOneCall("ice_alloc_msix_entries")
		.ignoreOtherParameters()
		.andReturnValue(-ENOMEM);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(-ENOMEM, result);
}


TEST(irq_grp, kernel_returns_max_msix_requested_expect_success)
{
	int num_cpus = 256;
	int requested_msix;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	requested_msix = 1 + num_cpus + num_cpus + ICE_RDMA_NUM_AEQ_MSIX + ICE_FDIR_MSIX +
		ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI + ICE_ESWITCH_MSIX;
	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(requested_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(requested_msix, result);
}

TEST(irq_grp, low_num_online_cpus_expect_minimum_plus_macvlan_msix)
{
	int requested_msix;
	int num_cpus = 1;
	int lan_msix;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);

#ifdef ADQ_SUPPORT
	lan_msix = ICE_ADQ_MAX_QPS;
#else
	lan_msix = num_cpus;
#endif
	requested_msix = 1 + lan_msix + 1 + num_cpus + ICE_FDIR_MSIX +
		ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI + ICE_ESWITCH_MSIX;
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(requested_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(requested_msix, result);
	CHECK_EQUAL(lan_msix + 1 + ICE_MIN_RDMA_MSIX + ICE_FDIR_MSIX +
		    ICE_ESWITCH_MSIX + ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI,
		    result);
	CHECK_EQUAL(lan_msix, pf->num_lan_msix);
	CHECK_EQUAL(ICE_MIN_RDMA_MSIX, pf->num_rdma_msix);
}

TEST(irq_grp, kernel_doesnt_have_initial_requested_msix_eswitch_msix_removed_returns_success)
{
	int requested_msix, lan_msix, rdma_msix, macvlan_msix, oicr_msix;
	int fdir_msix, eswitch_msix, adjusted_msix;
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	oicr_msix = 1;
	lan_msix = num_cpus;
	rdma_msix = num_cpus + ICE_RDMA_NUM_AEQ_MSIX;
	macvlan_msix = ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI;
	fdir_msix = ICE_FDIR_MSIX;
	eswitch_msix = ICE_ESWITCH_MSIX;

	requested_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix +
		macvlan_msix + eswitch_msix;
	adjusted_msix = requested_msix - eswitch_msix;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(adjusted_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(adjusted_msix, result);
	CHECK_EQUAL(lan_msix, pf->num_lan_msix);
	CHECK_EQUAL(rdma_msix, pf->num_rdma_msix);
	CHECK_TRUE(test_bit(ICE_FLAG_VMDQ_ENA, pf->flags));
	CHECK_FALSE(test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags));
}

TEST(irq_grp, kernel_doesnt_have_initial_requested_msix_macvlan_msix_removed_returns_success)
{
	int requested_msix, lan_msix, rdma_msix, macvlan_msix, oicr_msix;
	int fdir_msix, eswitch_msix, adjusted_msix;
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	oicr_msix = 1;
	lan_msix = num_cpus;
	rdma_msix = num_cpus + ICE_RDMA_NUM_AEQ_MSIX;
	macvlan_msix = ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI;
	fdir_msix = ICE_FDIR_MSIX;
	eswitch_msix = ICE_ESWITCH_MSIX;

	requested_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix +
		macvlan_msix + eswitch_msix;
	adjusted_msix = requested_msix - macvlan_msix - eswitch_msix;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(adjusted_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(adjusted_msix, result);
	CHECK_EQUAL(lan_msix, pf->num_lan_msix);
	CHECK_EQUAL(rdma_msix, pf->num_rdma_msix);
	CHECK_FALSE(test_bit(ICE_FLAG_VMDQ_ENA, pf->flags));
	CHECK_FALSE(test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags));
}

TEST(irq_grp, kernel_doesnt_have_enough_msix_for_max_lan_and_rdma_div_by_2_returns_success)
{
	int requested_msix, lan_msix, rdma_msix, macvlan_msix, oicr_msix;
	int fdir_msix, eswitch_msix, adjusted_msix;
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	oicr_msix = 1;
	lan_msix = num_cpus;
	rdma_msix = num_cpus + ICE_RDMA_NUM_AEQ_MSIX;
	macvlan_msix = ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI;
	fdir_msix = ICE_FDIR_MSIX;
	eswitch_msix = ICE_ESWITCH_MSIX;

	requested_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix +
		macvlan_msix + eswitch_msix;

	lan_msix = num_cpus / 2;
	rdma_msix = num_cpus / 2 + ICE_RDMA_NUM_AEQ_MSIX;
	adjusted_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(adjusted_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(adjusted_msix, result);
	CHECK_EQUAL(lan_msix, pf->num_lan_msix);
	CHECK_EQUAL(rdma_msix, pf->num_rdma_msix);
	CHECK_FALSE(test_bit(ICE_FLAG_VMDQ_ENA, pf->flags));
	CHECK_FALSE(test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags));
}

TEST(irq_grp, kernel_doesnt_have_enough_msix_for_max_lan_and_rdma_div_by_4_returns_success)
{
	int requested_msix, lan_msix, rdma_msix, macvlan_msix, oicr_msix;
	int fdir_msix, eswitch_msix, adjusted_msix;
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	oicr_msix = 1;
	lan_msix = num_cpus;
	rdma_msix = num_cpus + ICE_RDMA_NUM_AEQ_MSIX;
	macvlan_msix = ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI;
	fdir_msix = ICE_FDIR_MSIX;
	eswitch_msix = ICE_ESWITCH_MSIX;

	requested_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix +
		macvlan_msix + eswitch_msix;

	lan_msix = num_cpus / 4;
	rdma_msix = num_cpus / 4 + ICE_RDMA_NUM_AEQ_MSIX;
	adjusted_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(adjusted_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(adjusted_msix, result);
	CHECK_EQUAL(lan_msix, pf->num_lan_msix);
	CHECK_EQUAL(rdma_msix, pf->num_rdma_msix);
	CHECK_FALSE(test_bit(ICE_FLAG_VMDQ_ENA, pf->flags));
	CHECK_FALSE(test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags));
}

TEST(irq_grp, kernel_only_has_bare_minimum_returns_success)
{
	int requested_msix, lan_msix, rdma_msix, macvlan_msix, oicr_msix;
	int fdir_msix, eswitch_msix, adjusted_msix;
	int num_cpus = 256;

	pf->hw.func_caps.common_cap.num_msix_vectors = 1024;

	oicr_msix = ICE_OICR_MSIX;
	lan_msix = num_cpus;
	rdma_msix = num_cpus + ICE_RDMA_NUM_AEQ_MSIX;
	macvlan_msix = ICE_MAX_MACVLANS * ICE_DFLT_VEC_VMDQ_VSI;
	fdir_msix = ICE_FDIR_MSIX;
	eswitch_msix = ICE_ESWITCH_MSIX;
	requested_msix = oicr_msix + lan_msix + rdma_msix + fdir_msix +
		macvlan_msix + eswitch_msix;
	adjusted_msix = ICE_MIN_MSIX + ICE_MIN_RDMA_MSIX + ICE_FDIR_MSIX;

	mock().expectOneCall("num_online_cpus").andReturnValue(num_cpus);
	mock().expectOneCall("pci_enable_msix_range")
		.withParameter("maxvec", requested_msix)
		.ignoreOtherParameters()
		.andReturnValue(adjusted_msix);

	result = ice_ena_msix_range(pf);
	CHECK_EQUAL(adjusted_msix, result);
	CHECK_EQUAL(ICE_MIN_LAN_MSIX, pf->num_lan_msix);
	CHECK_EQUAL(ICE_MIN_RDMA_MSIX, pf->num_rdma_msix);
	CHECK_FALSE(test_bit(ICE_FLAG_VMDQ_ENA, pf->flags));
	CHECK_FALSE(test_bit(ICE_FLAG_ESWITCH_CAPABLE, pf->flags));
}
#endif /* Switching between different device type */
