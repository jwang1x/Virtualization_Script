#ifdef SIOV_SUPPORT
/*
 * Copyright(c) 2020 Intel Corporation.
 *
 * This file is NEVER to be distributed outside of Intel.
 */
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"

/////////////////////////////////////////////////
namespace ns_vdcm {
#include "tdd_shared_code_transform.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include "linux/irqbypass.h"
#include "asm-generic/page.h"
#include "asm-generic/pfn.h"
#include "linux/mm_types.h"

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_err_ptrs.cpp"
#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "KERNEL_MOCKS/mock_vdcm.cpp"
#include "CORE_MOCKS/mock_ice_siov.cpp"

#include "CORE_MOCKS/stdmock_ice_vdcm.cpp"

#include "../src/CORE/ice_vdcm.c"
}
/////////////////////////////////////////////////
using namespace ns_vdcm;

TEST_GROUP(ice_vdcm)
{
	struct mdev_device mdev;
	struct ice_vdcm ivdm;
	struct pci_dev pdev;
	struct device *dev;
	unsigned long arg;
	struct ice_adi adi;

	TEST_SETUP()
	{
		memset(&pdev, 0, sizeof(pdev));
		memset(&mdev, 0, sizeof(mdev));
		memset(&ivdm, 0, sizeof(ivdm));
		memset(&adi, 0, sizeof(adi));
		dev = &pdev.dev;
		mdev.driver_data = &ivdm;
		ivdm.adi = &adi;
		ivdm.parent_dev = dev;
	}
};

TEST(ice_vdcm, vdcm_init)
{
	int err;

	mock().expectOneCall("iommu_dev_enable_feature")
		.withParameter("dev", dev)
		.withParameter("f", IOMMU_DEV_FEAT_AUX);

	mock().expectOneCall("mdev_register_device")
		.withParameter("dev", dev)
		.withParameter("ops", &ice_vdcm_parent_ops);

	err = ice_vdcm_init(&pdev);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_deinit)
{
	mock().expectOneCall("mdev_unregister_device")
		.withParameter("dev", dev);

	mock().expectOneCall("iommu_dev_disable_feature")
		.withParameter("dev", dev)
		.withParameter("f", IOMMU_DEV_FEAT_AUX);

	ice_vdcm_deinit(&pdev);
};

TEST(ice_vdcm, vdcm_ioctl_get_info)
{
	int err;

	USE_STD_MOCK(ice_vdcm_vfio_device_get_info);

	mock().expectOneCall("ice_vdcm_vfio_device_get_info")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_ioctl(&mdev, VFIO_DEVICE_GET_INFO, arg);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_ioctl_get_region_info)
{
	int err;

	USE_STD_MOCK(ice_vdcm_vfio_device_get_region_info);

	mock().expectOneCall("ice_vdcm_vfio_device_get_region_info")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_ioctl(&mdev, VFIO_DEVICE_GET_REGION_INFO, arg);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_ioctl_get_irq_info)
{
	int err;

	USE_STD_MOCK(ice_vdcm_vfio_device_get_irq_info);

	mock().expectOneCall("ice_vdcm_vfio_device_get_irq_info")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_ioctl(&mdev, VFIO_DEVICE_GET_IRQ_INFO, arg);
	CHECK_EQUAL(0, err);
};


TEST(ice_vdcm, vdcm_ioctl_reset)
{
	int err;

	USE_STD_MOCK(ice_vdcm_vfio_device_reset);

	mock().expectOneCall("ice_vdcm_vfio_device_reset")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_ioctl(&mdev, VFIO_DEVICE_RESET, arg);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_vfio_device_get_config_region_index)
{
	struct vfio_region_info info = {};
	int err;

	info.index = VFIO_PCI_CONFIG_REGION_INDEX;
	info.argsz = sizeof(struct vfio_region_info);

	err = ice_vdcm_vfio_device_get_region_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_vfio_device_get_bar0_region_index)
{
	struct vfio_region_info info = {};
	int err;

	info.index = VFIO_PCI_BAR0_REGION_INDEX;
	info.argsz = sizeof(struct vfio_region_info);

	USE_STD_MOCK(ice_vdcm_sparse_mmap_cap);

	mock().expectOneCall("ice_vdcm_sparse_mmap_cap")
		.withParameter("adi", &adi)
		.andReturnValue(0);

	err = ice_vdcm_vfio_device_get_region_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, ice_vdcm_sparse_mmap_cap_success)
{
	struct vfio_info_cap caps = { .buf = NULL, .size = 0 };
	unsigned long size;
	int nr_areas = 14;
	int err = 0;

	size = sizeof(struct vfio_region_info_cap_sparse_mmap)
		+ nr_areas * sizeof(struct vfio_region_sparse_mmap_area);

	ivdm.adi->get_sparse_mmap_num = ice_adi_get_sparse_mmap_num;
	mock().expectOneCall("ice_adi_get_sparse_mmap_num")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(nr_areas);

	mock().expectOneCall("vfio_info_add_capability")
		.withParameter("caps", &caps)
		.withParameter("size", size)
		.andReturnValue(0);

	ivdm.adi->get_sparse_mmap_area = ice_adi_get_sparse_mmap_area;
	mock().expectNCalls(nr_areas, "ice_adi_get_sparse_mmap_area")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(0);

	err = ice_vdcm_sparse_mmap_cap(&caps, &adi);
	CHECK_EQUAL(0, err);
	free(caps.buf);
}

TEST(ice_vdcm, ice_vdcm_sparse_mmap_cap_get_num_0)
{
	struct vfio_info_cap caps = { .buf = NULL, .size = 0 };
	unsigned long size;
	int nr_areas = 0;
	int err = 0;

	size = sizeof(struct vfio_region_info_cap_sparse_mmap);

	ivdm.adi->get_sparse_mmap_num = ice_adi_get_sparse_mmap_num;
	mock().expectOneCall("ice_adi_get_sparse_mmap_num")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(nr_areas);

	ivdm.adi->get_sparse_mmap_area = ice_adi_get_sparse_mmap_area;
	mock().expectNCalls(nr_areas, "ice_adi_get_sparse_mmap_area")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(0);

	mock().expectOneCall("vfio_info_add_capability")
		.withParameter("caps", &caps)
		.withParameter("size", size)
		.andReturnValue(0);

	err = ice_vdcm_sparse_mmap_cap(&caps, &adi);
	CHECK_EQUAL(0, err);
	free(caps.buf);
}

TEST(ice_vdcm, ice_vdcm_sparse_mmap_cap_get_area_fail)
{
	struct vfio_info_cap caps = { .buf = NULL, .size = 0 };
	int nr_areas = 14;
	int err = 0;

	ivdm.adi->get_sparse_mmap_num = ice_adi_get_sparse_mmap_num;
	mock().expectOneCall("ice_adi_get_sparse_mmap_num")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(nr_areas);

	ivdm.adi->get_sparse_mmap_area = ice_adi_get_sparse_mmap_area;
	mock().expectOneCall("ice_adi_get_sparse_mmap_area")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(-EINVAL);

	err = ice_vdcm_sparse_mmap_cap(&caps, &adi);
	CHECK_EQUAL(-EINVAL, err);
}

TEST(ice_vdcm, vdcm_vfio_device_get_bar3_region_index)
{
	struct vfio_region_info info = {};
	int err;

	info.index = VFIO_PCI_BAR3_REGION_INDEX;
	info.argsz = sizeof(struct vfio_region_info);

	err = ice_vdcm_vfio_device_get_region_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_vfio_device_get_region_info_fail)
{
	struct vfio_region_info info = {};
	int err;

	err = ice_vdcm_vfio_device_get_region_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(-EINVAL, err);
};

TEST(ice_vdcm, vdcm_vfio_device_get_info)
{
	struct vfio_device_info info = {};
	int err;

	info.argsz = sizeof(struct vfio_device_info);

	err = ice_vdcm_vfio_device_get_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(0, err);
};

TEST(ice_vdcm, vdcm_vfio_device_get_irq_info)
{
	struct vfio_irq_info info = {};
	int err;

	ivdm.adi->get_vector_num = ice_adi_get_vector_num;
	mock().expectOneCall("ice_adi_get_vector_num")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(5);

	info.index = VFIO_PCI_MSIX_IRQ_INDEX;
	info.argsz = sizeof(struct vfio_irq_info);

	err = ice_vdcm_vfio_device_get_irq_info(&ivdm, (unsigned long)&info);
	CHECK_EQUAL(0, err);

	CHECK_EQUAL(5, info.count);
};

TEST(ice_vdcm, ice_vdcm_read)
{
	char buf[4] = {};
	loff_t ppos = 0;
	int count = 4;
	int err;

	USE_STD_MOCK(ice_vdcm_rw);

	mock().expectOneCall("ice_vdcm_rw")
		.withParameter("mdev", &mdev)
		.withParameter("is_write", false)
		.andReturnValue(count);

	err = ice_vdcm_read(&mdev, buf, count, &ppos);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_write)
{
	char buf[4] = {};
	loff_t ppos = 0;
	int count = 4;
	int err;

	USE_STD_MOCK(ice_vdcm_rw);

	mock().expectOneCall("ice_vdcm_rw")
		.withParameter("mdev", &mdev)
		.withParameter("is_write", true)
		.andReturnValue(count);

	err = ice_vdcm_write(&mdev, buf, count, &ppos);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_rw_cfg_read)
{
	char buf[4] = {};
	int count = 4;
	loff_t ppos;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_read);
	USE_STD_MOCK(ice_vdcm_cfg_write);

	mock().expectOneCall("ice_vdcm_cfg_read")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	ppos = VFIO_PCI_INDEX_TO_OFFSET(VFIO_PCI_CONFIG_REGION_INDEX);

	err = ice_vdcm_rw(&mdev, buf, count, &ppos, false);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_rw_cfg_write)
{
	char buf[4] = {};
	int count = 4;
	loff_t ppos;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_read);
	USE_STD_MOCK(ice_vdcm_cfg_write);

	mock().expectOneCall("ice_vdcm_cfg_write")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	ppos = VFIO_PCI_INDEX_TO_OFFSET(VFIO_PCI_CONFIG_REGION_INDEX);

	err = ice_vdcm_rw(&mdev, buf, count, &ppos, true);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_rw_fail)
{
	char buf[4] = {};
	int count = 4;
	loff_t ppos;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_read);
	USE_STD_MOCK(ice_vdcm_cfg_write);

	ppos = VFIO_PCI_INDEX_TO_OFFSET(VFIO_PCI_VGA_REGION_INDEX);

	err = ice_vdcm_rw(&mdev, buf, count, &ppos, true);
	CHECK_EQUAL(-EINVAL, err);
}

TEST(ice_vdcm, ice_vdcm_cfg_read)
{
	unsigned int pos = 0;
	char buf[4] = {};
	int count = 4;
	int err;

	err = ice_vdcm_cfg_read(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_cfg_write_for_bar)
{
	unsigned int pos = PCI_BASE_ADDRESS_0;
	char buf[4] = {};
	int count = 4;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_write_bar);
	USE_STD_MOCK(ice_vdcm_cfg_write_mask);

	mock().expectOneCall("ice_vdcm_cfg_write_bar")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_cfg_write(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_cfg_write_for_mask)
{
	unsigned int pos = PCI_COMMAND;
	char buf[4] = {};
	int count = 4;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_write_bar);
	USE_STD_MOCK(ice_vdcm_cfg_write_mask);

	mock().expectOneCall("ice_vdcm_cfg_write_mask")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_cfg_write(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_cfg_write_bar)
{
	unsigned int pos = PCI_BASE_ADDRESS_0;
	char buf[4] = {};
	int count = 4;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_write_mask);

	mock().expectOneCall("ice_vdcm_cfg_write_mask")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_cfg_write_bar(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_cfg_write_mask)
{
	unsigned int off = PCI_STATUS;
	u8 buf[2] = {0xff, 0xff};
	int count = 2;
	int err;

	memcpy(ivdm.pci_cfg_space, ice_vdcm_pci_config,
	       sizeof(ice_vdcm_pci_config));

	err = ice_vdcm_cfg_write_mask(&ivdm, off, buf, count);
	CHECK_EQUAL(0, err);

	err = ice_vdcm_cfg_read(&ivdm, off, (char *)buf, count);
	CHECK_EQUAL(0, err);

	CHECK_EQUAL(0x10, buf[0]);
	CHECK_EQUAL(0x00, buf[1]);
}

TEST(ice_vdcm, ice_vdcm_rw_bar0_read)
{
	char buf[4] = {};
	int count = 4;
	loff_t ppos;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_read);
	USE_STD_MOCK(ice_vdcm_cfg_write);
	USE_STD_MOCK(ice_vdcm_bar0_read);
	USE_STD_MOCK(ice_vdcm_bar0_write);

	mock().expectOneCall("ice_vdcm_bar0_read")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	ppos = VFIO_PCI_INDEX_TO_OFFSET(VFIO_PCI_BAR0_REGION_INDEX);
	err = ice_vdcm_rw(&mdev, buf, count, &ppos, false);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_rw_bar0_write)
{
	char buf[4] = {};
	int count = 4;
	loff_t ppos;
	int err;

	USE_STD_MOCK(ice_vdcm_cfg_read);
	USE_STD_MOCK(ice_vdcm_cfg_write);
	USE_STD_MOCK(ice_vdcm_bar0_read);
	USE_STD_MOCK(ice_vdcm_bar0_write);

	mock().expectOneCall("ice_vdcm_bar0_write")
		.withParameter("ivdm", &ivdm);

	ppos = VFIO_PCI_INDEX_TO_OFFSET(VFIO_PCI_BAR0_REGION_INDEX);

	err = ice_vdcm_rw(&mdev, buf, count, &ppos, true);
	CHECK_EQUAL(count, err);
}

TEST(ice_vdcm, ice_vdcm_bar0_read)
{
	unsigned int pos = 0;
	char buf[4] = {};
	int count = 4;
	int err;

	ivdm.adi->read_reg32 = ice_adi_read_reg32;
	mock().expectOneCall("ice_adi_read_reg32")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(0);

	err = ice_vdcm_bar0_read(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_bar0_write)
{
	unsigned int pos = 0;
	char buf[4] = {};
	int count = 4;
	int err;

	ivdm.adi->write_reg32 = ice_adi_write_reg32;
	mock().expectOneCall("ice_adi_write_reg32")
		.withParameter("adi", ivdm.adi);

	err = ice_vdcm_bar0_write(&ivdm, pos, buf, count);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_vfio_device_set_irqs)
{
	struct vfio_irq_set *irq_set;
	int total_vectors = 4;
	int err = 0, argsz;
	int nr_vectors = 2;
	int32_t *fds;

	argsz = sizeof(*irq_set) + nr_vectors * sizeof(*fds);

	irq_set = (struct vfio_irq_set *)malloc(argsz);
	irq_set->argsz = argsz;
	irq_set->flags = VFIO_IRQ_SET_DATA_EVENTFD | VFIO_IRQ_SET_ACTION_TRIGGER;
	irq_set->index = VFIO_PCI_MSIX_IRQ_INDEX;
	irq_set->start = 0;
	irq_set->count = nr_vectors;
	fds = (int32_t *)&irq_set->data;

	fds[0] = 1;
	fds[1] = 2;

	USE_STD_MOCK(ice_vdcm_set_msix_trigger);

	ivdm.adi->get_vector_num = ice_adi_get_vector_num;
	mock().expectOneCall("ice_adi_get_vector_num")
		.withParameter("adi", ivdm.adi)
		.andReturnValue(total_vectors);

	mock().expectOneCall("vfio_set_irqs_validate_and_prepare")
		.andReturnValue(0);

	mock().expectOneCall("ice_vdcm_set_msix_trigger")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_vfio_device_set_irqs(&ivdm, (unsigned long)irq_set);
	CHECK_EQUAL(0, err);

	free(irq_set);
}

TEST(ice_vdcm, ice_vdcm_set_msix_trigger_1)
{
	struct vfio_irq_set irq_set = {
		.argsz = sizeof(irq_set),
		.flags = VFIO_IRQ_SET_DATA_NONE | VFIO_IRQ_SET_ACTION_TRIGGER,
		.index = VFIO_PCI_MSIX_IRQ_INDEX,
		.start = 0,
		.count = 0,
	};
	int err;

	ivdm.irq_type = VFIO_PCI_MSIX_IRQ_INDEX;
	USE_STD_MOCK(ice_vdcm_msix_enable);
	USE_STD_MOCK(ice_vdcm_msix_disable);
	USE_STD_MOCK(ice_vdcm_set_vector_signals);

	mock().expectOneCall("ice_vdcm_msix_disable")
		.withParameter("ivdm", &ivdm);

	err = ice_vdcm_set_msix_trigger(&ivdm, &irq_set, NULL);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_set_msix_trigger_2)
{
	struct vfio_irq_set irq_set = {
		.argsz = sizeof(irq_set),
		.flags = VFIO_IRQ_SET_DATA_NONE | VFIO_IRQ_SET_ACTION_TRIGGER,
		.index = VFIO_PCI_MSIX_IRQ_INDEX,
		.start = 0,
		.count = 0,
	};
	int err;

	ivdm.irq_type = VFIO_PCI_NUM_IRQS;
	USE_STD_MOCK(ice_vdcm_msix_enable);
	USE_STD_MOCK(ice_vdcm_msix_disable);
	USE_STD_MOCK(ice_vdcm_set_vector_signals);

	err = ice_vdcm_set_msix_trigger(&ivdm, &irq_set, NULL);
	CHECK_EQUAL(0, err);
}

TEST(ice_vdcm, ice_vdcm_set_msix_trigger_3)
{
	struct vfio_irq_set *irq_set;
	int err = 0, argsz;
	int nr_vectors = 2;
	int32_t *fds;

	argsz = sizeof(*irq_set) + nr_vectors * sizeof(*fds);

	irq_set = (struct vfio_irq_set *)malloc(argsz);
	irq_set->argsz = argsz;
	irq_set->flags = VFIO_IRQ_SET_DATA_EVENTFD | VFIO_IRQ_SET_ACTION_TRIGGER;
	irq_set->index = VFIO_PCI_MSIX_IRQ_INDEX;
	irq_set->start = 0;
	irq_set->count = nr_vectors;
	fds = (int32_t *)&irq_set->data;

	fds[0] = 1;
	fds[1] = 2;

	ivdm.irq_type = VFIO_PCI_MSIX_IRQ_INDEX;
	USE_STD_MOCK(ice_vdcm_msix_enable);
	USE_STD_MOCK(ice_vdcm_msix_disable);
	USE_STD_MOCK(ice_vdcm_set_vector_signals);

	mock().expectOneCall("ice_vdcm_set_vector_signals")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	err = ice_vdcm_set_msix_trigger(&ivdm, irq_set, &irq_set->data);
	CHECK_EQUAL(0, err);

	free(irq_set);
}

TEST(ice_vdcm, ice_vdcm_set_msix_trigger_4)
{
	struct vfio_irq_set *irq_set;
	int err = 0, argsz;
	int nr_vectors = 2;
	int32_t *fds;

	argsz = sizeof(*irq_set) + nr_vectors * sizeof(*fds);

	irq_set = (struct vfio_irq_set *)malloc(argsz);
	irq_set->argsz = argsz;
	irq_set->flags = VFIO_IRQ_SET_DATA_EVENTFD | VFIO_IRQ_SET_ACTION_TRIGGER;
	irq_set->index = VFIO_PCI_MSIX_IRQ_INDEX;
	irq_set->start = 0;
	irq_set->count = nr_vectors;
	fds = (int32_t *)&irq_set->data;

	fds[0] = 1;
	fds[1] = 2;

	ivdm.irq_type = VFIO_PCI_NUM_IRQS;
	USE_STD_MOCK(ice_vdcm_msix_enable);
	USE_STD_MOCK(ice_vdcm_msix_disable);
	USE_STD_MOCK(ice_vdcm_set_vector_signals);

	mock().expectOneCall("ice_vdcm_msix_enable")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(0);

	mock().expectOneCall("ice_vdcm_set_vector_signals")
		.withParameter("ivdm", &ivdm)
		.andReturnValue(-EINVAL);

	mock().expectOneCall("ice_vdcm_msix_disable")
		.withParameter("ivdm", &ivdm);

	err = ice_vdcm_set_msix_trigger(&ivdm, irq_set, &irq_set->data);
	CHECK_EQUAL(-EINVAL, err);

	free(irq_set);
}
#endif /* SIOV_SUPPORT */
