#ifndef _TDD_FW_OBJECT_H_
#define _TDD_FW_OBJECT_H_

TEST_BASE(load_fw_object)
{
	struct firmware fw;

	void tdd_load_fw(const char *filename, bool increase_map_size)
	{
		const size_t large_map_size = 10*1024*1024;
		FILE *pldm_fw_file;
		const u8 *pldm_fw_data;
		size_t pldm_fw_size;

		pldm_fw_file = fopen(filename, "rb");
		if (!pldm_fw_file)
			FAIL(StringFromFormat("Unable to open `%s` test fw file", filename).asCharString());

		fseek(pldm_fw_file, 0L, SEEK_END);
		pldm_fw_size = ftell(pldm_fw_file);
		rewind(pldm_fw_file);

		pldm_fw_data = (const u8 *)mmap(NULL, pldm_fw_size, PROT_READ,
						MAP_PRIVATE, fileno(pldm_fw_file), 0);
		if (pldm_fw_data == MAP_FAILED)
			FAIL(StringFromFormat("Unable to memory map the `%s` test fw file", filename).asCharString());

		fclose(pldm_fw_file);

		if (increase_map_size && pldm_fw_size < large_map_size) {
			u8 *large_map_data;

			large_map_data = (u8 *)mmap(NULL, large_map_size, PROT_WRITE,
						    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
			if (large_map_data == MAP_FAILED)
				FAIL("Unable to memory map large block of data");

			/* Copy the original data over, then replace it */
			memcpy(large_map_data, pldm_fw_data, pldm_fw_size);

			munmap((void *)pldm_fw_data, pldm_fw_size);

			pldm_fw_data = large_map_data;
			pldm_fw_size = large_map_size;
		}

		fw.size = pldm_fw_size;
		fw.data = pldm_fw_data;
	}

	void tdd_load_fw(const char *filename)
	{
		tdd_load_fw(filename, true);
	}

	TEST_SETUP()
	{
		memset(&fw, 0, sizeof(fw));
	}

	TEST_TEARDOWN()
	{
		if (fw.data)
			munmap((void *)fw.data, fw.size);
		fw.data = NULL;
		fw.size = 0;
	}
};

#endif
