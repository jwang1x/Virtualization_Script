#ifdef DCF_SUPPORT
#include "ice_utest.h"

/////////////////////////////////////////////////
namespace ns_dcf {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"

#include "../src/CORE/ice.h"

#include "SHARED_MOCKS/mock_ice_common.cpp"
#include "SHARED_MOCKS/mock_ice_switch.cpp"
#include "SHARED_MOCKS/mock_ice_acl.cpp"
#include "SHARED_MOCKS/mock_ice_controlq.cpp"
#include "SHARED_MOCKS/mock_ice_flex_pipe.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"

#include "../src/CORE/ice_dcf.c"
}
/////////////////////////////////////////////////
using namespace ns_dcf;

TEST_GROUP(dcf_switch_rule_grp)
{
	struct ice_aqc_alloc_free_res_elem *res_buf;
	struct ice_aqc_sw_rules_elem *s_rule_list;
	struct ice_pf *pf;
	struct ice_vf *vf;

	void setup(void)
	{
		u16 len;

		len = ice_struct_size(res_buf, elem, 1);
		res_buf = (struct ice_aqc_alloc_free_res_elem*) calloc(1, len);

		len = (u16)ICE_SW_RULE_VSI_LIST_SIZE(2);
		s_rule_list = (struct ice_aqc_sw_rules_elem *) calloc(1, len);

		pf = (struct ice_pf*) calloc(1, sizeof(*pf));
		vf = (struct ice_vf*) calloc(1, sizeof(*vf));

		vf->pf = pf;

		ice_dcf_init_sw_rule_mgmt(pf);
	}

	void teardown(void)
	{
		ice_rm_all_dcf_sw_rules(pf);

		free(res_buf);
		free(s_rule_list);
		free(vf);
		free(pf);
	}
};

TEST(dcf_switch_rule_grp, dcf_handle_switch_rule_to_vsi)
{
	struct ice_dcf_sw_rule_entry *sw_entry;
	struct ice_aqc_sw_rules_elem s_rule;
	struct ice_aq_desc desc;
	u32 act;
	int ret;

	/* 1. add the switch rule with ID '100' to VSI ID '21' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_add_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	act = (21 << ICE_SINGLE_ACT_VSI_ID_S) & ICE_SINGLE_ACT_VSI_ID_M;
	act |= ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	s_rule.pdata.lkup_tx_rx.act = cpu_to_le32(act);
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.sw_rule_head));

	sw_entry = list_first_entry(&pf->dcf.sw_rule_head,
				    struct ice_dcf_sw_rule_entry, list_entry);
	CHECK_EQUAL(100, sw_entry->rule_id);
	CHECK_EQUAL(ICE_FWD_TO_VSI,sw_entry->fltr_act);
	CHECK_EQUAL(21, sw_entry->fwd_id.hw_vsi_id);

	/* 2. remove the switch rule with ID '100' to VSI ID '21' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_remove_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(list_empty(&pf->dcf.sw_rule_head));
}

TEST(dcf_switch_rule_grp, dcf_handle_switch_rule_to_vsi_with_auto_clean)
{
	struct ice_dcf_sw_rule_entry *sw_entry;
	struct ice_aqc_sw_rules_elem s_rule;
	struct ice_aq_desc desc;
	u32 act;
	int ret;

	/* 1. add the switch rule with ID '100' to VSI ID '21' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_add_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	act = (21 << ICE_SINGLE_ACT_VSI_ID_S) & ICE_SINGLE_ACT_VSI_ID_M;
	act |= ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	s_rule.pdata.lkup_tx_rx.act = cpu_to_le32(act);
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.sw_rule_head));

	sw_entry = list_first_entry(&pf->dcf.sw_rule_head,
				    struct ice_dcf_sw_rule_entry, list_entry);
	CHECK_EQUAL(100, sw_entry->rule_id);
	CHECK_EQUAL(ICE_FWD_TO_VSI,sw_entry->fltr_act);
	CHECK_EQUAL(21, sw_entry->fwd_id.hw_vsi_id);

	/* 2. remove the switch rule when exits */
	mock().expectOneCall("ice_aq_sw_rules")
		.ignoreOtherParameters()
		.andReturnValue(ICE_SUCCESS);
}

TEST(dcf_switch_rule_grp, dcf_handle_vsi_list_info)
{
	struct ice_dcf_vsi_list_info *vsi_list_info;
	struct ice_aq_desc desc;
	int ret;

	/* 1. add the empty list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_alloc_res);

	res_buf->res_type = cpu_to_le16(ICE_AQC_RES_TYPE_VSI_LIST_REP << ICE_AQC_RES_TYPE_S);
	res_buf->num_elems = cpu_to_le16(1);
	res_buf->elem[0].e.sw_resp = cpu_to_le16(200);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)res_buf);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.vsi_list_info_head));

	vsi_list_info = list_first_entry(&pf->dcf.vsi_list_info_head,
					 struct ice_dcf_vsi_list_info, list_entry);
	CHECK_EQUAL(200, vsi_list_info->list_id);
	CHECK_EQUAL(0, vsi_list_info->vsi_count);

	/* 2. remove the empty list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_free_res);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)res_buf);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(list_empty(&pf->dcf.vsi_list_info_head));
}

TEST(dcf_switch_rule_grp, dcf_handle_vsi_list_info_with_auto_clean)
{
	struct ice_dcf_vsi_list_info *vsi_list_info;
	struct ice_aq_desc desc;
	int ret;

	/* 1. add the empty list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_alloc_res);

	res_buf->res_type = cpu_to_le16(ICE_AQC_RES_TYPE_VSI_LIST_REP << ICE_AQC_RES_TYPE_S);
	res_buf->num_elems = cpu_to_le16(1);
	res_buf->elem[0].e.sw_resp = cpu_to_le16(200);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)res_buf);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.vsi_list_info_head));

	vsi_list_info = list_first_entry(&pf->dcf.vsi_list_info_head,
					 struct ice_dcf_vsi_list_info, list_entry);
	CHECK_EQUAL(200, vsi_list_info->list_id);
	CHECK_EQUAL(0, vsi_list_info->vsi_count);

	/* 2. remove the empty list when exits */
}

TEST(dcf_switch_rule_grp, dcf_handle_switch_rule_to_vsi_list)
{
	struct ice_dcf_vsi_list_info *vsi_list_info;
	struct ice_dcf_sw_rule_entry *sw_entry;
	struct ice_aqc_sw_rules_elem s_rule;
	struct ice_aq_desc desc;
	u32 act;
	int ret;

	/* 1. add the switch rule with ID '100' to VSI ID '21' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_add_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	act = (21 << ICE_SINGLE_ACT_VSI_ID_S) & ICE_SINGLE_ACT_VSI_ID_M;
	act |= ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	s_rule.pdata.lkup_tx_rx.act = cpu_to_le32(act);
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.sw_rule_head));

	sw_entry = list_first_entry(&pf->dcf.sw_rule_head,
				    struct ice_dcf_sw_rule_entry, list_entry);
	CHECK_EQUAL(100, sw_entry->rule_id);
	CHECK_EQUAL(ICE_FWD_TO_VSI,sw_entry->fltr_act);
	CHECK_EQUAL(21, sw_entry->fwd_id.hw_vsi_id);

	/* 2. add the empty list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_alloc_res);

	res_buf->res_type = cpu_to_le16(ICE_AQC_RES_TYPE_VSI_LIST_REP << ICE_AQC_RES_TYPE_S);
	res_buf->num_elems = cpu_to_le16(1);
	res_buf->elem[0].e.sw_resp = cpu_to_le16(200);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)res_buf);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(!list_empty(&pf->dcf.vsi_list_info_head));

	vsi_list_info = list_first_entry(&pf->dcf.vsi_list_info_head,
					 struct ice_dcf_vsi_list_info, list_entry);
	CHECK_EQUAL(200, vsi_list_info->list_id);
	CHECK_EQUAL(0, vsi_list_info->vsi_count);

	/* 3. set the two VSIs with ID '21' and '22' to the list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_add_sw_rules);

	s_rule_list->type = ICE_AQC_SW_RULES_T_VSI_LIST_SET;
	s_rule_list->pdata.vsi_list.index = cpu_to_le16(200);
	s_rule_list->pdata.vsi_list.number_vsi = cpu_to_le16(2);
	s_rule_list->pdata.vsi_list.vsi[0] = cpu_to_le16(21);
	s_rule_list->pdata.vsi_list.vsi[1] = cpu_to_le16(22);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)s_rule_list);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(2, vsi_list_info->vsi_count);
	CHECK(test_bit(21, vsi_list_info->hw_vsi_map));
	CHECK(test_bit(22, vsi_list_info->hw_vsi_map));

	/* 4. update the switch rule with ID '100' to the list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_update_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	act = (200 << ICE_SINGLE_ACT_VSI_LIST_ID_S) & ICE_SINGLE_ACT_VSI_LIST_ID_M;
	act |= ICE_SINGLE_ACT_VSI_LIST | ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	s_rule.pdata.lkup_tx_rx.act = cpu_to_le32(act);
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(100, sw_entry->rule_id);
	CHECK_EQUAL(ICE_FWD_TO_VSI_LIST,sw_entry->fltr_act);
	CHECK_EQUAL(200, sw_entry->fwd_id.vsi_list_id);

	/* 5. clear the VSIs from the list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_update_sw_rules);

	s_rule_list->type = ICE_AQC_SW_RULES_T_VSI_LIST_CLEAR;

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)s_rule_list);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(0, vsi_list_info->vsi_count);
	CHECK(!test_bit(21, vsi_list_info->hw_vsi_map));
	CHECK(!test_bit(22, vsi_list_info->hw_vsi_map));

	/* 6. update the switch rule with ID '100' to the VSI with ID '22' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_update_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	act = (22 << ICE_SINGLE_ACT_VSI_ID_S) & ICE_SINGLE_ACT_VSI_ID_M;
	act |= ICE_SINGLE_ACT_VSI_FORWARDING | ICE_SINGLE_ACT_VALID_BIT;
	s_rule.pdata.lkup_tx_rx.act = cpu_to_le32(act);
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK_EQUAL(ICE_FWD_TO_VSI,sw_entry->fltr_act);
	CHECK_EQUAL(22, sw_entry->fwd_id.hw_vsi_id);

	/* 7. remove the empty list with ID '200' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_free_res);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)res_buf);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(list_empty(&pf->dcf.vsi_list_info_head));

	/* 8. remove the switch rule with ID '100' to VSI ID '22' */
	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_remove_sw_rules);

	ice_memset(&s_rule, 0, sizeof(s_rule), ICE_NONDMA_MEM);
	s_rule.type = ICE_AQC_SW_RULES_T_LKUP_RX;
	s_rule.pdata.lkup_tx_rx.index = cpu_to_le16(100);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)&s_rule);
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);
	CHECK(list_empty(&pf->dcf.sw_rule_head));
}

static const ice_tunnel_type tnl_types[] = {
	TNL_VXLAN,
	TNL_GENEVE,
	TNL_LAST
};

static void ice_init_tnl_tbl(struct ice_hw *hw)
{
	int i;

	memset(&hw->tnl, 0, sizeof(hw->tnl));
	for (i = 0; tnl_types[i] != TNL_LAST; i++) {
		hw->tnl.tbl[hw->tnl.count].type = tnl_types[i];
		hw->tnl.tbl[hw->tnl.count].valid = true;
		hw->tnl.tbl[hw->tnl.count].in_use = false;
		hw->tnl.tbl[hw->tnl.count].marked = false;
		hw->tnl.tbl[hw->tnl.count].boost_addr = i;
		hw->tnl.tbl[hw->tnl.count].port = 0;
		hw->tnl.count++;
	}
};

#define ICE_ALIGN(ptr, align)	(((ptr) + ((align) - 1)) & ~((align) - 1))
enum ice_status
ice_pkg_buf_reserve_section(struct ice_buf_build *bld, u16 count)
{
	struct ice_buf_hdr *buf;
	u16 section_count;
	u16 data_end;

	if (!bld)
		return ICE_ERR_PARAM;

	buf = (struct ice_buf_hdr *)&bld->buf;

	/* already an active section, can't increase table size */
	section_count = LE16_TO_CPU(buf->section_count);
	if (section_count > 0)
		return ICE_ERR_CFG;

	if (bld->reserved_section_table_entries + count > ICE_MAX_S_COUNT)
		return ICE_ERR_CFG;
	bld->reserved_section_table_entries += count;

	data_end = LE16_TO_CPU(buf->data_end) +
		FLEX_ARRAY_SIZE(buf, section_entry, count);
	buf->data_end = CPU_TO_LE16(data_end);

	return ICE_SUCCESS;
}

void *
ice_pkg_buf_alloc_section(struct ice_buf_build *bld, u32 type, u16 size)
{
	struct ice_buf_hdr *buf;
	u16 sect_count;
	u16 data_end;

	if (!bld || !type || !size)
		return NULL;

	buf = (struct ice_buf_hdr *)&bld->buf;

	/* check for enough space left in buffer */
	data_end = LE16_TO_CPU(buf->data_end);

	/* section start must align on 4 byte boundary */
	data_end = ICE_ALIGN(data_end, 4);

	if ((data_end + size) > ICE_MAX_S_DATA_END)
		return NULL;

	/* check for more available section table entries */
	sect_count = LE16_TO_CPU(buf->section_count);
	if (sect_count < bld->reserved_section_table_entries) {
		void *section_ptr = ((u8 *)buf) + data_end;

		buf->section_entry[sect_count].offset = CPU_TO_LE16(data_end);
		buf->section_entry[sect_count].size = CPU_TO_LE16(size);
		buf->section_entry[sect_count].type = CPU_TO_LE32(type);

		data_end += size;
		buf->data_end = CPU_TO_LE16(data_end);

		buf->section_count = CPU_TO_LE16(sect_count + 1);
		return section_ptr;
	}

	/* no free section table entries */
	return NULL;
}

TEST_GROUP(dcf_udp_tunnel_grp)
{
	struct ice_boost_tcam_section *sect_rx, *sect_tx;
	struct ice_buf_hdr *pkg_buf;
	struct ice_buf_build *bld;
	struct ice_hw *hw;
	struct ice_pf *pf;
	struct ice_vf *vf;

	void setup(void)
	{
		pf = (struct ice_pf*) calloc(1, sizeof(*pf));
		vf = (struct ice_vf*) calloc(1, sizeof(*vf));
		pf->hw.hw_addr = (unsigned char *) calloc(1, sizeof(unsigned char) * 0x1000000);
		hw = &pf->hw;
		hw->back = pf;

		vf->pf = pf;
		ice_init_tnl_tbl(hw);
		ice_init_lock(&hw->tnl_lock);
		bld = (struct ice_buf_build *)calloc(1, sizeof(*bld));

		pkg_buf = (struct ice_buf_hdr *)bld;
		pkg_buf->data_end = CPU_TO_LE16(offsetof(struct ice_buf_hdr,
							 section_entry));
		ice_pkg_buf_reserve_section(bld, 2);

		sect_rx = (struct ice_boost_tcam_section *)
			ice_pkg_buf_alloc_section(bld, ICE_SID_RXPARSER_BOOST_TCAM,
						  ice_struct_size(sect_rx, tcam, 1));
		sect_rx->count = CPU_TO_LE16(1);

		sect_tx = (struct ice_boost_tcam_section *)
			ice_pkg_buf_alloc_section(bld, ICE_SID_TXPARSER_BOOST_TCAM,
						  ice_struct_size(sect_tx, tcam, 1));
		sect_tx->count = CPU_TO_LE16(1);
	}

	void teardown(void)
	{
		free(bld);
		ice_destroy_lock(&hw->tnl_lock);
		free(pf->hw.hw_addr);
		free(vf);
		free(pf);
	}
};

TEST(dcf_udp_tunnel_grp, dcf_handle_udp_tunnel)
{
	struct ice_aq_desc desc;
	int ret;

	/* create VXLAN tunnel with port 1111 */
	sect_rx->tcam[0].addr = 0;
	sect_rx->tcam[0].key.key.hv_dst_port_key = 64424;

	sect_rx->tcam[0].addr = 0;
	sect_rx->tcam[0].key.key2.hv_dst_port_key = 1111;

	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_update_pkg);
	desc.flags |= CPU_TO_LE16(ICE_AQ_FLAG_RD);

	mock().expectOneCall("ice_is_tunnel_empty")
		.ignoreOtherParameters()
		.andReturnValue(false);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)(&(bld->buf)));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);

	CHECK_EQUAL(true, hw->tnl.tbl[0].in_use);
	CHECK_EQUAL(1111, hw->tnl.tbl[0].port);
	CHECK_EQUAL(TNL_VXLAN, hw->tnl.tbl[0].type);
	CHECK_EQUAL(DCF_UDP_TUNNEL_CAP, hw->dcf_caps & DCF_UDP_TUNNEL_CAP);

	/* destroy VXLAN tunnel with port 1111 */
	sect_rx->tcam[0].addr = 0;
	sect_rx->tcam[0].key.key.hv_dst_port_key = 65297;

	sect_rx->tcam[0].addr = 0;
	sect_rx->tcam[0].key.key2.hv_dst_port_key = 65297;

	ice_fill_dflt_direct_cmd_desc(&desc, ice_aqc_opc_update_pkg);
	desc.flags |= CPU_TO_LE16(ICE_AQ_FLAG_RD);

	mock().expectOneCall("ice_is_tunnel_empty")
		.ignoreOtherParameters()
		.andReturnValue(true);

	ret = ice_dcf_post_aq_send_cmd(pf, &desc, (u8 *)(&(bld->buf)));
	CHECK_EQUAL(VIRTCHNL_STATUS_SUCCESS, ret);

	CHECK_EQUAL(false, hw->tnl.tbl[0].in_use);
	CHECK_EQUAL(0, hw->tnl.tbl[0].port);
	CHECK_EQUAL(0, hw->dcf_caps & DCF_UDP_TUNNEL_CAP);
}
#endif
