#ifndef NO_DCB_SUPPORT
#include "ice_utest.h"

#define KBUILD_MODNAME "ice_test"
#define HAVE_DCBNL_OPS_SETAPP_RETURN_INT

/////////////////////////////////////////////////
namespace ns_dcb_nl {
#include "tdd_shared_code_transform.h"
#include "../src/SHARED/ice_alloc.h"
#include "../src/SHARED/ice_status.h"
#include "ice_osdep.h"
#include "kernel_abstract.h"
#include <linux/device.h>
#include <linux/netdevice.h>
#include <net/dcbnl.h>

#include "../src/CORE/ice.h"

#include "KERNEL_MOCKS/mock_kernel.cpp"
#include "SHARED_MOCKS/mock_ice_dcb.cpp"
#include "CORE_MOCKS/mock_ice_main.cpp"
#include "CORE_MOCKS/mock_ice_lib.cpp"
#include "CORE_MOCKS/mock_ice_base.cpp"
#include "CORE_MOCKS/mock_ice_dcb_lib.cpp"
#include "../src/CORE/ice_dcb_nl.c"
}
/////////////////////////////////////////////////
using namespace ns_dcb_nl;

int ice_pf_dcb_cfg(struct ice_pf *pf, struct ice_dcbxcfg *new_cfg)
{
	mock().actualCall(__func__);
	return mock().returnIntValueOrDefault(0);
}

struct test_hw {
	/* 8MB of 32 bits each */
	uint32_t reg[2 * 1024 * 1024];
};

TEST_GROUP(ice_dcb_nl)
{
	struct net_device *netdev;
	struct ice_netdev_priv *np;
	struct ice_pf *pf;
	struct pci_dev *pdev;
	struct ice_vsi **vsi_list;
	struct ice_vsi *vsi;
	struct ice_port_info *pi;

	void setup(void)
	{
		pf = (struct ice_pf *)calloc(1, sizeof(struct ice_pf));
		pdev = (__typeof__(pdev))calloc(1, sizeof(*pdev));
		vsi_list = (struct ice_vsi **)calloc(1, sizeof(ice_vsi *));
		vsi = (struct ice_vsi *)calloc(1, sizeof(struct ice_vsi));
		pi = (struct ice_port_info *)
		    calloc(1, sizeof(struct ice_port_info));

		netdev = alloc_etherdev_mqs(sizeof(struct ice_netdev_priv), 1, 1);
		np = netdev_priv(netdev);
		np->vsi = vsi;
		vsi->netdev = netdev;
		vsi->back = pf;
		vsi_list[0] = vsi;
		pf->vsi = vsi_list;
		pf->hw.port_info = pi;
		pf->hw.hw_addr = (u8 *)calloc(1, sizeof(struct test_hw));
		pf->pdev = pdev;

		mutex_init(&pf->tc_mutex);
	}

	void teardown(void)
	{
		mock().checkExpectations();
		mock().clear();

		mutex_destroy(&pf->tc_mutex);

		free(pf->hw.hw_addr);
		free(pi);
		free(vsi);
		free(vsi_list);
		free(pf);
		free(pdev);
		free_netdev(netdev);
	}
};

TEST(ice_dcb_nl, ice_dcbnl_setup)
{
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.numapps = 1;
	set_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);
	set_bit(ICE_FLAG_DCB_ENA, pf->flags);

	ice_dcbnl_setup(vsi);
}

TEST(ice_dcb_nl, ice_dcbnl_getets)
{
	struct ieee_ets *ets;
	int ret = 0;

	ets = (struct ieee_ets *)calloc(1, sizeof(struct ieee_ets));

	ret = ice_dcbnl_getets(netdev, ets);
	CHECK_EQUAL(0, ret);

	free(ets);
}

TEST(ice_dcb_nl, ice_dcbnl_getpfc)
{
	struct ieee_pfc *pfc;
	int ret;

	pfc = (struct ieee_pfc *)calloc(1, sizeof(struct ieee_pfc));
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.pfc.pfccap = 0x1;
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.pfc.pfcena = 0x1;
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.pfc.mbc = 0x1;
	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;

	ret = ice_dcbnl_getpfc(netdev, pfc);
	CHECK_EQUAL(0, ret);

	free(pfc);
}

TEST(ice_dcb_nl, ice_dcbnl_getstate)
{
	int ret;

	ret = ice_dcbnl_getstate(netdev);
	CHECK_EQUAL(0, ret);
	set_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);
	ret = ice_dcbnl_getstate(netdev);
	CHECK_EQUAL(1, ret);
}

TEST(ice_dcb_nl, ice_dcbnl_getnumtcs)
{
	int ret, tcid = 0;
	u8 number = 0;

	clear_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);
	ret = ice_dcbnl_getnumtcs(netdev, tcid, &number);
	CHECK_EQUAL(-EINVAL, ret);

	set_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);
	ret = ice_dcbnl_getnumtcs(netdev, tcid, &number);
	CHECK_EQUAL(0, ret);

	CHECK_EQUAL(0, number);
}

TEST(ice_dcb_nl, ice_dcbnl_getdcbx)
{
	u8 ret;

	ret = ice_dcbnl_getdcbx(netdev);
	CHECK_EQUAL(ret, 0);

	pf->dcbx_cap = IEEE_8021QAZ_MAX_TCS;
	ret = ice_dcbnl_getdcbx(netdev);
	CHECK_EQUAL(ret, IEEE_8021QAZ_MAX_TCS);
}

TEST(ice_dcb_nl, ice_dcbnl_get_perm_hw_addr)
{
	int i, a_len = ETH_ALEN;
	u8 perm_addr[MAX_ADDR_LEN];

	netdev->addr_len = a_len;
	for (i = 0; i < a_len; i++)
		pi->mac.perm_addr[i] = 0xEE;
	ice_dcbnl_get_perm_hw_addr(netdev, perm_addr);
	for (i = 0; i < a_len; i++)
		CHECK_EQUAL(perm_addr[i], 0xEE);
	for (i = a_len; i < (a_len * 2); i++)
		CHECK_EQUAL(perm_addr[i], 0xEE);
}

TEST(ice_dcb_nl, ice_dcbnl_get_pfc_cfg)
{
	int prio = 1;
	u8 setting = 0;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	pi->qos_cfg.local_dcbx_cfg.pfc.pfcena = 0xFF;
	ice_dcbnl_get_pfc_cfg(netdev, prio, &setting);
	CHECK_EQUAL(1, setting);
}

TEST(ice_dcb_nl, ice_dcbnl_getpfcstate)
{
	u8 state;

	pi->qos_cfg.local_dcbx_cfg.pfc.pfcena = 0xFF;
	state = ice_dcbnl_getpfcstate(netdev);
	CHECK_EQUAL(1, state);
}

TEST(ice_dcb_nl, ice_dcbnl_get_pg_tc_cfg_tx)
{
	u8 prio_type = 0, pgid = 0, bw_pct = 0, up_map = 0;
	int prio = 1;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	pi->qos_cfg.local_dcbx_cfg.etscfg.prio_table[prio] = 0xFF;

	ice_dcbnl_get_pg_tc_cfg_tx(netdev, prio, &prio_type, &pgid, &bw_pct,
				   &up_map);
	CHECK_EQUAL(0xFF, pgid);
}

TEST(ice_dcb_nl, ice_dcbnl_get_pg_bwg_cfg_tx)
{
	int pgid = 1;
	u8 bw_pct = 0;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	pi->qos_cfg.local_dcbx_cfg.etscfg.tcbwtable[pgid] = 50;

	ice_dcbnl_get_pg_bwg_cfg_tx(netdev, pgid, &bw_pct);
	CHECK_EQUAL(50, bw_pct);
}

TEST(ice_dcb_nl, ice_dcbnl_get_pg_tc_cfg_rx)
{
	int prio = 1;
	u8 prio_type = 0, pgid = 0, bw_pct = 0, up_map = 0;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	pi->qos_cfg.local_dcbx_cfg.etscfg.prio_table[prio] = 0xFF;

	ice_dcbnl_get_pg_tc_cfg_rx(netdev, prio, &prio_type, &pgid, &bw_pct,
				   &up_map);
	CHECK_EQUAL(0xFF, pgid);
}

TEST(ice_dcb_nl, ice_dcbnl_get_pg_bwg_cfg_rx)
{
	int pgid = 1;
	u8 bw_pct = 0;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;

	ice_dcbnl_get_pg_bwg_cfg_rx(netdev, pgid, &bw_pct);
	CHECK_EQUAL(0, bw_pct);
}

TEST(ice_dcb_nl, ice_dcbnl_get_cap)
{
	int capid;
	u8 cap = 0, ret;

	clear_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);

	capid = DCB_CAP_ATTR_PG;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(1, ret);

	set_bit(ICE_FLAG_DCB_CAPABLE, pf->flags);

	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(true, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_PFC;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(true, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_UP2TC;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(false, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_PG_TCS;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(0x80, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_PFC_TCS;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(0x80, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_GSP;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(false, cap);
	CHECK_EQUAL(0, ret);

	capid = DCB_CAP_ATTR_BCN;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(false, cap);
	CHECK_EQUAL(0, ret);

	pf->dcbx_cap = 0xFF;
	capid = DCB_CAP_ATTR_DCBX;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(0xFF, cap);
	CHECK_EQUAL(0, ret);

	capid = -1;
	ret = ice_dcbnl_get_cap(netdev, capid, &cap);
	CHECK_EQUAL(false, cap);
	CHECK_EQUAL(0, ret);
}

TEST(ice_dcb_nl, ice_dcbnl_getapp)
{
	u8 idtype = 0x01;
	int ret;
	u16 id = 0xFFFF;

	pf->dcbx_cap = 0;
	mock().expectOneCall("dcb_getapp");
	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	ret = ice_dcbnl_getapp(netdev, idtype, id);
	CHECK_EQUAL(0, ret);
}

TEST(ice_dcb_nl, ice_dcbnl_setets)
{
	struct ieee_ets *ets;
	int ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;

	ets = (struct ieee_ets *)calloc(1, sizeof(struct ieee_ets));
	ets->willing = 0x1;
	ets->ets_cap = ICE_MAX_TRAFFIC_CLASS;
	ets->cbs = 0x1;
	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("ice_dcb_bwchk");
	mock().expectOneCall("ice_pf_dcb_cfg");

	ret = ice_dcbnl_setets(netdev, ets);
	CHECK_EQUAL(0, ret);
	free(ets);
}

TEST(ice_dcb_nl, ice_dcbnl_setpfc)
{
	struct ieee_pfc *pfc;
	int ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;

	mock().expectOneCall("ice_is_reset_in_progress");
	mock().expectOneCall("ice_pf_dcb_cfg");
	pfc = (struct ieee_pfc *)calloc(1, sizeof(struct ieee_pfc));
	pfc->pfc_cap = 0x4;
	pfc->pfc_en = 0xF;

	ret = ice_dcbnl_setpfc(netdev, pfc);
	CHECK_EQUAL(0, ret);
	free(pfc);
}

TEST(ice_dcb_nl, ice_dcbnl_setapp_vlan)
{
	struct dcb_app *app;
	int ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;

	app = (struct dcb_app *)calloc(1, sizeof(struct dcb_app));
	app->selector = 0x1;
	app->protocol = 0x8906;
	app->priority = 0x1;

	ret = ice_dcbnl_setapp(netdev, app);
	CHECK_EQUAL(-22, ret);
	free(app);
}

TEST(ice_dcb_nl, ice_dcbnl_delapp_vlan)
{
	struct dcb_app *app;
	int ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;

	app = (struct dcb_app *)calloc(1, sizeof(struct dcb_app));
	app->selector = 0x1;
	app->protocol = 0x8906;
	app->priority = 0x1;

	pf->hw.port_info->qos_cfg.local_dcbx_cfg.numapps = 2;
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.app[1].selector = 0x1;
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.app[1].prot_id = 0x8906;
	pf->hw.port_info->qos_cfg.local_dcbx_cfg.app[1].priority = 0x1;

	pf->hw.port_info->qos_cfg.desired_dcbx_cfg.numapps = 2;
	pf->hw.port_info->qos_cfg.desired_dcbx_cfg.app[1].selector = 0x1;
	pf->hw.port_info->qos_cfg.desired_dcbx_cfg.app[1].prot_id = 0x8906;
	pf->hw.port_info->qos_cfg.desired_dcbx_cfg.app[1].priority = 0x1;

	ret = ice_dcbnl_delapp(netdev, app);
	CHECK_EQUAL(2, ret);
	free(app);
}

TEST(ice_dcb_nl, ice_dcbnl_setstate)
{
	u8 state, ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	set_bit(ICE_FLAG_DCB_ENA, pf->flags);

	state = 0;
	ret = ice_dcbnl_setstate(netdev, state);
	CHECK_EQUAL(2, ret);

	state = 1;
	ret = ice_dcbnl_setstate(netdev, state);
	CHECK_EQUAL(2, ret);
}

TEST(ice_dcb_nl, ice_dcbnl_setdcbx)
{
	u8 ret, mode;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_IEEE;
	mode = DCB_CAP_DCBX_VER_CEE | DCB_CAP_DCBX_HOST;

	ret = ice_dcbnl_setdcbx(netdev, mode);
	CHECK_EQUAL(0, ret);
}

TEST(ice_dcb_nl, ice_dcbnl_set_pfc_cfg)
{
	int prio;
	u8 set;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	prio = 3;
	set = 0x1;

	ice_dcbnl_set_pfc_cfg(netdev, prio, set);
}

TEST(ice_dcb_nl, ice_dcbnl_set_pg_tc_cfg_tx)
{
	u8 prio_type, bwg_id, bw_pct, up_map;
	int tc;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	tc = 3;
	up_map = 0x3;
	prio_type = 0x1;
	bwg_id = 0x1;
	bw_pct = 0xF;

	ice_dcbnl_set_pg_tc_cfg_tx(netdev, tc, prio_type, bwg_id, bw_pct,
				   up_map);

}

TEST(ice_dcb_nl, ice_dcbnl_set_pg_bwg_cfg_tx)
{
	u8 bw_pct;
	int pgid;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;
	pgid = 3;
	bw_pct = 0xF;

	ice_dcbnl_set_pg_bwg_cfg_tx(netdev, pgid, bw_pct);
}

TEST(ice_dcb_nl, ice_dcbnl_set_pg_tc_cfg_rx)
{
	u8 prio_type, pgid, bw_pct, up_map;
	int prio;

	prio_type = 0;
	pgid = 0;
	bw_pct = 0;
	up_map = 0;
	prio = 0;

	ice_dcbnl_set_pg_tc_cfg_rx(netdev, prio, prio_type, pgid, bw_pct,
				   up_map);

}

TEST(ice_dcb_nl, ice_dcbnl_set_pg_bwg_cfg_rx)
{
	u8 bw_pct;
	int pgid;

	pgid = 3;
	bw_pct = 0xF;

	ice_dcbnl_set_pg_bwg_cfg_rx(netdev, pgid, bw_pct);
}

TEST(ice_dcb_nl, ice_dcbnl_cee_set_all)
{
	u8 ret;

	pf->dcbx_cap = DCB_CAP_DCBX_VER_CEE;

	mock().expectOneCall("ice_pf_dcb_cfg");

	ret = ice_dcbnl_cee_set_all(netdev);
	CHECK_EQUAL(0, ret);
}
#endif
