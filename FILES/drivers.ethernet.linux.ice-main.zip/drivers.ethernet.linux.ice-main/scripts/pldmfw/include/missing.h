#ifndef _ANALYZE_PLDM_HEADER_MISSING_H_
#define _ANALYZE_PLDM_HEADER_MISSING_H_

/* Assume Little Endian */
#define __BYTE_ORDER __LITTLE_ENDIAN

/* The only user of IS_ENABLED in this code checks CONFIG_PLDMFW and we want
 * this check to be skipped, so just define IS_ENABLED to 0.
 */
#define IS_ENABLED(x) (0)

#define PCI_ANY_ID (~0)

#define kzalloc(size, gfp) calloc(1, size)
#define kmalloc(size, gfp) calloc(1, size)
#define kcalloc(n, size, gfp) calloc(n, size)
#define kfree(ptr) free(ptr)

#define BIT(nr) (1UL << (nr))

#define BIT_WORD(nr)		((nr) / BITS_PER_LONG)
#define __KERNEL_DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#define BITS_PER_BYTE		8
#define BITS_PER_TYPE(type)	(sizeof(type) * BITS_PER_BYTE)
#define BITS_TO_LONGS(nr)	__KERNEL_DIV_ROUND_UP(nr, BITS_PER_TYPE(long))

#define WARN_ON(condition) ({						\
	int __ret_warn_on = !!(condition);				\
	if (__ret_warn_on) {						\
		fprintf(stderr, "WARN_ON(%s) at %s:%d\n",		\
		        #condition, __FILE__, __LINE__);		\
	}								\
	__ret_warn_on;							\
})

#define ____cacheline_aligned
#define __force

#define __cacheline_aligned					\
		__attribute__((__aligned__(SMP_CACHE_BYTES),			\
			       __section__(".data..cacheline_aligned")))

#define __cpu_to_le32
#define __le32_to_cpu
#define __be32_to_cpu __builtin_bswap32
#define __cpu_to_be32 __builtin_bswap32

/* the pldmfw library only uses the size and data fields, so we provide
 * a simplified structure here instead of the complete implementation from
 * Linux kernel.
 */
struct firmware {
	size_t size;
	const u8 *data;
};

#define UUID_SIZE 16

typedef struct {
	__u8 b[UUID_SIZE];
} uuid_t;

#define UUID_INIT(a, b, c, d0, d1, d2, d3, d4, d5, d6, d7)			\
((uuid_t)								\
{{ ((a) >> 24) & 0xff, ((a) >> 16) & 0xff, ((a) >> 8) & 0xff, (a) & 0xff, \
   ((b) >> 8) & 0xff, (b) & 0xff,					\
   ((c) >> 8) & 0xff, (c) & 0xff,					\
   (d0), (d1), (d2), (d3), (d4), (d5), (d6), (d7) }})

static inline bool uuid_equal(const uuid_t *u1, const uuid_t *u2)
{
	return memcmp(u1, u2, sizeof(uuid_t)) == 0;
}

struct device {
	int initialized;
};

struct pci_dev {
	unsigned short	vendor;
	unsigned short	device;
	unsigned short	subsystem_vendor;
	unsigned short	subsystem_device;
	struct device dev;
};

#define to_pci_dev(n) container_of(n, struct pci_dev, dev)

static inline void pldm_dbg_print(struct device *dev, const char *fmt, ...)
{
	va_list args;

	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);
}

#define dev_dbg(dev, fmt, ...) pldm_dbg_print(dev, ("dev_dbg: " fmt), ##__VA_ARGS__)

static inline u16 get_unaligned_le16(const void *p)
{
	__le16 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return le16toh(tmp);
}

static inline u32 get_unaligned_le32(const void *p)
{
	__le32 tmp;

	memmove(&tmp, p, sizeof(tmp));
	return le32toh(tmp);
}

#define BITMAP_LAST_WORD_MASK(nbits) (~0UL >> (-(nbits) & (BITS_PER_LONG - 1)))

static unsigned long
find_first_bit(const unsigned long *addr, unsigned long size)
{
	unsigned long idx;

	for (idx = 0; idx * BITS_PER_LONG < size; idx++) {
		if (addr[idx])
			return MIN(idx * BITS_PER_LONG + __builtin_ffs(addr[idx]),
				   size);
	}
	return size;
}

/**
 * __fls - find last (most-significant) set bit in a long word
 * @word: the word to search
 *
 * Undefined if no set bit exists, so code should check against 0 first.
 */
static __always_inline unsigned long __fls(unsigned long word)
{
	int num = BITS_PER_LONG - 1;

#if BITS_PER_LONG == 64
	if (!(word & (~0ul << 32))) {
		num -= 32;
		word <<= 32;
	}
#endif
	if (!(word & (~0ul << (BITS_PER_LONG-16)))) {
		num -= 16;
		word <<= 16;
	}
	if (!(word & (~0ul << (BITS_PER_LONG-8)))) {
		num -= 8;
		word <<= 8;
	}
	if (!(word & (~0ul << (BITS_PER_LONG-4)))) {
		num -= 4;
		word <<= 4;
	}
	if (!(word & (~0ul << (BITS_PER_LONG-2)))) {
		num -= 2;
		word <<= 2;
	}
	if (!(word & (~0ul << (BITS_PER_LONG-1))))
		num -= 1;
	return num;
}

static unsigned long
find_last_bit(const unsigned long *addr, unsigned long size)
{
	if (size) {
		unsigned long val = BITMAP_LAST_WORD_MASK(size);
		unsigned long idx = (size-1) / BITS_PER_LONG;

		do {
			val &= addr[idx];
			if (val)
				return idx * BITS_PER_LONG + __fls(val);

			val = ~0ul;
		} while (idx--);
	}
	return size;
}

static inline int
test_bit(unsigned int nr, const volatile unsigned long *addr)
{
	return 1UL & (addr[BIT_WORD(nr)] >> (nr & (BITS_PER_LONG-1)));
}

static inline void bitmap_set_value8(unsigned long *map, unsigned long value,
				     unsigned long start)
{
	const size_t index = BIT_WORD(start);
	const unsigned long offset = start % BITS_PER_LONG;

	map[index] &= ~(0xFFUL << offset);
	map[index] |= value << offset;
}

static unsigned long *bitmap_zalloc(unsigned int nbits, gfp_t flags)
{
	return (unsigned long *)calloc(BITS_TO_LONGS(nbits),
				       sizeof(unsigned long));
}

static void bitmap_free(unsigned long *bitmap)
{
	free(bitmap);
}

#endif /* _ANALYZE_PLDM_HEADER_MISSING_H_ */
