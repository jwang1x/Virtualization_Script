/*
 * @file analyze_pldm_header.c
 * @brief Utility program to analyze PLDM Firmware file headers
 * @note Copyright (C) Intel Corporation <jacob.e.keller@intel.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <errno.h>
#include <getopt.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include <sys/mman.h>
#include <linux/compiler.h>

#include "missing.h"
#include "crc32/crc32.c"
#include "../../src/COMPAT/kcompat_pldmfw.c"

static void usage(char *progname)
{
	printf("usage: %s [options] {file}\n"
	       "\n"
	       "Analyze the provided file as a PLDM firmware file.\n"
	       "\n"
	       "--options--\n"
	       "[-h] --help        display this message\n",
	       progname);
}

static int map_fw_data(struct firmware *fw, FILE *file)
{
	const u8 *fw_data;
	size_t fw_size;

	/* Calculate the total size */
	fseek(file, 0L, SEEK_END);
	fw_size = ftell(file);
	rewind(file);

	fw_data = (const u8 *)mmap(NULL, fw_size, PROT_READ, MAP_PRIVATE,
				   fileno(file), 0);
	if (fw_data == MAP_FAILED) {
		fprintf(stderr, "Failed to map firmware file, error %m (%d)\n",
			errno);
		return -1;
	}

	fw->size = fw_size;
	fw->data = fw_data;

	return 0;
}

static void unmap_fw_data(struct firmware *fw)
{
	if (fw->data)
		munmap((void *)fw->data, fw->size);
}

static const struct pldmfw_ops analyze_fwu_ops = {
	.match_record = pldmfw_op_pci_match_record,
};

static void print_pldm_version(const u8 *str, u8 len, u8 type)
{
	printf("Version: ");

	/* TODO: Convert and print the various UTF formats */
	switch (type) {
	case PLDM_STRING_TYPE_ASCII:
		fwrite(str, sizeof(char), len, stdout);
		printf("\n");
		break;
	case PLDM_STRING_TYPE_UTF8:
		printf("<UTF8 string>\n");
		break;
	case PLDM_STRING_TYPE_UTF16:
		printf("<UTF16 string>\n");
		break;
	case PLDM_STRING_TYPE_UTF16LE:
		printf("<UTF16LE string>\n");
		break;
	case PLDM_STRING_TYPE_UTF16BE:
		printf("<UTF16BE string>\n");
		break;
	case PLDM_STRING_TYPE_UNKNOWN:
	default:
		printf("<unknown format>\n");
		break;
	}
}

static void print_pldm_descs(struct pldmfw_record *record)
{
	struct pldmfw_desc_tlv *desc, *d_safe;
	int idx = 0;
	u16 value;

	list_for_each_entry_safe(desc, d_safe, &record->descs, entry) {
		printf("Desc %d: ", idx);

		switch (desc->type) {
		case PLDM_DESC_ID_PCI_VENDOR_ID:
			value = get_unaligned_le16(desc->data);
			printf("PCI Vendor ID 0x%04x\n", value);
			break;
		case PLDM_DESC_ID_PCI_DEVICE_ID:
			value = get_unaligned_le16(desc->data);
			printf("PCI Device ID 0x%04x\n", value);
			break;
		case PLDM_DESC_ID_PCI_SUBVENDOR_ID:
			value = get_unaligned_le16(desc->data);
			printf("PCI Subvendor ID 0x%04x\n", value);
			break;
		case PLDM_DESC_ID_PCI_SUBDEV_ID:
			value = get_unaligned_le16(desc->data);
			printf("PCI Subdevice ID 0x%04x\n", value);
			break;
		default:
			printf("Type %u, Size %u\n", desc->type, desc->size);
			break;
		}

		idx++;
	}
}

static void print_pldm_records(struct pldmfw_priv *data)
{
	struct pldmfw_record *record, *r_safe;
	int idx = 0;

	list_for_each_entry_safe(record, r_safe, &data->records, entry) {
		printf("-- Record %d --\n", idx);
		print_pldm_version(record->version_string, record->version_len,
				   record->version_type);
		printf("Package Data Size: %u\n", record->package_data_len);

		for (int c = 0; c < data->component_bitmap_len; c++) {
			if (test_bit(c, record->component_bitmap))
				printf("Uses component %d\n", c);
		}

		print_pldm_descs(record);

		printf("\n");

		idx++;
	}
}

static void print_pldm_components(struct pldmfw_priv *data)
{
	struct pldmfw_component *component, *c_safe;

	list_for_each_entry_safe(component, c_safe, &data->components, entry) {
		printf("-- Component %u --\n", component->index);
		printf("Identifier: %u\n", component->identifier);
		printf("Classification: %u\n", component->classification);
		printf("Comparison Stamp: 0x%08x\n", component->comparison_stamp);
		printf("Size: %u\n", component->component_size);
		print_pldm_version(component->version_string,
				   component->version_len,
				   component->version_type);
		printf("\n");
	}
}

static int analyze_pldm_header(const char *filename)
{
	struct pldmfw_priv data = {};
	struct pldmfw context = {};
	struct firmware fw = {};
	struct pci_dev pdev = {};
	FILE *file;
	int err;

	printf("Analyzing %s\n", filename);

	file = fopen(filename, "rb");
	if (!file) {
		fprintf(stderr, "Failed to open '%s', error %m (%d)\n",
			filename, errno);
		return -1;
	}

	err = map_fw_data(&fw, file);
	if (err) {
		goto err_close_file;
	}

	pdev.dev.initialized = 1;
	context.dev = &pdev.dev;
	context.ops = &analyze_fwu_ops;

	INIT_LIST_HEAD(&data.records);
	INIT_LIST_HEAD(&data.components);

	data.context = &context;
	data.fw = &fw;

	/* Parse the PLDM image first */
	err = pldm_parse_image(&data);
	if (err) {
		fprintf(stderr, "Image does not appear to contain a valid PLDM header, error %d\n",
			err);
		goto err_pldmfw_free_priv;
	}

	printf("Found valid PLDM header\n");
	printf("Header CRC: 0x%08x\n", data.header_crc);
	printf("Total Header Size: %u\n", data.total_header_size);
	printf("Record count: %d\n", data.record_count);
	printf("Component count: %d\n", data.component_count);
	printf("\n");

	print_pldm_records(&data);

	print_pldm_components(&data);

	pldmfw_free_priv(&data);
	unmap_fw_data(&fw);
	fclose(file);

	return 0;

err_pldmfw_free_priv:
	pldmfw_free_priv(&data);
	unmap_fw_data(&fw);
err_close_file:
	fclose(file);

	return err;
}

int main(int argc, char *argv[])
{
	const char *input_file;
	char *progname;

	progname = strrchr(argv[0], '/');
	progname = progname ? 1+progname : argv[0];

	while (1) {
		static struct option long_options[] = {
			{"help", no_argument, 0, 'h'},
			{0, 0, 0, 0}
		};

		int option_index = 0;
		int c;

		c = getopt_long(argc, argv, "h?",
				long_options, &option_index);

		/* no more options found */
		if (c == -1)
			break;

		switch (c) {
		case 'h':
			usage(progname);
			return 0;
		case '?':
		default:
			usage(progname);
			return -1;
		}
	}

	if (optind >= argc) {
		fprintf(stderr, "Expected argument after options\n");
		usage(progname);
		return -1;
	}

	input_file = argv[optind];

	return analyze_pldm_header(input_file);
}
