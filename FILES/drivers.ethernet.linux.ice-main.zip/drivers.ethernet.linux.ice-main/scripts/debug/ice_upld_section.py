#!/usr/bin/python3

# Not intended for external release.

# This script dumps CPK filter section blocks to a package file
# for analysis. It assumes that the ICE driver has been compiled
# so the "dump package <dir>" is available. It also assumes the
# user has issued the command "dump package upload" into debugfs.
# The directory "upload" is a choice, you can use another directory
# name.

from __future__ import print_function

import os
import sys
import getopt
import struct
import re

def_dev_name = "/sys/kernel/debug/ice/0000:05:00.0"
def_upload_dir = "upload"

dev_name = def_dev_name
upload_dir = def_upload_dir

BUF_SIZE = 4096
TOO_MANY = 256

def usage(prog_name):
    print("usage: {0} -i <input buffers> -o <output bin> \\".format(prog_name))
    print("\t\t-d <debugfs dir> -s <upload dir>")
    print("\ndefaults\n\tdebugfs dir = {0}\n\tupload dir = {1}".format(def_dev_name,def_upload_dir))

def rd_int(fname):
    try:
       file = open(fname, 'r')
    except FileNotFoundError:
       print("error: file \"{0}\" not found!".format(fname))
       sys.exit()
    int_str = file.read()
    val = int(int_str)
    file.close()
    return val

def wr(ofile, fmt, *args):
    ofile.write(struct.pack(fmt, *args))

def wr_buf(ofile, buf):
    ofile.write(buf)

def debugfs_upload(buffers):
    global dev_name
    global upload_dir
    dir_name = os.path.join(dev_name, upload_dir)
    dbg_name = os.path.join(dir_name, "buffer.bin")
    cnt_name = os.path.join(dir_name, "count")
    err_name = os.path.join(dir_name, "error")
    out_buff = []

    try:
       dbg_file = open(dbg_name, 'rb+')
    except FileNotFoundError:
       print("error: file \"{0}\" not found!".format(dbg_name))
       sys.exit()

    num_buf = 0
    for buf in buffers:
        sz = len(buf)
        if sz < BUF_SIZE:
            sz = BUF_SIZE - sz
            buf.extend(0xff for tmp in range(0, sz))
        init_val = rd_int(cnt_name)
        dbg_file.seek(0)
        dbg_file.write(buf)
        loop_cnt = 0
        while True:
            count = rd_int(cnt_name)
            loop_cnt = loop_cnt + 1
            if loop_cnt > TOO_MANY:
                break
            if init_val != count:
                break
        num_buf = num_buf + 1
        dbg_file.seek(0)
        new_buf = dbg_file.read(BUF_SIZE)
        out_buff.append(new_buf)
    dbg_file.close()
    return out_buff

def get_buffs(ifile):
   try:
       InputFile = open(ifile, 'rb')
   except FileNotFoundError:
       print("error: file \"{0}\" not found!".format(ifile))
       sys.exit()
   inbuf = InputFile.read()
   InputFile.close()

   buffers = []
   sz = len(inbuf)
   if sz % BUF_SIZE:
       print("error: length of {0} not multiple of 4k".format(ifile))
       sys.exit()

   bufs = sz // BUF_SIZE
   for i in range(0, bufs):
       start = i * BUF_SIZE
       buf4k = inbuf[start : start + BUF_SIZE]
       buffers.append(buf4k)

   return buffers

def write_pkg(buffers, ofile):
   try:
       OutputFile = open(ofile, 'wb+')
   except FileNotFoundError:
       print("error: file \"{0}\" not found!".format(ifile))
       sys.exit()

   OutputFile.seek(0)

   # pkg header
   wr(OutputFile, "=LL", 1, 2)  # 8 bytes

   # write segment offset
   wr(OutputFile, "=L", 16)          # 4 bytes  - Global metadata segment
   wr(OutputFile, "=L", 16 + 84)     # 4 bytes  - CPK segment

   # write Global metadata segment
   wr(OutputFile, "=LLL", 1, 1, 84)  # seg type, version, length

#   wr(OutputFile, "c" * 32, *bytearray(b'Global Metadata\x00                '))
   orig_str = b'Global Metadata\x00                '
   wr(OutputFile, "32s", orig_str)

   wr(OutputFile, "=LL", 1, 1)       # version, track

#   wr(OutputFile, "c" * 32, *"DEFAULT\x00                        ")
   orig_str = b'DEFAULT\x00                        '
   wr(OutputFile, "32s", orig_str)

   # write CPK segment type, version, size
   sz = 44 + 4 + 4 + 4 + (BUF_SIZE * len(buffers))
   wr(OutputFile, "=LLL", 0x10, 1, sz)

   # write segment name
#    wr(OutPutFile, "c" * 32, *"CPK Configuration Data\x00         ")
   orig_str = b'CPK Configuration Data\x00         '
   wr(OutputFile, "32s", orig_str)

   # write device id count, nvm version count
   wr(OutputFile, "=LL", 0, 0)

   # write buffer count
   wr(OutputFile, "=L", len(buffers))

   # write buffers
   for buf in buffers:
       sz = len(buf)
       if sz < BUF_SIZE:
           # pad to 4K
           sz = BUF_SIZE - sz
           buf.extend(0xff for tmp in range(0, sz))
#        if len(buf) != BUF_SIZE:
#            print "Error, buffer is not correct length, found", len(buf)
       wr_buf(OutputFile, buf)

   OutputFile.close()

def write_buffs(buffers, ofile):
   try:
       OutputFile = open(ofile, 'wb')
   except FileNotFoundError:
       print("error: file \"{0}\" not found!".format(ifile))
       sys.exit()
   OutputFile.seek(0)
   for buf in buffers:
       wr_buf(OutputFile, buf)
   OutputFile.close()

def process_files(ifile, ofile):
    buffs = get_buffs(ifile)

    print("input buffer file: {0}".format(ifile))
    print("buffers found: {0}".format(len(buffs)))
    print("output package file: {0}".format(ofile))

    new_buffs = debugfs_upload(buffs)
    write_pkg(new_buffs,ofile)

def main(argv):
    infile = ''
    outfile = ''
    global dev_name
    global upload_dir
    prog_name = __file__
    try:
        opts, args = getopt.getopt(argv,"hi:o:d:s:",["ifile=","ofile=","dev=","sub="])
    except getopt.GetoptError:
        usage(prog_name)
        sys.exit()
    for opt, arg in opts:
        if opt == "-h":
            usage(prog_name)
            sys.exit()
        elif opt in ("-i", "--ifile"):
            infile = arg
        elif opt in ("-o", "--ofile"):
            outfile = arg
        elif opt in ("-d", "--dev"):
            dev_name = arg
        elif opt in ("-s", "--sub"):
            upload_dir = arg
    if (infile == '' or outfile == ''):
        print("input and output file names can't be empty")
        sys.exit()
    process_files(infile, outfile)


if __name__ == "__main__":
    main(sys.argv[1:])
