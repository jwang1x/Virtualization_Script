# drivers.ethernet.linux.ice

The Linux ice driver for Intel's E800 series ethernet devices.

### Documentation

The documentation for this driver is written using reStructuredText and can
be found in the [Documentation](Documentation/index.rst) folder. It is also
formatted and published using Sphinx on
[ReadTheDocs](https://readthedocs.intel.com/drivers.ethernet.linux.ice/)
