Linux ice driver documentation
==============================

This is the top level of documentation for the ice Linux driver. It is
written for and by the device driver developers. Like most documentation, it
is very much a work in progress.

The ice driver supports a variety of products including the E810, E822, and
E830 series of Intel Ethernet Networking adapters.

The intent of this documentation is to aid developers in understanding
various portions of the driver code base. The documentation is split up into
multiple sub-directories with specific documentation for the various
portions and subsystems in the driver.

Improvements to correct mistakes, improve clarity, or expand the scope to
cover as-yet undocumented portions of the driver code are welcome.

This documentation should complement existing in-source documentation such
as header comments or function comments. It can be used for long-form
explanations of entire subsystems. In addition, other useful external
resources can be linked to make it easier to locate useful internal
resources.

By providing the documentation in-tree, we ensure that all developers who
have access to the repository implicitly have some documentation to get them
started. It reduces the effort of pointing people at the right
documentation, and ensures that the documentation itself is version
controlled.

Read The Docs
=============

We format and publish this documentation at `drivers.ethernet.linux.ice`_ on
Intel's internal Read the Docs website.

.. _drivers.ethernet.linux.ice:
   https://readthedocs.intel.com/drivers.ethernet.linux.ice

You may also be interested in reading the `kcompat`_ documentation which is
also available on Read the Docs.

.. _kcompat:
   https://readthedocs.intel.com/epg-docs-compat/

Table of Contents
=================

.. toctree::
   :maxdepth: 2

   obtaining
   submitting
   commitmessage
   xdp
   firmware/index
   readthedocs
   scalable_iov/index
   performance/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
