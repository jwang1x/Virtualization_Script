XDP and AF_XDP
==============

eXpress Data Path (XDP) is a Berkeley Packet Filter (eBPF) based high
performance data path that adds an early hook in the RX path of a kernel
and let a user supplied eBPF program decide the fate of the packet.
Due to that it can support a very high packet processing rate.

XDP gives you an access to packet-data, as early as it is possible, before
SKB is allocated. In this case, we do not waste CPU cycles for unnecessary
resource allocation or traversing kernel network stack.

AF_XDP is XDP based and was designed to enable zero-copy movement of packet
data between the user space and the kernel space using UMEM.

eBPF
----

Extended Barkley Packet Filtering (eBPF) is a technology that allows you to
run a program in the kernel of an operating system. As a result, the
capabilities of the kernel can be extended in a safe manner without changing
the kernel source code nor loading modules. As eBPF programs are natively
compiled using Just-In-Time (JIT) compiler and a verification engine, safety,
and efficiency of the solution is guaranteed.

Every eBPF program must have defined type, which essentially defines an API:
where the program can be attached, which in-kernel helper functions the
verifier will allow to be called, whether network packet data can be accessed
directly, the type of object passed as the first argument to the program.

Nowadays eBPF plays a main role in many kernel related areas such as for
example high performance networking, load-balancing in cloud native
environments, extracting security observability data, tracing
applications, troubleshooting performance, or enforcing runtime security.

eBPF maps
^^^^^^^^^

BPF map is an important concept, which is a simple key-value store, that
resides in kernel space. They can be accessed from a BPF program to keep state
among multiple BPF program invocations. It allows users to control the eBPF
program flow from the user space. Maps can also be accessed through file
descriptors from user space and can be arbitrarily shared with other BPF
programs or user space applications.

BPF programs, which share maps with each other are not required to be of the
same program type, for example, tracing programs can share maps with networking
programs. There are many eBPF map types, each of which was designed to store
different values.

eBPF verifier
^^^^^^^^^^^^^

There are security and stability risks with allowing user-space code to run
inside the kernel. That’s why, following checks are performed by eBPF verifier
on every eBPF program before it is really loaded:

1. Test ensures that the eBPF program terminates and does not contain any loops
   that could cause the kernel to lock up. This is checked by doing a
   depth-first search of the program's control flow graph (CFG). Unreachable
   instructions are strictly prohibited; any program that contains unreachable
   instructions will fail to load.

2. Test requires the verifier to simulate the execution of the eBPF program one
   instruction at a time. The virtual machine state is checked before and after
   the execution of every instruction to ensure that register and stack state
   are valid. Out of bounds jumps are prohibited, as is accessing out-of-range
   data.

3. The verifier also has a "secure mode" that prohibits pointer arithmetic. The
   idea is to make sure that kernel addresses do not leak to unprivileged users
   and that pointers cannot be written to memory. When it is not enabled
   pointer arithmetic is allowed but only after additional checks are
   performed.

4. Registers with uninitialized contents (those that have never been written
   to) cannot be read; doing so cause the program load to fail. The contents of
   registers R0-R5 are marked as unreadable across functions calls by storing
   a special value to catch any reads of an uninitialized register. Similar
   checks are done for reading variables on the stack and to make sure that no
   instructions write to the read-only frame-pointer register.

5. Lastly, the verifier uses the eBPF program type to restrict which kernel
   functions can be called from eBPF programs and which data structures can be
   accessed. Some program types can directly access network packet data, for
   example.

XDP
---

XDP was designed to provide high performance and programmability. It does not
require any additional driver. Every XDP program consists of two parts: actual
eBPF program to be compiled and loaded into the Kernel and a user-space
counterpart to load to this program and interact with it (trough eBPF maps).

XDP flow
^^^^^^^^

1. XDP program development [C, P4, Go or Rust]

2. XDP program compilation [llvm or clang; output of the llvm is an ELF file]

3. The eBPF bytecode load (ELF file) through the bpf tool loaders

4. Kernel verifier execution on the eBPF program

5. If success is returned and it is first XDP program loaded additional TX
   queues will be allocated

6. If success is returned the program will be loaded and executed on each
   incoming packet on an early hook (just after the interrupt processing,
   before the memory allocation)

After XDP program is executed one of the following XDP actions is returned:

* XDP_DROP - Packet will be dropped at the driver level without wasting any
  further resources

* XDP_PASS - Packet will be allowed to be passed up to the kernel's networking
  stack (current CPU that was processing this packet will allocate a skb,
  populates and passes it onwards)

* XDP_TX - Packet will be transmitted out of the same NIC it just arrived on

* XDP_REDIRECT - Packet will be either transmitted out of the other NIC than it
  just arrived on (similarly to TX) or will be passed to another CPU for
  processing and pushing to the upper kernel stack (similarly to PASS). This is
  achieved using special maps: cpumap for redirecting to other cores/CPUs and
  devmap for redirecting to other NICs (not supported by the VF driver)

* XDP_ABORTED - Same behavior as for DROP with an exception recorded. Should
  not be used in normal packet path

XDP hardware requirements
^^^^^^^^^^^^^^^^^^^^^^^^^

XDP does not require any specific HW to run.

However, to achieve maximum performance on XDP_TX and XDP_REDIRECT paths, it is
recommended to allocate additional Tx queues equal to the number of CPUs if
hardware supports arbitrary queues allocation. This is needed for lockless
transmission of frames: if a Tx queue is shared between CPUs or XDP path and
regular stack path, it is necessary to serialize access to this queue using
locks, which affects performance, especially if XDP path will be waiting for
the upper stack.

XDP and kernel relation
^^^^^^^^^^^^^^^^^^^^^^^

XDP is a core concept of the Linux kernel – it doesn’t require any third-party
kernel modules; it works in concert with the Linux Kernel. It is not a kernel
bypass, so it can reuse all the upstream developed kernel networking drivers,
user space tooling and other in-kernel infrastructure. XDP does not replace
TCP/IP stack. Its design allows for runtime program swapping w/o any network
traffic interruption.

XDP use cases
^^^^^^^^^^^^^

Primary motivation for XDP is to allow system or data center administrators to
develop solution that fits to their needs in a flexible manner. Such solutions
may consist of, for example filtering/DDoS mitigation, firewalling,
forwarding, load balancing in a cluster, pre-stack processing - parsing,
manipulating, batching, flow sampling or monitoring.

XDP operating modes
^^^^^^^^^^^^^^^^^^^

There are two modes that XDP can operate in – busy polling and interrupt
driven. In busy polling XDP prog enters a loop in which it checks the status
of a until it is ready to be pulled. This technique introduces small latency
but increases overall performance of the solution. In interrupt driven mode
each interrupt causes XDP prog to pull.

XDP Security
^^^^^^^^^^^^

XDP has the same security model as the rest of the kernel for accessing
hardware. Each XDP program must be verified before it is applied. See section
eBPF verifier above for more information.

XDP Hints
^^^^^^^^^

The efficiency of eBPF programs can be improved by using parsing hints provided
by the NICs built in parser. This concept can then be extended to other areas
such as certain packet modification actions. List of different types of hints
or metadata that will be useful for an XDP program:

* Packet Type - Identify the packet's protocol type

* Rx Hash Value - If RSS/Hashing has been performed on the packet indicate it

* Header offsets: Depending on the packet type provide L2/L3/L4 header offset

* VLAN - Presence/absence of VLAN headers (upto 2)

* Queue ID - Port-Queue the packet was received on

* Timestamp - Rx timestamp (optional)

* csum status - Packet csum done or not

* Flexible packet offsets - For eBPF programs that need offsets into custom
  protocol or extend the offsets beyond existing headers

XDP hints flow
^^^^^^^^^^^^^^

1. Develop an eBPF program in clang

2. Develops eBPF code and use sys calls to get hints a metadata. Code is
   written to handle cases where HW fails to provide requested hints.

3. Compile using llvm or gcc

4. Develop a user space program that will configure hints

5. OS loads the eBPF bytecode (ELF file) through the bpf tool loaders

6. The OS will execute the kernel verifier on the eBPF program

7. The NIC driver will then translate the generated hint formats to the HW
   specific API, and programs the underlying rules, tables, and filters

AF_XDP
------

AF_XDP stands for Address Family XDP. Previously described XDP can perform
simple routing using the REDIRECT action (redirect to the different NIC or
CPU). AF_XDP is designed to enable zero-copy movement of packet data between
the user space and the kernel space using UMEM.

AF_XDP receive flow
^^^^^^^^^^^^^^^^^^^

1. User space application create an array in user-space memory called UMEM
   (contiguous memory, divided into equal-sized "frames" (the actual size is
   specified by the caller), each of which can hold a single packet)

2. Memory is registered with the socket using the XDP_UMEM_REG command of the
   setsockopt() system call

3. User space application creates a circular buffer called the fill queue using
   the XDP_UMEM_FILL_QUEUE setsockopt() call. This queue is then mapped into
   user-space memory using mmap()

4. The application request that the kernel place an incoming packet into a
   specific frame in the UMEM array by adding that frame's descriptor to the
   fill queue

5. User space application creates a circular buffer called the receive queue,
   using the XDP_RX_QUEUE setsockopt() call. This queue is then mapped into
   user-space memory using mmap()

6. Once a frame has been filled with a packet, its descriptor will be moved to
   the receive queue

7. A call to poll()is used to wait for packets to arrive in the receive queue

AF_XDP transmit flow
^^^^^^^^^^^^^^^^^^^^

1. User space application uses previously created UMEM

2. User space application creates a circular buffer called the transmit queue,
   using the XDP_TX_QUEUE setsockopt() call. This queue is then mapped into
   user-space memory using mmap().

3. A packet is transmitted by placing its descriptor into the transmit queue

4. User space application creates a circular buffer called the completion
   queue, using the XDP_UMEM_COMPLETION_QUEUE setsockopt() call. This queue is
   then mapped into user-space memory using mmap().

5. A call to sendmsg() informs the kernel that one or more descriptors are
   ready for transmission

6. After the packets have been transmitted the completion queue receives
   descriptors from the kernel

UMEM
^^^^

UMEM is a chunk of contiguous memory, divided into equal-sized "frames" - the
actual size is specified by the caller, each of which can hold a single
packet. After the memory has been allocated by the application, this array is
registered with the socket.  Each frame in the array has an integer index
called a "descriptor".

In a receive path, to use those descriptors, the application creates circular
buffer called the "fill queue“. Those queue can then be mapped into the
user-space. The application can request that the kernel place an incoming
packet into a specific frame in the UMEM array by adding that frame's
descriptor to the “fill queue”. Once a descriptor goes into the fill queue,
the kernel owns it - and the associated UMEM frame. To get that descriptor
back, once a frame has been filled with a packet, its descriptor will be moved
to the receive queue. A call to poll() can be used to wait for packets to
arrive in the receive queue.

A similar story exists on the transmit side. The application creates a
“transmit queue” and “completion queue”, then maps them, packet is transmitted
by placing its descriptor into transmit queue. A call to sendmsg() informs the
kernel that one or more descriptors are ready for transmission. The completion
queue receives descriptors from the kernel after the packets the contain have
been transmitted.

Hardware requirements
^^^^^^^^^^^^^^^^^^^^^

AF_XDP does not require any specific HW to run, but the same rules regarding
additional queues apply.

AF_XDP can share a queue pair with XDP path or – best case scenario – use an
additional pair exclusively. This is needed to isolate AF_XDP frames from XDP
frames and thus simplify driver routines.

AF_XDP and kernel relation
^^^^^^^^^^^^^^^^^^^^^^^^^^

Same as XDP

Use cases
^^^^^^^^^

This interface is intended for applications that prioritize packet-processing
performance above convenience, as the user space application must be modified
to work in concert with AF XDP program.
