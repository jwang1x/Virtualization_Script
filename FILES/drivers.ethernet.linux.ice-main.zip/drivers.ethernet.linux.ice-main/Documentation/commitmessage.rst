Commit message guidelines
=========================

We follow Linux kernel style commit message guidelines, it is well described
`here`_. Below you can find a quick summary and advices that are specific to
our process.

.. _here:
   https://www.kernel.org/doc/html/latest/process/submitting-patches.html#describe-your-changes


Commit message title
--------------------

Use prefix ``ice-linux:`` and follow it with a title describing your change.
Keep it short and in imperative form. Use present simple tense,
so no "fixing xyz", no "fixed xyz" just simple "fix xyz".
Example: ``ice-linux: allow 3k MTU for XDP``

Commit message body
-------------------

First and foremost describe *WHY* your change is needed. After that, give
a short description what is changed in the code.

Do not exceed 75 characters per line.

If you want to include any confidential information or specific to our
organization (i.e. DCR number) add ``INTERNAL ONLY:`` and put the details below.
It will tell anyone who will upstream this patch (probably you) to strip this
section from commit message before sending it to mailing list.

Abbreviations
-------------

When you use any abbreviations either in commit title or body, please follow
already publicly used terms, like: ``AF_XDP`` (no afxdp/af_xdp). For
abbreviations specific to our code use what is already used: ``Tx queue``
(no TXQ/txq/TxQ), ``VSI`` instead of vsi.

Footer
------

If your patch fixes a bug in specific commit, include:
``Fixes: <12-chars-SHA> ("commit title")`` tag, i.e.:

.. code-block:: shell

   Fixes: 1234567890ab ("ice-linux: commit title")

Add ``Signed-off-by:`` with your name. When you worked with someone else
on this patch, you can add his name as well.

.. code-block:: shell

   Signed-off-by: John Doe <john.doe@intel.com>

Add ``Change-type:`` tag. There are few to choose from ``DefectResolution``,
``FeatureImplementation``, ``ImplementationChange``, ``EngineeringNotes``,
``Other``.

When you were fixing a bug that has an HSD, add details about it:

.. code-block:: shell

   HSDES-number: 0123456789
   HSDES-Tenant: server_platf_lan.bug

Add ``Title:``.

You can use a template below to speed up the process. Create file called
``.gitcommit`` in your home directory and add the below text to it, with
your details.

.. code-block:: shell

   ice-linux:
   ice-shared:

   Fixes: <12 digit hash> ("<commit_title>")
   Signed-off-by: John Doe <john.doe@intel.com>
   Change-type: DefectResolution
   Change-type: FeatureImplementation
   Change-type: ImplementationChange
   Change-type: EngineeringNotes
   Change-type: Other
   HSDES-number: 0123456789
   HSDES-Tenant: server_platf_lan.bug
   Title:

Inform git to use .gitcommit using git-config:

.. code-block:: shell

   git config --global commit.template /home/jdoe/.gitcommit

