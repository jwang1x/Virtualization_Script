Setting up ReadTheDocs
======================

We publish formatted versions of our documentation to `readthedocs`_. This
enables everyone to easily view the latest version of the formatted
documentation.

.. _readthedocs:
   https://readthedocs.intel.com/drivers.ethernet.linux.ice/

This page describes the process and moving parts we use to make the
documentation automatically publish to the readthedocs website.

For a more detailed overview of the `readthedocs`_ infrastructure, please see
read the `SATG Infrastructure`_ documentation.

.. _SATG Infrastructure:
   https://readthedocs.intel.com/os-static/ExtCollab/readthedocs-hosting.html

Overall Steps
-------------

#. Create documentation in your repository
#. Generate HTML documentation
#. Setup a branch or repository to house the generated documentation
#. Publish HTML documentation to that location
#. Setup webhook to link into readthedocs
#. Create automation to verify the docs will compile
#. Create automation to update the formatted docs repository on commit

Creating documentation
----------------------

Our documentation is written in the `reStructuredText`_ (rST) format. This
is a what-you-see-is-what-you-get plaintext markup synxtax. We use the
`sphinx`_ tool to generate HTML documentation from the rST source.

.. _reStructuredText:
   https://docutils.sourceforge.io/rst.html

.. _sphinx:
   https://www.sphinx-doc.org/en/master/

A complete guide to the rST format is beyond the scope of this document.
The `quickstart`_ guide may be helpful to understand rST basics.

.. _quickstart:
   https://docutils.sourceforge.io/docs/user/rst/quickstart.html

We recommend housing the rST files inside of a ``Documentation`` subfolder
of your repository. This is similar to the Linux kernel and other open
source projects.

For example this project's Documentation tree is similar to the following:

::

   Documentation
   ├── conf.py
   ├── index.rst
   ├── Makefile
   ├── <...>
   ├── output
   ├── readthedocs.rst
   └── submitting.rst

The ``Makefile`` is a simple minimal makefile for Sphinx projects laid out
as described by this document. It can safely be copied without modification
to new projects.

The ``conf.py`` file is the python file used to configure the Sphinx build.
You may re-use it, but will need to update the project information for your
specific project.

The ``index.rst`` file is required as the main entry point, or front page,
of your documentation. All other files will be included by linking them from
your index file.

Larger projects with more complex documentation may use subfolders to store
related documentation. Each subfolder may also have its own ``index.rst``
file.

Generating HTML documentation
-----------------------------

To generate HTML from the rST content, we use the `sphinx`_ tool along with
the opensource `Read The Docs`_ theme.

.. _Read The Docs:
   https://sphinx-rtd-theme.readthedocs.io/en/stable/

On Fedora Linux you can install both tools:

.. code:: shell

   $ dnf install sphinx python3-sphinx_rtd_theme

If you used the ``Makefile`` and ``conf.py`` from this project you can
generate the HTML content into the ``output`` directory using make.

.. code:: shell

   $ cd Documentation
   $ make html

This generates all of the HTML necessary for your documentation into the
``output`` directory.

Storing the generated documentation
-----------------------------------

In order to integrate with SATG `readthedocs`_ infrastructure, the generated
HTML of your documentation must be stored on `Intel's Github Organization`_.

.. _Intel's Github Organization:
   https://github.com/intel-innersource/

It is recommended to use a special orphan branch of your repository for this
purpose. You may also use a separate repository if desired.

Creating an orphan branch
=========================

Using a separate orphan branch avoids the need to create and manage an
entirely separate repository. The main complication with an orphan branch is
that it will have distinct unrelated history from your main project. By
convention, we recommend that you use ``rst-pages`` as the name for this
branch.

To create an orphan branch, we recommend using a separate clone of your
repository. For example, to create the ``rst-pages`` orphan branch for a
repository, you might use the following steps:

.. code-block:: shell

   $ cd ~/git
   $ git clone https://github.com/intel-innersource/drivers.ethernet.linux.ice ice-docs
   $ cd ice-docs
   $ git switch --orphan rst-pages

This creates a new branch in the repository called ``rst-pages`` with no
commits and no current contents.

Note that ``git switch --orphan`` behaves differently from the older ``git
checkout --orphan``. It is recommended to use ``git switch`` if available on
your system. If not, please read the ``git checkout`` documentation
carefully.

You only need to create the orphan branch once for the initial commit of
your documentation. For future updates you can simply clone the repository
at this branch if its not already cloned on your system:

.. code-block:: shell

   $ cd ~/git
   $ git clone https://github.com/intel-innersource/drivers.ethernet.linux.ice -b rst-pages ice-docs

Creating a separate repository
==============================

Using a separate repository avoids the complexity of an orphan branch, but
at the cost of maintaining a second repository. While we originally used
this approach for our initial projects, we recommend using a separate orphan
branch now.

If you do decide to use a separate repository for your documentation, we
recommend the convention of appending ``.docs`` as a suffix to your original
repository name.

You can create the repository on `Intel's Github Organization`_ as usual.

For the example steps, it is assumed you have cloned this repository as
``~/git/ice-docs``.

.. code-block:: shell

   $ cd ~/git
   $ git clone https://github.com/intel-innersource/drivers.ethernet.linux.ice.docs ice-docs

Uploading initial documentation
-------------------------------

First, you need to build the HTML documentation

.. code-block:: shell

  $ cd Documentation
  $ make html

You'll also need a clone of the location your docs will be stored. This is
either a clone checked out to the orphan branch of your existing repository,
or a clone of the separate documentation repository. We assume its located
at ``~/git/ice-docs`` for this example.

Copy the generated documentation from the output directory into your cloned
repository. We recommend ``rsync``.

.. code-block:: shell

  $ rsync -av output/html/* ~/git/ice-docs/

Once you've copied the contents of the output folder, you will need to
generate a commit and publish it.

.. code-block:: shell

  $ cd ~/git/ice-docs/
  $ git add .
  $ git commit -s
  $ git push origin

Create a section on readthedocs.intel.com
-----------------------------------------

The Intel ReadTheDocs hosting is provided by the SATG/Infrastructure team as
a way to host internal documentation which anyone at Intel can access. It is
suitable for Intel Confidential data, but does not provide access controls.

To add a new section to the site, you must follow the steps found `here`_.
As a short summary you will need to do the following.

.. _here:
   https://readthedocs.intel.com/os-static/ExtCollab/readthedocs-hosting.html

#. Submit a ticket to request a new ReadTheDocs site

  #. Provide the URL and branch of the github repo containing the HTML
     formatted documentation you created in the previous step

  #. Provide a name for the site. Our recommendation is that you use the
     name of the repository the documentation is for.

#. The SATG team will get back to you with a deploy key and a webhook to add
   to the github project. This allows them to automate updating their site
   from the contents of the repository.

#. From this point, any update to the repository you created will
   automatically translate into updates to the web page.

Setting up Webhook to automate updates
--------------------------------------

In addition to the deploy key, you will be asked to setup a web hook which
will allow automatically triggering a new publish whenever the repository is
updated.

The webhook will target a ``_publisher`` URL which when tickled
automatically checks the source branch for updates and updates the
``readthedocs`` webpage.

You can manually perform an update by accessing the publisher URL by hand,
but the web hook automates this process for you.

Once a repository is part of ``inner-source`` the web hook will need to have
an official channel made for it.

Updating the docs after initial commit
--------------------------------------

Updating the published content on ``readthedocs`` requires performing the
following steps.

#. generate new HTML from current source
#. copy the new HTML into documentation branch or repository
#. push the new commit to the documentation branch or repository
#. tickle the ``_publisher`` URL (automated by webhook)

These steps are the same as described above with the exception that you
re-use the documentation target branch or repository, instead of creating a
new one.

It is possible to simply do these updates periodically by hand. However, we
recommend setting up automation that triggers for every commit to the base
repository.

Automating updates to the formatted documentation
-------------------------------------------------

Once the initial setup of the page for ``readthedocs.intel.com`` is ready,
any time you publish to the backing branch, the formatted documentation
will update.

We recommend using a CI job that automatically formats the HTML
documentation and publishes to the branch of the repository you setup with
ReadTheDocs.

For this documentation we use a Jenkins pipeline and the ``sys-nosbuild``
account. The pipeline is intended to run on every review to verify that the
changes in that review don't break the HTML formatting. In addition, it runs
on ref updates where it will publish the results to the github repository.

Once the CI is running, any changes to the documentation will result in new
commits to the formatted HTML repository. These then trigger an update of
the Intel ReadTheDocs hosted webpage.
