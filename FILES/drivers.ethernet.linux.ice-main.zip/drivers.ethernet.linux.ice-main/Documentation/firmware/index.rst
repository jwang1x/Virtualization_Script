ice driver Firmware support
===========================

The ice driver supports device flash update over the ``devlink``
interface. Firmware files for the E800 series hardware use the `PLDM for
Firmware Update`_ standard.

.. _PLDM for Firmware Update:
   https://www.dmtf.org/documents/pmci/pldm-firmware-update-specification-100

To support processing these files, the driver relies on the Linux kernel's
``pldmfw`` library, documented in the Linux Kernel at
`Documentation/driver-api/pldmfw`_.

.. _Documentation/driver-api/pldmfw:
   https://www.kernel.org/doc/html/latest/driver-api/pldmfw/

Files
-----

* ``ice_fw_udpate.c`` implements the bulk of the flash update support
  including setting up and calling the ``pldmfw`` library.

* ``ice_devlink.c`` implements the driver's devlink support. For firmware
  update this includes the info reporting and reload support.

* ``kcompat_pldmfw.c`` is a compatibility implementation of ``pldmfw`` used
  when the kernel does not provides CONFIG_PLDMFW. It should be equivalent
  functionality as normally provided by the kernel.

* ``test_kcompat_pldmfw.c`` is a test file used to validate the
  implementation of the pldmfw library. It works by loading the
  kcompat_pldfw.c files and memory mapping binary test files to verify the
  expected behavior.

* ``test_ice_fw_update.c`` is a test file used to validate the full flash
  update process of the ice driver.

Analyzing PLDM binary images
----------------------------

It can sometimes be useful to analyze a binary file with a PLDM header. For
example when checking if an image would be valid, or for determining what
devices the image supports. The ``scripts/pldmfw/`` folder contains a C
utility based on the ``kcompat_pldmfw.c`` implementation.

This C program compiles in the pldmfw library and various kernel facilities
in order to generate a user space program which can process the PLDM header
of a given binary.

For example, parsing an ice firmware file might look like the following:

.. code-block:: shell

   $ ./scripts/pldmfw/analyze_pldm_header \
       CPK_B0_SNR_Map_3p00_FW_5p5p9_NCSI_SEC_4x25_CEI_FC_2.00_800095FE.bin
    Analyzing CPK_B0_SNR_Map_3p00_FW_5p5p9_NCSI_SEC_4x25_CEI_FC_2.00_800095FE.bin
    Found valid PLDM header
    Header CRC: 0x5f823ccc
    Total Header Size: 444
    Record count: 1
    Component count: 3

    -- Record 0 --
    Version: N:040095FEO:010BD400T:00000000
    Package Data Size: 158
    Uses component 0
    Uses component 1
    Uses component 2
    Desc 0: PCI Vendor ID 0x8086
    Desc 1: PCI Device ID 0x1888
    Desc 2: PCI Subvendor ID 0x8086
    Desc 3: PCI Subdevice ID 0x0000

    -- Component 0 --
    Identifier: 6
    Classification: 10
    Comparison Stamp: 0x040095fe
    Size: 4300800
    Version: 040095FE.0000000A

    -- Component 1 --
    Identifier: 5
    Classification: 10
    Comparison Stamp: 0x010bd400
    Size: 512000
    Version: 010BD400.0000000B

    -- Component 2 --
    Identifier: 8
    Classification: 10
    Comparison Stamp: 0x00000000
    Size: 28672
    Version: 00000000.00000000.91000000.00000000.0000
