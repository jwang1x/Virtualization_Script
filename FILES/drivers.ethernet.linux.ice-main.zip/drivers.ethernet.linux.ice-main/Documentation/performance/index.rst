Performance High Level Design
=============================

This documentation attempts to describe some of the performance features
used by and provided by the driver code.

.. toctree::

   theory
