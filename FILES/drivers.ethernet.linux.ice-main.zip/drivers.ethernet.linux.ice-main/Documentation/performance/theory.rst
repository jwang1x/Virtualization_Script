Theory of ICE driver performance
================================

High speed Ethernet devices such as Columbiaville or Columbia Park for
which the ice driver is written use several methods, in order to go fast.

Fast in this context means that the driver can enable the hardware to
transmit at line rate, receive at line rate, handle packets at a minimum
latency and also transmit/receive simultaneously at line rate.

In some instances performance will be measured by how many packets-per-
second that the driver can handle, rather than in gigabits-per-second.

There are several QRC metrics used by the release teams that are documented
in the performance KPI requirements.

Performance Pillars
-------------------

It is useful to categorize the performance of any workload with four
typical pillars, Throughput, CPU utilization, Latency, and Jitter. Each
workload that the driver might do may include a focus on one or more
vectors.

Goals
-----

* The driver should use a minimum of CPU cycles whenever possible.
* The driver should be able to provide decent if not line rate performance
  with driver defaults.
* The driver will use hardware offloads whenever possible to reduce CPU or
  increase performance.
* The driver will default to using multiple queues and interrupt vectors, with all those 


Design
------

Hardware Design
^^^^^^^^^^^^^^^

The hardware is generally configured by the driver to write back or fetch
descriptors in as efficient a way as possible. This is usually configured
by the transmit or receive queue contexts. Some of the configuration may be
in the VSI contexts.

Efficient in this context means that the hardware wants to write and read
whole cache-lines or multiples of cache-lines.  The hardware cache-line size
is generally specified in the PCIe config space, but is mostly assumed to
be 64 bytes. Some platforms set the cache-line size to be 32 in order to
try to encourage fairness from the DMA devices. The Intel Xeon processors
use a 64 byte cache line size universally.

The Columbiaville hardware has a relatively small PCIe buffer that only
allows it to read and write 128 bytes of descriptor data at a time.  In the
configurations the LAN driver uses, the descriptors are 16 bytes long (for
transmit) and 32 bytes for receive.  The hardware also supports 16 byte
"legacy" descriptors for receive.

Ring Design
^^^^^^^^^^^

The driver uses a "single producer/consumer" descriptor ring to provide
buffers to the hardware to send, or receive into.  Because this descriptor
ring's entries are owned completely by hardware once the driver has "rang
the doorbell" or "bumped the tail", the driver must store per-descriptor
metadata in the buffer_info structure, sometimes called "bi".

The driver uses a single index into both these arrays, and attempts to
issue prefetch commands when able to predict that some data will be needed
by the driver or kernel stack in the near future.

Data Structure Design
^^^^^^^^^^^^^^^^^^^^^

The driver attempts to limit the amount of cache lines touched in the
hot-path of the transmit and receive routines by using a "hot path
structure."  This structure is optimized to have no "empty space" using a
tool called pahole, and is kept as short as possible while providing
a super efficient way for the routines to get just the data they need.
Developers should always be mindful of modifying these structures so that
"holes" in the structure are not introduced by non-aligned members.

Performance Features
--------------------

Scaling to go faster
^^^^^^^^^^^^^^^^^^^^

The CPUs in Linux are generally able to keep up with about 2,000,000
packets per second per core / queue.  In order to scale performance the
driver enables multiple transmit and receive queues, and configure RSS to
automatically parse packets and spread flows over multiple receive queues,
and depends on OS mechanisms to direct transmit flows to multiple queues.

In recent processor generations such as Ice-lake and modern kernels, we are
starting to see the throughput of single queue TSO workloads go as fast as
60-70 Gb/s on a 100Gb/s adapter port.

Interrupt Moderation
^^^^^^^^^^^^^^^^^^^^

Interrupt moderation is the primary way that the driver increases hardware
efficiency of write-backs to memory, as well as reducing CPU load by
delaying interrupts from the hardware in order to "batch process"
completions of transmits or receives from the hardware.

The downside of interrupt moderation is that the driver is increasing the
latency of the completions when delaying the interrupt from the hardware.

This trade-off is present at all times in the driver, playing off low
latency against high CPU utilization.

Of course there is always "busy-polling" which allows the kernel stack to
avoid any interrupt latencies by keeping a CPU awake and reading the
descriptor ring continuously by calling napi_poll even when there is no
work done by the driver.

NAPI
^^^^

The "New API" for interrupt processing in the driver increases performance
by acting as a "bottom half" handler, which is scheduled by the
hard-interrupt handler in the driver.  The NAPI handler runs at a lower
priority than a hard interrupt handler. It runs as a kernel thread or as a
ksoftirqd thread, which is designed to defer execution after handling so
many packets (the NAPI Weight) in order to ensure system level fairness and
letting other processes run on the CPU.  The NAPI thread use also allows
the full stack to run in the context of the receive call of the driver,
bypassing a queueing mechanism above the driver.

By using NAPI, the driver also achieves an ability to handle overload
conditions by pushing drops to the hardware.  When the per-packet cost of
receives becomes too high, the driver naturally falls behind in processing
descriptors, and will push the drops into the hardware because there will
be no empty receive buffers.

Implementation Hints
--------------------

The driver depends on DDIO to help improve the cache-hit rate of both
descriptors and data written from DMA to the host.

When the driver is running on a remote node, or on a system without DDIO,
the drivers' prefetch() instructions are used to pre-warm cache lines that
the driver will need soon.

Hardware Offloads
-----------------

GRO - Generic Receive Offload
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Generic Receive Offload is a kernel implementation of the "Large Receive
Offload" algorithm, which builds single SKBs to transfer to the stack from
multiple received frames from the driver on the same flows.  The driver
helps to enable this by marking frames with good checksums, and indicating
the RSS hash to the stack so that the GRO layer knows which flow this
packet is associated with.  The driver also notifies the stack to "flush"
GRO when the interrupt routine is exiting.

TSO - Transmit Segmentation Offload
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Transmit Segmentation Offload is a stateless transmit offload which allows
the stack to build a single ``struct sk_buff`` with a single header and
multiple MSS worth of data attached.  The driver then sets up a chain of
transmit descriptors and the hardware builds each frame on the wire via
combining the header and MSS worth of data, and updating the appropriate
header fields.  The hardware can send back to back packets at line rate
when doing TSO.  This can cause performance problems for some network
elements or receivers that might be congested with incoming line rate
traffic. This might be an interesting research area to follow up on.


Open questions
--------------

* Some architectures may benefit from prefetch related tuning. The bad
  thing about prefetches is that sometimes they waste CPU cycles by causing
  the CPU to stall when it has to fetch a cold cache line. It's also hard to
  get the placement and timing right so that stalls are avoided and
  prefetching doesn't just slow things down.

* Can the driver pace traffic onto the wire using per-queue rate limiting
  in order to not overwhelm the network with line-rate back to back traffic?

..
   vim: set tw=75:set spell:set spelllang=en_us:
