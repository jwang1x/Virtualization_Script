Scalable IOV
============

Scalable I/O Virtualization is a device and driver feature which enables
exposing segments of a device's hardware to a virtual machine (VM). It is
similar to existing Single Root I/O Virtualization, but creates composed
virtual devices which use direct hardware access for performance critical
tasks, while using software emulation for complex control and configuration
tasks. This flexibility enables simpler device designs and can help address
limitations associated with SR-IOV's direct assignment model.

This document provides an overview of the implementation of Scalable IOV
features in the ice driver.

MDEV Implementation
-------------------

The current implementation uses the `VFIO Mediated Devices`_ (MDEV)
framework to create the composed virtual device.

Although MDEV is supported in current Linux kernel releases, this
implementation uses interfaces which are only supported between Linux 5.11
and 5.15. Newer kernels have removed some necessary functions required by
this implementation. Thus, it does not work on kernels 5.16 and newer.

The bulk of the implementation is contained in the following files:

* ice_vdcm.c

  * The Virtual Device Composition Module (VDCM) implementation for ice.
    This module integrates with MDEV to create the composed device. It
    receives requests for new devices from MDEV and then interactes with the
    ice driver through the operations defined in ``struct ice_adi``.

* ice_siov.c

  * The main Scalable IOV implementation file for the ice driver. This file
    implements the ``struct ice_adi`` interface for VDCM. It integrates with
    the generic virtualization files by implementing the ``struct
    ice_vf_ops``.

* ice_vf_lib.c

  * The generic VF library code used by the ice driver. This file is
    shared by both the Scalable IOV and Single Root IOV implementations. It
    defines common and generic operations on VFs. It allows sharing basic
    logic between VF implementations. It uses the ``struct ice_vf_ops``
    interface to interact with the virtualization implementation.

* ice_virtchnl.c

  * The virtchnl interface implementation. This file implements the logic
    for handling all of PF to VF communications defined by the
    ``virtchnl.h`` specification.

.. _VFIO Mediated Devices:
   https://docs.kernel.org/driver-api/vfio-mediated-device.html?highlight=mediated%20device

The following diagram shows the overall communication flow for creation of a
VF in the MDEV based implementation:

::

  ┌──────────┐
  │  Kernel  │
  └──────────┘
    │
    │
    ▼
  ┌──────────┐
  │   mdev   │
  └──────────┘
    │
    │
    ▼
  ┌──────────┐
  │   vdcm   │
  └──────────┘
    │
    │
    ▼
  ┌──────────┐
  │   siov   │
  └──────────┘
    │
    │
    ▼
  ┌──────────┐
  │  vf_lib  │ ◀┐
  └──────────┘  │
    │           │
    │           │
    ▼           │
  ┌──────────┐  │
  │ virtchnl │ ─┘
  └──────────┘

..
  The block diagram was generated using graph-easy.

  $ cat <<-EOF | graph-easy --as boxart
  digraph {
    Kernel -> mdev
    mdev -> vdcm
    vdcm -> siov
    siov -> vf_lib
    vf_lib -> virtchnl
    virtchnl -> vf_lib
  }
  EOF


The MDEV framework handles interface for adding and removing a mediated
device. It sends a request for a new device to VDCM, which requests a new
ADI from ice_siov.c This triggers the creation of a new VF which is inserted
into the VF hash table.

proposed devlink VFIO implementation
------------------------------------

Newer versions of the Linux kernel are incompatible with the existing MDEV
implementation. The upstream community has moved away from using MDEV
entirely. Instead it appears that the best direction is a customized VFIO
driver specific to the device. To support this, we are designing a new
implementation of Scalable IOV based on devlink and a new VFIO framework.
This document covers the proposed design, but implementation is not yet
complete.

This implementation will integrate with devlink to support creating of ports
and thus VFs through the devlink netlink interface.

This implementation will re-use much of the existing code and file layout.
The primary change is that devlink will now be in control of new VF
creation, rather than MDEV.

* ice_devlink.c (and maybe a new ice_devlink_port.c?)

  * The main entry point for devlink code. This file will handle the call
    backs to add and remove ports. When a new port is requested, it should
    check the attributes and allocate a tracking structure for the port. For
    a Scalable VF port, it would also interact with ice_siov.c to create the
    ADI used to track the VF. Finally, once the port is activated, it would
    integrate with auxiliary bus to communicate with VDCM.

* ice_vdcm.c

  * As before, this is the Virtual Device Composition Module, and it will be
    the main point for integrating with the VFIO framework. Based on
    expected feedback, this module will be modified to become an auxiliary
    driver. When new devices are created by devlink port, they will bind
    over the auxiliary bus to this driver. It will use the interface
    provided to communicate with the device as necessary.


The followind diagram shows the overall communication flow for creation of a
VF in the new devlink based implementation:

::

               ┌──────────┐
               │  Kernel  │
               └──────────┘
                 │
                 │
                 ▼
               ┌──────────┐
               │ devlink  │ ─┐
               └──────────┘  │
                 │           │
                 │ auxbus    │
                 ▼           │
  ┌──────┐     ┌──────────┐  │
  │ vfio │ ◀── │   vdcm   │  │
  └──────┘     └──────────┘  │
                 │           │
                 │ auxbus    │
                 ▼           │
               ┌──────────┐  │
            ┌─ │   siov   │ ◀┘
            │  └──────────┘
            │    │
            │    │
            │    ▼
            │  ┌──────────┐
            │  │ virtchnl │
            │  └──────────┘
            │    │
            │    │
            │    ▼
            │  ┌──────────┐
            └▶ │  vf_lib  │
               └──────────┘

..
  The block diagram was generated using graph-easy.

  $ cat <<-EOF | graph-easy --as boxart
  digraph {
    Kernel -> devlink
    devlink -> siov
    siov -> vf_lib
    siov -> virtchnl
    virtchnl -> vf_lib
    devlink -> vdcm [ label="auxbus" ]
    vdcm -> siov [ label="auxbus" ]
    vdcm -> vfio
  }
  EOF

A more detailed explanation for the proposed changes can be found in
separate documents.

.. toctree::

   devlink
   auxiliary-vdcm
   switchdev
   interrupts

Open Questions and risks
------------------------

* details of the new VFIO framework are yet to be provided by SATG

* Interrupt Message Store (IMS) support is still being developed

* dynamic MSI-X support is still being developed

* we lack knowledge of switchdev

Handling implementation divergence
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The changes proposed here to support devlink require significant refactor of
the VDCM. This also changes the user interface in a significant way, making
the new implementation incompatible with the existing implementation.

We can't upstream the existing version, and the new implementation will
diverge significantly as a result of the change to devlink.

The current MDEV implementation is going to ship to customers as part of our
CVL 4.0 release. This means the implementation may be used by customers
running the supported kernel releases mentioned above.

The changes required to support the new implementation are not compatible
with the existing MDEV implementation. It is not feasible to support both
the new and old implementations together in our out-of-tree driver.
Attempting to do so would incur a significant development cost as we would
have to abstract differences or duplicate code. We lack the resources to
fully support both implementations.

This needs to be clearly communicated to stakeholders and customers. We do
not want to surprise anyone with an unexpected interface change.

The new VFIO framework
^^^^^^^^^^^^^^^^^^^^^^

A group from SATG has been working on proposed extensions to the VFIO
subsystem to support Scalable IOV and the IMS interrupt mechanism. This work
is ongoing, and we hope to rely on it for our implementation.

Currently, the details of this implementation are unclear to us, which may
lead to challenges if it does not behave how we expect.

switchdev integration
^^^^^^^^^^^^^^^^^^^^^

Existing SR-IOV VFs support some operations for changing features such as
port VLANs, assigning MAC addresses, Tx rate limiting, and other
configuration. The Scalable implementation does not work with these
interfaces because the core kernel code expects only SR-IOV devices and
checks against the PCI config space.

In addition, SR-IOV has some optional support for switchdev using an
E-Switch mode, which can cover some of the same use cases.

For Scalable IOV, we want to integrate with switchdev as well.

* should this be optional, or required?

* what are the gaps left if we support switchdev?

  * will we have analogs for every netdev operation?

* none of us are experts, so we need help from switchdev team

* we also need to investigate TC filtering

* switchdev also requires port representor netdevs

Ideally, the folks who implemented ice_eswitch.c and ice_repr.c can help us
modify the code to support Scalable IOV with minimal difficulty.
