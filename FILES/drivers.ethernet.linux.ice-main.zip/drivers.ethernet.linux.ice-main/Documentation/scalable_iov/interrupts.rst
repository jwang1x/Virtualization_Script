MSI-X and IMS interrupts
========================

The existing Scalable IOV implementation uses MSI-X interrupts. The ice
driver pre-allocates a large number of MSI-X interrupts for use with
Scalable IOV. These interrupts are then assigned to Scalable VFs as they
are created.

This design is problematic because it forces the driver to over allocate
during initialization. At this early stage the driver does not know how many
VFs are desired.

Single Root IOV avoids this problem because the interrupts are not mapped
into the host kernel, only into the guest VMs.

When the driver requests a large number of interrupt vectors, the Linux
kernel may reject the request or only grant a smaller total number of
vectors.

The Scalable IOV specification describes a new interrupt mechanism called
the Interrupt Message Storage (IMS) mechanism. This IMS mechanism is a
device-specific storage for interrupts that is distinct from the PCIe MSI-X
specification. For a complete description see the `Scalable IOV technical
specification`_.

There is also ongoing work upstream to refactor the MSI-X implementation to
allow for a `dynamic allocation scheme`_.

.. _dynamic allocation scheme:
   https://lore.kernel.org/all/87o85v3znb.ffs@tglx/

.. _Scalable IOV technical specification:
   https://www.opencompute.org/documents/ocp-scalable-io-virtualization-technical-specification-revision-1-v1-2-pdf

Goals
-----

* prevent resource hogging by delaying allocation of interrupts until point
  of use, rather than driver initialization

* Support a large number of interrupts, possibly greater than the number of
  MSI-X interrupts supported by the device.

Design
------

The Interrupt Message Storage (IMS) is a new device-specific interrupt
mechanism. It is similar to existing interrupt technology like MSI and
MSI-X, but uses a device specific storage mechanism which can scale better
than the PCIe MSI-X standard.

The IMS feature requires both device and software support. The device
exposes support through one of the bits in the Scalable IOV Designated
Vendor Specific Extended Capability (DVSEC).

The kernel does not yet support IMS, so a complete design for how this
integrates with the driver is not yet available.

Open questions
--------------

* it is unclear when the IMS feature support will land in the Linux kernel.
  There is a team in SATG working on this, but it has not yet been published
  to the community.

* Thomas Gleixner has been working on refactoring the Linux kernel MSI
  implementation to support dynamic allocation. This has gone through
  multiple series and revision. The complete work is not yet merged, and it
  is not clear what kernel release it will land in.
