devlink integration
===================

Scalable IOV will need to integrate with devlink to add and remove the port
instances.

Devlink has a notion of "subfunctions" which refer to lightweight portions
of a PCI function on which it is deployed. These are created and deployed in
units of 1, and don't have a proper PCI virtual function associated with
them.

Internally, we often refer to subfunctions solely with the intent of using
them with containers and netdevs in the host. This design proposes also
using the subfunction interface of devlink to support Scalable IOV.

To do this, a new port type will be introduced which allows creating a
Scalable instance instead of a host netdev. The Scalable instance will use
VDCM to talk to the VFIO framework and generate a device object suitable for
QEMU/KVM which gets exposed to the VM as an iAVF device.

.. note::
   Some existing documentation may use the subfunction term to exclusively
   refer to the host netdev based implementation.

Goals
-----

#. Manage creation of Scalable instances via devlink port creation
#. Integrate with new VFIO framework and VDCM using auxiliary devices

Design
------

Use the devlink port interface to create new devlink ports with the
``DEVLINK_PORT_FLAVOUR_PCI_SF`` and a new proposed type
``DEVLINK_PORT_TYPE_VF``. These would be VF subfunctions.

There is an existing proposal using the same devlink port interface to
create netdev subfunctions. This design specifically covers use for Scalable
IOV. It is intended to be compatible with the netdev subfunction proposal
through the use of a distinct port type. A complete discussion of the netdev
subfunctions and their design is beyond the scope of this document.

Devlink ports are managed using three steps:

* Create
* Setup and configure
* Deploy

Creation
^^^^^^^^

Userspace requests a new port via the ``DEVLINK_CMD_PORT_NEW`` netlink
command, with the ``DEVLINK_ATTR_PORT_FLAVOUR`` set to
``DEVLINK_PORT_FLAVOUR_PCI_SF``. The core devlink code processes this
command and then calls the driver's ``.port_new`` devlink operation.

The ice driver must implement this operation. It should create the new port
along with associated internal tracking structures in the driver.

.. note::
   By default new subfunction ports will be in the netdev mode, unless the
   user specifically requested a ``DEVLINK_PORT_TYPE_VF`` at creation.

Devlink ports are specified by their ``DEV/PORT_INDEX`` name, which is a
unique identifier combining the devlink device name and a unique port index,
for example ``pci/0000:af:00.0/3`` refers to port 3 on PCI device
``0000:af:00.0``.

The port index is unique for a given devlink instance, and static for the
lifetime of the port.

Subfunctions also have a subfunction number, which is distinct from the port
index. For our implementation, userspace will not be allowed to request the
subfunction number. We suggest using the VSI number here, assuming that
updating the subfunction number is safe. Otherwise, a unique identifier
should be determined by the driver. We do not support userspace requesting
specific subfunction numbers.

.. note::
   Need to review the netdev subfunction proposal and make sure the choice
   of subfunction number can be consistent with both types.

Setup
^^^^^

Userspace then can configure the port. The first step is to assign the port
type. We will try to propose a new ``DEVLINK_PORT_TYPE_VF`` to distinguish
from the ``DEVINK_PORT_TYPE_ETH``. The ethernet port type will be used for
the host netdev based setup. The VF port type will be used to create a
virtual device through VFIO.

The devlink core code processes this request and then calls the
``.port_type_set`` devlink operation on the devlink port.

The ice driver will handle this callback and for ``DEVLINK_PORT_TYPE_VF`` it
will then set up the ADI and other Scalable-specific tracking pieces.

.. note::
   We plan to re-use as much port tracking structures and logic as possible,
   but each type may have some unique requirements.
   other designs.

.. note::
   The devlink port documentation assumes operating in the switchdev mode
   for the e-Switch. This means that port representors will be created. The
   initial netdev subfunction proposal plans to only support legacy e-Switch
   mode. This design covers both legacy and switchdev mode, but the initial
   proposal will support legacy first, with switchdev support as a
   follow-on.

At this point the ADI should exist, and able to be configured in the host.
It will not yet be deployed with VFIO. This is the point where configuration
can be set before the Scalable instance is enabled.

Configuration may come from a variety of mechanisms, including devlink,
netdev operations when in switchdev mode, etc.

* devlink parameters?
* rate limiting? (devlink seems to have good infrastructure here)
* MAC Address, VLAN, etc? (e-switch port representor mode only?)
* maximum number of queues or interrupts? (can we use port representor?)

The initial implementation will not include parameters to control port
settings. A followup series after the initial implemenation is merged will
be made which will include devlink resources to control the following types
of parameters:

* maximum number of queues

* maximum number of interrupts

* parameter to control VF trust state

* maximum of MAC address and VLAN filters

* other parameters (?)

Deploy
^^^^^^

Once userspace is ready to activate the port, it issues a
``DEVLINK_CMD_PORT_SET`` with the ``DEVLINK_ATTR_PORT_FUNCTION`` attribute
containing a sub attribute with the ``DEVLINK_PORT_FN_ATTR_STATE`` set to
the active state.

The core devlink code processes this command and then calls the
``.port_fn_state_set`` devlink operation.

The ice driver implements this operation and then on receipt will call into
ice_vdcm.c to request setup with the VFIO framework.

To support this, the VDCM framework needs to be adjusted to be an auxiliary
driver. The ice driver would then simply create an auxiliary device tied to
the VDCM auxiliary driver name.

This will require defining the interface between the auxiliary device and
driver instances. This should re-use as much of the existing VDCM interface
as possible.

Once deployed, the Scalable VF will be available to use through VFIO
framework along with KVM/QEMU.

Scalable vs netdev
^^^^^^^^^^^^^^^^^^

The steps for create, setup and deploy will be similar for both netdev host
subfunctions and Scalable subfunctions. The key difference is in which port
type is assigned during the setup phase.

Scalable ports will be assigned the new ``DEVLINK_PORT_TYPE_VF``, while
netdev subfunctions will be assigned the ``DEVLINK_PORT_TYPE_ETH``.

Assigning the port type is the decision point to choose between the
functionality. Changing the port type requires that the port be inactive,
(and thus the auxiliary device removed). When changed, any existing VSI and
related tracking structures will first be removed. Then the new VSI type and
tracking structures added.

MAC address
^^^^^^^^^^^

Devlink supports assigning a ``hw_addr`` value to a port. This is expected
to be the MAC address for Ethernet functions. We should be able to re-use
this for assigning the host-based MAC address.

Rate limiting
^^^^^^^^^^^^^

netdevices have some support for Tx rate limiting through
``.ndo_set_tx_maxrate``. However, devlink ports appear to have a rich rate
limiting interface that we need to investigate. If possible, we should
enable rate limiting control through devlink since it supports both Tx and
Rx, as well as groupings of ports.

"trusted" VF
^^^^^^^^^^^^

The ice driver currently uses the ``.ndo_set_vf_trust`` interface for
configuring VFs into the "trusted" mode. This mode of operation enables some
features which are disabled by default. To support this, a new devlink port
parameter for the feature will be proposed to allow configuring the mode.
This parameter should be added to the generic list, as the kernel community
prefers these over driver-specific settings.

Example commands
----------------

There are multiple phases for creating and configuring a devlink port. This
section shows the proposed userspace commands used to perform these steps.

::

  ┌───────────┐
  │   Create  │
  └───────────┘
    │
    │
    ▼
  ┌───────────┐
  │   Setup   │
  └───────────┘
    │
    │
    ▼
  ┌───────────┐
  │  Deploy   │
  └───────────┘

..
  The block diagram was generated using graph-easy.

  $ cat <<-EOF | graph-easy --as boxart
  digraph {
    Create -> Setup
    Setup -> Deploy
  }
  EOF

.. code-block:: shell

   #
   # Create
   #

   # Create a new subfunction port, let driver decide the ID, of type VF
   $ devlink port add pci/0000:af:00.0 flavour pcisf type vf

   # Create a new subfunction port using the specified index
   $ devlink port add pci/0000:af:00.0/3 flavour pcisf

   #
   # Setup
   #

   # Set port type (if you didn't specify it during creation) where 3 is the
   # port index that was created in the previous step, not the subfunction #
   number.
   $ devlink port set pci/0000:af:00.0/3 type vf

   # perform other setup, for example in switchdev e-Switch mode, you might
   # configure the port representor netdev, etc.

   # Show the port info. If the e-Switch is in switchdev mode, this includes
   # port representor netdev.
   $ devlink port show pci/0000:af:00.0/3
   pci/0000:af:00.0/3: type vf netdev enp175s0f0pf0sf5 flavour pcisf sfnum 5

   # set proposed "trusted_vf" parameter
   $ devlink dev param set pci/0000:af:00.0/3 name trusted_vf value 1 cmode runtime

   # assign a HW (MAC) address
   $ devlink port function set pci/0000:af:00.0/3 hw_addr 00:11:22:33:44:55

   #
   # Deploy
   #

   # activate the port, triggering creation of auxiliary device
   $ devlink port function set pci/0000:af:00.0/3 state active

Open questions
--------------

* This relies on the new VFIO framework, as the existing implementation
  assumes that MDEV will manage the device life cycle.

* Creation of subfunction ports may overlap with proposed implementations
  for host netdev subfunctions. We need to ensure these designs are
  compatible so as to prevent challenges when integrating both features in
  future driver releases.

* devlink has rich support for rate limiting both with Tx and Rx. However,
  implementing this is a larger task, and needs its own investigation and
  design. Likely need to ask for a DCR to support this.

* Should we leave the port type initialized to ``DEVLINK_PORT_TYPE_NOTSET``,
  avoiding initial allocations until set? This is simpler but requires users
  to always perform an extra step during setup of assigning the port type.
  We suspect that initial versions of subfunction support would simply
  default to ``DEVLINK_PORT_TYPE_ETH``.

* Need to build a plan for initial phases of development and how to break
  down the implementation into parts for prototyping.

* Subfunction numbering. This design proposes using the VSI number and not
  letting userspace request a specific value. This may conflict with the
  netdev subfunctions being proposed soon. Need to follow up with that. We
  also need to confirm if the subfunction number changing is a problem.
