VDCM as an auxiliary driver
===========================

The Virtual Device Composition Module (VDCM) is a component of the Scalable
IOV specification. It is responsible for composing a virtual device which
mimics the iAVF interface used inside a virtual machine. The VDCM
implementation for the ``ice`` driver uses the Linux kernels Virtual Function
I/O (VFIO) subsystem.

The module currently uses an operations struct, ``struct ice_adi`` to
communicate with the rest of the ice driver. Based on documentation and
expected upstream feedback, this design proposes refactoring the VDCM to use
`auxiliary bus`_ as the mechanism for communication with the ice driver.

.. _auxiliary bus:
   https://docs.kernel.org/driver-api/auxiliary_bus.html?highlight=auxiliary%20bus

Goals
-----

#. Use the expected kernel interfaces as documented by devlink
#. Make the VDCM code re-usable with future drivers
#. Change flow of Scalable instance creation

Design
------

The existing VDCM code is already modular. An operations structure is used
to separate the concerns of the normal ice driver from the VDCM code. The
use of the auxiliary bus further separates this by fully separating the VDCM
from the ice driver.

The VDCM must register itself as an auxiliary driver using the
``auxiliary_driver_register`` interface. Then, it awaits for new auxiliary
devices to be loaded on the auxiliary bus. This occurs during the module
load, rather than as a call to ``ice_vdcm_init`` during ice device probe.

To register with the VDCM, the ice driver will create an auxiliary device.
This is done by creating the ``struct auxiliary_device`` wrapped in the
appropriate container structure, ``struct ice_adi``, defined by the VDCM.
The ice driver will call ``auxiliary_device_init`` and then
``auxiliary_device_add``. The auxiliary kernel module will then connect the
devices to the bus and call the VDCM ``.probe`` callback to start the
device.

When the ice driver is ready to remove the device, it will call
``auxiliary_device_delete`` and then ``auxiliary_device_uninit``. This will
remove the device from VDCM by calling its ``.remove`` handler.

The existing ``struct ice_adi`` structure and operations table can be reused
as it already provides a strong separation between VDCM and ice.

The major change to this setup, is the overall flow between VDCM and the ice
Scalable IOV code. The existing implementation is mainly driven *from* MDEV
into VDCM and then into ice_siov.c

The new proposed flow requires ice to register the devices. This will occur
during devlink port activation. This is a flow change due to the expected
change in behavior with the change to a new VFIO framework, instead of using
MDEV.

In this new flow, the ``struct ice_adi`` will be allocated and managed by
the ice driver, and then passed into the VDCM as part of
``auxiliary_device_add``. This is in contract to the existing flow where
the VDCM decides when to add anew ``struct ice_adi``.

UUID
^^^^

The existing MDEV implementation uses a UUID to identify the mediated device
it created. It is unclear if we still need this with a new VFIO framework.
If a UUID is needed, this design proposes the following:

* automatically generate a UUID by driver at port creation

* allow reassigning to specific address during port setup via devlink parameter

Open Questions
--------------

* We expect the new VFIO framework to require the ice driver to manage
  creation of the subdevices as part of devlink. This is probable, but we
  don't have guarantee at this stage.

* If the VFIO framework is not ready, these changes may have to be delayed
  or modified. The existing design expects MDEV to create the device. It is
  not trivial to refactor the creation process while still using MDEV.o

* Setting ``IOMMU_DEV_FEAT_AUX`` likely needs to move into ice_probe
  somewhere and out of ice_vdcm.c
