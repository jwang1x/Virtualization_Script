switchdev integration
=====================

Single Root IOV has existing support for exposing the embedded hardware
switch (eSwitch) through switchdev and host netdev port representors. These
features should be supported with Scalable IOV as well.

Use of the switchdev support can provide some configuration for Scalable IOV
that is otherwise not available, such as port VLANs.

Goals
-----

#. Allow configuration of VF features from the host

   #. Changing or assigning VLANs for the VF

   #. Program traffic filters on the host through iproute2's ``tc`` command,
      connecting to the embedded switch via switchdev interface.

#. Support rate limiting through .ndo_set_tx_maxrate

#. Maintain feature parity with Single Root IOV where feasible.

Design
------

The existing eSwitch and port representor code is not compatible with the
Scalable IOV design. This code assumes all VFs will be added at once.

To fix this, we need to re-design the code to handle individual VF addition
and removal.

The current method of assigning control VSI queues to VF port representors
assumes that every queue ID has a matching VF ID. With Scalable IOV, this is
not true, since the VF IDs are non-contiguous. In particular, the slow path
eSwitch control VSI uses one queue pair per VF and assigns the queue pair
based on VF ID.

We need to allow adding and removing VFs to update this VSI appropriately.
This will require a new method of mapping and tracking the port representor
to control VSI queues. This must allow for dynamic addition and removal of
VFs, without prior knowledge of the total number of VFs.

When in switchdev mode, we will create port representor netdevs which will
allow configuring some aspects of the VF functionality from the PF. This
includes VLANs, Tx rate limiting, link, etc. Some of these features are
available for Single Root IOV through the ``.ndo_set_vf_*`` callbacks.
However, these do not work for Scalable IOV due to not being reported as
part of the PCI config space.

Open questions
--------------

* Rate limiting on the netdev doesn't appear to support Rx limiting.
  devlink has its own rate limiting support which appears to have more
  features. We should investigate this approach. It is a large change and
  might require its own design and DCR.

* devlink port creation also allows assigning the hardware address, which
  for Ethernet ports is equivalent to the MAC address. We should use this
  interface, while also allowing the port repesentor to display the address.

* Currently, it is not possible to change the eSwitch mode from legacy to
  switchdev while there are active VFs.
