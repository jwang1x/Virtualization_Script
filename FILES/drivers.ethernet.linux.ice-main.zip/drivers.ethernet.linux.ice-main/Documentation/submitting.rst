Submitting Code
===============

All development for the ice driver occurs on `github`_ using pull requests
and code review.

.. _github:
   https://github.com/intel-sandbox/drivers.ethernet.linux.ice/

Developers are expected to fork the repository and publish code there before
making a pull request. Code review is required and takes place through the
Github Pull Request workflow.

We require all requests to undergo code review and to pass the automated
checks before merging.

For developers experienced with the command line, it is recommended to use
Intel's `devtool`_ or the official `Github CLI`_ to work with Github's API
from the terminal.

.. _devtool:
   https://github.com/intel-innersource/applications.productivity.devtool

.. _Github CLI:
   https://cli.github.com/

Instructions for installing devtool, ``dt``, can be found on the `1Source`_
page, as well as on the project's Github page.

.. _1Source:
   https://1source.intel.com/docs/getting_started/on_board#user-environment-configuration-automatic-devtool

Although you can install ``gh`` directly, it is recommended to install and
use it as part of ``dt``.

.. code-block:: shell

   $ dt extensions enable gh

The ``dt`` program does have some Github API support built-in, but the
extension enables using any available ``gh`` command by wrapping it with
``dt``.

This document will provide both a description of the web UIs available as
well as examples for both ``dt`` and ``gh``.

Note that this document assumes you are using ``gh`` through the ``dt``
wrapper and will prefix all commands with ``dt``. If you have setup ``gh``
manually, then this is unnecessary and you can simply remove the ``dt``
prefix.

Forking
-------

To avoid cluttering the main repository with many private branches, each
developer is expected to submit code through their own fork. Creating a fork
can be done from the `github`_ page by clicking the button labeled ``fork``
in the top right of the page.

.. _github:
    https://github.com/intel-sandbox/drivers.ethernet.linux.ice/

This will create a forked copy of the project under your Github account
namespace. For example, my fork is located `here`_.

.. _here:
   https://github.com/jacob-keller/drivers.ethernet.linux.ice

``jacob-keller`` is my github account name. Your fork will use your own
github account name. **Note that this is probably not your Intel idsid**

Once you've created the fork, you will need to add a new remote for it into
your repository to allow interacting with both the primary repository and
your fork.

You can add a new remote for your fork using git:

.. code-block:: shell

   # Add a new remote named 'fork' pointing at the fork you want to add
   $ git remote add fork https://github.com/jacob-keller/drivers.ethernet.linux.ice

If you have a clone of the repository already, you can create a fork and
automatically add it as a remote using ``gh`` or ``dt``:

.. code-block:: shell

   $ dt gh repo fork

You may also create a fork and clone a repository you don't yet have cloned.

.. code-block:: shell

   $ dt gh repo fork https://github.com/intel-sandbox/drivers.ethernet.linux.ice/ --clone

Note that by default ``gh`` renames your ``origin`` remote to ``upstream``
and sets ``origin`` to point to the fork. If you find this confusing, you
may use the ``--remote-name`` command line option to set the remote name you
desire for your fork instead.

Creating a pull request
-----------------------

Once you have work ready to merge and have created a fork of the repository,
you will need to create a pull request. It is recommended that you always do
new development on a local branch which is based on the tip of the
development branch you are targeting. For example, new development will be
based on ``main``, while development for bug fixes on previous releases will
use the appropriate release branch, i.e. ``cvl_sw3.1_branch``.

``devtool`` provides a simple command to aid in the creation of a new pull
request branch. Assuming your remote ``upstream`` points to the main
repository:

.. code-block:: shell

   $ git fetch upstream
   $ dt pr init my-branch upstream/main

*Note there is no equivalent gh command*

Once you have a branch, and you are ready to submit the work. You must
create a pull request.

You'll first need to push the changes to a branch on your fork. Assuming
that ``fork`` is the name you gave your fork remote you can use a standard
git push command.

.. code-block:: shell

   $ git push fork my-branch

This pushes the contents of my-branch to the remote named fork.

**Note for those with write access to the main repository, its important to
make sure you use the remote for your fork. Otherwise you may
unintentionally create a branch on the main repository instead.**

Once you have work pushed to your fork you can make a pull request from the
`web UI`_ of the main repository by clicking the ``New Pull Request``
button.

.. _web UI:
   https://github.com/intel-sandbox/drivers.ethernet.linux.ice/pulls

For convenience, recently pushed branches may also show up with a message
asking if you want to make a pull request in both the main repository and
your fork.

The web UI will let you select the source and target branches for your
request, and then request that you provide a title and a description. For
small "single commit" pull requests, re-using the commit message is
acceptable. For larger series of commits, a sort of 'cover letter' with an
explanation of the entire request is recommended.

You can also push a branch and create a pull request all at once using
either ``dt`` or ``gh``.

.. code-block:: shell

   $ dt gh pr create

The ``gh`` command will interactively ask you which repository to push to,
allow you to set the pull request title, and open your editor to set the
pull request message.

*Note that gh by default selects the main branch as the target for the pull
request, regardless of what your local tracking for the branch is. To select
a different target branch, use the -B option*

``dt`` also has its own create command which has slightly different
semantics.

.. code-block:: shell

   $ dt pr create

The ``dt`` command will:

* Fork the repository to your account (unless --no-fork is supplied)
* Push the local branch to the remote repo (normally the fork)
* Set the local branch to track the newly pushed remote branch
* Initiate a new pull request using GitHub's REST API
* Print the URL for the newly created pull request

Note that it does not allow using an editor to set the pull request title or
message, however there are command line options to set these.

Choosing a different branch
^^^^^^^^^^^^^^^^^^^^^^^^^^^

By default, the gh command will always use the default branch when creating
a pull request. For most repositories, this will be the "main" branch.

If you want to make a pull request to another branch you must specify it
using the ``--base`` or ``-B`` option of the ``gh`` command

.. code-block:: shell

   $ dt gh pr create -B GPL

The ``dt`` utility's builtin PR creation command makes an attempt to select
the target branch using the remote tracking information of the currently
checked out local branch. If this is unset, or set to a branch that is not
in the target repository, it will fall back to using the default branch of
the target repository.

It is good practice to double check the target when making a pull request
which you intend to be for any branch other than the main branch.

Pull Request Review
-------------------

Once a pull request has been made, it needs to undergo review. In addition,
automated continuous integration checks will start and they must pass before
a request to merge will be accepted.o

The ice driver requires at least one person with write permission approves
the review. You can view all active `pull requests`_ and review them on the
web.

.. _pull requests:
   https://github.com/intel-sandbox/drivers.ethernet.linux.ice/pulls

When reviewing pull requests, review of both the content as well as the
commit messages is appreciated. Because we eventually upstream changes to
the Linux kernel, isolated commits with detailed messages are important.

You can also view and interact with pull requests from the command line
using ``gh``.

.. code-block:: shell

   # List all active PRs for a given repository
   $ dt gh pr list

   # Locate the PR for the currently checked out branch
   $ dt gh pr view

   # Checkout PR 37 locally
   $ dt gh pr checkout 37
   OR
   $ dt pr download 37

   # View the CI status for a PR
   $ dt gh pr checks

The ice driver requires that all pull requests be approved by another
developer. GitHub only counts reviews from developers who have write access
to the repository. Currently write access is granted for developers with the
"EPG SW Linux Write" permission on `AGS`_.

.. _AGS:
   https://ags.intel.com/

Making changes during review
----------------------------

When a pull request undergoes review, it is likely that changes will be
needed. To do this, you must update the branch used by the PR on your fork.

Because we ultimately depend on converting out-of-tree changes into upstream
commits, it is recommended and allowed to re-write history using ``git
rebase`` or ``git commit --amend``.

You may edit your branch locally and then update the fork with a force push.

.. code-block:: shell

   $ git push --force-with-lease fork my-branch

Note that other teams may have different policy about forced updates. It is
best to check with each team how they manage their repository.

Merging a pull request
----------------------

Once a pull request is ready, it will need to be merged into the main
branch. The ice driver uses **merge commits**. This is a change from
historically enforcing pure linear history.

Merge commits for PRs have a few advantages

* The merge commit has two parents which shows the commit object being
  merged into the main branch as well as the commit object where the PR was
  based.
* Merge commits allow including a summary message similar to a "cover
  letter".
* Enforcing that all changes have a merge commit allows using tools like
  ``git log --first-parent`` to view just "what PRs have been merged".
* In the event that pull requests are merged onto an older base commit, such
  as if another merge was made before that request was last rebased, git log
  will default to displaying commits in chronological order based on commit
  timestamps. To avoid intermingling commits from multiple pull requests,
  you can use ``--topo-order``.
* Use of merge commits improves the reliability of ``git bisect`` since we
  only test the tip of each pull request with our CI. It will first locate
  which merge introduced the bug before attempting to bisect the commits
  brought into that merge.

When merging a pull request it is recommended to include a short summary of
the changes in the request. **Note that the web UI does not automatically
insert line breaks so please avoid long lines and insert breaks manually
after ~70 characters**

You can also merge pull requests from the command line using ``gh``.

.. code-block:: shell

   $ dt gh pr merge 25
