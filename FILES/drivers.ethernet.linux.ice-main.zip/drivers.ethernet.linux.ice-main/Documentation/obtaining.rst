Obtaining Code
==============

The ice driver source code is maintained on `Intel's Github Organization`_
as a core repository along with a few dependent repositories.

.. _Intel's Github Organization:
   https://github.com/intel-innersource

* https://github.com/intel-sandbox/drivers.ethernet.linux.ice

  * The ice Linux core driver code

* https://github.com/intel-sandbox/drivers.ethernet.shared.ice

  * The ice shared code

* https://github.com/intel-sandbox/drivers.ethernet.linux.auxiliary

  * Auxiliary Bus module to support older kernels

* https://github.com/intel-sandbox/drivers.ethernet.linux.idc

  * Inter-driver Communication framework

* https://github.com/intel-sandbox/drivers.ethernet.linux.common

  * Common Linux build scripts

* https://github.com/intel-sandbox/drivers.ethernet.linux.compat

  * The kernel compatibility framework

* https://github.com/intel-sandbox/drivers.ethernet.linux.hooks

  * Scripts primarily targeting Continuous Integration

The ice driver is also published as part of the `upstream kernel`_ under the
"drivers/net/ethernet/intel/ice" subfolder, and a released version of the
source is available on `Sourceforge`_.

.. _upstream kernel:
   https://www.kernel.org/

.. _Sourceforge:
   https://sourceforge.net/projects/e1000/files/ice%20stable/

Access
------

Read access to the core driver repository and its submodules is available
for any user which has access to Intel's organization. This includes both
the ability to clone as well as to submit pull requests.

Contractors can obtain read rights through the ``EPG SW Linux CVL CPK CNV
Read CW`` entitlement on `AGS`_.

In order to merge changes, or for your review approval to count, you must
have the ``EPG SW Linux CVL CPK CNV Write`` entitlement on `AGS`_. Likewise,
contractors must have the ``EPG SW Linux CVL CPK CNV Write CW`` entitlement.

Administrators of the repository must have the ``EPG SW Linux CVL CPK CNV
Admin`` entitlement.

.. _AGS:
   https://ags.intel.com

Migrating an old clone
----------------------

Historically the repository code was available on a Gerrit server. If you
have a local clone with a remote pointing to the old repository URL, the
following steps may aid you in updating to the new source of truth.

.. code-block:: shell

   # Update remote URL <assumes origin as remote name>
   $ git remote set-url origin https://github.com/intel-sandbox/drivers.ethernet.linux.ice

   # Fetch the new remote
   $ git fetch origin

   # Switch to master branch
   $ git switch master

   # Rename the master branch
   $ git branch -m master main

   # Update the tracking information
   $ git branch --set-upstream-to=origin/main

   # Update the branch to latest version
   $ git pull --rebase

   # Update outer submodule URLs to the new remotes
   $ git submodule sync

   # Update outer submodules contents
   $ git submodule update

   # Update inner submodule URLs to new remotes
   $ git submodule sync --recursive

   # Update inner submodule contents
   $ git submodule update --recursive
